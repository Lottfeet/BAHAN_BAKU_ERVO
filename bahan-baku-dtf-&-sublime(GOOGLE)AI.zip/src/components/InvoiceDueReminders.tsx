import React, { useState } from 'react';
import { 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  CreditCard, 
  Phone, 
  MessageSquare, 
  Copy, 
  Check, 
  ArrowUpRight, 
  Search, 
  Filter, 
  ExternalLink, 
  DollarSign, 
  AlertCircle,
  X,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Invoice } from '../types';
import { 
  formatRupiah, 
  formatDueDateIndo,
  getInvoiceDueInfo, 
  generateInvoiceWaReminder, 
  formatWaPhone,
  playPushNotificationSound 
} from '../utils/helpers';

interface InvoiceDueRemindersProps {
  invoices: Invoice[];
  onUpdateInvoiceStatus: (invoiceId: string, status: 'lunas' | 'belum_lunas' | 'dp', paidAmount: number) => void;
  onNavigateToSales?: (statusFilter?: 'all' | 'lunas' | 'belum_lunas' | 'dp', invoiceId?: string) => void;
}

export const InvoiceDueReminders: React.FC<InvoiceDueRemindersProps> = ({
  invoices,
  onUpdateInvoiceStatus,
  onNavigateToSales,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'overdue' | 'today' | 'upcoming' | 'dp' | 'belum_lunas'>('all');
  const [copiedInvoiceId, setCopiedInvoiceId] = useState<string | null>(null);
  const [payingInvoice, setPayingInvoice] = useState<Invoice | null>(null);
  const [paymentOption, setPaymentOption] = useState<'full' | 'partial'>('full');
  const [customPaidAmount, setCustomPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('Transfer Bank');

  // Filter only unpaid or DP invoices
  const unpaidInvoices = invoices.filter(
    (inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp'
  );

  // Compute metrics
  let totalReceivable = 0; // Total sisa tagihan
  let overdueCount = 0;
  let dueTodayCount = 0;
  let upcomingCount = 0;
  let dpCount = 0;
  let belumLunasCount = 0;

  unpaidInvoices.forEach((inv) => {
    const dueInfo = getInvoiceDueInfo(inv);
    totalReceivable += dueInfo.unpaidAmount;
    if (dueInfo.isOverdue) overdueCount++;
    if (dueInfo.isDueToday) dueTodayCount++;
    if (dueInfo.isUpcoming) upcomingCount++;
    if (inv.paymentStatus === 'dp') dpCount++;
    if (inv.paymentStatus === 'belum_lunas') belumLunasCount++;
  });

  // Filter list based on selected filter and search
  const filteredInvoices = unpaidInvoices.filter((inv) => {
    const dueInfo = getInvoiceDueInfo(inv);

    const matchesSearch =
      inv.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inv.customerPhone.includes(searchQuery);

    if (!matchesSearch) return false;

    if (filterType === 'overdue') return dueInfo.isOverdue;
    if (filterType === 'today') return dueInfo.isDueToday;
    if (filterType === 'upcoming') return dueInfo.isUpcoming;
    if (filterType === 'dp') return inv.paymentStatus === 'dp';
    if (filterType === 'belum_lunas') return inv.paymentStatus === 'belum_lunas';
    return true;
  });

  // Sort by urgency: overdue first, then due today, then upcoming, then normal
  const sortedInvoices = [...filteredInvoices].sort((a, b) => {
    const infoA = getInvoiceDueInfo(a);
    const infoB = getInvoiceDueInfo(b);
    return infoA.diffDays - infoB.diffDays;
  });

  const handleCopyReminder = (inv: Invoice) => {
    const text = generateInvoiceWaReminder(inv);
    navigator.clipboard.writeText(text);
    setCopiedInvoiceId(inv.id);
    setTimeout(() => {
      setCopiedInvoiceId(null);
    }, 2500);
  };

  const handleOpenWhatsApp = (inv: Invoice) => {
    const phone = formatWaPhone(inv.customerPhone);
    const text = encodeURIComponent(generateInvoiceWaReminder(inv));
    const url = `https://wa.me/${phone}?text=${text}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleOpenPaymentModal = (inv: Invoice) => {
    setPayingInvoice(inv);
    setPaymentOption('full');
    setCustomPaidAmount(inv.grandTotal - inv.paidAmount);
  };

  const handleConfirmPayment = () => {
    if (!payingInvoice) return;

    const remaining = payingInvoice.grandTotal - payingInvoice.paidAmount;
    let newPaidAmount = payingInvoice.paidAmount;
    let newStatus: 'lunas' | 'belum_lunas' | 'dp' = payingInvoice.paymentStatus;

    if (paymentOption === 'full') {
      newPaidAmount = payingInvoice.grandTotal;
      newStatus = 'lunas';
    } else {
      newPaidAmount = Math.min(payingInvoice.grandTotal, payingInvoice.paidAmount + customPaidAmount);
      newStatus = newPaidAmount >= payingInvoice.grandTotal ? 'lunas' : 'dp';
    }

    onUpdateInvoiceStatus(payingInvoice.id, newStatus, newPaidAmount);

    if (newStatus === 'lunas') {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
        playPushNotificationSound();
      } catch {
        // ignore
      }
    }

    setPayingInvoice(null);
  };

  return (
    <div id="section-invoice-due-reminders" className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 border border-rose-500/30">
              <Clock className="w-4 h-4 animate-pulse" />
            </div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>Pengingat Jatuh Tempo Tagihan Pelanggan</span>
              {overdueCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-mono font-bold">
                  {overdueCount} LEWAT TEMPO
                </span>
              )}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Monitoring otomatis piutang pelanggan untuk invoice status <strong>Belum Lunas</strong> dan <strong>DP (Uang Muka)</strong>.
          </p>
        </div>

        {onNavigateToSales && (
          <button
            id="btn-goto-sales-invoices"
            onClick={() => onNavigateToSales('all')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 shrink-0"
          >
            <span>Semua Faktur Penjualan</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* 4 Summary Receivable Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl">
          <span className="text-[11px] text-slate-400 block">Total Piutang Belum Tertagih</span>
          <span className="text-sm sm:text-lg font-bold text-rose-400 font-mono block mt-1">
            {formatRupiah(totalReceivable)}
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            Dari {unpaidInvoices.length} transaksi invoice
          </span>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl">
          <span className="text-[11px] text-rose-400 font-medium block">🚨 Lewat Jatuh Tempo</span>
          <span className="text-sm sm:text-lg font-bold text-rose-400 font-mono block mt-1">
            {overdueCount} Pelanggan
          </span>
          <span className="text-[10px] text-rose-400/70 mt-0.5 block">
            Perlu tindak lanjut segera
          </span>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl">
          <span className="text-[11px] text-amber-300 font-medium block">⏰ Jatuh Tempo Hari Ini / Dekat</span>
          <span className="text-sm sm:text-lg font-bold text-amber-300 font-mono block mt-1">
            {dueTodayCount + upcomingCount} Invoice
          </span>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            {dueTodayCount} hari ini, {upcomingCount} &le; 3 hari
          </span>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl">
          <span className="text-[11px] text-slate-400 block">Status Pembayaran</span>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-xs font-bold text-amber-400">{dpCount} DP</span>
            <span className="text-slate-600">/</span>
            <span className="text-xs font-bold text-rose-400">{belumLunasCount} Belum Bayar</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-0.5 block">
            Siap kirim tagihan WhatsApp
          </span>
        </div>
      </div>

      {/* Search & Filter Pills */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nama pelanggan, nomor nota, atau HP..."
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 text-xs">
          <button
            onClick={() => setFilterType('all')}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'all'
                ? 'bg-slate-800 text-white border border-slate-700'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Semua ({unpaidInvoices.length})
          </button>
          <button
            onClick={() => setFilterType('overdue')}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
              filterType === 'overdue'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                : 'text-slate-400 hover:text-rose-300'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
            <span>Lewat Tempo ({overdueCount})</span>
          </button>
          <button
            onClick={() => setFilterType('today')}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
              filterType === 'today'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <span>Hari Ini ({dueTodayCount})</span>
          </button>
          <button
            onClick={() => setFilterType('upcoming')}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1 ${
              filterType === 'upcoming'
                ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40'
                : 'text-slate-400 hover:text-yellow-300'
            }`}
          >
            <span>&le; 3 Hari ({upcomingCount})</span>
          </button>
          <button
            onClick={() => setFilterType('dp')}
            className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
              filterType === 'dp'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            DP ({dpCount})
          </button>
        </div>
      </div>

      {/* List of Due Reminders */}
      {sortedInvoices.length === 0 ? (
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-8 text-center space-y-2">
          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
          <h4 className="text-sm font-bold text-white">
            {unpaidInvoices.length === 0 
              ? 'Luar Biasa! Tidak Ada Tagihan yang Tertunggak' 
              : 'Tidak Ada Invoice yang Sesuai Filter'}
          </h4>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            {unpaidInvoices.length === 0
              ? 'Semua pelanggan telah melunasi invoice pembelian bahan baku DTF dan Sublimasi mereka.'
              : 'Cobalah mengganti filter atau kata kunci pencarian Anda.'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedInvoices.map((inv) => {
            const dueInfo = getInvoiceDueInfo(inv);
            const isCopied = copiedInvoiceId === inv.id;

            return (
              <div
                key={inv.id}
                className={`p-3.5 sm:p-4 rounded-xl border transition-all ${
                  dueInfo.isOverdue
                    ? 'bg-slate-950 border-rose-500/40 shadow-sm shadow-rose-950/20'
                    : dueInfo.isDueToday
                    ? 'bg-slate-950 border-amber-500/40'
                    : 'bg-slate-950 border-slate-800'
                }`}
              >
                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3">
                  {/* Left: Customer & Invoice Info */}
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-sm text-white truncate">
                        {inv.customerName}
                      </span>
                      <span className="font-mono text-xs text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                        {inv.invoiceNumber}
                      </span>
                      {/* Payment Status Pill */}
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                          inv.paymentStatus === 'dp'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        }`}
                      >
                        {inv.paymentStatus === 'dp' ? 'UANG MUKA (DP)' : 'BELUM BAYAR'}
                      </span>
                      {/* Due Status Pill */}
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${dueInfo.badgeClass}`}>
                        {dueInfo.statusLabel}
                      </span>
                    </div>

                    {/* Customer phone and due date details */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                      <div className="flex items-center gap-1 font-mono">
                        <Phone className="w-3 h-3 text-slate-500" />
                        <span>{inv.customerPhone}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        <span>Tgl Terbit: {inv.date}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-300">
                        <Clock className="w-3 h-3 text-amber-400" />
                        <span>Jatuh Tempo: <strong>{formatDueDateIndo(inv.dueDate)}</strong></span>
                      </div>
                    </div>

                    {/* Purchased items preview */}
                    <div className="text-[11px] text-slate-400 truncate max-w-xl">
                      <span className="text-slate-500">Item: </span>
                      {inv.items.map((it) => `${it.quantity}x ${it.productName}`).join(', ')}
                    </div>
                  </div>

                  {/* Middle: Financial figures */}
                  <div className="flex items-center gap-4 py-1.5 px-3 bg-slate-900/80 rounded-xl border border-slate-800 text-xs shrink-0 w-full sm:w-auto justify-between sm:justify-start">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Total Nota</span>
                      <span className="font-mono text-slate-300">{formatRupiah(inv.grandTotal)}</span>
                    </div>
                    {inv.paymentStatus === 'dp' && (
                      <div>
                        <span className="text-[10px] text-amber-400 block">DP Masuk</span>
                        <span className="font-mono text-amber-300">{formatRupiah(inv.paidAmount)}</span>
                      </div>
                    )}
                    <div className="border-l border-slate-800 pl-3">
                      <span className="text-[10px] font-bold text-rose-400 block">Sisa Tagihan</span>
                      <span className="font-mono text-sm font-bold text-rose-400">
                        {formatRupiah(dueInfo.unpaidAmount)}
                      </span>
                    </div>
                  </div>

                  {/* Right: Action Buttons */}
                  <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                    {/* Copy text button */}
                    <button
                      onClick={() => handleCopyReminder(inv)}
                      title="Salin template pengingat WA"
                      className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-[10px] text-emerald-400 hidden sm:inline">Disalin</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span className="text-[10px] hidden sm:inline">Salin</span>
                        </>
                      )}
                    </button>

                    {/* WhatsApp Action */}
                    <button
                      onClick={() => handleOpenWhatsApp(inv)}
                      title="Kirim pesan tagihan via WhatsApp"
                      className="px-2.5 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tagih WA</span>
                    </button>

                    {/* Catat Pelunasan Button */}
                    <button
                      onClick={() => handleOpenPaymentModal(inv)}
                      title="Catat penerimaan pembayaran pelunasan"
                      className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm transition-all"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Catat Lunas</span>
                    </button>

                    {/* View invoice in Sales view */}
                    {onNavigateToSales && (
                      <button
                        onClick={() => onNavigateToSales('all', inv.id)}
                        title="Buka detail nota"
                        className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800 rounded-xl transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* QUICK PAYMENT RECORDING MODAL */}
      {payingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-5 shadow-2xl text-slate-100 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <h4 className="font-bold text-sm text-white">Catat Pelunasan Tagihan</h4>
              </div>
              <button
                onClick={() => setPayingInvoice(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Customer & Invoice details */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Pelanggan:</span>
                <span className="font-bold text-white">{payingInvoice.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">No. Invoice:</span>
                <span className="font-mono text-cyan-400">{payingInvoice.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Transaksi:</span>
                <span className="font-mono text-slate-200">{formatRupiah(payingInvoice.grandTotal)}</span>
              </div>
              {payingInvoice.paidAmount > 0 && (
                <div className="flex justify-between">
                  <span className="text-amber-400">Sudah Masuk (DP):</span>
                  <span className="font-mono text-amber-300">{formatRupiah(payingInvoice.paidAmount)}</span>
                </div>
              )}
              <div className="flex justify-between pt-1 border-t border-slate-800">
                <span className="font-bold text-rose-400">Sisa Tagihan:</span>
                <span className="font-mono font-bold text-rose-400 text-sm">
                  {formatRupiah(payingInvoice.grandTotal - payingInvoice.paidAmount)}
                </span>
              </div>
            </div>

            {/* Payment Choice */}
            <div className="space-y-2 text-xs">
              <label className="font-semibold text-slate-300 block">Pilihan Pembayaran:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentOption('full')}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    paymentOption === 'full'
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="font-bold block text-xs">🟢 Lunas Penuh</span>
                  <span className="text-[10px] text-slate-400 font-mono mt-0.5 block">
                    {formatRupiah(payingInvoice.grandTotal - payingInvoice.paidAmount)}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentOption('partial')}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    paymentOption === 'partial'
                      ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="font-bold block text-xs">🟡 Cicilan / Parsial</span>
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Input nominal transfer
                  </span>
                </button>
              </div>

              {paymentOption === 'partial' && (
                <div className="pt-2">
                  <label className="block text-slate-400 text-[11px] mb-1">Nominal yang Dibayarkan Sekarang (Rp):</label>
                  <input
                    type="number"
                    min="1000"
                    step="1000"
                    value={customPaidAmount}
                    onChange={(e) => setCustomPaidAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              )}

              <div className="pt-2">
                <label className="block text-slate-400 text-[11px] mb-1">Metode Pembayaran:</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value="Transfer Bank">🏦 Transfer Bank</option>
                  <option value="QRIS">📱 QRIS Instan</option>
                  <option value="Tunai">💵 Tunai / Kas Toko</option>
                </select>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setPayingInvoice(null)}
                className="px-3 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmPayment}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all shadow-md"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Simpan Pelunasan</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
