import React, { useState, useEffect } from 'react';
import { PackagePlus, X, Send, AlertCircle, Building, DollarSign, Settings2, Truck } from 'lucide-react';
import { Product, User, SupplierItem } from '../types';
import { formatRupiah } from '../utils/helpers';

interface RestockModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  targetProduct?: Product | null;
  currentUser: User;
  suppliers?: SupplierItem[];
  onOpenMasterData?: (tab?: 'category' | 'unit' | 'location' | 'supplier') => void;
  onConfirmRestock: (data: {
    productId: string;
    quantity: number;
    supplierName: string;
    poNumber: string;
    costPrice?: number;
    notes: string;
    operatorUser?: User;
  }) => void;
}

export const RestockModal: React.FC<RestockModalProps> = ({
  isOpen,
  onClose,
  products,
  targetProduct,
  currentUser,
  suppliers = [],
  onOpenMasterData,
  onConfirmRestock,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(
    targetProduct?.id || (products.length > 0 ? products[0].id : '')
  );

  const [quantity, setQuantity] = useState<number>(5);
  const [costPrice, setCostPrice] = useState<number>(targetProduct?.costPrice || (products.length > 0 ? products[0].costPrice : 0));
  const [supplierName, setSupplierName] = useState<string>('');
  const [poNumber, setPoNumber] = useState<string>(
    `PO-IN-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
  );
  const [notes, setNotes] = useState<string>('Penerimaan stok bahan baru dari pengiriman kargo');

  // Synchronize state when modal opens or targetProduct changes
  useEffect(() => {
    if (isOpen) {
      const activeProd = targetProduct || (products.length > 0 ? products[0] : null);
      if (activeProd) {
        setSelectedProductId(activeProd.id);
        setCostPrice(activeProd.costPrice);
      }
      setQuantity(5);
      setSupplierName('');
      setPoNumber(`PO-IN-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`);
      setNotes('Penerimaan stok bahan baru dari pengiriman kargo');
    }
  }, [isOpen, targetProduct, products]);

  const currentProd = products.find((p) => p.id === selectedProductId) || targetProduct || products[0];

  // Update costPrice when product selection changes
  const handleProductChange = (prodId: string) => {
    setSelectedProductId(prodId);
    const p = products.find((pr) => pr.id === prodId);
    if (p) {
      setCostPrice(p.costPrice);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentProd || quantity <= 0) return;

    onConfirmRestock({
      productId: currentProd.id,
      quantity: Number(quantity),
      supplierName: supplierName.trim(),
      poNumber: poNumber.trim(),
      costPrice: currentUser.canViewFinancials ? Number(costPrice) : currentProd.costPrice,
      notes: notes.trim(),
      operatorUser: currentUser,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-4 sm:p-6 shadow-2xl text-slate-100 my-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <PackagePlus className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-sm sm:text-base text-white">Tambah Stok Masuk (Restock)</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
          {/* Target Product Summary Card */}
          {currentProd && (
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-between gap-3 shadow-2xs">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/25 text-amber-300 border border-amber-500/40">
                    {currentProd.code}
                  </span>
                  <span className="font-bold text-white text-xs truncate">
                    {currentProd.name}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400 flex-wrap">
                  <span>Stok saat ini: <strong className="text-white font-mono">{currentProd.currentStock} {currentProd.unit}</strong></span>
                  <span>•</span>
                  <span>Min: <span className="font-mono text-slate-300">{currentProd.minStockAlert}</span></span>
                  <span>•</span>
                  <span className="text-slate-400">{currentProd.location}</span>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="text-[10px] text-slate-400 block">Setelah Restok:</span>
                <span className="font-mono font-bold text-xs sm:text-sm text-emerald-400">
                  {currentProd.currentStock + Number(quantity || 0)} {currentProd.unit.split(' ')[0]}
                </span>
              </div>
            </div>
          )}

          <div>
            <label className="block font-medium text-slate-300 mb-1">Pilih / Ganti Bahan Baku</label>
            <select
              value={selectedProductId}
              onChange={(e) => handleProductChange(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 font-semibold"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  [{p.code}] {p.name} (Stok sekarang: {p.currentStock} {p.unit})
                </option>
              ))}
            </select>
          </div>

          <div className={currentUser.canViewFinancials ? 'grid grid-cols-2 gap-3' : ''}>
            <div>
              <label className="block font-medium text-slate-300 mb-1">
                Jumlah Masuk ({currentProd?.unit.split(' ')[0]})
              </label>
              <input
                type="number"
                min="1"
                required
                value={quantity}
                onChange={(e) => setQuantity(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-emerald-400 font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>

            {currentUser.canViewFinancials && (
              <div>
                <label className="block font-medium text-slate-300 mb-1">
                  Harga Beli Satuan (HPP)
                </label>
                <input
                  type="number"
                  min="0"
                  value={costPrice}
                  onChange={(e) => setCostPrice(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-indigo-300 font-mono font-bold focus:outline-none focus:border-indigo-500"
                />
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block font-medium text-slate-300">Nama Supplier / Vendor</label>
              {onOpenMasterData && (
                <button
                  type="button"
                  onClick={() => onOpenMasterData('supplier')}
                  className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium transition-colors"
                >
                  <Settings2 className="w-2.5 h-2.5" />
                  <span>+ Kelola Suplier</span>
                </button>
              )}
            </div>
            <div className="relative">
              <input
                type="text"
                list="supplier-restock-list"
                required
                value={supplierName}
                onChange={(e) => setSupplierName(e.target.value)}
                placeholder="Ketik atau pilih nama vendor / supplier..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 font-medium"
              />
              <datalist id="supplier-restock-list">
                {suppliers.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.phone ? `${s.name} (${s.phone})` : s.name}
                  </option>
                ))}
              </datalist>
            </div>

            {/* Quick Supplier Chips */}
            {suppliers.length > 0 && (
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar mt-1.5 py-0.5">
                <span className="text-[10px] text-slate-500 shrink-0 flex items-center gap-0.5">
                  <Truck className="w-2.5 h-2.5" />
                  Pilih:
                </span>
                {suppliers.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSupplierName(s.name)}
                    className={`text-[10px] px-2 py-0.5 rounded border transition-colors shrink-0 ${
                      supplierName === s.name
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                    }`}
                  >
                    {s.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block font-medium text-slate-300 mb-1">No. Surat Jalan / Purchase Order (PO)</label>
            <input
              type="text"
              required
              value={poNumber}
              onChange={(e) => setPoNumber(e.target.value)}
              placeholder="misal: PO-IN-2026-042"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-300 mb-1">Catatan Penerimaan Gudang</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="misal: Barang diterima dalam kondisi segel baik tanpa bocor"
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Active Logged-in Operator Info */}
          <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs">
            <span className="text-slate-400">Petugas Penerima (Akun Login):</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <span>{currentUser.name}</span>
              <span className="text-[10px] text-slate-400 font-normal">({currentUser.roleTitle || currentUser.role})</span>
            </span>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
            >
              Batal
            </button>
            <button
              id="btn-confirm-restock"
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
            >
              <PackagePlus className="w-4 h-4" />
              <span>Konfirmasi Masuk Gudang</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
