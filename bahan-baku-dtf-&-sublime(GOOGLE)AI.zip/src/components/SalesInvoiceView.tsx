import React, { useState, useMemo, useEffect } from 'react';
import { 
  FileText, 
  Plus, 
  Trash2, 
  Printer, 
  Share2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Search, 
  Eye, 
  Download, 
  Building2, 
  Phone, 
  Calendar, 
  X,
  CreditCard,
  MessageSquare,
  Users,
  UserCheck,
  UserPlus,
  Receipt,
  Wallet,
  History,
  FileDown,
  Loader2,
  Edit3,
  AlertTriangle,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Product, Invoice, InvoiceItem, User, CustomerItem, PaymentRecord, CompanyProfile } from '../types';
import { 
  formatRupiah, 
  formatDateIndo, 
  formatDueDateIndo,
  getInvoiceDueInfo, 
  generateInvoiceWaReminder, 
  generatePaymentHistoryWaMessage,
  formatWaPhone 
} from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';
import { PaymentHistoryModal } from './PaymentHistoryModal';
import { CustomerReceivablesView } from './CustomerReceivablesView';
import { DueDateSelector } from './DueDateSelector';

interface SalesInvoiceViewProps {
  products: Product[];
  invoices: Invoice[];
  customers?: CustomerItem[];
  onAddCustomer?: (customer: CustomerItem) => void;
  onOpenMasterDataCustomer?: () => void;
  currentUser: User;
  onCreateInvoice: (newInvoice: Invoice) => void;
  onUpdateInvoiceStatus: (invoiceId: string, status: 'lunas' | 'belum_lunas' | 'dp', paidAmount: number) => void;
  onRecordPayment?: (
    invoiceId: string,
    paymentData: {
      amount: number;
      paymentMethod: string;
      referenceNumber?: string;
      notes?: string;
      date?: string;
      nextDueDate?: string;
      receivedByUser?: User;
    }
  ) => void;
  onDeletePayment?: (invoiceId: string, paymentId: string) => void;
  onEditInvoice?: (
    invoiceId: string,
    updatedData: {
      customerName?: string;
      customerPhone?: string;
      customerAddress?: string;
      date?: string;
      dueDate?: string;
      paymentMethod?: string;
      notes?: string;
      taxPercent?: number;
      items?: InvoiceItem[];
    },
    operatorUser?: User
  ) => { success: boolean; message?: string };
  onDeleteInvoice?: (invoiceId: string, operatorUser?: User) => { success: boolean; message?: string };
  selectedPreProduct?: Product | null;
  companyProfile?: CompanyProfile;
  initialSubTab?: 'create' | 'receivables';
  initialStatusFilter?: 'all' | 'lunas' | 'belum_lunas' | 'dp';
}

interface PrintableInvoicesListDocumentContentProps {
  filteredInvoices: Invoice[];
  companyProfile?: CompanyProfile;
  currentUser: User;
  statusFilter: string;
  customerFilter: string;
  dateFilterLabel: string;
  searchQuery: string;
  filteredTotalGrand: number;
  filteredTotalPaid: number;
  filteredTotalUnpaid: number;
}

const PrintableInvoicesListDocumentContent: React.FC<PrintableInvoicesListDocumentContentProps> = ({
  filteredInvoices,
  companyProfile,
  currentUser,
  statusFilter,
  customerFilter,
  dateFilterLabel,
  searchQuery,
  filteredTotalGrand,
  filteredTotalPaid,
  filteredTotalUnpaid,
}) => {
  return (
    <>
      {/* Official Letterhead Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-900">
        <div className="flex items-start gap-3 sm:gap-4">
          {companyProfile?.logoUrl ? (
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl border border-slate-200 bg-white p-1.5 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
              <img
                src={companyProfile.logoUrl}
                alt={companyProfile.companyName || 'Logo Perusahaan'}
                className="w-full h-full object-contain"
              />
            </div>
          ) : (
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-base sm:text-lg shrink-0">
              {companyProfile?.shortName || companyProfile?.appLogoBadge || 'DTF'}
            </div>
          )}
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
              SISTEM MANAJEMEN PENJUALAN & INVOICE KONSUMEN
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {companyProfile?.companyName || 'GUDANG SUPLAI SABLON DTF & SUBLIME'}
            </h1>
            <p className="text-xs text-slate-600 mt-0.5">
              {companyProfile?.tagline || 'Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise'}
            </p>
            <p className="text-[11px] text-slate-500">
              {companyProfile?.address || 'Bandung'} • Telp: {companyProfile?.phone || '0812-9988-7766'} • Email: {companyProfile?.email || 'logistik@dtfsublime.id'}
            </p>
          </div>
        </div>
        <div className="text-left sm:text-right shrink-0">
          <span className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-extrabold text-xs tracking-wider uppercase">
            REKAPITULASI DAFTAR FAKTUR PENJUALAN
          </span>
          <p className="font-mono font-bold text-xs text-slate-800 mt-2">
            REF: REKAP-INV-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
          </p>
          <p className="text-[11px] text-slate-600">
            Dicetak: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <p className="text-[11px] text-slate-600">
            Oleh: <strong>{currentUser.name}</strong> ({currentUser.roleTitle || 'Petugas Penjualan'})
          </p>
        </div>
      </div>

      {/* Audit Parameter Box */}
      <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 space-y-3">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-slate-200 pb-3">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Status Pembayaran</span>
            <span className="font-bold text-slate-900 text-xs block mt-0.5">
              {statusFilter === 'all' ? 'Seluruh Status (Semua)' : statusFilter === 'lunas' ? 'Lunas' : statusFilter === 'dp' ? 'Uang Muka (DP)' : 'Belum Lunas (Tempo)'}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Filter Konsumen</span>
            <span className="font-semibold text-slate-800 text-xs block truncate mt-0.5">
              {customerFilter === 'all' ? 'Seluruh Konsumen' : customerFilter}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Periode Waktu</span>
            <span className="font-semibold text-slate-800 text-xs block mt-0.5">
              {dateFilterLabel}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Kata Kunci Cari</span>
            <span className="font-semibold text-slate-800 text-xs block truncate mt-0.5">
              {searchQuery ? `"${searchQuery}"` : 'Semua Data (Tanpa Filter Kata Kunci)'}
            </span>
          </div>
        </div>

        {/* 4 Financial Highlight Blocks */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Jumlah Faktur</span>
            <span className="font-mono font-black text-sm text-slate-900 block mt-0.5">
              {filteredInvoices.length} Dokumen
            </span>
            <span className="text-[10px] text-slate-500">Sesuai filter pencarian</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Nilai Tagihan (Omset)</span>
            <span className="font-mono font-black text-sm text-slate-900 block mt-0.5">
              {formatRupiah(filteredTotalGrand)}
            </span>
            <span className="text-[10px] text-slate-500">Akumulasi penjualan kotor</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Kas Masuk (Terbayar)</span>
            <span className="font-mono font-black text-sm text-emerald-700 block mt-0.5">
              {formatRupiah(filteredTotalPaid)}
            </span>
            <span className="text-[10px] text-slate-500">Pelunasan & cicilan diterima</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Sisa Piutang Berjalan</span>
            <span className="font-mono font-black text-sm text-rose-700 block mt-0.5">
              {formatRupiah(filteredTotalUnpaid)}
            </span>
            <span className="text-[10px] text-slate-500">Tagihan yang belum lunas</span>
          </div>
        </div>
      </div>

      {/* Printable Invoices Table */}
      <div className="overflow-x-auto rounded-lg border border-slate-300">
        <table className="w-full text-left text-[11px] border-collapse">
          <thead className="bg-slate-100 border-b border-slate-300 text-slate-700 font-bold uppercase text-[10px]">
            <tr>
              <th className="py-2 px-2.5 w-8 text-center">No</th>
              <th className="py-2 px-2.5">No. Faktur</th>
              <th className="py-2 px-2.5">Tanggal</th>
              <th className="py-2 px-2.5">Konsumen</th>
              <th className="py-2 px-2.5">Rincian Barang</th>
              <th className="py-2 px-2.5">Metode & Status</th>
              <th className="py-2 px-2.5">Jatuh Tempo</th>
              <th className="py-2 px-2.5 text-right">Total Tagihan</th>
              <th className="py-2 px-2.5 text-right">Terbayar</th>
              <th className="py-2 px-2.5 text-right">Sisa Piutang</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {filteredInvoices.length === 0 ? (
              <tr>
                <td colSpan={10} className="py-8 text-center text-slate-500">
                  Tidak ada faktur yang cocok dengan filter pencarian Anda.
                </td>
              </tr>
            ) : (
              filteredInvoices.map((inv, idx) => {
                const due = getInvoiceDueInfo(inv);
                const isUnpaid = inv.paymentStatus !== 'lunas' && due.unpaidAmount > 0;

                return (
                  <tr key={inv.id} className={due.isOverdue && isUnpaid ? 'bg-rose-50/70' : ''}>
                    <td className="py-1.5 px-2.5 text-center text-slate-400">{idx + 1}</td>
                    <td className="py-1.5 px-2.5 font-mono font-bold text-slate-900">{inv.invoiceNumber}</td>
                    <td className="py-1.5 px-2.5 font-mono text-slate-600">{inv.date}</td>
                    <td className="py-1.5 px-2.5">
                      <span className="font-semibold text-slate-900 block">{inv.customerName}</span>
                      <span className="text-[10px] text-slate-500 font-mono">{inv.customerPhone}</span>
                    </td>
                    <td className="py-1.5 px-2.5 text-slate-700 max-w-[200px] truncate">
                      {inv.items.map((i) => `${i.productName} (${i.quantity} ${i.unit})`).join(', ')}
                    </td>
                    <td className="py-1.5 px-2.5">
                      <span className="font-semibold block text-slate-800">{inv.paymentMethod}</span>
                      <span className={`inline-block text-[9px] font-bold px-1.5 py-0.2 rounded border uppercase ${
                        inv.paymentStatus === 'lunas'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                          : inv.paymentStatus === 'dp'
                          ? 'bg-amber-100 text-amber-800 border-amber-300'
                          : 'bg-rose-100 text-rose-800 border-rose-300'
                      }`}>
                        {inv.paymentStatus === 'lunas' ? 'Lunas' : inv.paymentStatus === 'dp' ? 'DP' : 'Tempo'}
                      </span>
                    </td>
                    <td className="py-1.5 px-2.5 font-mono">
                      {isUnpaid ? (
                        <span className={due.isOverdue ? 'text-rose-700 font-bold' : 'text-slate-700'}>
                          {formatDueDateIndo(inv.dueDate)} {due.isOverdue ? `(Lewat ${Math.abs(due.diffDays)} hr)` : ''}
                        </span>
                      ) : (
                        <span className="text-emerald-700 font-semibold">Lunas</span>
                      )}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-mono font-semibold text-slate-900">
                      {formatRupiah(inv.grandTotal)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-mono text-emerald-700">
                      {formatRupiah(inv.paidAmount)}
                    </td>
                    <td className="py-1.5 px-2.5 text-right font-mono font-bold text-rose-700">
                      {formatRupiah(due.unpaidAmount)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
          <tfoot className="bg-slate-100 border-t-2 border-slate-300 font-bold text-[11px] text-slate-900">
            <tr>
              <td colSpan={7} className="py-2.5 px-3 text-right uppercase text-[10px] text-slate-600">
                TOTAL ({filteredInvoices.length} FAKTUR TERPILIH):
              </td>
              <td className="py-2.5 px-2.5 text-right font-mono text-slate-900">
                {formatRupiah(filteredTotalGrand)}
              </td>
              <td className="py-2.5 px-2.5 text-right font-mono text-emerald-700">
                {formatRupiah(filteredTotalPaid)}
              </td>
              <td className="py-2.5 px-2.5 text-right font-mono text-rose-700">
                {formatRupiah(filteredTotalUnpaid)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Signatures */}
      <div className="grid grid-cols-3 gap-6 pt-6 border-t-2 border-slate-900 text-center text-xs">
        <div className="space-y-12">
          <p className="font-bold text-slate-800">
            {companyProfile?.signerTitle1 || 'Petugas Administrasi / Kasir'}
          </p>
          <div>
            <p className="font-bold underline text-slate-900">{currentUser.name}</p>
            <p className="text-[10px] text-slate-500">{currentUser.roleTitle || 'Staff Logistik & Penjualan'}</p>
          </div>
        </div>

        <div className="space-y-12">
          <p className="font-bold text-slate-800">
            {companyProfile?.signerTitle2 || 'Supervisor Gudang & Keuangan'}
          </p>
          <div>
            <p className="font-bold underline text-slate-900">Agus Setiawan, S.E.</p>
            <p className="text-[10px] text-slate-500">Supervisor Operasional</p>
          </div>
        </div>

        <div className="space-y-12">
          <p className="font-bold text-slate-800">
            {companyProfile?.signerTitle3 || 'Pimpinan / Pemilik Usaha'}
          </p>
          <div>
            <p className="font-bold underline text-slate-900">
              {currentUser.role === 'owner' ? currentUser.name : 'Pimpinan Manajemen'}
            </p>
            <p className="text-[10px] text-slate-500">Pemilik Usaha (Owner)</p>
          </div>
        </div>
      </div>

      {/* Footer Notice */}
      <div className="text-[10px] text-slate-500 text-center pt-3 border-t border-slate-200">
        Laporan rekapitulasi faktur ini digenerate secara otomatis oleh Sistem Gudang Sablon DTF & Sublime Pro sesuai filter yang ditentukan.
      </div>
    </>
  );
};

export const SalesInvoiceView: React.FC<SalesInvoiceViewProps> = ({
  products,
  invoices,
  customers = [],
  onAddCustomer,
  onOpenMasterDataCustomer,
  currentUser,
  companyProfile,
  onCreateInvoice,
  onUpdateInvoiceStatus,
  onRecordPayment,
  onDeletePayment,
  onEditInvoice,
  onDeleteInvoice,
  selectedPreProduct,
  initialSubTab,
  initialStatusFilter,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'create' | 'receivables'>(initialSubTab || 'receivables');

  useEffect(() => {
    if (initialSubTab) {
      setActiveSubTab(initialSubTab);
    }
  }, [initialSubTab]);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'lunas' | 'belum_lunas' | 'dp'>(initialStatusFilter || 'all');
  const [customerFilter, setCustomerFilter] = useState<string>('all');
  const [dateRangeFilter, setDateRangeFilter] = useState<'all' | 'today' | 'this_month' | 'custom'>('all');
  const [startDateFilter, setStartDateFilter] = useState<string>('');
  const [endDateFilter, setEndDateFilter] = useState<string>('');
  const [showInvoicesListRecapModal, setShowInvoicesListRecapModal] = useState<boolean>(false);
  const [isSavingInvoicesListPdf, setIsSavingInvoicesListPdf] = useState<boolean>(false);
  const [invoicesListPdfSuccess, setInvoicesListPdfSuccess] = useState<string | null>(null);

  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [selectedPaymentInvoiceId, setSelectedPaymentInvoiceId] = useState<string | null>(null);
  const [isSavingInvoicePdf, setIsSavingInvoicePdf] = useState<boolean>(false);
  const [invoiceSaveSuccess, setInvoiceSaveSuccess] = useState<string | null>(null);

  const handleSaveInvoicePdf = async (inv: Invoice) => {
    setIsSavingInvoicePdf(true);
    setInvoiceSaveSuccess(null);
    try {
      const cleanNum = inv.invoiceNumber.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Faktur_Penjualan_${cleanNum}_${inv.date}.pdf`;
      const success = await exportElementToPdf('printable-invoice', filename);
      if (success) {
        setInvoiceSaveSuccess(`File PDF Faktur ${inv.invoiceNumber} berhasil disimpan & diunduh!`);
        setTimeout(() => setInvoiceSaveSuccess(null), 4500);
      }
    } finally {
      setIsSavingInvoicePdf(false);
    }
  };

  const handlePrintInvoice = () => {
    printElementDirect('printable-invoice');
  };

  const handlePrintInvoicesList = () => {
    printElementDirect('printable-invoices-list-recap', 'landscape');
  };

  const handleSaveInvoicesListPdf = async () => {
    setIsSavingInvoicesListPdf(true);
    setInvoicesListPdfSuccess(null);
    try {
      const dateStr = new Date().toISOString().split('T')[0];
      const searchTag = searchQuery ? `_${searchQuery.replace(/[^a-zA-Z0-9]/g, '_').slice(0, 15)}` : '';
      const statusTag = statusFilter !== 'all' ? `_${statusFilter}` : '';
      const filename = `Rekap_Daftar_Faktur_Penjualan${searchTag}${statusTag}_${dateStr}.pdf`;
      const success = await exportElementToPdf('printable-invoices-list-recap', filename, {
        orientation: 'landscape',
      });
      if (success) {
        setInvoicesListPdfSuccess('File PDF Rekapitulasi Daftar Faktur Penjualan berhasil diunduh!');
        setTimeout(() => setInvoicesListPdfSuccess(null), 4500);
      }
    } finally {
      setIsSavingInvoicesListPdf(false);
    }
  };

  // Active reactive invoice for Payment Modal & Preview
  const activePaymentInvoice = invoices.find((inv) => inv.id === selectedPaymentInvoiceId) || null;
  const currentPreviewInvoice = previewInvoice 
    ? invoices.find((inv) => inv.id === previewInvoice.id) || previewInvoice 
    : null;

  // New Invoice Form State
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerName, setCustomerName] = useState('Percetakan Sablon Bintang');
  const [customerPhone, setCustomerPhone] = useState('0813-8899-7766');
  const [customerAddress, setCustomerAddress] = useState('Jl. Percetakan Negara No. 12');
  const [paymentStatus, setPaymentStatus] = useState<'lunas' | 'belum_lunas' | 'dp'>('lunas');
  const [dueDate, setDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [paymentMethod, setPaymentMethod] = useState<'Tunai' | 'Transfer Bank' | 'QRIS' | string>('Transfer Bank');
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [notes, setNotes] = useState('Barang diambil langsung di gudang');
  const [discountTotal, setDiscountTotal] = useState<number>(0);

  // Hak Akses Granular
  const canEditSalesInvoice = currentUser.role === 'owner' || Boolean(currentUser.canEditSalesInvoice);
  const canDeleteSalesInvoice = currentUser.role === 'owner' || Boolean(currentUser.canDeleteSalesInvoice);

  // Edit Invoice State
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editCustomerPhone, setEditCustomerPhone] = useState<string>('');
  const [editCustomerAddress, setEditCustomerAddress] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [editDueDate, setEditDueDate] = useState<string>('');
  const [editPaymentMethod, setEditPaymentMethod] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editTaxPercent, setEditTaxPercent] = useState<number>(0);
  const [editItems, setEditItems] = useState<InvoiceItem[]>([]);
  const [editSelectedProductId, setEditSelectedProductId] = useState<string>('');

  // Delete Invoice State
  const [deletingInvoice, setDeletingInvoice] = useState<Invoice | null>(null);
  const [isDeletingInvoice, setIsDeletingInvoice] = useState<boolean>(false);
  const [invoiceToast, setInvoiceToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showInvoiceToast = (type: 'success' | 'error', message: string) => {
    setInvoiceToast({ type, message });
    setTimeout(() => setInvoiceToast(null), 4000);
  };

  const handleOpenEditInvoice = (inv: Invoice) => {
    setEditingInvoice(inv);
    setEditCustomerName(inv.customerName);
    setEditCustomerPhone(inv.customerPhone || '');
    setEditCustomerAddress(inv.customerAddress || '');
    setEditDate(inv.date);
    setEditDueDate(inv.dueDate);
    setEditPaymentMethod(inv.paymentMethod);
    setEditNotes(inv.notes || '');
    setEditTaxPercent(inv.taxPercent || 0);
    setEditItems(inv.items ? JSON.parse(JSON.stringify(inv.items)) : []);
    setEditSelectedProductId('');
  };

  const handleAddEditItem = (productIdToAdd?: string) => {
    // If a specific product ID is explicitly supplied
    if (productIdToAdd) {
      const targetProd = products.find((p) => p.id === productIdToAdd);
      if (!targetProd) return;

      const existingIndex = editItems.findIndex((ei) => ei.productId === targetProd.id);
      if (existingIndex >= 0) {
        handleUpdateEditItemQty(existingIndex, editItems[existingIndex].quantity + 1);
        showInvoiceToast('success', `Jumlah item "${targetProd.name}" dinaikkan (+1).`);
        return;
      }

      const newItem: InvoiceItem = {
        productId: targetProd.id,
        productCode: targetProd.code,
        productName: targetProd.name,
        unit: targetProd.unit,
        quantity: 1,
        unitPrice: targetProd.sellingPrice,
        costPrice: targetProd.costPrice,
        discount: 0,
        subtotal: targetProd.sellingPrice,
      };

      setEditItems((prev) => [...prev, newItem]);
      showInvoiceToast('success', `Item "${targetProd.name}" berhasil ditambahkan ke faktur.`);
      return;
    }

    // Default: Add empty row with blank/unselected product data as requested
    const newEmptyItem: InvoiceItem = {
      productId: '',
      productCode: '-',
      productName: '',
      unit: '',
      quantity: 1,
      unitPrice: 0,
      costPrice: 0,
      discount: 0,
      subtotal: 0,
    };

    setEditItems((prev) => [...prev, newEmptyItem]);
    showInvoiceToast('success', 'Baris item baru kosong ditambahkan. Silakan pilih bahan baku.');
  };

  const handleUpdateEditItemProduct = (index: number, newProductId: string) => {
    if (!newProductId) {
      setEditItems((prev) => {
        const copy = [...prev];
        copy[index] = {
          ...copy[index],
          productId: '',
          productCode: '-',
          productName: '',
          unit: '',
          unitPrice: 0,
          costPrice: 0,
          subtotal: 0,
        };
        return copy;
      });
      return;
    }

    const prod = products.find((p) => p.id === newProductId);
    if (!prod) return;
    setEditItems((prev) => {
      const copy = [...prev];
      const qty = copy[index].quantity > 0 ? copy[index].quantity : 1;
      const disc = copy[index].discount || 0;
      copy[index] = {
        ...copy[index],
        productId: prod.id,
        productCode: prod.code,
        productName: prod.name,
        unit: prod.unit,
        quantity: qty,
        unitPrice: prod.sellingPrice,
        costPrice: prod.costPrice,
        subtotal: Math.max(0, qty * prod.sellingPrice - disc),
      };
      return copy;
    });
  };

  const handleUpdateEditItemQty = (index: number, qty: number) => {
    setEditItems((prev) => {
      const copy = [...prev];
      const validQty = Math.max(1, qty);
      copy[index] = {
        ...copy[index],
        quantity: validQty,
        subtotal: Math.max(0, validQty * copy[index].unitPrice - (copy[index].discount || 0)),
      };
      return copy;
    });
  };

  const handleUpdateEditItemPrice = (index: number, price: number) => {
    setEditItems((prev) => {
      const copy = [...prev];
      const validPrice = Math.max(0, price);
      copy[index] = {
        ...copy[index],
        unitPrice: validPrice,
        subtotal: Math.max(0, copy[index].quantity * validPrice - (copy[index].discount || 0)),
      };
      return copy;
    });
  };

  const handleUpdateEditItemDiscount = (index: number, disc: number) => {
    setEditItems((prev) => {
      const copy = [...prev];
      const validDisc = Math.max(0, disc);
      copy[index] = {
        ...copy[index],
        discount: validDisc,
        subtotal: Math.max(0, copy[index].quantity * copy[index].unitPrice - validDisc),
      };
      return copy;
    });
  };

  const handleRemoveEditItem = (index: number) => {
    if (editItems.length <= 1) {
      showInvoiceToast('error', 'Faktur harus menyisakan setidaknya 1 item.');
      return;
    }
    setEditItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSaveEditInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice || !onEditInvoice) return;

    if (!editCustomerName.trim()) {
      showInvoiceToast('error', 'Nama pelanggan tidak boleh kosong.');
      return;
    }
    if (editItems.length === 0) {
      showInvoiceToast('error', 'Faktur harus memiliki setidaknya 1 item produk.');
      return;
    }
    const unselected = editItems.some((item) => !item.productId);
    if (unselected) {
      showInvoiceToast('error', 'Silakan pilih bahan baku untuk semua baris item baru atau hapus baris yang kosong.');
      return;
    }

    const res = onEditInvoice(editingInvoice.id, {
      customerName: editCustomerName.trim(),
      customerPhone: editCustomerPhone.trim(),
      customerAddress: editCustomerAddress.trim(),
      date: editDate,
      dueDate: editDueDate,
      paymentMethod: editPaymentMethod,
      notes: editNotes.trim(),
      taxPercent: editTaxPercent,
      items: editItems,
    }, currentUser);

    if (res.success) {
      setEditingInvoice(null);
      showInvoiceToast('success', res.message || 'Faktur penjualan berhasil diperbarui.');
    } else {
      showInvoiceToast('error', res.message || 'Gagal memperbarui faktur penjualan.');
    }
  };

  const handleConfirmDeleteInvoice = () => {
    if (!deletingInvoice || !onDeleteInvoice) return;
    setIsDeletingInvoice(true);
    try {
      const res = onDeleteInvoice(deletingInvoice.id, currentUser);
      if (res.success) {
        setDeletingInvoice(null);
        if (previewInvoice?.id === deletingInvoice.id) {
          setPreviewInvoice(null);
        }
        showInvoiceToast('success', res.message || 'Faktur berhasil dihapus dan stok dikembalikan.');
      } else {
        showInvoiceToast('error', res.message || 'Gagal menghapus faktur invoice.');
      }
    } finally {
      setIsDeletingInvoice(false);
    }
  };

  // Cart items
  const [cartItems, setCartItems] = useState<InvoiceItem[]>(() => {
    if (selectedPreProduct) {
      return [{
        productId: selectedPreProduct.id,
        productCode: selectedPreProduct.code,
        productName: selectedPreProduct.name,
        unit: selectedPreProduct.unit,
        quantity: 1,
        unitPrice: selectedPreProduct.sellingPrice,
        costPrice: selectedPreProduct.costPrice,
        discount: 0,
        subtotal: selectedPreProduct.sellingPrice,
      }];
    }
    const defaultProd = products[0] || null;
    if (!defaultProd) return [];
    return [{
      productId: defaultProd.id,
      productCode: defaultProd.code,
      productName: defaultProd.name,
      unit: defaultProd.unit,
      quantity: 1,
      unitPrice: defaultProd.sellingPrice,
      costPrice: defaultProd.costPrice,
      discount: 0,
      subtotal: defaultProd.sellingPrice,
    }];
  });

  // Calculate totals
  const subtotal = cartItems.reduce((acc, item) => acc + item.subtotal, 0);
  const grandTotal = Math.max(0, subtotal - discountTotal);

  const addItemToCart = () => {
    const available = products.find((p) => !cartItems.some((ci) => ci.productId === p.id));
    const targetProd = available || products[0];
    if (!targetProd) return;

    setCartItems([
      ...cartItems,
      {
        productId: targetProd.id,
        productCode: targetProd.code,
        productName: targetProd.name,
        unit: targetProd.unit,
        quantity: 1,
        unitPrice: targetProd.sellingPrice,
        costPrice: targetProd.costPrice,
        discount: 0,
        subtotal: targetProd.sellingPrice,
      },
    ]);
  };

  const updateCartItemProduct = (index: number, newProductId: string) => {
    const prod = products.find((p) => p.id === newProductId);
    if (!prod) return;
    const newItems = [...cartItems];
    newItems[index] = {
      ...newItems[index],
      productId: prod.id,
      productCode: prod.code,
      productName: prod.name,
      unit: prod.unit,
      unitPrice: prod.sellingPrice,
      costPrice: prod.costPrice,
      subtotal: Math.max(0, prod.sellingPrice * newItems[index].quantity - newItems[index].discount),
    };
    setCartItems(newItems);
  };

  const updateCartItemQty = (index: number, qty: number) => {
    const newItems = [...cartItems];
    const validQty = Math.max(1, qty);
    newItems[index].quantity = validQty;
    newItems[index].subtotal = Math.max(
      0,
      newItems[index].unitPrice * validQty - (newItems[index].discount || 0)
    );
    setCartItems(newItems);
  };

  const updateCartItemPrice = (index: number, price: number) => {
    const newItems = [...cartItems];
    newItems[index].unitPrice = Math.max(0, price);
    newItems[index].subtotal = Math.max(
      0,
      price * newItems[index].quantity - (newItems[index].discount || 0)
    );
    setCartItems(newItems);
  };

  const removeCartItem = (index: number) => {
    if (cartItems.length <= 1) return;
    setCartItems(cartItems.filter((_, i) => i !== index));
  };

  const handleCreateInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0 || !customerName.trim()) return;

    // Check if any item exceeds available stock
    for (const item of cartItems) {
      const prod = products.find((p) => p.id === item.productId);
      if (prod && prod.currentStock < item.quantity) {
        alert(
          `Gagal: Stok "${item.productName}" tidak cukup! Sisa di gudang: ${prod.currentStock} ${prod.unit}, Anda memesan: ${item.quantity}.`
        );
        return;
      }
    }

    const todayStr = new Date().toISOString().slice(0, 10);
    const invoiceNum = `INV-${todayStr.replace(/-/g, '').slice(0, 6)}-${String(
      invoices.length + 1
    ).padStart(3, '0')}`;

    const effectivePaid = paymentStatus === 'lunas' ? grandTotal : paymentStatus === 'dp' ? (paidAmount || grandTotal / 2) : 0;
    const effectivePaymentMethod = paymentStatus === 'belum_lunas' ? 'Belum Ada (Tempo / Piutang)' : paymentMethod;

    const newInv: Invoice = {
      id: `inv-${Date.now()}`,
      invoiceNumber: invoiceNum,
      date: todayStr,
      dueDate: paymentStatus === 'lunas' ? todayStr : (dueDate || todayStr),
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      items: cartItems,
      subtotal,
      discountTotal,
      taxPercent: 0,
      taxAmount: 0,
      grandTotal,
      paidAmount: effectivePaid,
      paymentStatus,
      paymentMethod: effectivePaymentMethod,
      notes: notes.trim(),
      createdBy: {
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        userRoleTitle: currentUser.roleTitle,
      },
    };

    onCreateInvoice(newInv);

    // Fire celebratory confetti!
    try {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }

    setPreviewInvoice(newInv);
    setActiveSubTab('receivables');
  };

  const filteredInvoices = useMemo(() => {
    return invoices.filter((inv) => {
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.customerName.toLowerCase().includes(q) ||
        inv.customerPhone.includes(q) ||
        (inv.notes && inv.notes.toLowerCase().includes(q)) ||
        inv.items.some(
          (item) =>
            item.productName.toLowerCase().includes(q) ||
            item.productCode.toLowerCase().includes(q)
        );

      if (!matchSearch) return false;

      // Status Filter
      if (statusFilter !== 'all' && inv.paymentStatus !== statusFilter) {
        return false;
      }

      // Customer Filter
      if (
        customerFilter !== 'all' &&
        inv.customerName.trim().toLowerCase() !== customerFilter.trim().toLowerCase()
      ) {
        return false;
      }

      // Date Range Filter
      if (dateRangeFilter === 'today') {
        const todayStr = new Date().toISOString().split('T')[0];
        if (inv.date !== todayStr) return false;
      } else if (dateRangeFilter === 'this_month') {
        const now = new Date();
        const yMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        if (!inv.date.startsWith(yMonth)) return false;
      } else if (dateRangeFilter === 'custom') {
        if (startDateFilter && inv.date < startDateFilter) return false;
        if (endDateFilter && inv.date > endDateFilter) return false;
      }

      return true;
    });
  }, [invoices, searchQuery, statusFilter, customerFilter, dateRangeFilter, startDateFilter, endDateFilter]);

  const filteredTotalGrand = useMemo(
    () => filteredInvoices.reduce((acc, inv) => acc + inv.grandTotal, 0),
    [filteredInvoices]
  );
  const filteredTotalPaid = useMemo(
    () => filteredInvoices.reduce((acc, inv) => acc + inv.paidAmount, 0),
    [filteredInvoices]
  );
  const filteredTotalUnpaid = useMemo(
    () => Math.max(0, filteredTotalGrand - filteredTotalPaid),
    [filteredTotalGrand, filteredTotalPaid]
  );

  const totalCustomersWithDebt = useMemo(() => {
    const debtSet = new Set<string>();
    invoices.forEach((inv) => {
      const due = getInvoiceDueInfo(inv);
      if (inv.paymentStatus !== 'lunas' && due.unpaidAmount > 0) {
        debtSet.add(inv.customerName.trim().toLowerCase());
      }
    });
    return debtSet.size;
  }, [invoices]);

  const uniqueInvoiceCustomerNames = useMemo(() => {
    const set = new Set<string>();
    invoices.forEach((inv) => {
      if (inv.customerName) set.add(inv.customerName.trim());
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [invoices]);

  const dateFilterLabel = useMemo(() => {
    if (dateRangeFilter === 'today') return 'Hari Ini';
    if (dateRangeFilter === 'this_month') return 'Bulan Ini';
    if (dateRangeFilter === 'custom') {
      if (startDateFilter && endDateFilter) return `${startDateFilter} s/d ${endDateFilter}`;
      if (startDateFilter) return `Mulai ${startDateFilter}`;
      if (endDateFilter) return `Sampai ${endDateFilter}`;
    }
    return 'Semua Periode Transaksi';
  }, [dateRangeFilter, startDateFilter, endDateFilter]);

  const sendInvoiceViaWhatsApp = (inv: Invoice) => {
    const phone = formatWaPhone(inv.customerPhone);
    if (inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp') {
      const text = encodeURIComponent(
        inv.paymentHistory && inv.paymentHistory.length > 0
          ? generatePaymentHistoryWaMessage({
              invoiceNumber: inv.invoiceNumber,
              customerName: inv.customerName,
              grandTotal: inv.grandTotal,
              paidAmount: inv.paidAmount,
              paymentStatus: inv.paymentStatus,
              paymentHistory: inv.paymentHistory,
            })
          : generateInvoiceWaReminder(inv)
      );
      window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
      return;
    }

    const cleanPhone = inv.customerPhone.replace(/\D/g, '');
    const phoneWithCountry = cleanPhone.startsWith('0') ? '62' + cleanPhone.slice(1) : cleanPhone;
    
    let text = `*FAKTUR / INVOICE PENJUALAN BAHAN DTF & SUBLIME*\n`;
    text += `No. Invoice: ${inv.invoiceNumber}\n`;
    text += `Tanggal: ${inv.date}\n`;
    text += `Konsumen: ${inv.customerName}\n`;
    text += `Status: ${(inv.paymentStatus || '').toUpperCase()}\n\n`;
    text += `*Rincian Pembelian:*\n`;
    inv.items.forEach((item, idx) => {
      text += `${idx + 1}. ${item.productName} (${item.quantity} ${item.unit}) = ${formatRupiah(item.subtotal)}\n`;
    });
    text += `\n*TOTAL TAGIHAN: ${formatRupiah(inv.grandTotal)}*\n`;
    text += `Total Terbayar: ${formatRupiah(inv.paidAmount)}\n`;
    text += `Metode Pembayaran: ${inv.paymentMethod}\n`;
    if (inv.paymentHistory && inv.paymentHistory.length > 0) {
      text += `\n*Riwayat Pembayaran:* (${inv.paymentHistory.length}x pembayaran)\n`;
      inv.paymentHistory.forEach((p, pIdx) => {
        text += `${pIdx + 1}. ${p.date.slice(0, 16)} • ${p.paymentMethod}: ${formatRupiah(p.amount)}${p.notes ? ` (${p.notes})` : ''}\n`;
      });
    }
    text += `\nTerima kasih telah berbelanja di Gudang DTF & Sublime Pro! 🙏`;

    const encoded = encodeURIComponent(text);
    window.open(`https://wa.me/${phoneWithCountry}?text=${encoded}`, '_blank');
  };

  return (
    <div className="space-y-6 pt-1 sm:pt-2">
      {/* Top Header & Sub-Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4">
          <div>
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-400" />
              <h2 className="text-base sm:text-lg font-bold text-white">Penjualan Bahan Baku & Invoice</h2>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Jual bahan baku (Tinta DTF/Sublime, PET Film, Powder, Kertas) ke konsumen luar, otomatis memotong stok & catat omset.
            </p>
          </div>

          {/* Sub Tab Switcher */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0 w-full sm:w-auto overflow-x-auto scrollbar-none">
            <button
              id="tab-btn-create-invoice"
              onClick={() => setActiveSubTab('create')}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeSubTab === 'create'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ Buat Invoice</span>
            </button>
            <button
              id="tab-btn-receivables-invoices"
              onClick={() => setActiveSubTab('receivables')}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeSubTab === 'receivables'
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Rekap Piutang</span>
              {totalCustomersWithDebt > 0 && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                  activeSubTab === 'receivables' ? 'bg-white text-rose-700' : 'bg-rose-500 text-white'
                }`}>
                  {totalCustomersWithDebt}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {activeSubTab === 'create' && (
        /* CREATE INVOICE FORM */
        <form onSubmit={handleCreateInvoice} className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Customer info & Item cart */}
          <div className="lg:col-span-8 space-y-5">
            {/* Customer Details Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3.5">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-emerald-400" />
                  <span>Informasi Pembeli / Konsumen</span>
                </h3>

                <div className="flex items-center gap-2">
                  {onOpenMasterDataCustomer && (
                    <button
                      type="button"
                      onClick={onOpenMasterDataCustomer}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/20 text-[11px] font-medium transition-colors"
                      title="Kelola Daftar Pelanggan"
                    >
                      <Users className="w-3 h-3 text-cyan-400" />
                      <span>Kelola Pelanggan ({customers.length})</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Quick Customer Picker Dropdown */}
              {customers.length > 0 && (
                <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-medium flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-cyan-400" />
                      Pilih Cepat dari Pelanggan Terdaftar:
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-slate-500 hidden sm:inline">
                        (Data nama, WA, & alamat akan terisi otomatis)
                      </span>
                      {(customerName || customerPhone || customerAddress || selectedCustomerId) && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedCustomerId('');
                            setCustomerName('');
                            setCustomerPhone('');
                            setCustomerAddress('');
                          }}
                          className="text-[10px] text-slate-400 hover:text-rose-300 transition-colors"
                          title="Kosongkan form untuk ketik manual baru"
                        >
                          ✕ Kosongkan Form
                        </button>
                      )}
                    </div>
                  </div>
                  <select
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
                    value={selectedCustomerId}
                    onChange={(e) => {
                      const selectedId = e.target.value;
                      setSelectedCustomerId(selectedId);
                      if (!selectedId) return;
                      const selected = customers.find((c) => c.id === selectedId);
                      if (selected) {
                        setCustomerName(selected.name);
                        setCustomerPhone(selected.phone);
                        setCustomerAddress(selected.address || '');
                      }
                    }}
                  >
                    <option value="">-- Pilih Pelanggan (atau ketik langsung di bawah) --</option>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} • {c.phone} {c.address ? `(${c.address})` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">Nama Konsumen / Vendor *</label>
                    {customerName.trim() && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                        customers.some((c) => c.name.toLowerCase() === customerName.trim().toLowerCase())
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                      }`}>
                        {customers.some((c) => c.name.toLowerCase() === customerName.trim().toLowerCase())
                          ? '✓ Pelanggan Terdaftar'
                          : '+ Otomatis Ditambahkan'}
                      </span>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => {
                      const val = e.target.value;
                      setCustomerName(val);
                      // Otomatis kembalikan pilih cepat ke default saat ketik manual
                      setSelectedCustomerId('');
                      // Auto-fill phone/address if exact match found
                      const matched = customers.find((c) => c.name.toLowerCase() === val.trim().toLowerCase());
                      if (matched) {
                        if (matched.phone) setCustomerPhone(matched.phone);
                        if (matched.address) setCustomerAddress(matched.address);
                      }
                    }}
                    placeholder="misal: Percetakan Berkah Jaya"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">No. WhatsApp / Telepon *</label>
                  <input
                    type="text"
                    required
                    value={customerPhone}
                    onChange={(e) => {
                      setCustomerPhone(e.target.value);
                      // Otomatis kembalikan pilih cepat ke default saat ketik manual
                      setSelectedCustomerId('');
                    }}
                    placeholder="misal: 0812-3456-7890"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Alamat Pengiriman (Opsional)</label>
                <input
                  type="text"
                  value={customerAddress}
                  onChange={(e) => {
                    setCustomerAddress(e.target.value);
                    // Otomatis kembalikan pilih cepat ke default saat ketik manual
                    setSelectedCustomerId('');
                  }}
                  placeholder="misal: Jl. Riau No. 45, Bandung"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Informative helper note */}
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 bg-slate-950/40 p-2 rounded-lg border border-slate-800/60">
                <UserPlus className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span>
                  Jika data nama, no. WA, atau alamat belum ada di sistem, akan <strong>otomatis tersimpan</strong> ke master pelanggan saat faktur ini diterbitkan.
                </span>
              </div>
            </div>

            {/* Item Cart Table */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-cyan-400" />
                  <span>Daftar Bahan Baku yang Dibeli</span>
                </h3>
                <button
                  type="button"
                  onClick={addItemToCart}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-semibold transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Baris Bahan</span>
                </button>
              </div>

              <div className="space-y-3">
                {cartItems.map((item, idx) => {
                  const targetProd = products.find((p) => p.id === item.productId);
                  const isStockShort = targetProd ? targetProd.currentStock < item.quantity : false;

                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border transition-colors ${
                        isStockShort
                          ? 'bg-rose-500/10 border-rose-500/40'
                          : 'bg-slate-950 border-slate-800/80'
                      }`}
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                        {/* Select Product */}
                        <div className="sm:col-span-5">
                          <label className="block text-[10px] text-slate-400 font-medium mb-1">
                            Pilih Bahan Baku:
                          </label>
                          <select
                            value={item.productId}
                            onChange={(e) => updateCartItemProduct(idx, e.target.value)}
                            className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                          >
                            {products.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.name} (Stok: {p.currentStock} {p.unit})
                              </option>
                            ))}
                          </select>
                          {targetProd && (
                            <span className="text-[10px] text-slate-400 block mt-1">
                              Stok Gudang: <strong className="text-cyan-300">{targetProd.currentStock} {targetProd.unit}</strong>
                            </span>
                          )}
                        </div>

                        {/* Qty */}
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] text-slate-400 font-medium mb-1">
                            Jumlah ({item.unit.split(' ')[0]}):
                          </label>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => updateCartItemQty(idx, Number(e.target.value))}
                            className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white font-bold text-center focus:outline-none focus:border-cyan-500"
                          />
                        </div>

                        {/* Unit Price */}
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] text-slate-400 font-medium mb-1">
                            Harga Satuan:
                          </label>
                          <input
                            type="number"
                            min="0"
                            step="1000"
                            value={item.unitPrice}
                            onChange={(e) => updateCartItemPrice(idx, Number(e.target.value))}
                            className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-500"
                          />
                        </div>

                        {/* Subtotal & Delete */}
                        <div className="sm:col-span-3 flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-4">
                          <div className="text-right">
                            <span className="text-[10px] text-slate-400 block">Subtotal</span>
                            <span className="text-xs font-bold text-white font-mono">
                              {formatRupiah(item.subtotal)}
                            </span>
                          </div>
                          <button
                            type="button"
                            disabled={cartItems.length <= 1}
                            onClick={() => removeCartItem(idx)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg hover:bg-slate-900 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {isStockShort && (
                        <p className="text-[11px] text-rose-400 mt-2 font-medium flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          Peringatan: Jumlah beli melebihi stok yang ada di gudang ({targetProd?.currentStock})!
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right: Payment Details & Summary Card */}
          <div className="lg:col-span-4 space-y-5">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2 border-b border-slate-800 pb-3">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <span>Pembayaran & Total</span>
              </h3>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Status Pembayaran</label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 font-semibold"
                  >
                    <option value="lunas">🟢 Lunas Sepenuhnya</option>
                    <option value="dp">🟡 Uang Muka (DP)</option>
                    <option value="belum_lunas">🔴 Belum Dibayar (Tempo / Piutang)</option>
                  </select>
                </div>

                {paymentStatus === 'dp' && (
                  <div>
                    <label className="block text-xs font-medium text-amber-300 mb-1">Nominal DP Diterima</label>
                    <input
                      type="number"
                      min="0"
                      step="1000"
                      value={paidAmount}
                      onChange={(e) => setPaidAmount(Number(e.target.value))}
                      placeholder="misal: 300000"
                      className="w-full px-3 py-2 bg-slate-950 border border-amber-500/40 rounded-lg text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-400"
                    />
                  </div>
                )}

                {(paymentStatus === 'belum_lunas' || paymentStatus === 'dp') && (
                  <div className="bg-slate-900/50 p-3.5 rounded-xl border border-rose-500/20">
                    <DueDateSelector
                      value={dueDate}
                      onChange={setDueDate}
                      label="Batas Tanggal Jatuh Tempo Pelunasan"
                      helperText="Pengingat jatuh tempo otomatis akan aktif di dasbor & notifikasi untuk menagih sisa pembayaran."
                      colorTheme="rose"
                    />
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className={`block text-xs font-medium ${
                      paymentStatus === 'belum_lunas' ? 'text-slate-500' : 'text-slate-300'
                    }`}>
                      Metode Pembayaran
                    </label>
                    {paymentStatus === 'belum_lunas' && (
                      <span className="text-[10px] text-amber-400 font-medium">
                        Otomatis tidak aktif (Belum bayar)
                      </span>
                    )}
                  </div>
                  <select
                    disabled={paymentStatus === 'belum_lunas'}
                    value={paymentStatus === 'belum_lunas' ? 'Belum Ada (Tempo / Piutang)' : paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className={`w-full px-3 py-2 border rounded-lg text-xs transition-all ${
                      paymentStatus === 'belum_lunas'
                        ? 'bg-slate-900/60 border-slate-800 text-slate-500 cursor-not-allowed select-none opacity-60'
                        : 'bg-slate-950 border-slate-800 text-white focus:outline-hidden focus:border-emerald-500'
                    }`}
                  >
                    {paymentStatus === 'belum_lunas' ? (
                      <option value="Belum Ada (Tempo / Piutang)">
                        ⛔ Belum Ditentukan (Tempo / Piutang)
                      </option>
                    ) : (
                      <>
                        <option value="Tunai">💵 Tunai / Cash di Toko</option>
                        <option value="Transfer Bank">🏦 Transfer Bank</option>
                        <option value="QRIS">📱 QRIS Instan</option>
                      </>
                    )}
                  </select>
                  {paymentStatus === 'belum_lunas' && (
                    <p className="text-[10px] text-slate-500 mt-1">
                      Metode pembayaran akan ditentukan saat konsumen membayar cicilan atau melunasi faktur.
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Potongan / Diskon (Rp)</label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={discountTotal}
                    onChange={(e) => setDiscountTotal(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Catatan Invoice</label>
                  <textarea
                    rows={2}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="misal: Pengambilan barang via kurir Lalamove"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Price Calculation Box */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span className="font-mono text-slate-200">{formatRupiah(subtotal)}</span>
                </div>
                {discountTotal > 0 && (
                  <div className="flex justify-between text-rose-400">
                    <span>Diskon:</span>
                    <span className="font-mono">-{formatRupiah(discountTotal)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline">
                  <span className="font-bold text-white text-sm">Grand Total:</span>
                  <span className="font-mono text-base font-extrabold text-emerald-400">
                    {formatRupiah(grandTotal)}
                  </span>
                </div>
              </div>

              {/* Submit Button */}
              <button
                id="btn-submit-invoice"
                type="submit"
                className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 transition-all"
              >
                <FileText className="w-4 h-4" />
                <span>Terbitkan Invoice & Potong Stok</span>
              </button>
            </div>
          </div>
        </form>
      )}

      {/* Subtab Daftar Faktur ditiadakan karena telah terwakili penuh di Rekap Piutang */}
      {false && (
        /* INVOICE LIST VIEW */
        <div className="space-y-4">
          {/* PRINT / EXPORT PDF BAR GOVERNED DIRECTLY BY SEARCH & FILTERS */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shrink-0">
                <Printer className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-xs sm:text-sm font-bold text-white">
                    Cetak / Print PDF Rekapitulasi Faktur
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold font-mono">
                    {filteredInvoices.length} Faktur Sesuai Filter
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Laporan cetak & file PDF 100% dipengaruhi oleh pencarian {searchQuery ? <strong className="text-cyan-300 font-mono">"{searchQuery}"</strong> : 'semua data'}, status, konsumen, & periode.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 flex-wrap sm:flex-nowrap">
              {/* Direct Print Button */}
              <button
                type="button"
                id="btn-direct-print-filtered-invoices"
                onClick={handlePrintInvoicesList}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-xs"
                title="Cetak langsung ke mesin printer sesuai filter pencarian saat ini"
              >
                <Printer className="w-4 h-4 text-cyan-400" />
                <span>Cetak ({filteredInvoices.length})</span>
              </button>

              {/* Direct PDF Download Button */}
              <button
                type="button"
                id="btn-direct-download-filtered-invoices-pdf"
                onClick={handleSaveInvoicesListPdf}
                disabled={isSavingInvoicesListPdf}
                className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold active:scale-95 transition-all cursor-pointer shadow-xs shadow-cyan-950/40"
                title="Unduh file PDF resmi A4 Landscape sesuai hasil filter pencarian saat ini"
              >
                {isSavingInvoicesListPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <FileDown className="w-4 h-4" />
                )}
                <span>{isSavingInvoicesListPdf ? 'Menyimpan PDF...' : 'Unduh Rekap PDF'}</span>
              </button>

              {/* Preview Modal Button */}
              <button
                type="button"
                id="btn-preview-invoices-recap-modal"
                onClick={() => setShowInvoicesListRecapModal(true)}
                className="flex items-center justify-center gap-1 px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 text-xs font-medium active:scale-95 transition-all cursor-pointer"
                title="Buka pratinjau lembar faktur resmi sebelum mencetak"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Pratinjau</span>
              </button>
            </div>
          </div>

          {/* Direct PDF Download Feedback Banner */}
          {invoicesListPdfSuccess && !showInvoicesListRecapModal && (
            <div className="bg-emerald-950/80 border border-emerald-500/40 rounded-xl px-4 py-2.5 text-xs text-emerald-300 font-medium flex items-center justify-between gap-2 shadow-xs">
              <div className="flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{invoicesListPdfSuccess}</span>
              </div>
              <button 
                type="button" 
                onClick={() => setInvoicesListPdfSuccess(null)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>
          )}

          {/* Main Filter & Control Panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
            {/* Row 1: Search & Status Filter */}
            <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari no invoice (INV-...), nama konsumen, no telp, catatan, atau nama item..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-10 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Status Filter Buttons */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0 scrollbar-none shrink-0">
                <span className="text-xs text-slate-400 mr-1 hidden sm:inline">Status:</span>
                {[
                  { id: 'all', label: 'Semua Status' },
                  { id: 'lunas', label: 'Lunas' },
                  { id: 'dp', label: 'DP' },
                  { id: 'belum_lunas', label: 'Belum Lunas' },
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setStatusFilter(st.id as any)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer shrink-0 ${
                      statusFilter === st.id
                        ? 'bg-slate-700 text-white shadow-xs'
                        : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Row 2: Customer Filter, Period Filter, Custom Dates, and Action Buttons */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
              <div className="flex items-center gap-2 flex-wrap text-xs">
                {/* Customer Filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 text-[11px] font-medium hidden sm:inline">Konsumen:</span>
                  <select
                    value={customerFilter}
                    onChange={(e) => setCustomerFilter(e.target.value)}
                    className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer max-w-[180px] truncate"
                  >
                    <option value="all">Semua Konsumen ({uniqueInvoiceCustomerNames.length})</option>
                    {uniqueInvoiceCustomerNames.map((name) => (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Period Filter */}
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 text-[11px] font-medium hidden sm:inline">Periode:</span>
                  <select
                    value={dateRangeFilter}
                    onChange={(e) => setDateRangeFilter(e.target.value as any)}
                    className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    <option value="all">Semua Waktu</option>
                    <option value="today">Hari Ini</option>
                    <option value="this_month">Bulan Ini</option>
                    <option value="custom">Rentang Tanggal Kustom...</option>
                  </select>
                </div>

                {/* Custom Date Inputs */}
                {dateRangeFilter === 'custom' && (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="date"
                      value={startDateFilter}
                      onChange={(e) => setStartDateFilter(e.target.value)}
                      className="px-2 py-1 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                      title="Dari Tanggal"
                    />
                    <span className="text-slate-500">-</span>
                    <input
                      type="date"
                      value={endDateFilter}
                      onChange={(e) => setEndDateFilter(e.target.value)}
                      className="px-2 py-1 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-cyan-500 font-mono"
                      title="Sampai Tanggal"
                    />
                  </div>
                )}

                {/* Clear filters button */}
                {(searchQuery || statusFilter !== 'all' || customerFilter !== 'all' || dateRangeFilter !== 'all') && (
                  <button
                    type="button"
                    onClick={() => {
                      setSearchQuery('');
                      setStatusFilter('all');
                      setCustomerFilter('all');
                      setDateRangeFilter('all');
                      setStartDateFilter('');
                      setEndDateFilter('');
                    }}
                    className="text-[11px] text-slate-400 hover:text-rose-300 underline transition-colors cursor-pointer"
                  >
                    Reset Filter
                  </button>
                )}
              </div>

              {/* Action Buttons: Print List & Download PDF Recap & Go to Receivables */}
              <div className="flex items-center gap-2 flex-wrap shrink-0">
                <button
                  type="button"
                  id="btn-print-invoices-recap"
                  onClick={handlePrintInvoicesList}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-2xs"
                  title="Cetak langsung Rekapitulasi Daftar Faktur sesuai filter saat ini"
                >
                  <Printer className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Cetak Rekap ({filteredInvoices.length})</span>
                </button>

                <button
                  type="button"
                  id="btn-download-invoices-pdf"
                  onClick={handleSaveInvoicesListPdf}
                  disabled={isSavingInvoicesListPdf}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-xs shadow-cyan-950/40"
                  title="Unduh File PDF Rekapitulasi Faktur Penjualan sesuai filter saat ini"
                >
                  {isSavingInvoicesListPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isSavingInvoicesListPdf ? 'Menyimpan...' : 'Unduh Rekap PDF'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveSubTab('receivables')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 text-xs font-semibold active:scale-95 transition-all cursor-pointer"
                  title="Buka Halaman Rekap Piutang per Nama Pelanggan"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Rekap Piutang Pelanggan</span>
                  <span className="sm:hidden">Piutang</span>
                  {totalCustomersWithDebt > 0 && (
                    <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold">
                      {totalCustomersWithDebt}
                    </span>
                  )}
                </button>
              </div>
            </div>

            {/* Filtered Summary KPIs Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800/60 text-xs">
              <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-500 block uppercase">Faktur Ditemukan</span>
                <span className="font-bold text-white text-xs font-mono">{filteredInvoices.length} Faktur</span>
              </div>
              <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-500 block uppercase">Total Omset</span>
                <span className="font-bold text-slate-200 text-xs font-mono truncate block">
                  {formatRupiah(filteredTotalGrand)}
                </span>
              </div>
              <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-500 block uppercase">Kas Masuk (Terbayar)</span>
                <span className="font-bold text-emerald-400 text-xs font-mono truncate block">
                  {formatRupiah(filteredTotalPaid)}
                </span>
              </div>
              <div className="bg-slate-950/60 px-3 py-1.5 rounded-xl border border-slate-800/80">
                <span className="text-[10px] text-slate-500 block uppercase">Sisa Piutang</span>
                <span className="font-bold text-rose-400 text-xs font-mono truncate block">
                  {formatRupiah(filteredTotalUnpaid)}
                </span>
              </div>
            </div>
          </div>

          {/* MOBILE PORTRAIT INVOICE CARDS (Shown on phone screens) */}
          <div className="md:hidden space-y-3">
            {filteredInvoices.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
                Tidak ada invoice yang ditemukan.
              </div>
            ) : (
              filteredInvoices.map((inv) => {
                const dueInfo = getInvoiceDueInfo(inv);
                return (
                  <div
                    key={inv.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="font-mono font-bold text-cyan-300 text-sm block">
                          {inv.invoiceNumber}
                        </span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[11px] text-slate-400">{inv.date}</span>
                          {inv.paymentStatus !== 'lunas' && (
                            <span className="text-[10px] text-rose-400 flex items-center gap-1 font-mono">
                              <Clock className="w-3 h-3" />
                              <span>Tempo: {formatDueDateIndo(inv.dueDate)}</span>
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 flex-wrap justify-end">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                          inv.paymentStatus === 'lunas'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : inv.paymentStatus === 'dp'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        }`}>
                          {inv.paymentStatus === 'lunas' ? 'LUNAS' : inv.paymentStatus === 'dp' ? 'DP' : 'BELUM LUNAS'}
                        </span>
                        {inv.paymentStatus !== 'lunas' && (
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded border ${dueInfo.badgeClass}`}>
                            {dueInfo.statusLabel}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-1">
                      <div className="flex items-baseline justify-between">
                        <span className="text-xs font-bold text-white">{inv.customerName}</span>
                        <span className="text-[11px] text-slate-400 font-mono">{inv.customerPhone}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate">
                        {inv.items.map((i) => `${i.productName} (${i.quantity} ${i.unit})`).join(', ')}
                      </p>
                      {/* Payment Status & Installment Progress */}
                      <div className="flex items-center justify-between text-[11px] pt-1.5 border-t border-slate-800 text-slate-300">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span>Terbayar: <strong className="font-mono text-emerald-400">{formatRupiah(inv.paidAmount)}</strong></span>
                          {inv.paymentHistory && inv.paymentHistory.length > 0 && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono">
                              {inv.paymentHistory.length}x Bayar
                            </span>
                          )}
                        </div>
                        {inv.paymentStatus !== 'lunas' && (
                          <span className="text-rose-400 font-mono font-bold">
                            Sisa: {formatRupiah(dueInfo.unpaidAmount)}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-2 border-t border-slate-800/80 gap-2.5">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Total Tagihan ({inv.paymentMethod})</span>
                        <span className="font-mono font-extrabold text-emerald-400 text-base">
                          {formatRupiah(inv.grandTotal)}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          onClick={() => setSelectedPaymentInvoiceId(inv.id)}
                          className="flex-1 sm:flex-none px-3 py-2 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all shadow-xs"
                          title="Catat Cicilan & Lihat Riwayat Pembayaran"
                        >
                          <Receipt className="w-3.5 h-3.5" />
                          <span>{inv.paymentStatus !== 'lunas' ? 'Cicilan / Histori' : 'Histori Bayar'}</span>
                        </button>
                        <button
                          onClick={() => setPreviewInvoice(inv)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all"
                        >
                          <Eye className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Nota</span>
                        </button>
                        <button
                          onClick={() => sendInvoiceViaWhatsApp(inv)}
                          title={inv.paymentStatus !== 'lunas' ? 'Kirim Pengingat Tagihan WA' : 'Kirim Nota via WA'}
                          className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all border ${
                            inv.paymentStatus !== 'lunas'
                              ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40'
                              : 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border-emerald-500/30'
                          }`}
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{inv.paymentStatus !== 'lunas' ? 'Tagih WA' : 'Kirim WA'}</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEditInvoice(inv)}
                          disabled={!canEditSalesInvoice}
                          title={canEditSalesInvoice ? "Edit Data Faktur Penjualan" : "Akses ditolak: Izin 'Edit Faktur Penjualan' tidak aktif"}
                          className={`px-2.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 transition-all border ${
                            canEditSalesInvoice
                              ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer'
                              : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeletingInvoice(inv)}
                          disabled={!canDeleteSalesInvoice}
                          title={canDeleteSalesInvoice ? "Hapus Faktur Penjualan & Revert Stok" : "Akses ditolak: Izin 'Hapus Faktur Penjualan' tidak aktif"}
                          className={`px-2.5 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 transition-all border ${
                            canDeleteSalesInvoice
                              ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer'
                              : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Hapus</span>
                        </button>
                        {inv.paymentStatus !== 'lunas' && (
                          <button
                            onClick={() => {
                              onUpdateInvoiceStatus(inv.id, 'lunas', inv.grandTotal);
                              confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
                            }}
                            className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition-all"
                            title="Tandai pembayaran telah dilunasi"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>Lunas</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* DESKTOP / TABLET INVOICE TABLE (Hidden on Mobile) */}
          <div className="hidden md:block bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
            <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
              <table className="w-full min-w-[960px] text-left text-xs sm:text-sm border-collapse">
                <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] sm:text-[11px] tracking-wider sticky top-0 z-10">
                  <tr>
                    <th className="py-3.5 px-4 min-w-[160px]">No. Invoice & Tanggal</th>
                    <th className="py-3.5 px-4 min-w-[170px]">Konsumen</th>
                    <th className="py-3.5 px-3 min-w-[180px]">Item Bahan</th>
                    <th className="py-3.5 px-3 min-w-[190px]">Metode, Status & Jatuh Tempo</th>
                    <th className="py-3.5 px-4 text-right min-w-[150px]">Total Tagihan</th>
                    <th className="py-3.5 px-4 text-right min-w-[150px]">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {filteredInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-400 text-xs">
                        Tidak ada invoice yang ditemukan.
                      </td>
                    </tr>
                  ) : (
                    filteredInvoices.map((inv) => {
                      const dueInfo = getInvoiceDueInfo(inv);
                      const paymentCount = inv.paymentHistory?.length || (inv.paidAmount > 0 ? 1 : 0);
                      return (
                        <tr key={inv.id} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3.5 px-4 whitespace-nowrap">
                            <span className="font-mono font-bold text-cyan-300 text-xs block">
                              {inv.invoiceNumber}
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono">{inv.date}</span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span className="font-semibold text-slate-100 block">{inv.customerName}</span>
                            <span className="text-[11px] text-slate-400 font-mono">{inv.customerPhone}</span>
                          </td>
                          <td className="py-3.5 px-3">
                            <span className="text-xs text-slate-300 font-medium">
                              {inv.items.length} jenis bahan
                            </span>
                            <span className="block text-[10px] text-slate-500 truncate max-w-[200px]">
                              {inv.items.map((i) => i.productName).join(', ')}
                            </span>
                          </td>
                          <td className="py-3.5 px-3">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                inv.paymentStatus === 'lunas'
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                  : inv.paymentStatus === 'dp'
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                  : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                              }`}>
                                {inv.paymentStatus === 'lunas' ? 'LUNAS' : inv.paymentStatus === 'dp' ? 'DP' : 'BELUM LUNAS'}
                              </span>
                              <button
                                type="button"
                                onClick={() => setSelectedPaymentInvoiceId(inv.id)}
                                className="inline-flex items-center gap-1 text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800/80 hover:bg-cyan-900 transition-colors"
                                title="Buka Riwayat Cicilan"
                              >
                                <Receipt className="w-2.5 h-2.5" />
                                <span>{paymentCount}x Bayar</span>
                              </button>
                              {inv.paymentStatus !== 'lunas' && (
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded border ${dueInfo.badgeClass}`}>
                                  {dueInfo.statusLabel}
                                </span>
                              )}
                            </div>
                            <span className="block text-[10px] text-slate-400 mt-1">
                              {inv.paymentMethod} {inv.paymentStatus !== 'lunas' ? `• Tempo: ${formatDueDateIndo(inv.dueDate)}` : ''}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right font-mono text-xs whitespace-nowrap">
                            <div className="tabular-nums font-bold text-emerald-400">{formatRupiah(inv.grandTotal)}</div>
                            <div className="text-[10px] text-slate-400 mt-0.5 tabular-nums">
                              Terbayar: {formatRupiah(inv.paidAmount)}
                            </div>
                            {inv.paymentStatus !== 'lunas' && (
                              <span className="text-[10px] text-rose-400 font-semibold block tabular-nums">
                                Sisa: {formatRupiah(dueInfo.unpaidAmount)}
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => setSelectedPaymentInvoiceId(inv.id)}
                                title="Kelola Riwayat & Tambah Pembayaran Cicilan"
                                className="px-2.5 py-1 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs"
                              >
                                <Receipt className="w-3.5 h-3.5" />
                                <span>{inv.paymentStatus !== 'lunas' ? 'Cicilan' : 'Histori'}</span>
                              </button>
                              <button
                                onClick={() => setPreviewInvoice(inv)}
                                title="Lihat & Cetak Invoice"
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs"
                              >
                                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                                <span>Nota</span>
                              </button>
                              <button
                                onClick={() => sendInvoiceViaWhatsApp(inv)}
                                title={inv.paymentStatus !== 'lunas' ? 'Kirim Pengingat Tagihan ke WhatsApp' : 'Kirim Nota ke WhatsApp'}
                                className={`p-1.5 rounded-lg border active:scale-95 transition-all shadow-2xs ${
                                  inv.paymentStatus !== 'lunas'
                                    ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40'
                                    : 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border-emerald-500/30'
                                }`}
                              >
                                <MessageSquare className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleOpenEditInvoice(inv)}
                                disabled={!canEditSalesInvoice}
                                title={canEditSalesInvoice ? "Edit Data Faktur Penjualan" : "Akses ditolak: Izin 'Edit Faktur Penjualan' tidak aktif"}
                                className={`px-2 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1 border transition-all ${
                                  canEditSalesInvoice
                                    ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer active:scale-95'
                                    : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                                }`}
                              >
                                <Edit3 className="w-3 h-3" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingInvoice(inv)}
                                disabled={!canDeleteSalesInvoice}
                                title={canDeleteSalesInvoice ? "Hapus Faktur Penjualan & Revert Stok" : "Akses ditolak: Izin 'Hapus Faktur Penjualan' tidak aktif"}
                                className={`px-2 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1 border transition-all ${
                                  canDeleteSalesInvoice
                                    ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer active:scale-95'
                                    : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                                }`}
                              >
                                <Trash2 className="w-3 h-3" />
                                <span>Hapus</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* REKAP PIUTANG PER NAMA PELANGGAN SUB-TAB */}
      {activeSubTab === 'receivables' && (
        <CustomerReceivablesView
          invoices={invoices}
          customers={customers}
          currentUser={currentUser}
          companyProfile={companyProfile}
          onRecordPayment={onRecordPayment}
          onDeletePayment={onDeletePayment}
          onUpdateInvoiceStatus={onUpdateInvoiceStatus}
          onViewInvoice={(inv) => setPreviewInvoice(inv)}
          onOpenPaymentModal={(id) => setSelectedPaymentInvoiceId(id)}
          onDeleteInvoice={onDeleteInvoice}
        />
      )}

      {/* MODAL PREVIEW & PRINT INVOICE */}
      {previewInvoice && (() => {
        const targetPreviewInvoice = currentPreviewInvoice || previewInvoice;
        const previewHistory: PaymentRecord[] = targetPreviewInvoice.paymentHistory || (
          targetPreviewInvoice.paidAmount > 0 ? [
            {
              id: `pay-prev-${targetPreviewInvoice.id}`,
              date: targetPreviewInvoice.date ? `${targetPreviewInvoice.date} 10:00` : '2026-09-18 10:00',
              amount: targetPreviewInvoice.paidAmount,
              paymentMethod: targetPreviewInvoice.paymentMethod,
              notes: targetPreviewInvoice.paymentStatus === 'dp' ? 'Uang Muka (DP) Awal' : 'Pembayaran Awal Faktur',
              receivedBy: targetPreviewInvoice.createdBy,
            }
          ] : []
        );
        const previewTotalPaid = previewHistory.reduce((s, p) => s + p.amount, 0);
        const previewUnpaid = Math.max(0, targetPreviewInvoice.grandTotal - previewTotalPaid);

        return (
          <div className="fixed inset-0 z-50 overflow-y-auto p-2 sm:p-6 bg-slate-950/90 backdrop-blur-xs flex justify-center items-start">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full shadow-2xl text-slate-100 my-2 sm:my-6 overflow-hidden flex flex-col">
              {/* Top Bar with actions - STICKY AT TOP */}
              <div className="sticky top-0 z-30 bg-slate-900/98 backdrop-blur-md px-4 sm:px-6 py-3.5 border-b border-slate-800 flex items-center justify-between gap-2 shadow-sm">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div className="min-w-0">
                    <h3 className="font-bold text-xs sm:text-base text-white truncate">
                      Faktur {targetPreviewInvoice.invoiceNumber}
                    </h3>
                    <p className="text-[10px] text-slate-400 font-mono hidden sm:block">
                      Tanggal: {targetPreviewInvoice.date} • {targetPreviewInvoice.customerName}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 flex-wrap sm:flex-nowrap">
                  <button
                    type="button"
                    onClick={() => setSelectedPaymentInvoiceId(targetPreviewInvoice.id)}
                    className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded-lg text-xs font-semibold transition-colors shadow-xs active:scale-95"
                    title="Catat Cicilan atau Lihat Riwayat Pembayaran"
                  >
                    <Receipt className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Histori / Cicilan</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSaveInvoicePdf(targetPreviewInvoice)}
                    disabled={isSavingInvoicePdf}
                    className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors shadow-xs active:scale-95 cursor-pointer"
                    title="Unduh faktur sebagai file PDF ke perangkat Anda"
                  >
                    {isSavingInvoicePdf ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                    ) : (
                      <FileDown className="w-3.5 h-3.5" />
                    )}
                    <span>{isSavingInvoicePdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handlePrintInvoice}
                    className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors shadow-xs active:scale-95 cursor-pointer"
                    title="Cetak Faktur fisik lewat printer bawaan"
                  >
                    <Printer className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="hidden sm:inline">Cetak</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => sendInvoiceViaWhatsApp(targetPreviewInvoice)}
                    className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-semibold transition-colors shadow-xs"
                    title="Kirim Nota ke WhatsApp Konsumen"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">WhatsApp</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPreviewInvoice(null);
                      handleOpenEditInvoice(targetPreviewInvoice);
                    }}
                    disabled={!canEditSalesInvoice}
                    title={canEditSalesInvoice ? "Edit Data Faktur Penjualan" : "Akses ditolak: Izin 'Edit Faktur Penjualan' tidak aktif"}
                    className={`flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shadow-xs border active:scale-95 ${
                      canEditSalesInvoice
                        ? 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border-amber-500/40 cursor-pointer'
                        : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPreviewInvoice(null);
                      setDeletingInvoice(targetPreviewInvoice);
                    }}
                    disabled={!canDeleteSalesInvoice}
                    title={canDeleteSalesInvoice ? "Hapus Faktur Penjualan & Revert Stok" : "Akses ditolak: Izin 'Hapus Faktur Penjualan' tidak aktif"}
                    className={`flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shadow-xs border active:scale-95 ${
                      canDeleteSalesInvoice
                        ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40 cursor-pointer'
                        : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Hapus</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewInvoice(null)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                    title="Tutup Faktur"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Notification Banner */}
              {invoiceSaveSuccess && (
                <div className="px-4 py-2 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium shrink-0">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                  <span>{invoiceSaveSuccess}</span>
                </div>
              )}

              {/* Modal Body */}
              <div className="p-3 sm:p-6 space-y-4">
                {/* Printable Invoice Template (White clean sheet) */}
                <div id="printable-invoice" className="bg-white text-slate-900 p-4 sm:p-8 rounded-xl shadow-md font-sans text-xs sm:text-sm">
                  {/* Header */}
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b-2 border-slate-900">
                    <div className="flex items-start gap-3 sm:gap-4">
                      {companyProfile?.logoUrl ? (
                        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl border border-slate-200 bg-white p-1.5 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
                          <img
                            src={companyProfile.logoUrl}
                            alt={companyProfile.companyName || 'Logo Perusahaan'}
                            className="w-full h-full object-contain"
                          />
                        </div>
                      ) : (
                        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-lg sm:text-xl shrink-0">
                          {companyProfile?.shortName || companyProfile?.appLogoBadge || 'DTF'}
                        </div>
                      )}
                      <div>
                        <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight uppercase">
                          {companyProfile?.companyName || 'GUDANG BAHAN DTF & SUBLIME'}
                        </h1>
                        <p className="text-xs text-slate-600 mt-1">
                          {companyProfile?.tagline || 'Pusat Suplai Tinta, PET Film, Hot Melt Powder & Kertas Sublimasi'}
                        </p>
                        <p className="text-xs text-slate-500">
                          {companyProfile?.address || 'Kawasan Industri Kreatif No. 88'}, {companyProfile?.city || 'Bandung'} • Telp/WA: {companyProfile?.phone || '0812-9988-7766'}
                        </p>
                      </div>
                    </div>
                    <div className="text-left sm:text-right">
                      <span className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-extrabold text-sm tracking-wider uppercase">
                        INVOICE PENJUALAN
                      </span>
                      <p className="font-mono font-bold text-sm text-slate-800 mt-2">
                        {targetPreviewInvoice.invoiceNumber}
                      </p>
                      <p className="text-xs text-slate-600">Tanggal: {targetPreviewInvoice.date}</p>
                    </div>
                  </div>

                  {/* Billed To & Payment Status */}
                  <div className="grid grid-cols-2 gap-4 py-4 text-xs">
                    <div>
                      <span className="text-[11px] font-bold text-slate-500 uppercase">Ditujukan Kepada:</span>
                      <p className="font-bold text-sm text-slate-900 mt-0.5">{targetPreviewInvoice.customerName}</p>
                      <p className="text-slate-600">{targetPreviewInvoice.customerPhone}</p>
                      {targetPreviewInvoice.customerAddress && (
                        <p className="text-slate-500 mt-0.5">{targetPreviewInvoice.customerAddress}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-[11px] font-bold text-slate-500 uppercase">Status & Metode:</span>
                      <p className="font-bold text-slate-900 text-sm mt-0.5">
                        {targetPreviewInvoice.paymentMethod}
                      </p>
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold mt-1 uppercase ${
                        targetPreviewInvoice.paymentStatus === 'lunas'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : targetPreviewInvoice.paymentStatus === 'dp'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}>
                        {targetPreviewInvoice.paymentStatus === 'lunas' ? 'LUNAS' : targetPreviewInvoice.paymentStatus === 'dp' ? 'UANG MUKA (DP)' : 'BELUM LUNAS'}
                      </span>
                    </div>
                  </div>

                  {/* Items Table */}
                  <div className="overflow-x-auto -mx-2 px-2">
                    <table className="w-full my-4 text-left border-collapse text-xs min-w-[320px]">
                      <thead>
                        <tr className="bg-slate-100 border-y border-slate-300 font-bold text-slate-700 uppercase text-[10px]">
                          <th className="py-2 px-2">No</th>
                          <th className="py-2 px-2">Nama Bahan Baku</th>
                          <th className="py-2 px-2 text-center">Satuan</th>
                          <th className="py-2 px-2 text-center">Qty</th>
                          <th className="py-2 px-2 text-right">Harga Satuan</th>
                          <th className="py-2 px-2 text-right">Subtotal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {targetPreviewInvoice.items.map((item, idx) => (
                          <tr key={idx}>
                            <td className="py-2 px-2 text-slate-500 font-mono">{idx + 1}</td>
                            <td className="py-2 px-2">
                              <span className="font-bold text-slate-900 block">{item.productName}</span>
                              <span className="text-[10px] text-slate-500 font-mono">{item.productCode}</span>
                            </td>
                            <td className="py-2 px-2 text-center text-slate-600">{item.unit}</td>
                            <td className="py-2 px-2 text-center font-bold text-slate-900">{item.quantity}</td>
                            <td className="py-2 px-2 text-right font-mono text-slate-700">{formatRupiah(item.unitPrice)}</td>
                            <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">{formatRupiah(item.subtotal)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {/* Printable Payment History Table */}
                  <div className="my-4 pt-3 border-t border-slate-300">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">
                        Riwayat Penerimaan Pembayaran & Cicilan Konsumen:
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {previewHistory.length} Transaksi Tercatat
                      </span>
                    </div>
                    {previewHistory.length === 0 ? (
                      <p className="text-xs text-slate-400 italic py-1">
                        Belum ada pembayaran yang tercatat untuk faktur ini.
                      </p>
                    ) : (
                      <div className="overflow-x-auto -mx-2 px-2">
                        <table className="w-full text-left border-collapse text-xs min-w-[320px]">
                          <thead>
                            <tr className="bg-slate-100 border-y border-slate-300 font-bold text-slate-700 text-[10px] uppercase">
                              <th className="py-1.5 px-2">No</th>
                              <th className="py-1.5 px-2">Waktu Pembayaran</th>
                              <th className="py-1.5 px-2">Metode & Ref</th>
                              <th className="py-1.5 px-2">Kasir</th>
                              <th className="py-1.5 px-2">Keterangan</th>
                              <th className="py-1.5 px-2 text-right">Nominal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {previewHistory.map((p, idx) => (
                              <tr key={p.id || idx}>
                                <td className="py-1.5 px-2 font-mono text-slate-500">{idx + 1}</td>
                                <td className="py-1.5 px-2 font-mono text-slate-700">{p.date}</td>
                                <td className="py-1.5 px-2 text-slate-800 font-medium">
                                  {p.paymentMethod} {p.referenceNumber ? `[${p.referenceNumber}]` : ''}
                                </td>
                                <td className="py-1.5 px-2 text-slate-600">{p.receivedBy?.userName || targetPreviewInvoice.createdBy.userName}</td>
                                <td className="py-1.5 px-2 text-slate-600 italic">{p.notes || '-'}</td>
                                <td className="py-1.5 px-2 text-right font-mono font-bold text-slate-900">{formatRupiah(p.amount)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                  {/* Totals */}
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pt-3 border-t-2 border-slate-900">
                    <div className="text-xs text-slate-500 max-w-sm space-y-1.5">
                      <p className="font-semibold text-slate-700">Catatan & Ketentuan:</p>
                      <p className="leading-relaxed">{targetPreviewInvoice.notes || companyProfile?.invoiceNotes || 'Barang yang sudah dibeli telah dicek sesuai dengan spesifikasi.'}</p>
                      {((companyProfile?.bankAccounts && companyProfile.bankAccounts.length > 0) || companyProfile?.bankAccountNo) && (
                        <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-[10px] text-slate-700 mt-2 space-y-1.5">
                          <div className="flex items-center justify-between pb-1 border-b border-slate-200/90">
                            <span className="font-bold text-slate-800 text-[9.5px] uppercase font-sans tracking-wide">
                              Pembayaran Transfer Bank / QRIS:
                            </span>
                            <span className="text-[9px] text-slate-500 font-mono">
                              {(companyProfile?.bankAccounts?.length || 1)} Rekening Resmi
                            </span>
                          </div>

                          <div className="space-y-1 font-mono text-[10px]">
                            {companyProfile?.bankAccounts && companyProfile.bankAccounts.length > 0 ? (
                              companyProfile.bankAccounts.map((acc, idx) => (
                                <div
                                  key={acc.id || idx}
                                  className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-0.5 border-b border-dashed border-slate-200/80 last:border-b-0 gap-0.5"
                                >
                                  <div>
                                    <span className="font-bold text-slate-900 font-sans mr-1.5 bg-slate-200/90 px-1 py-0.5 rounded text-[9px]">
                                      {acc.bankName}
                                    </span>
                                    <strong className="text-slate-900 text-[10.5px] tracking-wide">{acc.accountNumber}</strong>
                                    <span className="text-slate-600 font-sans text-[9px] ml-1">a/n {acc.holderName}</span>
                                    {acc.isPrimary && (
                                      <span className="ml-1 text-[8px] text-emerald-700 bg-emerald-100 font-semibold px-1 py-0.2 rounded font-sans">
                                        Utama
                                      </span>
                                    )}
                                  </div>
                                  {acc.notes && (
                                    <span className="text-[9px] text-slate-500 italic font-sans">{acc.notes}</span>
                                  )}
                                </div>
                              ))
                            ) : (
                              <div>
                                <span>Bank {companyProfile.bankName} - No. Rek: <strong>{companyProfile.bankAccountNo}</strong></span>
                                <span className="block text-slate-600">a/n {companyProfile.bankAccountHolder}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                      {companyProfile?.invoiceFooterNotice && (
                        <p className="text-[10px] text-slate-500 italic mt-1">
                          "{companyProfile.invoiceFooterNotice}"
                        </p>
                      )}
                      <p className="text-[10.5px] text-slate-400 mt-1 font-mono">
                        Petugas Kasir: <strong>{targetPreviewInvoice.createdBy.userName}</strong>
                      </p>
                    </div>
                    <div className="w-full sm:w-64 space-y-1.5 text-xs">
                      <div className="flex justify-between text-slate-600">
                        <span>Subtotal:</span>
                        <span className="font-mono">{formatRupiah(targetPreviewInvoice.subtotal)}</span>
                      </div>
                      {targetPreviewInvoice.discountTotal > 0 && (
                        <div className="flex justify-between text-rose-600">
                          <span>Diskon:</span>
                          <span className="font-mono">-{formatRupiah(targetPreviewInvoice.discountTotal)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-base font-extrabold text-slate-900 pt-2 border-t border-slate-300">
                        <span>Total Tagihan:</span>
                        <span className="font-mono text-emerald-700">{formatRupiah(targetPreviewInvoice.grandTotal)}</span>
                      </div>
                      <div className="flex justify-between text-slate-700 font-semibold">
                        <span>Total Sudah Terbayar:</span>
                        <span className="font-mono text-emerald-700 font-bold">{formatRupiah(previewTotalPaid)}</span>
                      </div>
                      <div className={`flex justify-between font-bold pt-1 border-t border-slate-200 ${
                        previewUnpaid <= 0 ? 'text-emerald-700' : 'text-rose-700'
                      }`}>
                        <span>Sisa Tagihan (Kekurangan):</span>
                        <span className="font-mono text-sm font-extrabold">
                          {formatRupiah(previewUnpaid)} {previewUnpaid <= 0 ? '(LUNAS)' : ''}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Signatures */}
                  <div className="grid grid-cols-2 gap-4 mt-8 pt-4 text-center text-xs text-slate-600 border-t border-slate-200">
                    <div>
                      <p>Tanda Terima Konsumen,</p>
                      <div className="h-14"></div>
                      <p className="font-semibold text-slate-900 border-t border-slate-400 inline-block px-8">
                        ( {targetPreviewInvoice.customerName} )
                      </p>
                    </div>
                    <div>
                      <p>{companyProfile?.signerTitle1 || 'Hormat Kami / Bagian Gudang'},</p>
                      <div className="h-14"></div>
                      <p className="font-semibold text-slate-900 border-t border-slate-400 inline-block px-8">
                        ( {targetPreviewInvoice.createdBy.userName} )
                      </p>
                    </div>
                  </div>
                </div>

                {/* Quick Status and Installment Action banner inside modal */}
                {previewUnpaid > 0 && (
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                      <span className="text-slate-300">
                        Sisa tagihan belum lunas: <strong className="text-rose-400 font-mono font-bold">{formatRupiah(previewUnpaid)}</strong>
                      </span>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => setSelectedPaymentInvoiceId(targetPreviewInvoice.id)}
                        className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold flex items-center justify-center gap-1.5 shrink-0 active:scale-95 transition-all shadow-sm"
                      >
                        <Receipt className="w-3.5 h-3.5" />
                        <span>+ Catat Cicilan Baru</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          onUpdateInvoiceStatus(targetPreviewInvoice.id, 'lunas', targetPreviewInvoice.grandTotal);
                          confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
                        }}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center justify-center gap-1 shrink-0 active:scale-95 transition-all"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Tandai Lunas Penuh</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Modal Bottom Footer Actions */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-800/80">
                  <span className="text-xs text-slate-400 text-center sm:text-left">
                    💡 Faktur diformat standar A4. Simpan langsung sebagai file <strong>PDF</strong> atau cetak lewat printer.
                  </span>
                  <div className="flex items-center gap-2 ml-auto w-full sm:w-auto justify-end">
                    <button
                      type="button"
                      onClick={() => setPreviewInvoice(null)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Tutup
                    </button>
                    <button
                      type="button"
                      onClick={handlePrintInvoice}
                      className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer active:scale-95"
                    >
                      <Printer className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Cetak (Print)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaveInvoicePdf(targetPreviewInvoice)}
                      disabled={isSavingInvoicePdf}
                      className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer active:scale-95"
                    >
                      {isSavingInvoicePdf ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                      ) : (
                        <FileDown className="w-3.5 h-3.5" />
                      )}
                      <span>{isSavingInvoicePdf ? 'Menyimpan PDF...' : 'Simpan PDF (Download)'}</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* DEDICATED PAYMENT HISTORY & INSTALLMENT MODAL */}
      {activePaymentInvoice && (
        <PaymentHistoryModal
          invoice={activePaymentInvoice}
          isOpen={Boolean(selectedPaymentInvoiceId)}
          onClose={() => setSelectedPaymentInvoiceId(null)}
          currentUser={currentUser}
          onRecordPayment={onRecordPayment}
          onDeletePayment={onDeletePayment}
          onViewInvoice={(inv) => {
            setSelectedPaymentInvoiceId(null);
            setPreviewInvoice(inv);
          }}
        />
      )}

      {/* MODAL EDIT FAKTUR PENJUALAN */}
      {editingInvoice && (() => {
        const editSubtotal = editItems.reduce((acc, item) => acc + item.subtotal, 0);
        const editTaxAmount = (editSubtotal * (Number(editTaxPercent) || 0)) / 100;
        const editGrandTotal = editSubtotal + editTaxAmount;

        return (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
              {/* Header */}
              <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                    <Edit3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-white">Edit Faktur Penjualan</h3>
                    <p className="text-[11px] text-amber-300 font-mono">
                      No. Faktur: <strong>{editingInvoice.invoiceNumber}</strong>
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingInvoice(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Form Content */}
              <form onSubmit={handleSaveEditInvoice} className="flex flex-col flex-1 overflow-hidden">
                <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
                  {/* Customer Information */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                    <h4 className="font-bold text-slate-300 flex items-center gap-1.5 text-xs">
                      <Users className="w-4 h-4 text-amber-400" />
                      <span>Data Pelanggan & Konsumen</span>
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Nama Pelanggan / Usaha *</label>
                        <input
                          type="text"
                          required
                          value={editCustomerName}
                          onChange={(e) => setEditCustomerName(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Nomor WhatsApp / Kontak</label>
                        <input
                          type="text"
                          value={editCustomerPhone}
                          onChange={(e) => setEditCustomerPhone(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Alamat Pelanggan</label>
                        <input
                          type="text"
                          value={editCustomerAddress}
                          onChange={(e) => setEditCustomerAddress(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Dates & Payment Details */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                    <h4 className="font-bold text-slate-300 flex items-center gap-1.5 text-xs">
                      <Calendar className="w-4 h-4 text-cyan-400" />
                      <span>Tanggal & Termin Faktur</span>
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Tanggal Faktur</label>
                        <input
                          type="date"
                          value={editDate}
                          onChange={(e) => setEditDate(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Metode Pembayaran</label>
                        <input
                          type="text"
                          value={editPaymentMethod}
                          onChange={(e) => setEditPaymentMethod(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div className="sm:col-span-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                        <DueDateSelector
                          value={editDueDate}
                          onChange={setEditDueDate}
                          label="Batas Tanggal Jatuh Tempo"
                          helperText="Pilih batas jatuh tempo: Tanpa batas (tidak terbatas), atau aksi cepat 2 minggu, 1 bulan, 2 bulan."
                          colorTheme="cyan"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Catatan / Keterangan</label>
                        <input
                          type="text"
                          value={editNotes}
                          onChange={(e) => setEditNotes(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1 font-medium">Pajak PPN (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          step="0.1"
                          value={editTaxPercent}
                          onChange={(e) => setEditTaxPercent(Number(e.target.value) || 0)}
                          className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Items List in Invoice */}
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-3">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-850 pb-3">
                      <div>
                        <h4 className="font-bold text-slate-300 flex items-center gap-1.5 text-xs">
                          <FileText className="w-4 h-4 text-emerald-400" />
                          <span>Item Bahan Baku dalam Faktur</span>
                        </h4>
                        <span className="text-[11px] text-slate-500 font-mono">
                          {editItems.length} Produk dalam transaksi ini
                        </span>
                      </div>

                      {/* Header Button to Add Item */}
                      <button
                        type="button"
                        onClick={() => handleAddEditItem()}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer shrink-0"
                        title="Tambah baris item bahan baku ke faktur"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>+ Tambah Item Produk</span>
                      </button>
                    </div>

                    {/* Quick Add Product Dropdown Bar */}
                    <div className="p-2.5 bg-slate-900/90 rounded-xl border border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <div className="flex-1">
                        <select
                          value={editSelectedProductId}
                          onChange={(e) => setEditSelectedProductId(e.target.value)}
                          className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500"
                        >
                          <option value="">-- Pilih bahan baku untuk langsung ditambahkan --</option>
                          {products.map((p) => {
                            const isAlreadyIn = editItems.some((ei) => ei.productId === p.id);
                            return (
                              <option key={p.id} value={p.id}>
                                {p.name} ({p.code}) • Stok: {p.currentStock} {p.unit} • {formatRupiah(p.sellingPrice)} {isAlreadyIn ? '✓ (Sudah ada)' : ''}
                              </option>
                            );
                          })}
                        </select>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (editSelectedProductId) {
                            handleAddEditItem(editSelectedProductId);
                            setEditSelectedProductId('');
                          } else {
                            handleAddEditItem();
                          }
                        }}
                        className="px-3 py-1.5 bg-emerald-600/25 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambahkan ke Faktur</span>
                      </button>
                    </div>

                    <div className="space-y-2">
                      {editItems.map((item, idx) => {
                        const originalItem = editingInvoice.items.find((orig) => orig.productId === item.productId);
                        const matchedProd = products.find((p) => p.id === item.productId);
                        const currentStock = matchedProd?.currentStock ?? 0;
                        const origQty = originalItem?.quantity ?? 0;
                        const diffQty = item.quantity - origQty;
                        const projectedStock = Math.max(0, currentStock - diffQty);

                        return (
                          <div key={item.productId || idx} className="p-3 bg-slate-900/90 rounded-xl border border-slate-800 space-y-2">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <select
                                    value={item.productId}
                                    onChange={(e) => handleUpdateEditItemProduct(idx, e.target.value)}
                                    className="bg-slate-950 border border-slate-750 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:outline-none focus:border-amber-500 max-w-full"
                                  >
                                    <option value="">-- Pilih Bahan Baku --</option>
                                    {products.map((p) => (
                                      <option key={p.id} value={p.id}>
                                        {p.name} ({p.code}) • Stok: {p.currentStock} {p.unit}
                                      </option>
                                    ))}
                                  </select>
                                  {item.productId ? (
                                    <span className="text-[10px] text-cyan-400 font-mono bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                                      {item.productCode} • {item.unit}
                                    </span>
                                  ) : (
                                    <span className="text-[10px] text-amber-300 font-semibold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                                      Belum dipilih
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] text-slate-400 mt-1 block">
                                  {item.productId ? (
                                    <>Stok gudang saat ini: <strong className="text-slate-200">{currentStock} {item.unit}</strong></>
                                  ) : (
                                    <span className="text-slate-500 italic">Pilih bahan baku di atas untuk memuat data stok & harga otomatis</span>
                                  )}
                                </span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemoveEditItem(idx)}
                                title="Hapus item ini dari faktur"
                                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer shrink-0"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>

                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                              <div>
                                <label className="text-[10px] text-slate-400 block mb-0.5">Jumlah ({item.unit || 'Qty'})</label>
                                <input
                                  type="number"
                                  min="1"
                                  value={item.quantity}
                                  onChange={(e) => handleUpdateEditItemQty(idx, Number(e.target.value))}
                                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-slate-400 block mb-0.5">Harga Jual Satuan</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={item.unitPrice}
                                  onChange={(e) => handleUpdateEditItemPrice(idx, Number(e.target.value))}
                                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-slate-400 block mb-0.5">Diskon Item</label>
                                <input
                                  type="number"
                                  min="0"
                                  value={item.discount || 0}
                                  onChange={(e) => handleUpdateEditItemDiscount(idx, Number(e.target.value))}
                                  className="w-full px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-slate-400 block mb-0.5">Subtotal</label>
                                <div className="px-2.5 py-1.5 bg-slate-950/60 border border-slate-850 rounded-lg text-emerald-400 font-mono font-bold text-xs truncate">
                                  {formatRupiah(item.subtotal)}
                                </div>
                              </div>
                            </div>

                            {/* Stock Adjustment Hint */}
                            {Boolean(item.productId && diffQty !== 0) && (
                              <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-850">
                                <span>Perubahan Kuantiti: <strong className={diffQty > 0 ? 'text-amber-400' : 'text-emerald-400'}>{diffQty > 0 ? `+${diffQty}` : diffQty} {item.unit}</strong></span>
                                <span>Estimasi Stok Fisik: <strong className="text-cyan-300 font-mono">{projectedStock} {item.unit}</strong></span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Bottom Add Item Line Button */}
                    <button
                      type="button"
                      onClick={() => handleAddEditItem()}
                      className="w-full py-2.5 border border-dashed border-slate-750 hover:border-emerald-500/60 rounded-xl text-xs font-semibold text-slate-400 hover:text-emerald-300 bg-slate-900/40 hover:bg-emerald-950/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4 text-emerald-400" />
                      <span>+ Tambah Baris Bahan Baku Baru</span>
                    </button>

                    {/* Summary Calculation */}
                    <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1.5 font-mono text-xs">
                      <div className="flex justify-between text-slate-400">
                        <span>Subtotal Item:</span>
                        <span className="text-white">{formatRupiah(editSubtotal)}</span>
                      </div>
                      {editTaxPercent > 0 && (
                        <div className="flex justify-between text-slate-400">
                          <span>PPN ({editTaxPercent}%):</span>
                          <span className="text-cyan-400">+{formatRupiah(editTaxAmount)}</span>
                        </div>
                      )}
                      <div className="flex justify-between text-sm font-bold text-white pt-1.5 border-t border-slate-800">
                        <span>Total Tagihan Baru:</span>
                        <span className="text-emerald-400 font-extrabold">{formatRupiah(editGrandTotal)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Footer Buttons */}
                <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-end gap-2.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => setEditingInvoice(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer active:scale-95"
                  >
                    <Check className="w-4 h-4" />
                    <span>Simpan Perubahan Faktur</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* MODAL HAPUS FAKTUR PENJUALAN & REVERT STOK */}
      {deletingInvoice && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-rose-500/30 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Header */}
            <div className="p-4 sm:p-5 bg-rose-950/40 border-b border-rose-500/20 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">Konfirmasi Hapus Faktur</h3>
                  <p className="text-[11px] text-rose-300 font-mono">
                    {deletingInvoice.invoiceNumber}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeletingInvoice(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 space-y-4 text-xs">
              <p className="text-slate-300 leading-relaxed">
                Apakah Anda yakin ingin menghapus faktur invoice <strong className="text-white font-mono">{deletingInvoice.invoiceNumber}</strong> untuk pelanggan <strong className="text-white">{deletingInvoice.customerName}</strong>?
              </p>

              {/* Warning on Stock Revert */}
              <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-[11px] text-rose-200 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-rose-300">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>Pengembalian Stok Fisik Otomatis ke Gudang:</span>
                </div>
                <p className="text-rose-200/90 leading-relaxed">
                  Menghapus faktur ini akan membatalkan riwayat mutasi keluar dan <strong>mengembalikan seluruh kuantiti bahan</strong> di bawah ini kembali ke stok gudang:
                </p>
                <div className="bg-slate-950/80 p-2.5 rounded-lg border border-rose-900/50 space-y-1">
                  {deletingInvoice.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between items-center text-xs font-mono">
                      <span className="text-slate-300 truncate max-w-[240px]">{item.productName}</span>
                      <span className="text-emerald-400 font-bold">+{item.quantity} {item.unit}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Invoice Summary */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>Tanggal Transaksi:</span>
                  <span className="font-mono text-white">{deletingInvoice.date}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Total Tagihan:</span>
                  <span className="font-mono font-bold text-emerald-400">{formatRupiah(deletingInvoice.grandTotal)}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Status Pembayaran:</span>
                  <span className={`font-bold px-1.5 py-0.5 rounded text-[10px] ${
                    deletingInvoice.paymentStatus === 'lunas'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : 'bg-rose-500/20 text-rose-300'
                  }`}>
                    {deletingInvoice.paymentStatus === 'lunas' ? 'Lunas' : 'Belum Lunas / Piutang'}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setDeletingInvoice(null)}
                  disabled={isDeletingInvoice}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDeleteInvoice}
                  disabled={isDeletingInvoice}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer active:scale-95"
                >
                  {isDeletingInvoice ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4" />
                  )}
                  <span>Ya, Hapus Faktur & Kembalikan Stok</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL PRATINJAU & CETAK REKAPITULASI DAFTAR FAKTUR PENJUALAN   */}
      {/* ============================================================== */}
      {showInvoicesListRecapModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Top Header */}
            <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Pratinjau Cetak Rekapitulasi Faktur Penjualan
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Menampilkan {filteredInvoices.length} faktur yang difilter • Siap cetak & ekspor PDF (A4 Landscape)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintInvoicesList}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                  title="Cetak langsung via printer"
                >
                  <Printer className="w-4 h-4 text-cyan-400" />
                  <span className="hidden sm:inline">Cetak Langsung</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveInvoicesListPdf}
                  disabled={isSavingInvoicesListPdf}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors shadow-xs shadow-cyan-950/40 cursor-pointer disabled:opacity-50"
                  title="Download File PDF Resmi"
                >
                  {isSavingInvoicesListPdf ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Memproses PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-4 h-4" />
                      <span>Unduh File PDF</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setShowInvoicesListRecapModal(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Success notification banner */}
            {invoicesListPdfSuccess && (
              <div className="bg-emerald-950/80 border-b border-emerald-500/40 px-4 py-2 text-xs text-emerald-300 font-medium flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{invoicesListPdfSuccess}</span>
              </div>
            )}

            {/* Modal Body: Printable Document Sheet */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
              <div
                id="printable-invoices-list-recap"
                className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-5xl mx-auto space-y-6"
              >
                <PrintableInvoicesListDocumentContent
                  filteredInvoices={filteredInvoices}
                  companyProfile={companyProfile}
                  currentUser={currentUser}
                  statusFilter={statusFilter}
                  customerFilter={customerFilter}
                  dateFilterLabel={dateFilterLabel}
                  searchQuery={searchQuery}
                  filteredTotalGrand={filteredTotalGrand}
                  filteredTotalPaid={filteredTotalPaid}
                  filteredTotalUnpaid={filteredTotalUnpaid}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Offscreen Printable Document - Mounted when modal is closed to allow instant direct Print / PDF export */}
      {!showInvoicesListRecapModal && (
        <div 
          style={{ position: 'fixed', left: '-9999px', top: 0, width: '1120px', zIndex: -99, pointerEvents: 'none', opacity: 0 }}
          aria-hidden="true"
        >
          <div
            id="printable-invoices-list-recap"
            className="bg-white text-slate-900 p-6 sm:p-8 font-sans text-xs space-y-6"
          >
            <PrintableInvoicesListDocumentContent
              filteredInvoices={filteredInvoices}
              companyProfile={companyProfile}
              currentUser={currentUser}
              statusFilter={statusFilter}
              customerFilter={customerFilter}
              dateFilterLabel={dateFilterLabel}
              searchQuery={searchQuery}
              filteredTotalGrand={filteredTotalGrand}
              filteredTotalPaid={filteredTotalPaid}
              filteredTotalUnpaid={filteredTotalUnpaid}
            />
          </div>
        </div>
      )}

      {/* FLOATING ACTION TOAST */}
      {invoiceToast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-5 duration-300">
          <div className={`px-4 py-3 rounded-xl shadow-2xl border text-xs font-semibold flex items-center gap-2 max-w-md ${
            invoiceToast.type === 'success'
              ? 'bg-slate-900 border-emerald-500/50 text-emerald-300 shadow-emerald-950/40'
              : 'bg-slate-900 border-rose-500/50 text-rose-300 shadow-rose-950/40'
          }`}>
            {invoiceToast.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{invoiceToast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
};
