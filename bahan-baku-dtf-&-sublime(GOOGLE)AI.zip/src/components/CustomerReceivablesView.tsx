import React, { useState, useMemo } from 'react';
import { 
  CreditCard, 
  Search, 
  Printer, 
  FileDown, 
  Clock, 
  AlertTriangle, 
  CheckCircle2, 
  Phone, 
  MessageSquare, 
  Copy, 
  Check, 
  Eye, 
  Receipt, 
  Building2, 
  Users, 
  ChevronDown, 
  ChevronUp, 
  Calendar, 
  ArrowUpDown,
  Filter,
  X,
  ExternalLink,
  Loader2,
  FileText,
  DollarSign,
  AlertCircle,
  Trash2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Invoice, CustomerItem, User, CompanyProfile } from '../types';
import { 
  formatRupiah, 
  formatDateIndo, 
  formatDueDateIndo,
  getInvoiceDueInfo, 
  formatWaPhone,
  generateCustomerConsolidatedWaReminder
} from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';

interface CustomerReceivablesViewProps {
  invoices: Invoice[];
  customers?: CustomerItem[];
  currentUser: User;
  companyProfile?: CompanyProfile;
  onRecordPayment?: (
    invoiceId: string,
    paymentData: {
      amount: number;
      paymentMethod: string;
      referenceNumber?: string;
      notes?: string;
      date?: string;
      nextDueDate?: string;
    }
  ) => void;
  onDeletePayment?: (invoiceId: string, paymentId: string) => void;
  onUpdateInvoiceStatus: (invoiceId: string, status: 'lunas' | 'belum_lunas' | 'dp', paidAmount: number) => void;
  onViewInvoice: (invoice: Invoice) => void;
  onOpenPaymentModal: (invoiceId: string) => void;
  onDeleteInvoice?: (invoiceId: string) => { success: boolean; message?: string };
}

interface CustomerGroupData {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  invoices: Invoice[];
  unpaidInvoices: Invoice[];
  totalInvoiced: number;
  totalPaid: number;
  totalReceivable: number;
  overdueInvoicesCount: number;
  dueTodayCount: number;
  upcomingCount: number;
  earliestDueDate: string;
  latestDueDate: string;
  paymentRatio: number;
  hasOverdue: boolean;
}

interface PrintableSingleCustomerContentProps {
  targetCustomer: CustomerGroupData;
  companyProfile?: CompanyProfile;
  currentUser: User;
  elementId?: string;
  orientation?: 'portrait' | 'landscape';
}

const PrintableSingleCustomerContent: React.FC<PrintableSingleCustomerContentProps> = ({
  targetCustomer,
  companyProfile,
  currentUser,
  elementId = 'printable-single-customer-recap',
  orientation = 'landscape',
}) => {
  const cleanPhone = targetCustomer.customerPhone || '-';
  const cleanAddress = targetCustomer.customerAddress || '-';
  const isLandscape = orientation === 'landscape';

  return (
    <div
      id={elementId}
      className={`bg-white text-slate-900 p-5 sm:p-7 rounded-xl font-sans text-xs mx-auto space-y-4 shadow-lg ${
        isLandscape ? 'w-full max-w-[1060px]' : 'w-full max-w-[780px]'
      }`}
      style={{ boxSizing: 'border-box' }}
    >
      {/* Kop Surat Perusahaan */}
      <div className="flex justify-between items-start gap-4 pb-3.5 border-b-2 border-slate-900">
        <div className="flex items-start gap-3 sm:gap-4 flex-1 min-w-0">
          {companyProfile?.logoUrl ? (
            <div className="w-13 h-13 sm:w-15 sm:h-15 rounded-xl border border-slate-200 bg-white p-1 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
              <img
                src={companyProfile.logoUrl}
                alt={companyProfile.companyName || 'Logo Perusahaan'}
                className="w-full h-full object-contain"
              />
            </div>
          ) : (
            <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-xl bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-sm sm:text-base shrink-0">
              {companyProfile?.shortName || companyProfile?.appLogoBadge || 'DTF'}
            </div>
          )}
          <div className="min-w-0 flex-1">
            <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 block">
              SURAT REKAPITULASI PIUTANG KONSUMEN
            </span>
            <h1 className="text-base sm:text-xl font-black text-slate-900 tracking-tight mt-0.5 break-words">
              {companyProfile?.companyName || 'GUDANG SUPLAI SABLON DTF & SUBLIME'}
            </h1>
            <p className="text-[10.5px] text-slate-600 mt-0.5 line-clamp-1">
              {companyProfile?.tagline || 'Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey & Merchandise'}
            </p>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {companyProfile?.address || 'Bandung'} • Telp: {companyProfile?.phone || '0812-9988-7766'} • Email: {companyProfile?.email || 'logistik@dtfsublime.id'}
            </p>
          </div>
        </div>
        <div className="text-right shrink-0 max-w-[280px]">
          <span className="inline-block px-2.5 py-0.5 rounded bg-slate-900 text-white font-extrabold text-[10px] tracking-wider uppercase">
            KARTU PIUTANG KONSUMEN
          </span>
          <p className="font-mono font-bold text-[10.5px] text-slate-800 mt-1.5 break-all">
            REF: KARTU-{targetCustomer.customerName.replace(/[^a-zA-Z0-9]/g, '').slice(0, 5).toUpperCase()}-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
          </p>
          <p className="text-[10px] text-slate-600 mt-0.5">
            Tanggal: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
          <p className="text-[10px] text-slate-600">
            Petugas: <strong>{currentUser.name}</strong> ({currentUser.roleTitle || 'Kasir/Admin'})
          </p>
        </div>
      </div>

      {/* Box Info Konsumen & Status */}
      <div className="grid grid-cols-2 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-300">
        <div className="space-y-0.5 min-w-0">
          <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 block">
            INFORMASI KONSUMEN
          </span>
          <p className="text-sm font-black text-slate-900 break-words">{targetCustomer.customerName}</p>
          <p className="text-[11px] text-slate-700 font-mono">No. Telp / WA: {cleanPhone}</p>
          <p className="text-[11px] text-slate-600 break-words">Alamat: {cleanAddress}</p>
        </div>
        <div className="space-y-0.5 text-right min-w-0">
          <span className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 block">
            STATUS REKAPITULASI
          </span>
          <span className={`inline-block font-extrabold text-[10.5px] px-2 py-0.5 rounded border ${
            targetCustomer.totalReceivable > 0
              ? 'bg-rose-100 text-rose-800 border-rose-300'
              : 'bg-emerald-100 text-emerald-800 border-emerald-300'
          }`}>
            {targetCustomer.totalReceivable > 0 ? '⚠️ MEMILIKI SISA PIUTANG' : '✅ SELURUH FAKTUR LUNAS'}
          </span>
          <p className="text-[11px] text-slate-700 mt-0.5">
            Total: <strong>{targetCustomer.invoices.length} Faktur</strong> ({targetCustomer.unpaidInvoices.length} Belum Lunas)
          </p>
          {targetCustomer.totalReceivable > 0 && targetCustomer.earliestDueDate && (
            <p className="text-[10.5px] text-slate-600">
              Jatuh Tempo: <strong className="text-rose-700">{formatDueDateIndo(targetCustomer.earliestDueDate)}</strong>
            </p>
          )}
        </div>
      </div>

      {/* 3 Financial Summary Cards */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
          <span className="text-[9.5px] font-bold text-slate-500 uppercase block">Total Nilai Faktur</span>
          <span className="font-mono font-black text-sm sm:text-base text-slate-900 block mt-0.5">
            {formatRupiah(targetCustomer.totalInvoiced)}
          </span>
          <span className="text-[9px] text-slate-500">Akumulasi pembelanjaan</span>
        </div>
        <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
          <span className="text-[9.5px] font-bold text-slate-500 uppercase block">Total Pembayaran Masuk</span>
          <span className="font-mono font-black text-sm sm:text-base text-emerald-700 block mt-0.5">
            {formatRupiah(targetCustomer.totalPaid)}
          </span>
          <span className="text-[9px] text-slate-500">Terbayar {targetCustomer.paymentRatio}%</span>
        </div>
        <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-300">
          <span className="text-[9.5px] font-bold text-rose-700 uppercase block">Sisa Total Piutang</span>
          <span className="font-mono font-black text-sm sm:text-base text-rose-700 block mt-0.5">
            {formatRupiah(targetCustomer.totalReceivable)}
          </span>
          <span className="text-[9px] text-rose-600">Sisa saldo wajib dilunasi</span>
        </div>
      </div>

      {/* Tabel Rincian Faktur Konsumen */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider">
            Rincian Faktur Pembelian Konsumen ({targetCustomer.invoices.length} Faktur)
          </h3>
          <span className="text-[9.5px] text-slate-500 font-mono">
            {isLandscape ? 'Format Lanskap (Optimal)' : 'Format Potret'}
          </span>
        </div>
        <table className="w-full text-left border-collapse border border-slate-300 table-fixed">
          <colgroup>
            <col style={{ width: '3.5%' }} />
            <col style={{ width: '13.5%' }} />
            <col style={{ width: '9%' }} />
            <col style={{ width: '11%' }} />
            <col style={{ width: '25%' }} />
            <col style={{ width: '11%' }} />
            <col style={{ width: '10.5%' }} />
            <col style={{ width: '11%' }} />
            <col style={{ width: '5.5%' }} />
          </colgroup>
          <thead className="bg-slate-100 text-slate-700 font-bold text-[9.5px] uppercase border-b border-slate-300">
            <tr>
              <th className="py-2 px-1 text-center border-r border-slate-300">No</th>
              <th className="py-2 px-1.5 border-r border-slate-300">No. Faktur</th>
              <th className="py-2 px-1.5 border-r border-slate-300">Tanggal</th>
              <th className="py-2 px-1.5 border-r border-slate-300">Jatuh Tempo</th>
              <th className="py-2 px-2 border-r border-slate-300">Item Bahan / Jasa</th>
              <th className="py-2 px-1.5 text-right border-r border-slate-300">Total Faktur</th>
              <th className="py-2 px-1.5 text-right border-r border-slate-300">Terbayar</th>
              <th className="py-2 px-1.5 text-right border-r border-slate-300">Sisa Piutang</th>
              <th className="py-2 px-1 text-center">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {targetCustomer.invoices.map((inv, invIdx) => {
              const dueInfo = getInvoiceDueInfo(inv);
              const isUnpaid = inv.paymentStatus !== 'lunas' && dueInfo.unpaidAmount > 0;

              return (
                <tr key={inv.id} className={dueInfo.isOverdue && isUnpaid ? 'bg-rose-50/70' : ''}>
                  <td className="py-2 px-1 text-center font-mono text-slate-500 border-r border-slate-200 align-top text-[10px]">
                    {invIdx + 1}
                  </td>
                  <td className="py-2 px-1.5 font-mono font-bold text-slate-900 border-r border-slate-200 align-top text-[10px] break-words">
                    {inv.invoiceNumber}
                  </td>
                  <td className="py-2 px-1.5 font-mono text-slate-600 border-r border-slate-200 align-top text-[10px]">
                    {inv.date}
                  </td>
                  <td className="py-2 px-1.5 font-mono border-r border-slate-200 align-top text-[10px]">
                    {isUnpaid ? (
                      <div className="space-y-0.5 leading-tight">
                        <span className={dueInfo.isOverdue ? 'text-rose-700 font-bold block' : 'text-slate-800 block'}>
                          {formatDueDateIndo(inv.dueDate)}
                        </span>
                        {dueInfo.isOverdue && (
                          <span className="inline-block px-1 py-0.2 text-[8.5px] font-bold text-rose-700 bg-rose-100 rounded border border-rose-200 leading-tight">
                            Lewat {Math.abs(dueInfo.diffDays)} hr
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-emerald-700 font-semibold">-</span>
                    )}
                  </td>
                  <td className="py-2 px-2 text-slate-800 border-r border-slate-200 align-top text-[9.5px]">
                    {inv.items && inv.items.length > 0 ? (
                      <div className="space-y-1">
                        {inv.items.map((it, itIdx) => (
                          <div key={itIdx} className="leading-tight flex items-start gap-1">
                            {inv.items.length > 1 && (
                              <span className="text-cyan-700 font-bold select-none text-[9px] mt-0.5">•</span>
                            )}
                            <div className="min-w-0 flex-1">
                              <span className="font-semibold text-slate-900 break-words">{it.productName}</span>
                              <span className="text-slate-500 font-mono text-[9px] ml-1 bg-slate-100 px-1 py-0.5 rounded border border-slate-200 inline-block">
                                {it.quantity} {it.unit || 'pcs'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-400 italic text-[9.5px]">-</span>
                    )}
                  </td>
                  <td className="py-2 px-1.5 text-right font-mono text-slate-900 border-r border-slate-200 align-top text-[10px]">
                    {formatRupiah(inv.grandTotal)}
                  </td>
                  <td className="py-2 px-1.5 text-right font-mono text-emerald-700 border-r border-slate-200 align-top text-[10px]">
                    {formatRupiah(inv.paidAmount)}
                  </td>
                  <td className="py-2 px-1.5 text-right font-mono font-bold text-rose-700 border-r border-slate-200 align-top text-[10px]">
                    {formatRupiah(Math.max(0, inv.grandTotal - inv.paidAmount))}
                  </td>
                  <td className="py-2 px-1 text-center align-top">
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[8.5px] font-extrabold uppercase ${
                      inv.paymentStatus === 'lunas'
                        ? 'bg-emerald-100 text-emerald-800'
                        : inv.paymentStatus === 'dp'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {inv.paymentStatus === 'lunas' ? 'LUNAS' : inv.paymentStatus === 'dp' ? 'DP' : 'TEMPO'}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
          <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
            <tr>
              <td colSpan={5} className="py-2 px-2 text-right text-slate-800 border-r border-slate-300 text-[9.5px] uppercase font-bold tracking-wider">
                TOTAL KESELURUHAN:
              </td>
              <td className="py-2 px-1.5 text-right font-mono text-slate-900 border-r border-slate-300 text-[10px]">
                {formatRupiah(targetCustomer.totalInvoiced)}
              </td>
              <td className="py-2 px-1.5 text-right font-mono text-emerald-700 border-r border-slate-300 text-[10px]">
                {formatRupiah(targetCustomer.totalPaid)}
              </td>
              <td className="py-2 px-1.5 text-right font-mono font-bold text-rose-700 border-r border-slate-300 text-[10px]">
                {formatRupiah(targetCustomer.totalReceivable)}
              </td>
              <td className="py-2 px-1 text-center text-[10px] text-slate-500">
                -
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Rekening Pembayaran */}
      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex justify-between items-center text-xs">
        <div>
          <span className="font-bold text-slate-800 block text-[10.5px]">Rekening Resmi Pembayaran:</span>
          <p className="text-[10px] text-slate-600 mt-0.5">
            BCA: <strong>123-456-7890</strong> a.n. Gudang DTF & Sublime • Mandiri: <strong>987-654-3210</strong>
          </p>
        </div>
        <div className="text-right">
          <span className="text-[9.5px] text-slate-500 block">Harap konfirmasi via WhatsApp:</span>
          <span className="font-mono font-bold text-slate-800 text-[11px]">{companyProfile?.phone || '0812-9988-7766'}</span>
        </div>
      </div>

      {/* Signatures */}
      <div className="pt-4 border-t border-slate-200 grid grid-cols-3 gap-4 text-center text-xs">
        <div>
          <p className="text-slate-500 text-[10px]">Dibuat Oleh,</p>
          <div className="h-14 flex items-end justify-center">
            <p className="font-bold text-slate-900 border-b border-slate-400 pb-0.5 px-3 text-[11px]">
              {currentUser.name}
            </p>
          </div>
          <p className="text-[9.5px] text-slate-500 mt-0.5">{currentUser.roleTitle || 'Kasir / Petugas Admin'}</p>
        </div>
        <div>
          <p className="text-slate-500 text-[10px]">Diterima / Pelanggan,</p>
          <div className="h-14 flex items-end justify-center">
            <p className="font-bold text-slate-900 border-b border-slate-400 pb-0.5 px-3 text-[11px] break-words">
              {targetCustomer.customerName}
            </p>
          </div>
          <p className="text-[9.5px] text-slate-500 mt-0.5">Pihak Konsumen</p>
        </div>
        <div>
          <p className="text-slate-500 text-[10px]">Mengetahui,</p>
          <div className="h-14 flex items-end justify-center">
            <p className="font-bold text-slate-900 border-b border-slate-400 pb-0.5 px-3 text-[11px]">
              {companyProfile?.signerTitle3 || 'Pimpinan / Owner'}
            </p>
          </div>
          <p className="text-[9.5px] text-slate-500 mt-0.5">Manajemen</p>
        </div>
      </div>
    </div>
  );
};

export const CustomerReceivablesView: React.FC<CustomerReceivablesViewProps> = ({
  invoices,
  customers = [],
  currentUser,
  companyProfile,
  onRecordPayment,
  onDeletePayment,
  onUpdateInvoiceStatus,
  onViewInvoice,
  onOpenPaymentModal,
  onDeleteInvoice,
}) => {
  const isOwnerOrSpv = 
    currentUser.role === 'owner' || 
    currentUser.role === 'warehouse_admin' || 
    currentUser.roleTitle?.toLowerCase().includes('spv') || 
    currentUser.roleTitle?.toLowerCase().includes('supervisor') ||
    Boolean(currentUser.canDeleteSalesInvoice);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all_debt' | 'overdue' | 'due_week' | 'all'>('all_debt');
  const [sortOption, setSortOption] = useState<'debt_desc' | 'urgent' | 'name_asc' | 'invoices_count'>('debt_desc');
  const [expandedCustomers, setExpandedCustomers] = useState<Record<string, boolean>>({});
  const [showRecapModal, setShowRecapModal] = useState<boolean>(false);
  const [isSavingPdf, setIsSavingPdf] = useState<boolean>(false);
  const [pdfSuccessMsg, setPdfSuccessMsg] = useState<string | null>(null);
  const [copiedCustomerId, setCopiedCustomerId] = useState<string | null>(null);
  const [selectedCustomerForPrint, setSelectedCustomerForPrint] = useState<CustomerGroupData | null>(null);
  const [customerToPreview, setCustomerToPreview] = useState<CustomerGroupData | null>(null);
  const [isSavingCustomerPdf, setIsSavingCustomerPdf] = useState<string | null>(null);
  const [singleCustomerOrientation, setSingleCustomerOrientation] = useState<'portrait' | 'landscape'>('landscape');
  const [customerToDelete, setCustomerToDelete] = useState<CustomerGroupData | null>(null);
  const [invoiceToDelete, setInvoiceToDelete] = useState<Invoice | null>(null);
  const [isDeletingCustomer, setIsDeletingCustomer] = useState(false);
  const [deleteNotification, setDeleteNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Group invoices by Customer Name
  const customerGroups = useMemo(() => {
    const map = new Map<string, CustomerGroupData>();

    invoices.forEach((inv) => {
      const nameKey = (inv.customerName || 'Pelanggan Umum').trim();
      const lowerKey = nameKey.toLowerCase();

      // Find matching profile from customers array
      const matchedProfile = customers.find(
        (c) => c.name.trim().toLowerCase() === lowerKey
      );

      const phone = inv.customerPhone || matchedProfile?.phone || '-';
      const address = inv.customerAddress || matchedProfile?.address || '-';

      const dueInfo = getInvoiceDueInfo(inv);
      const isUnpaid = inv.paymentStatus !== 'lunas' && dueInfo.unpaidAmount > 0;

      if (!map.has(lowerKey)) {
        map.set(lowerKey, {
          customerName: nameKey,
          customerPhone: phone,
          customerAddress: address,
          invoices: [],
          unpaidInvoices: [],
          totalInvoiced: 0,
          totalPaid: 0,
          totalReceivable: 0,
          overdueInvoicesCount: 0,
          dueTodayCount: 0,
          upcomingCount: 0,
          earliestDueDate: inv.dueDate || '9999-12-31',
          latestDueDate: inv.dueDate || '',
          paymentRatio: 0,
          hasOverdue: false,
        });
      }

      const grp = map.get(lowerKey)!;
      grp.invoices.push(inv);
      grp.totalInvoiced += inv.grandTotal;
      grp.totalPaid += inv.paidAmount;

      if (isUnpaid) {
        grp.unpaidInvoices.push(inv);
        grp.totalReceivable += dueInfo.unpaidAmount;

        if (dueInfo.isOverdue) {
          grp.overdueInvoicesCount++;
          grp.hasOverdue = true;
        }
        if (dueInfo.isDueToday) grp.dueTodayCount++;
        if (dueInfo.isUpcoming) grp.upcomingCount++;

        if (inv.dueDate && inv.dueDate < grp.earliestDueDate) {
          grp.earliestDueDate = inv.dueDate;
        }
        if (inv.dueDate && inv.dueDate > grp.latestDueDate) {
          grp.latestDueDate = inv.dueDate;
        }
      }
    });

    // Compute ratios & sort invoices inside each customer
    const list: CustomerGroupData[] = [];
    map.forEach((grp) => {
      grp.paymentRatio = grp.totalInvoiced > 0 
        ? Math.min(100, Math.round((grp.totalPaid / grp.totalInvoiced) * 100)) 
        : 100;
      
      // Sort customer's invoices: unpaid first, then by date descending
      grp.invoices.sort((a, b) => {
        if (a.paymentStatus !== 'lunas' && b.paymentStatus === 'lunas') return -1;
        if (a.paymentStatus === 'lunas' && b.paymentStatus !== 'lunas') return 1;
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });

      list.push(grp);
    });

    return list;
  }, [invoices, customers]);

  // Overall Receivables Metrics
  const globalMetrics = useMemo(() => {
    let totalDebt = 0;
    let totalInvoicedAll = 0;
    let totalPaidAll = 0;
    let customersWithDebt = 0;
    let customersOverdue = 0;
    let overdueDebtAmount = 0;
    let dueThisMonthAmount = 0;

    const now = new Date();
    const currentYearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    customerGroups.forEach((grp) => {
      totalInvoicedAll += grp.totalInvoiced;
      totalPaidAll += grp.totalPaid;
      totalDebt += grp.totalReceivable;

      if (grp.totalReceivable > 0) {
        customersWithDebt++;
      }
      if (grp.hasOverdue) {
        customersOverdue++;
      }

      grp.unpaidInvoices.forEach((inv) => {
        const dueInfo = getInvoiceDueInfo(inv);
        if (dueInfo.isOverdue) {
          overdueDebtAmount += dueInfo.unpaidAmount;
        }
        if (inv.dueDate && inv.dueDate.startsWith(currentYearMonth)) {
          dueThisMonthAmount += dueInfo.unpaidAmount;
        }
      });
    });

    return {
      totalDebt,
      totalInvoicedAll,
      totalPaidAll,
      customersWithDebt,
      customersOverdue,
      overdueDebtAmount,
      dueThisMonthAmount,
      totalCustomers: customerGroups.length,
    };
  }, [customerGroups]);

  // Filtered customer groups based on search & filter tabs
  const filteredCustomers = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    return customerGroups
      .filter((grp) => {
        // Search query
        if (q) {
          const matchName = grp.customerName.toLowerCase().includes(q);
          const matchPhone = grp.customerPhone.includes(q);
          const matchAddress = grp.customerAddress.toLowerCase().includes(q);
          const matchInvoice = grp.invoices.some((inv) => inv.invoiceNumber.toLowerCase().includes(q));
          if (!matchName && !matchPhone && !matchAddress && !matchInvoice) return false;
        }

        // Filter Type
        if (filterType === 'all_debt') {
          return grp.totalReceivable > 0;
        }
        if (filterType === 'overdue') {
          return grp.hasOverdue && grp.totalReceivable > 0;
        }
        if (filterType === 'due_week') {
          return grp.totalReceivable > 0 && (grp.dueTodayCount > 0 || grp.upcomingCount > 0);
        }
        // 'all': return all customers
        return true;
      })
      .sort((a, b) => {
        if (sortOption === 'debt_desc') {
          return b.totalReceivable - a.totalReceivable;
        }
        if (sortOption === 'urgent') {
          if (a.hasOverdue && !b.hasOverdue) return -1;
          if (!a.hasOverdue && b.hasOverdue) return 1;
          return a.earliestDueDate.localeCompare(b.earliestDueDate);
        }
        if (sortOption === 'name_asc') {
          return a.customerName.localeCompare(b.customerName);
        }
        if (sortOption === 'invoices_count') {
          return b.unpaidInvoices.length - a.unpaidInvoices.length;
        }
        return 0;
      });
  }, [customerGroups, searchQuery, filterType, sortOption]);

  const toggleExpand = (customerName: string) => {
    setExpandedCustomers((prev) => ({
      ...prev,
      [customerName]: !prev[customerName],
    }));
  };

  const expandAll = () => {
    const next: Record<string, boolean> = {};
    filteredCustomers.forEach((c) => {
      next[c.customerName] = true;
    });
    setExpandedCustomers(next);
  };

  const collapseAll = () => {
    setExpandedCustomers({});
  };

  // WhatsApp Billing Link
  const handleSendCustomerWhatsApp = (grp: CustomerGroupData) => {
    if (grp.unpaidInvoices.length === 0) return;
    const msg = generateCustomerConsolidatedWaReminder(
      grp.customerName,
      grp.unpaidInvoices.map((i) => ({
        invoiceNumber: i.invoiceNumber,
        date: i.date,
        dueDate: i.dueDate,
        grandTotal: i.grandTotal,
        paidAmount: i.paidAmount,
      })),
      companyProfile?.companyName || 'Gudang DTF & Sublime'
    );
    const cleanPhone = formatWaPhone(grp.customerPhone);
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  const handleCopyWaMessage = (grp: CustomerGroupData) => {
    const msg = generateCustomerConsolidatedWaReminder(
      grp.customerName,
      grp.unpaidInvoices.map((i) => ({
        invoiceNumber: i.invoiceNumber,
        date: i.date,
        dueDate: i.dueDate,
        grandTotal: i.grandTotal,
        paidAmount: i.paidAmount,
      })),
      companyProfile?.companyName || 'Gudang DTF & Sublime'
    );
    navigator.clipboard.writeText(msg);
    setCopiedCustomerId(grp.customerName);
    setTimeout(() => setCopiedCustomerId(null), 3000);
  };

  // Print & PDF Export
  const handlePrintRecap = () => {
    setShowRecapModal(true);
    setTimeout(() => {
      printElementDirect('printable-customer-receivables-recap', 'landscape');
    }, 150);
  };

  const handlePrintSingleCustomer = (grp: CustomerGroupData, orient?: 'portrait' | 'landscape') => {
    const targetOrient = orient || singleCustomerOrientation;
    setSelectedCustomerForPrint(grp);
    setTimeout(() => {
      printElementDirect('printable-single-customer-recap', targetOrient);
    }, 120);
  };

  const handleSaveSingleCustomerPdf = async (grp: CustomerGroupData, orient?: 'portrait' | 'landscape') => {
    const targetOrient = orient || singleCustomerOrientation;
    setSelectedCustomerForPrint(grp);
    setIsSavingCustomerPdf(grp.customerName);
    try {
      await new Promise((resolve) => setTimeout(resolve, 150));
      const cleanName = grp.customerName.replace(/[^a-zA-Z0-9]/g, '_');
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `Rekap_Piutang_${cleanName}_${dateStr}.pdf`;
      const success = await exportElementToPdf('printable-single-customer-recap', filename, {
        orientation: targetOrient,
      });
      if (success) {
        setPdfSuccessMsg(`File PDF Rekap Piutang konsumen ${grp.customerName} berhasil diunduh (${targetOrient === 'landscape' ? 'Lanskap' : 'Potret'})!`);
        setTimeout(() => setPdfSuccessMsg(null), 4500);
      }
    } finally {
      setIsSavingCustomerPdf(null);
    }
  };

  const handleSaveRecapPdf = async () => {
    setShowRecapModal(true);
    setIsSavingPdf(true);
    setPdfSuccessMsg(null);
    try {
      await new Promise((resolve) => setTimeout(resolve, 200));
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `Rekap_Piutang_Pelanggan_${dateStr}.pdf`;
      const success = await exportElementToPdf('printable-customer-receivables-recap', filename, {
        orientation: 'landscape',
      });
      if (success) {
        setPdfSuccessMsg('File PDF Rekapitulasi Piutang Pelanggan berhasil diunduh!');
        setTimeout(() => setPdfSuccessMsg(null), 4500);
      }
    } finally {
      setIsSavingPdf(false);
    }
  };

  const handleConfirmDeleteCustomer = () => {
    if (!customerToDelete || !onDeleteInvoice) return;
    setIsDeletingCustomer(true);
    let successCount = 0;
    let lastError: string | null = null;

    customerToDelete.invoices.forEach((inv) => {
      const res = onDeleteInvoice(inv.id);
      if (res.success) {
        successCount++;
      } else {
        lastError = res.message || 'Gagal menghapus sebagian data faktur.';
      }
    });

    setIsDeletingCustomer(false);
    if (successCount > 0) {
      setDeleteNotification({
        type: 'success',
        message: `Berhasil menghapus ${successCount} data faktur lunas untuk pelanggan "${customerToDelete.customerName}".`,
      });
      setTimeout(() => setDeleteNotification(null), 4500);
      setCustomerToDelete(null);
    } else {
      setDeleteNotification({
        type: 'error',
        message: lastError || 'Gagal menghapus data faktur.',
      });
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Header & Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Rekapitulasi Piutang per Nama Pelanggan
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Buku besar saldo sisa tagihan, tempo pembayaran, dan penagihan terpusat per konsumen
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons: Direct Print, Direct Download PDF, & Preview */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            type="button"
            id="btn-direct-print-customer-receivables"
            onClick={handlePrintRecap}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold active:scale-95 transition-all shadow-xs cursor-pointer"
            title="Cetak langsung ke printer buku besar piutang pelanggan"
          >
            <Printer className="w-4 h-4 text-cyan-400" />
            <span>Cetak ({filteredCustomers.length})</span>
          </button>

          <button
            type="button"
            id="btn-preview-customer-receivables-modal"
            onClick={() => setShowRecapModal(true)}
            className="flex items-center gap-1 px-2.5 py-2 rounded-xl bg-slate-950 hover:bg-slate-850 text-slate-300 border border-slate-800 text-xs font-medium active:scale-95 transition-all cursor-pointer"
            title="Buka pratinjau lembar rekapitulasi sebelum mencetak"
          >
            <Eye className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Pratinjau</span>
          </button>
        </div>
      </div>

      {/* Direct PDF Success Banner */}
      {pdfSuccessMsg && !showRecapModal && (
        <div className="bg-emerald-950/80 border border-emerald-500/40 rounded-xl px-4 py-2.5 text-xs text-emerald-300 font-medium flex items-center justify-between gap-2 shadow-xs">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{pdfSuccessMsg}</span>
          </div>
          <button 
            type="button" 
            onClick={() => setPdfSuccessMsg(null)}
            className="text-slate-400 hover:text-white text-xs cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Delete Notification Banner */}
      {deleteNotification && (
        <div className={`rounded-xl px-4 py-2.5 text-xs font-medium flex items-center justify-between gap-2 shadow-xs border ${
          deleteNotification.type === 'success'
            ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
            : 'bg-rose-950/80 border-rose-500/40 text-rose-300'
        }`}>
          <div className="flex items-center gap-2">
            {deleteNotification.type === 'success' ? (
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{deleteNotification.message}</span>
          </div>
          <button 
            type="button" 
            onClick={() => setDeleteNotification(null)}
            className="text-slate-400 hover:text-white text-xs cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* 4 Financial Highlight Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Card 1: Total Sisa Piutang Berjalan */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-rose-300">Total Sisa Piutang</span>
            <div className="p-1.5 sm:p-2 rounded-xl bg-rose-500/20 text-rose-400">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold font-mono text-rose-400 mt-1 truncate">
            {formatRupiah(globalMetrics.totalDebt)}
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 block truncate">
            Dari <strong>{globalMetrics.customersWithDebt}</strong> pelanggan berpiutang
          </span>
        </div>

        {/* Card 2: Piutang Kritis / Lewat Tempo */}
        <div className={`border rounded-2xl p-3.5 sm:p-4 shadow-sm relative overflow-hidden ${
          globalMetrics.overdueDebtAmount > 0 
            ? 'bg-rose-500/10 border-rose-500/30' 
            : 'bg-slate-900 border-slate-800'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-amber-300">Lewat Jatuh Tempo</span>
            <div className="p-1.5 sm:p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Clock className="w-4 h-4 animate-pulse" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold font-mono text-amber-300 mt-1 truncate">
            {formatRupiah(globalMetrics.overdueDebtAmount)}
          </p>
          <span className="text-[10px] sm:text-[11px] text-amber-400/80 mt-0.5 block truncate">
            <strong>{globalMetrics.customersOverdue}</strong> pelanggan perlu ditagih
          </span>
        </div>

        {/* Card 3: Kas Diterima (DP / Cicilan) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-emerald-400">Kas Masuk (Terbayar)</span>
            <div className="p-1.5 sm:p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold font-mono text-emerald-400 mt-1 truncate">
            {formatRupiah(globalMetrics.totalPaidAll)}
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 block truncate">
            Dari total omset {formatRupiah(globalMetrics.totalInvoicedAll)}
          </span>
        </div>

        {/* Card 4: Jatuh Tempo Bulan Ini */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-cyan-300">Tempo Bulan Ini</span>
            <div className="p-1.5 sm:p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold font-mono text-cyan-300 mt-1 truncate">
            {formatRupiah(globalMetrics.dueThisMonthAmount)}
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-0.5 block truncate">
            Target penerimaan bulan berjalan
          </span>
        </div>
      </div>

      {/* Filter, Search & Sorting Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nama pelanggan, no telepon, alamat, atau no invoice..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-10 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-slate-400 hidden sm:inline flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
              Urutkan:
            </span>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as any)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="debt_desc">💰 Piutang Terbesar (Rp)</option>
              <option value="urgent">🚨 Paling Mendesak / Overdue</option>
              <option value="name_asc">🔤 Nama Pelanggan (A-Z)</option>
              <option value="invoices_count">📑 Jumlah Faktur Terbanyak</option>
            </select>

            {/* Expand / Collapse All */}
            <div className="flex items-center gap-1 border-l border-slate-800 pl-2">
              <button
                type="button"
                onClick={expandAll}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                title="Buka semua rincian faktur pelanggan"
              >
                Buka Semua
              </button>
              <button
                type="button"
                onClick={collapseAll}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors"
                title="Tutup semua rincian faktur pelanggan"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 scrollbar-none text-xs">
          <span className="text-slate-400 text-[11px] font-medium shrink-0 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3 text-cyan-400" />
            Filter:
          </span>
          {[
            { id: 'all_debt', label: 'Pelanggan Berpiutang', count: globalMetrics.customersWithDebt },
            { id: 'overdue', label: '🚨 Lewat Tempo', count: globalMetrics.customersOverdue },
            { id: 'due_week', label: '⏰ Tempo Minggu Ini' },
            { id: 'all', label: 'Semua Pelanggan (Termasuk Lunas)', count: globalMetrics.totalCustomers },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                filterType === tab.id
                  ? 'bg-rose-500 text-white font-bold shadow-xs'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              {tab.label} {tab.count !== undefined ? `(${tab.count})` : ''}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Receivables List */}
      <div className="space-y-3">
        {filteredCustomers.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
            <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 flex items-center justify-center text-xl text-slate-300">
              💳
            </div>
            <p className="text-slate-200 font-semibold text-sm">Tidak Ada Piutang yang Sesuai Kriteria</p>
            <p className="text-slate-500 text-xs">
              {filterType === 'all_debt' 
                ? 'Semua pelanggan telah melunasi tagihannya atau belum ada faktur tempo yang tercatat.'
                : 'Coba ubah kata kunci pencarian atau ubah filter status di atas.'}
            </p>
          </div>
        ) : (
          filteredCustomers.map((grp) => {
            const isExpanded = expandedCustomers[grp.customerName] ?? false;
            const hasOverdue = grp.hasOverdue;
            const hasDebt = grp.totalReceivable > 0;

            return (
              <div
                key={grp.customerName}
                className={`bg-slate-900 border rounded-2xl transition-all overflow-hidden shadow-xs ${
                  hasOverdue && hasDebt
                    ? 'border-rose-500/40 bg-rose-500/5'
                    : hasDebt
                    ? 'border-slate-800 hover:border-slate-700'
                    : 'border-slate-800/60 opacity-85'
                }`}
              >
                {/* Customer Card Header Bar */}
                <div className="p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Customer Profile info */}
                  <div className="flex items-start gap-3.5">
                    <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 border ${
                      hasOverdue && hasDebt
                        ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                        : hasDebt
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                    }`}>
                      {grp.customerName.slice(0, 2).toUpperCase()}
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-bold text-white text-sm sm:text-base tracking-tight">
                          {grp.customerName}
                        </h3>
                        {hasOverdue && hasDebt && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                            🚨 {grp.overdueInvoicesCount} Faktur Lewat Tempo
                          </span>
                        )}
                        {hasDebt && !hasOverdue && grp.dueTodayCount > 0 && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            ⏰ Tempo Hari Ini
                          </span>
                        )}
                        {!hasDebt && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            ✓ Lunas
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-3 text-xs text-slate-400 flex-wrap">
                        <span className="flex items-center gap-1 font-mono">
                          <Phone className="w-3.5 h-3.5 text-slate-500" />
                          {grp.customerPhone}
                        </span>
                        {grp.customerAddress && grp.customerAddress !== '-' && (
                          <span className="flex items-center gap-1 truncate max-w-xs text-slate-500">
                            • {grp.customerAddress}
                          </span>
                        )}
                        <span className="text-slate-500">
                          • {grp.invoices.length} Total Faktur ({grp.unpaidInvoices.length} Belum Lunas)
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Outstanding Debt & Action Buttons */}
                  <div className="flex items-center justify-between lg:justify-end gap-3 sm:gap-6 pt-3 lg:pt-0 border-t lg:border-t-0 border-slate-800">
                    <div className="text-left lg:text-right">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">
                        Sisa Piutang Berjalan
                      </span>
                      <span className={`text-base sm:text-xl font-bold font-mono block ${
                        hasDebt ? 'text-rose-400' : 'text-emerald-400'
                      }`}>
                        {formatRupiah(grp.totalReceivable)}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Terbayar: {formatRupiah(grp.totalPaid)} ({grp.paymentRatio}%)
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                      {/* Tombol Aksi Cetak PDF per Pelanggan */}
                      {grp.invoices.length > 0 && (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            id={`btn-print-pdf-${grp.customerName.replace(/[^a-zA-Z0-9]/g, '-')}`}
                            onClick={() => handleSaveSingleCustomerPdf(grp)}
                            disabled={isSavingCustomerPdf === grp.customerName}
                            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-xs disabled:opacity-50 ${
                              hasDebt
                                ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 hover:border-rose-500/50'
                                : 'bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 hover:border-slate-600'
                            }`}
                            title={`Cetak dan unduh berkas PDF rekapitulasi piutang untuk ${grp.customerName}`}
                          >
                            {isSavingCustomerPdf === grp.customerName ? (
                              <>
                                <Loader2 className="w-3.5 h-3.5 animate-spin text-rose-400" />
                                <span>Menyiapkan...</span>
                              </>
                            ) : (
                              <>
                                <FileText className="w-3.5 h-3.5 text-rose-400" />
                                <span>Cetak PDF</span>
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => setCustomerToPreview(grp)}
                            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold active:scale-95 transition-all cursor-pointer"
                            title={`Pratinjau lembar rekapitulasi piutang ${grp.customerName}`}
                          >
                            <Eye className="w-3.5 h-3.5 text-cyan-400" />
                          </button>
                        </div>
                      )}

                      {/* Tombol Hapus (Khusus Akun Owner dan SPV ketika faktur sudah lunas) */}
                      {isOwnerOrSpv && !hasDebt && grp.invoices.length > 0 && onDeleteInvoice && (
                        <button
                          type="button"
                          onClick={() => setCustomerToDelete(grp)}
                          className="flex items-center gap-1.5 px-2.5 sm:px-3 py-2 rounded-xl bg-rose-950/70 hover:bg-rose-900/90 text-rose-300 hover:text-white border border-rose-500/40 text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-xs"
                          title={`Hapus riwayat faktur lunas milik ${grp.customerName} (Khusus Owner & SPV)`}
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Hapus</span>
                        </button>
                      )}

                      {/* Toggle Expand Details */}
                      <button
                        type="button"
                        onClick={() => toggleExpand(grp.customerName)}
                        className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold active:scale-95 transition-all cursor-pointer border ${
                          isExpanded
                            ? 'bg-cyan-600/20 text-cyan-300 border-cyan-500/30'
                            : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                        }`}
                      >
                        <span>{isExpanded ? 'Tutup Faktur' : 'Rincian Faktur'}</span>
                        {isExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Expanded Invoice List Table */}
                {isExpanded && (
                  <div className="bg-slate-950/70 border-t border-slate-800/80 p-3 sm:p-5 space-y-3 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-300">
                          Daftar Faktur Penjualan • {grp.customerName}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          ({grp.unpaidInvoices.length} aktif berpiutang)
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setCustomerToPreview(grp)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-700 text-[11px] font-medium active:scale-95 transition-all cursor-pointer"
                          title={`Pratinjau lembar surat rekapitulasi piutang ${grp.customerName}`}
                        >
                          <Eye className="w-3 h-3 text-cyan-400" />
                          <span>Pratinjau Surat</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handlePrintSingleCustomer(grp)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-700 text-[11px] font-medium active:scale-95 transition-all cursor-pointer"
                          title={`Cetak langsung ke printer untuk ${grp.customerName}`}
                        >
                          <Printer className="w-3 h-3 text-cyan-400" />
                          <span>Printer</span>
                        </button>
                      </div>
                    </div>

                    <div className="overflow-x-auto rounded-xl border border-slate-800">
                      <table className="w-full text-left text-xs border-collapse min-w-[700px]">
                        <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase text-[10px] font-semibold tracking-wider">
                          <tr>
                            <th className="py-2.5 px-3">No. Invoice & Tgl</th>
                            <th className="py-2.5 px-3">Jatuh Tempo</th>
                            <th className="py-2.5 px-3">Status</th>
                            <th className="py-2.5 px-3">Rincian Item</th>
                            <th className="py-2.5 px-3 text-right">Total Tagihan</th>
                            <th className="py-2.5 px-3 text-right">Terbayar</th>
                            <th className="py-2.5 px-3 text-right">Sisa Piutang</th>
                            <th className="py-2.5 px-3 text-right">Aksi</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/80 font-sans">
                          {grp.invoices.map((inv) => {
                            const dueInfo = getInvoiceDueInfo(inv);
                            const isUnpaid = inv.paymentStatus !== 'lunas' && dueInfo.unpaidAmount > 0;

                            return (
                              <tr
                                key={inv.id}
                                className={`hover:bg-slate-900/60 transition-colors ${
                                  dueInfo.isOverdue && isUnpaid ? 'bg-rose-500/5' : ''
                                }`}
                              >
                                <td className="py-2.5 px-3 whitespace-nowrap">
                                  <span className="font-mono font-bold text-cyan-300 block">
                                    {inv.invoiceNumber}
                                  </span>
                                  <span className="text-[10px] text-slate-400 font-mono">{inv.date}</span>
                                </td>

                                <td className="py-2.5 px-3 whitespace-nowrap font-mono">
                                  {isUnpaid ? (
                                    <div>
                                      <span className="text-slate-300 block">{formatDueDateIndo(inv.dueDate)}</span>
                                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${dueInfo.badgeClass}`}>
                                        {dueInfo.statusLabel}
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-slate-500 text-[11px]">- (Lunas)</span>
                                  )}
                                </td>

                                <td className="py-2.5 px-3 whitespace-nowrap">
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${
                                    inv.paymentStatus === 'lunas'
                                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                                      : inv.paymentStatus === 'dp'
                                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                      : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  }`}>
                                    {inv.paymentStatus === 'lunas' ? 'Lunas' : inv.paymentStatus === 'dp' ? 'DP' : 'Tempo'}
                                  </span>
                                </td>

                                <td className="py-2.5 px-3 text-slate-300 max-w-[200px]">
                                  <span className="block truncate text-[11px]">
                                    {inv.items.map((i) => `${i.productName} (${i.quantity} ${i.unit})`).join(', ')}
                                  </span>
                                </td>

                                <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-200">
                                  {formatRupiah(inv.grandTotal)}
                                </td>

                                <td className="py-2.5 px-3 text-right font-mono text-emerald-400">
                                  {formatRupiah(inv.paidAmount)}
                                </td>

                                <td className="py-2.5 px-3 text-right font-mono font-bold text-rose-400">
                                  {formatRupiah(dueInfo.unpaidAmount)}
                                </td>

                                <td className="py-2.5 px-3 text-right whitespace-nowrap">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() => onOpenPaymentModal(inv.id)}
                                      className="px-2 py-1 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs"
                                      title="Kelola & Tambah Pembayaran Cicilan"
                                    >
                                      <Receipt className="w-3 h-3" />
                                      <span>{isUnpaid ? 'Bayar / Cicil' : 'Histori'}</span>
                                    </button>

                                    <button
                                      type="button"
                                      onClick={() => onViewInvoice(inv)}
                                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs"
                                      title="Lihat Pratinjau Faktur"
                                    >
                                      <Eye className="w-3 h-3" />
                                      <span>Nota</span>
                                    </button>

                                    {isUnpaid && (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          onUpdateInvoiceStatus(inv.id, 'lunas', inv.grandTotal);
                                          confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
                                        }}
                                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold active:scale-95 transition-all"
                                        title="Pelunasan instan"
                                      >
                                        Lunas
                                      </button>
                                    )}

                                    {/* Hapus Faktur Lunas (Owner / SPV) */}
                                    {isOwnerOrSpv && inv.paymentStatus === 'lunas' && onDeleteInvoice && (
                                      <button
                                        type="button"
                                        onClick={() => setInvoiceToDelete(inv)}
                                        className="p-1 bg-rose-950/60 hover:bg-rose-900/90 text-rose-400 hover:text-white border border-rose-500/30 rounded-lg text-xs font-semibold inline-flex items-center active:scale-95 transition-all shadow-2xs"
                                        title="Hapus Faktur Lunas Ini (Khusus Owner & SPV)"
                                      >
                                        <Trash2 className="w-3 h-3 text-rose-400" />
                                      </button>
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                        <tfoot className="bg-slate-900 border-t border-slate-800 font-semibold text-xs text-slate-300">
                          <tr>
                            <td colSpan={4} className="py-2.5 px-3 text-right text-slate-400 font-bold uppercase text-[10px]">
                              Total Akumulasi Pelanggan:
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-white">
                              {formatRupiah(grp.totalInvoiced)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-emerald-400">
                              {formatRupiah(grp.totalPaid)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono text-rose-400 font-bold">
                              {formatRupiah(grp.totalReceivable)}
                            </td>
                            <td></td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* ============================================================== */}
      {/* MODAL PRATINJAU & CETAK BUKU BESAR PIUTANG PELANGGAN (PDF)     */}
      {/* ============================================================== */}
      {showRecapModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[94vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Top Header */}
            <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Pratinjau Rekapitulasi Piutang per Nama Pelanggan
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Dokumen siap cetak & diekspor sebagai file PDF resmi (A4 Landscape)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrintRecap}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                  title="Cetak via printer dialog"
                >
                  <Printer className="w-4 h-4 text-cyan-400" />
                  <span className="hidden sm:inline">Cetak Langsung</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveRecapPdf}
                  disabled={isSavingPdf}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors shadow-xs shadow-cyan-950/40 cursor-pointer disabled:opacity-50"
                  title="Download File PDF"
                >
                  {isSavingPdf ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Memproses PDF...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-4 h-4" />
                      <span>Unduh File PDF</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setShowRecapModal(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors ml-1 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Success notification banner */}
            {pdfSuccessMsg && (
              <div className="bg-emerald-950/80 border-b border-emerald-500/40 px-4 py-2 text-xs text-emerald-300 font-medium flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{pdfSuccessMsg}</span>
              </div>
            )}

            {/* Modal Body: Printable Document Sheet */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
              <div
                id="printable-customer-receivables-recap"
                className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-5xl mx-auto space-y-6"
              >
                {/* Official Letterhead Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-900">
                  <div className="flex items-start gap-3 sm:gap-4">
                    {companyProfile?.logoUrl ? (
                      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl border border-slate-200 bg-white p-1.5 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
                        <img
                          src={companyProfile.logoUrl}
                          alt={companyProfile.companyName || 'Logo Perusahaan'}
                          className="w-full h-full object-contain"
                        />
                      </div>
                    ) : (
                      <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-base sm:text-lg shrink-0">
                        {companyProfile?.shortName || companyProfile?.appLogoBadge || 'DTF'}
                      </div>
                    )}
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                        SISTEM LOGISTIK & KEUANGAN GUDANG
                      </span>
                      <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
                        {companyProfile?.companyName || 'GUDANG SUPLAI SABLON DTF & SUBLIME'}
                      </h1>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {companyProfile?.tagline || 'Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey & Merchandise'}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {companyProfile?.address || 'Bandung'} • Telp: {companyProfile?.phone || '0812-9988-7766'} • Email: {companyProfile?.email || 'logistik@dtfsublime.id'}
                      </p>
                    </div>
                  </div>
                  <div className="text-left sm:text-right shrink-0">
                    <span className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-extrabold text-xs tracking-wider uppercase">
                      BUKU BESAR REKAPITULASI PIUTANG PER PELANGGAN
                    </span>
                    <p className="font-mono font-bold text-xs text-slate-800 mt-2">
                      REF: REKAP-AR-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      Dicetak: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      Oleh: <strong>{currentUser.name}</strong> ({currentUser.roleTitle || 'Petugas Gudang'})
                    </p>
                  </div>
                </div>

                {/* Audit Parameter Box */}
                <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-slate-200 pb-3">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Cakupan Data</span>
                      <span className="font-bold text-slate-900 text-xs block truncate mt-0.5">
                        {filterType === 'all_debt' ? 'Pelanggan Berpiutang Aktif' : filterType === 'overdue' ? 'Pelanggan Lewat Tempo (Overdue)' : 'Semua Pelanggan'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Pencarian</span>
                      <span className="font-semibold text-slate-800 text-xs block truncate mt-0.5">
                        {searchQuery ? `"${searchQuery}"` : 'Semua Pelanggan'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Jumlah Pelanggan</span>
                      <span className="font-bold text-slate-900 text-xs block mt-0.5">
                        {filteredCustomers.length} Pelanggan Terpilih
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Status Tempo</span>
                      <span className="font-bold text-rose-700 text-xs block mt-0.5">
                        {globalMetrics.customersOverdue} Pelanggan Lewat Tempo
                      </span>
                    </div>
                  </div>

                  {/* 4 Financial Highlight Blocks */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Piutang Berjalan</span>
                      <span className="font-mono font-black text-sm text-rose-700 block mt-0.5">
                        {formatRupiah(globalMetrics.totalDebt)}
                      </span>
                      <span className="text-[10px] text-slate-500">Saldo tagihan belum lunas</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Piutang Lewat Tempo</span>
                      <span className="font-mono font-black text-sm text-amber-700 block mt-0.5">
                        {formatRupiah(globalMetrics.overdueDebtAmount)}
                      </span>
                      <span className="text-[10px] text-slate-500">Perlu penagihan intensif</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Kas Diterima</span>
                      <span className="font-mono font-black text-sm text-emerald-700 block mt-0.5">
                        {formatRupiah(globalMetrics.totalPaidAll)}
                      </span>
                      <span className="text-[10px] text-slate-500">Akumulasi pelunasan/DP</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Nilai Faktur</span>
                      <span className="font-mono font-black text-sm text-slate-900 block mt-0.5">
                        {formatRupiah(globalMetrics.totalInvoicedAll)}
                      </span>
                      <span className="text-[10px] text-slate-500">Omset penjualan bruto</span>
                    </div>
                  </div>
                </div>

                {/* Printable Ledger Table Grouped per Customer */}
                <div className="space-y-5">
                  {filteredCustomers.length === 0 ? (
                    <div className="py-8 text-center text-slate-500 border border-slate-200 rounded-lg">
                      Tidak ada data piutang untuk kriteria saat ini.
                    </div>
                  ) : (
                    filteredCustomers.map((grp, idx) => (
                      <div key={grp.customerName} className="border border-slate-300 rounded-lg overflow-hidden">
                        {/* Customer Header Row */}
                        <div className="bg-slate-100 px-3.5 py-2 border-b border-slate-300 flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-slate-800 text-white text-[10px] font-bold flex items-center justify-center">
                              {idx + 1}
                            </span>
                            <span className="font-extrabold text-slate-900 text-xs">
                              {grp.customerName}
                            </span>
                            <span className="text-[11px] text-slate-600 font-mono">
                              • Telp: {grp.customerPhone}
                            </span>
                            {grp.customerAddress && grp.customerAddress !== '-' && (
                              <span className="text-[11px] text-slate-500">
                                • {grp.customerAddress}
                              </span>
                            )}
                          </div>
                          <div className="text-right flex items-center gap-3">
                            <span className="text-[11px] text-slate-600">
                              {grp.unpaidInvoices.length} Faktur Berpiutang
                            </span>
                            <span className="font-mono font-extrabold text-rose-700 text-xs">
                              Sisa: {formatRupiah(grp.totalReceivable)}
                            </span>
                          </div>
                        </div>

                        {/* Customer Invoices Table */}
                        <table className="w-full text-left text-[11px] border-collapse">
                          <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[10px] uppercase">
                            <tr>
                              <th className="py-2 px-2.5 w-8 text-center">No</th>
                              <th className="py-2 px-2.5 whitespace-nowrap">No. Faktur</th>
                              <th className="py-2 px-2.5 whitespace-nowrap">Tanggal</th>
                              <th className="py-2 px-2.5 whitespace-nowrap">Jatuh Tempo</th>
                              <th className="py-2 px-3 min-w-[200px]">Rincian Item Pembelian</th>
                              <th className="py-2 px-2.5 text-right whitespace-nowrap">Nilai Faktur</th>
                              <th className="py-2 px-2.5 text-right whitespace-nowrap">Terbayar</th>
                              <th className="py-2 px-2.5 text-right whitespace-nowrap">Sisa Piutang</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200">
                            {grp.invoices.map((inv, invIdx) => {
                              const dueInfo = getInvoiceDueInfo(inv);
                              const isUnpaid = inv.paymentStatus !== 'lunas' && dueInfo.unpaidAmount > 0;

                              return (
                                <tr key={inv.id} className={`align-top ${dueInfo.isOverdue && isUnpaid ? 'bg-rose-50/60' : ''}`}>
                                  <td className="py-2 px-2.5 text-center text-slate-400 align-top">{invIdx + 1}</td>
                                  <td className="py-2 px-2.5 font-mono font-bold text-slate-900 align-top whitespace-nowrap">{inv.invoiceNumber}</td>
                                  <td className="py-2 px-2.5 font-mono text-slate-600 align-top whitespace-nowrap">{inv.date}</td>
                                  <td className="py-2 px-2.5 font-mono align-top whitespace-nowrap">
                                    {isUnpaid ? (
                                      <span className={dueInfo.isOverdue ? 'text-rose-700 font-bold' : 'text-slate-800'}>
                                        {formatDueDateIndo(inv.dueDate)} {dueInfo.isOverdue ? `(Lewat ${Math.abs(dueInfo.diffDays)} hr)` : ''}
                                      </span>
                                    ) : (
                                      <span className="text-emerald-700 font-semibold">Lunas</span>
                                    )}
                                  </td>
                                  <td className="py-2 px-3 text-slate-800 align-top whitespace-normal break-words min-w-[200px]">
                                    {inv.items && inv.items.length > 0 ? (
                                      <div className="space-y-1">
                                        {inv.items.map((i, iIdx) => (
                                          <div key={iIdx} className="leading-snug flex items-start justify-between gap-2 text-[10.5px]">
                                            <div className="flex items-start gap-1">
                                              {inv.items.length > 1 && (
                                                <span className="text-cyan-700 font-bold select-none text-[9px] leading-tight mt-0.5">•</span>
                                              )}
                                              <span className="font-semibold text-slate-900 break-words">{i.productName}</span>
                                            </div>
                                            <span className="text-slate-600 font-mono text-[10px] whitespace-nowrap shrink-0 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                                              {i.quantity} {i.unit || 'pcs'}
                                            </span>
                                          </div>
                                        ))}
                                      </div>
                                    ) : (
                                      <span className="text-slate-400 italic text-[10px]">-</span>
                                    )}
                                  </td>
                                  <td className="py-2 px-2.5 text-right font-mono text-slate-800 align-top whitespace-nowrap">{formatRupiah(inv.grandTotal)}</td>
                                  <td className="py-2 px-2.5 text-right font-mono text-emerald-700 align-top whitespace-nowrap">{formatRupiah(inv.paidAmount)}</td>
                                  <td className="py-2 px-2.5 text-right font-mono font-bold text-rose-700 align-top whitespace-nowrap">{formatRupiah(dueInfo.unpaidAmount)}</td>
                                </tr>
                              );
                            })}
                          </tbody>
                          <tfoot className="bg-slate-50 font-bold border-t border-slate-300 text-[11px]">
                            <tr>
                              <td colSpan={5} className="py-2 px-3 text-right text-slate-600 uppercase text-[10px]">
                                Subtotal {grp.customerName}:
                              </td>
                              <td className="py-2 px-3 text-right font-mono text-slate-900 whitespace-nowrap">{formatRupiah(grp.totalInvoiced)}</td>
                              <td className="py-2 px-3 text-right font-mono text-emerald-700 whitespace-nowrap">{formatRupiah(grp.totalPaid)}</td>
                              <td className="py-2 px-3 text-right font-mono text-rose-700 whitespace-nowrap">{formatRupiah(grp.totalReceivable)}</td>
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    ))
                  )}
                </div>

                {/* Grand Total Summary Box */}
                <div className="bg-slate-900 text-white rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                      TOTAL REKAPITULASI PIUTANG KESELURUHAN
                    </span>
                    <span className="text-xs text-slate-300">
                      Mencakup {filteredCustomers.length} pelanggan dan seluruh faktur berpiutang aktif
                    </span>
                  </div>
                  <div className="flex items-center gap-6 font-mono text-right">
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase">Total Omset</span>
                      <span className="font-bold text-slate-200">{formatRupiah(globalMetrics.totalInvoicedAll)}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-emerald-400 block uppercase">Total Terbayar</span>
                      <span className="font-bold text-emerald-400">{formatRupiah(globalMetrics.totalPaidAll)}</span>
                    </div>
                    <div className="border-l border-slate-700 pl-6">
                      <span className="text-[10px] text-rose-400 block uppercase font-bold">TOTAL PIUTANG</span>
                      <span className="font-black text-rose-400 text-base">{formatRupiah(globalMetrics.totalDebt)}</span>
                    </div>
                  </div>
                </div>

                {/* Formal Signature Blocks */}
                <div className="grid grid-cols-2 gap-12 pt-6 border-t-2 border-slate-900 text-center text-xs">
                  <div className="space-y-12">
                    <p className="font-bold text-slate-800">
                      {companyProfile?.signerTitle1 || 'Petugas Penagihan / Kasir'}
                    </p>
                    <div>
                      <p className="font-bold underline text-slate-900">{currentUser.name}</p>
                      <p className="text-[10px] text-slate-500">{currentUser.roleTitle || 'Staff Administrasi'}</p>
                    </div>
                  </div>

                  <div className="space-y-12">
                    <p className="font-bold text-slate-800">
                      {companyProfile?.signerTitle3 || 'Pimpinan / Pemilik Usaha'}
                    </p>
                    <div>
                      <p className="font-bold underline text-slate-900">
                        {currentUser.role === 'owner' ? currentUser.name : 'Pimpinan Manajemen'}
                      </p>
                      <p className="text-[10px] text-slate-500">Pemilik Usaha (Owner)</p>
                    </div>
                  </div>
                </div>

                {/* Footer Notice */}
                <div className="text-[10px] text-slate-500 text-center pt-3 border-t border-slate-200">
                  Dokumen rekapitulasi buku besar piutang ini diterbitkan secara otomatis oleh Sistem Gudang Sablon DTF & Sublime Pro.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* MODAL PRATINJAU SURAT REKAPITULASI PIUTANG KONSUMEN (PDF)    */}
      {/* ============================================================ */}
      {customerToPreview && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="bg-slate-850 px-4 sm:px-6 py-3.5 border-b border-slate-800 flex items-center justify-between shrink-0 gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-2 rounded-xl bg-rose-500/15 text-rose-400 border border-rose-500/30 shrink-0">
                  <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-sm sm:text-base text-white truncate">
                    Surat Rekapitulasi Piutang Pelanggan
                  </h3>
                  <p className="text-[11px] text-slate-400 truncate">
                    Pratinjau lembar penagihan resmi • <span className="text-cyan-300 font-semibold">{customerToPreview.customerName}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 flex-wrap">
                {/* Switch Orientasi Lanskap / Potret */}
                <div className="flex items-center bg-slate-800 p-0.5 rounded-xl border border-slate-700 text-xs">
                  <button
                    type="button"
                    onClick={() => setSingleCustomerOrientation('landscape')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                      singleCustomerOrientation === 'landscape'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white'
                    }`}
                    title="Format Lanskap (Lebar & Terbuka - Optimal untuk Rincian Faktur)"
                  >
                    <span>📑 Lanskap</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setSingleCustomerOrientation('portrait')}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
                      singleCustomerOrientation === 'portrait'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white'
                    }`}
                    title="Format Potret Standar"
                  >
                    <span>📄 Potret</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => handlePrintSingleCustomer(customerToPreview)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold active:scale-95 transition-all cursor-pointer shadow-xs"
                  title="Cetak langsung ke printer fisik"
                >
                  <Printer className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="hidden sm:inline">Cetak Langsung</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveSingleCustomerPdf(customerToPreview)}
                  disabled={isSavingCustomerPdf === customerToPreview.customerName}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold active:scale-95 transition-all shadow-xs cursor-pointer disabled:opacity-50"
                  title="Unduh dokumen dalam format PDF A4"
                >
                  {isSavingCustomerPdf === customerToPreview.customerName ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Menyiapkan...</span>
                    </>
                  ) : (
                    <>
                      <FileDown className="w-3.5 h-3.5" />
                      <span>Unduh PDF</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setCustomerToPreview(null)}
                  className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup pratinjau"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body: Printable Sheet Preview */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60 flex justify-center">
              <PrintableSingleCustomerContent
                targetCustomer={customerToPreview}
                companyProfile={companyProfile}
                currentUser={currentUser}
                elementId="printable-single-customer-recap"
                orientation={singleCustomerOrientation}
              />
            </div>
          </div>
        </div>
      )}

      {/* Offscreen Printable Document for Direct Card Print / PDF Download */}
      {!customerToPreview && (
        <div 
          style={{ 
            position: 'fixed', 
            left: '-9999px', 
            top: 0, 
            width: singleCustomerOrientation === 'landscape' ? '1120px' : '794px', 
            zIndex: -99, 
            pointerEvents: 'none', 
            opacity: 0 
          }}
          aria-hidden="true"
        >
          {(() => {
            const targetCustomer = selectedCustomerForPrint || filteredCustomers[0] || null;
            if (!targetCustomer) return null;
            return (
              <PrintableSingleCustomerContent
                targetCustomer={targetCustomer}
                companyProfile={companyProfile}
                currentUser={currentUser}
                elementId="printable-single-customer-recap"
                orientation={singleCustomerOrientation}
              />
            );
          })()}
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL KONFIRMASI HAPUS FAKTUR LUNAS (KHUSUS OWNER & SPV)       */}
      {/* ============================================================== */}
      {customerToDelete && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-2xl w-full max-w-md p-5 shadow-2xl space-y-4 animate-in fade-in duration-200">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm sm:text-base text-white">
                  Hapus Data Faktur Pelanggan Lunas?
                </h3>
                <p className="text-xs text-rose-400 font-medium mt-0.5">
                  Khusus Akun <strong>Owner</strong> & <strong>Supervisor (SPV)</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Nama Pelanggan:</span>
                <span className="font-bold text-white text-sm">{customerToDelete.customerName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Status Pembayaran:</span>
                <span className="font-bold text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 text-[10px]">
                  ✓ Lunas Sepenuhnya (Rp 0)
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Jumlah Faktur Terhapus:</span>
                <span className="font-mono font-bold text-cyan-300">{customerToDelete.invoices.length} Faktur</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Total Transaksi:</span>
                <span className="font-mono font-bold text-slate-200">{formatRupiah(customerToDelete.totalInvoiced)}</span>
              </div>
            </div>

            <div className="text-[11px] text-amber-300 bg-amber-950/40 border border-amber-500/30 p-3 rounded-xl flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                Peringatan: Seluruh data faktur yang telah lunas ({customerToDelete.invoices.length} faktur) untuk pelanggan ini akan dihapus secara permanen dari sistem.
              </span>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                disabled={isDeletingCustomer}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteCustomer}
                disabled={isDeletingCustomer}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold cursor-pointer active:scale-95 transition-all shadow-md shadow-rose-950/50 disabled:opacity-50"
              >
                {isDeletingCustomer ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Hapus {customerToDelete.invoices.length} Faktur Lunas</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS SINGLE FAKTUR LUNAS */}
      {invoiceToDelete && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-500/50 rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4 animate-in fade-in duration-200">
            <div className="flex items-start gap-3">
              <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-sm text-white">
                  Hapus Faktur {invoiceToDelete.invoiceNumber}?
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Faktur lunas milik <strong>{invoiceToDelete.customerName}</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Total Nilai:</span>
                <span className="font-mono font-bold text-white">{formatRupiah(invoiceToDelete.grandTotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Status:</span>
                <span className="font-bold text-emerald-400">Lunas</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteInvoice) {
                    const res = onDeleteInvoice(invoiceToDelete.id);
                    if (res.success) {
                      setDeleteNotification({
                        type: 'success',
                        message: `Faktur ${invoiceToDelete.invoiceNumber} berhasil dihapus.`,
                      });
                      setTimeout(() => setDeleteNotification(null), 3500);
                      setInvoiceToDelete(null);
                    } else {
                      setDeleteNotification({
                        type: 'error',
                        message: res.message || 'Gagal menghapus faktur.',
                      });
                    }
                  }
                }}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Hapus Faktur</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
