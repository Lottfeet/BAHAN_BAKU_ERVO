import React, { useState } from 'react';
import { 
  Bell, 
  ShieldAlert, 
  ShieldCheck,
  ChevronDown, 
  Check, 
  AlertTriangle,
  Flame,
  Clock,
  Menu,
  LogOut,
  Sliders,
  Database,
  Building2,
  Cloud,
  RefreshCw,
  Sun,
  Moon
} from 'lucide-react';
import { User, PushNotification, CompanyProfile } from '../types';
import { NotificationPopup } from './NotificationPopup';
import { useTheme } from '../context/ThemeContext';

interface NavbarProps {
  activeTab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname';
  setActiveTab: (tab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname') => void;
  currentUser: User;
  allUsers: User[];
  companyProfile?: CompanyProfile;
  onOpenCompanyModal?: () => void;
  onSelectUser?: (user: User) => void;
  onLogout?: () => void;
  onOpenBackupModal?: () => void;
  lowStockCount: number;
  unpaidInvoicesCount?: number;
  overdueInvoicesCount?: number;
  notifications: PushNotification[];
  onOpenNotifications: () => void;
  onOpenMobileSimulator?: () => void;
  onQuickLowStockClick: () => void;
  onQuickInvoiceDueClick: () => void;
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
  autoHideMode?: boolean;
  onToggleAutoHide?: () => void;
  onMarkAsRead?: (id: string) => void;
  onToggleRead?: (id: string) => void;
  onMarkAllAsRead?: () => void;
  onDeleteNotification?: (id: string) => void;
  onClearAllReadNotifications?: () => void;
  onNavigateFromNotification?: (notif: PushNotification) => void;
  onReloadActiveAlerts?: () => void;
  onTriggerTestPush?: () => void;
  isCloudSyncing?: boolean;
  cloudSyncStatus?: 'connected' | 'syncing' | 'offline';
  onManualSyncCloud?: () => void;
  lastSyncTime?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  allUsers,
  companyProfile,
  onOpenCompanyModal,
  onSelectUser,
  onLogout,
  onOpenBackupModal,
  lowStockCount,
  overdueInvoicesCount = 0,
  notifications,
  onQuickLowStockClick,
  onQuickInvoiceDueClick,
  onToggleSidebar,
  autoHideMode = false,
  onToggleAutoHide,
  onOpenMobileSimulator,
  onMarkAsRead = () => {},
  onToggleRead = () => {},
  onMarkAllAsRead = () => {},
  onDeleteNotification = () => {},
  onClearAllReadNotifications = () => {},
  onNavigateFromNotification,
  onReloadActiveAlerts,
  onTriggerTestPush,
  isCloudSyncing = false,
  cloudSyncStatus = 'connected',
  onManualSyncCloud,
  lastSyncTime,
}) => {
  const { theme, toggleTheme, isDark } = useTheme();
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showNotificationPopup, setShowNotificationPopup] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="shrink-0 bg-slate-900 border-b border-slate-800 text-slate-100 z-40 select-none">
      {/* Top Banner for Overdue Invoices or Low Stock Alerts */}
      {overdueInvoicesCount > 0 ? (
        <div 
          onClick={onQuickInvoiceDueClick}
          className="bg-rose-500/20 border-b border-rose-500/40 px-3 sm:px-4 py-1.5 text-xs text-rose-200 flex items-center justify-between cursor-pointer hover:bg-rose-500/25 transition-colors"
        >
          <div className="flex items-center gap-1.5 sm:gap-2 font-medium truncate pr-2">
            <Clock className="w-3.5 h-3.5 text-rose-400 shrink-0 animate-pulse" />
            <span className="hidden sm:inline">
              Pengingat Tagihan: Ada <strong>{overdueInvoicesCount} invoice konsumen</strong> yang sudah melewati batas tanggal jatuh tempo!
            </span>
            <span className="sm:hidden text-[11px] truncate">
              <strong>{overdueInvoicesCount} Invoice</strong> jatuh tempo!
            </span>
          </div>
          <span className="text-[11px] underline font-semibold flex items-center gap-1 shrink-0">
            Periksa Faktur &rarr;
          </span>
        </div>
      ) : lowStockCount > 0 ? (
        <div 
          onClick={onQuickLowStockClick}
          className="bg-amber-500/15 border-b border-amber-500/30 px-3 sm:px-4 py-1.5 text-xs text-amber-300 flex items-center justify-between cursor-pointer hover:bg-amber-500/20 transition-colors"
        >
          <div className="flex items-center gap-1.5 sm:gap-2 font-medium truncate pr-2">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
            <span className="hidden sm:inline">
              Perhatian: Ada <strong>{lowStockCount} bahan baku</strong> DTF / Sublime yang sudah mencapai level minimum stok!
            </span>
            <span className="sm:hidden text-[11px] truncate">
              <strong>{lowStockCount} Bahan</strong> capai batas minimum stok!
            </span>
          </div>
          <span className="text-[11px] underline font-semibold flex items-center gap-1 shrink-0">
            Cek Stok &rarr;
          </span>
        </div>
      ) : null}

      {/* Main Bar */}
      <div className="w-full px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-14 sm:h-16 gap-2 sm:gap-4">
          
          {/* Left: Sidebar Toggle, Logo & Brand */}
          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            {onToggleSidebar && (
              <button
                type="button"
                id="btn-toggle-sidebar"
                onClick={onToggleSidebar}
                title="Buka / Tutup Menu Sidebar"
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-400 hover:text-white border border-slate-700 transition-all flex items-center justify-center shadow-xs"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}

            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-indigo-500 to-rose-500 p-0.5 shadow-sm flex items-center justify-center shrink-0">
              <div className="w-full h-full bg-slate-950 rounded-[9px] flex items-center justify-center overflow-hidden">
                {companyProfile?.logoUrl ? (
                  <img
                    src={companyProfile.logoUrl}
                    alt={companyProfile.appName || 'Logo'}
                    className="w-full h-full object-contain p-0.5 bg-white/10"
                  />
                ) : companyProfile?.shortName ? (
                  <span className="text-[11px] font-black text-cyan-400 font-mono tracking-tighter">
                    {companyProfile.shortName.slice(0, 3)}
                  </span>
                ) : (
                  <Flame className="w-4 h-4 text-cyan-400" />
                )}
              </div>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="font-bold text-sm sm:text-base tracking-tight text-white truncate">
                  {companyProfile?.appName || 'DTF & Sublime'}
                </span>
                <span className="hidden sm:inline-block text-[9px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shrink-0">
                  {companyProfile?.appLogoBadge || 'Gudang'}
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 hidden md:block truncate">
                {companyProfile?.companyName || companyProfile?.appSubtitle || 'Manajemen Stok, Produksi & Invoice Konsumen'}
              </p>
            </div>
          </div>

          {/* Right Action Icons & User Profile */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Firebase Cloud Status Indicator (Desktop) */}
            <div 
              className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800/90 text-slate-300 border border-slate-700/80 text-xs font-medium shadow-xs"
              title="Terhubung ke Google Cloud Firestore (rare-stacker-w83d0, asia-southeast1)"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse shrink-0" />
              <span className="text-[11px] text-slate-300 font-mono hidden xl:inline">Firebase:</span>
              <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block"></span>
                Tersinkron
              </span>
            </div>

            {/* Quick Button Identitas Perusahaan & Aplikasi (Desktop) */}
            {(currentUser.role === 'owner' || Boolean(currentUser.canManageCompanyProfile) || Boolean(currentUser.canManageAccessControl)) && onOpenCompanyModal && (
              <button
                type="button"
                id="btn-navbar-company-profile"
                onClick={onOpenCompanyModal}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 border border-slate-700/80 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                title="Kelola Identitas Perusahaan, Kop Surat, Rekening Bank & Branding Aplikasi"
              >
                <Building2 className="w-4 h-4 text-cyan-400" />
                <span className="hidden xl:inline text-[11px]">Identitas Usaha</span>
              </button>
            )}

            {/* Backup & Checkpoint Quick Button (Desktop) */}
            {(currentUser.role === 'owner' || currentUser.role === 'warehouse_admin') && onOpenBackupModal && (
              <button
                type="button"
                id="btn-navbar-backup"
                onClick={onOpenBackupModal}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-cyan-300 border border-slate-700/80 text-xs font-semibold transition-all cursor-pointer shadow-xs"
                title="Checkpoint Berkala & Backup Lokal (.json)"
              >
                <Database className="w-4 h-4 text-cyan-400" />
                <span className="hidden lg:inline text-[11px]">Backup & Checkpoint</span>
              </button>
            )}

            {/* Cloud Real-Time Status & Manual Sync Button */}
            <button
              type="button"
              id="btn-navbar-cloud-sync"
              onClick={onManualSyncCloud}
              disabled={isCloudSyncing}
              className={`flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer shadow-xs ${
                cloudSyncStatus === 'connected'
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300 hover:bg-emerald-900/50'
                  : cloudSyncStatus === 'syncing' || isCloudSyncing
                  ? 'bg-cyan-950/40 border-cyan-500/30 text-cyan-300'
                  : 'bg-amber-950/40 border-amber-500/30 text-amber-300 hover:bg-amber-900/50'
              }`}
              title={`Status Cloud: ${
                cloudSyncStatus === 'connected'
                  ? 'Database Terhubung & Tersinkron Antar-Perangkat (Klik untuk segarkan data)'
                  : cloudSyncStatus === 'syncing' || isCloudSyncing
                  ? 'Sedang menyinkronkan data cloud...'
                  : 'Mode Offline (Klik untuk mencoba menghubungkan kembali)'
              } ${lastSyncTime ? `• Terakhir: ${lastSyncTime}` : ''}`}
            >
              {isCloudSyncing ? (
                <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
              ) : (
                <Cloud className={`w-3.5 h-3.5 ${
                  cloudSyncStatus === 'connected' ? 'text-emerald-400' : 'text-amber-400'
                }`} />
              )}
              <span className="hidden md:inline text-[11px]">
                {isCloudSyncing ? 'Sinkron Cloud...' : cloudSyncStatus === 'connected' ? 'Cloud Aktif' : 'Offline'}
              </span>
            </button>

            {/* Notification Bell Dropdown */}
            <div className="relative">
              <button
                id="btn-notification-bell"
                onClick={() => {
                  setShowNotificationPopup(!showNotificationPopup);
                  setShowRoleDropdown(false);
                }}
                className={`relative p-2 rounded-xl transition-all ${
                  showNotificationPopup
                    ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950/50'
                    : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700/80'
                }`}
                title="Notifikasi & Peringatan Bahan"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white ring-2 ring-slate-900 animate-pulse">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </button>
            </div>

            {/* Theme Mode Toggle Button (Light / Dark) */}
            <button
              type="button"
              id="btn-navbar-theme-toggle"
              onClick={toggleTheme}
              className="flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 text-xs font-semibold transition-all cursor-pointer shadow-xs"
              title={isDark ? 'Beralih ke Mode Terang (Light Mode)' : 'Beralih ke Mode Gelap (Dark Mode)'}
            >
              {isDark ? (
                <>
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span className="hidden xl:inline text-[11px]">Terang</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-cyan-400" />
                  <span className="hidden xl:inline text-[11px]">Gelap</span>
                </>
              )}
            </button>

            {/* User Profile Dropdown */}
            <div className="relative">
              <button
                id="btn-user-profile-menu"
                onClick={() => {
                  setShowRoleDropdown(!showRoleDropdown);
                  setShowNotificationPopup(false);
                }}
                className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-left transition-all cursor-pointer"
                title={`Profil Pengguna: ${currentUser.name} (${currentUser.roleTitle})`}
              >
                <div className={`w-7 h-7 rounded-lg ${currentUser.avatarColor} text-white flex items-center justify-center text-xs font-bold shrink-0 shadow-xs`}>
                  {currentUser.name.charAt(0)}
                </div>
                <div className="hidden sm:block text-left leading-tight pr-1">
                  <p className="text-xs font-semibold text-white truncate max-w-[120px]">{currentUser.name}</p>
                  <p className="text-[10px] text-slate-400 truncate max-w-[120px]">{currentUser.roleTitle}</p>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              </button>

              {showRoleDropdown && (
                <div className="fixed sm:absolute right-3 sm:right-0 top-16 sm:top-auto sm:mt-2 w-[calc(100vw-1.5rem)] sm:w-72 max-w-sm rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-3 z-50 animate-in fade-in zoom-in-95 duration-150">
                  {/* Profil Pengguna Aktif */}
                  <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                    <div className={`w-10 h-10 rounded-xl ${currentUser.avatarColor} text-white flex items-center justify-center text-sm font-bold shrink-0 shadow-md`}>
                      {currentUser.name.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 inline-block" title="Sesi Login Aktif" />
                      </div>
                      <p className="text-[11px] text-cyan-400 font-medium truncate">{currentUser.roleTitle}</p>
                      <p className="text-[10px] text-slate-400 truncate font-mono mt-0.5">{currentUser.email}</p>
                    </div>
                    <button
                      onClick={() => setShowRoleDropdown(false)}
                      className="text-xs text-slate-400 hover:text-white sm:hidden px-1.5 py-0.5"
                    >
                      ✕
                    </button>
                  </div>

                  {/* Menu Navigasi Pengguna */}
                  <div className="pt-2 space-y-1">
                    {/* Akses ke Backup & Checkpoint khusus Owner & SPV */}
                    {(currentUser.role === 'owner' || currentUser.role === 'warehouse_admin') && onOpenBackupModal && (
                      <button
                        type="button"
                        id="btn-dropdown-backup"
                        onClick={() => {
                          setShowRoleDropdown(false);
                          onOpenBackupModal();
                        }}
                        className="w-full flex items-center justify-between p-2 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Database className="w-4 h-4 text-cyan-400" />
                          <span>Backup & Checkpoint Data</span>
                        </div>
                        <span className="text-[10px] text-slate-500">&rarr;</span>
                      </button>
                    )}

                    {/* Akses ke Pengaturan Identitas Perusahaan & Aplikasi */}
                    {(currentUser.role === 'owner' || Boolean(currentUser.canManageCompanyProfile) || Boolean(currentUser.canManageAccessControl)) && onOpenCompanyModal && (
                      <button
                        type="button"
                        id="btn-dropdown-company-profile"
                        onClick={() => {
                          setShowRoleDropdown(false);
                          onOpenCompanyModal();
                        }}
                        className="w-full flex items-center justify-between p-2 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-cyan-400" />
                          <span>Identitas Usaha & Aplikasi</span>
                        </div>
                        <span className="text-[10px] text-slate-500">&rarr;</span>
                      </button>
                    )}

                    {/* Akses ke Manajemen Hak Akses */}
                    {(currentUser.role === 'owner' || Boolean(currentUser.canManageAccessControl)) && (
                      <button
                        type="button"
                        id="btn-goto-access-control"
                        onClick={() => {
                          setShowRoleDropdown(false);
                          setActiveTab('access');
                        }}
                        className="w-full flex items-center justify-between p-2 rounded-xl text-left text-xs text-slate-200 hover:bg-slate-800 hover:text-white transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <ShieldCheck className="w-4 h-4 text-cyan-400" />
                          <span>Hak Akses & Pengguna</span>
                        </div>
                        <span className="text-[10px] text-slate-500">&rarr;</span>
                      </button>
                    )}

                    {/* Mode Tampilan Terang / Gelap Switcher */}
                    <div className="flex items-center justify-between p-2 rounded-xl text-xs text-slate-200 hover:bg-slate-800 transition-colors">
                      <div className="flex items-center gap-2">
                        {isDark ? (
                          <Moon className="w-4 h-4 text-cyan-400" />
                        ) : (
                          <Sun className="w-4 h-4 text-amber-400" />
                        )}
                        <span>Mode {isDark ? 'Gelap (Dark)' : 'Terang (Light)'}</span>
                      </div>
                      <button
                        type="button"
                        id="btn-dropdown-toggle-theme"
                        onClick={toggleTheme}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all cursor-pointer border ${
                          isDark
                            ? 'bg-amber-500/15 border-amber-500/30 text-amber-300 hover:bg-amber-500/25'
                            : 'bg-cyan-500/15 border-cyan-500/30 text-cyan-300 hover:bg-cyan-500/25'
                        }`}
                      >
                        {isDark ? 'Ganti ke Terang' : 'Ganti ke Gelap'}
                      </button>
                    </div>

                    {onLogout && (
                      <div className="pt-1.5 border-t border-slate-800">
                        <button
                          type="button"
                          id="btn-navbar-logout"
                          onClick={() => {
                            setShowRoleDropdown(false);
                            onLogout();
                          }}
                          className="w-full flex items-center justify-between p-2 rounded-xl text-left text-xs text-rose-400 hover:bg-rose-500/15 hover:text-rose-300 transition-colors font-semibold cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <LogOut className="w-4 h-4 text-rose-400" />
                            <span>Keluar dari Sistem (Logout)</span>
                          </div>
                          <span className="text-[10px] text-rose-400">&rarr;</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* Backdrop for open role dropdown */}
      {showRoleDropdown && (
        <div 
          onClick={() => setShowRoleDropdown(false)}
          className="fixed inset-0 bg-slate-950/40 backdrop-blur-2xs z-30 transition-opacity"
        />
      )}

      {/* Slide-over Notification Panel */}
      <NotificationPopup
        notifications={notifications}
        isOpen={showNotificationPopup}
        onClose={() => setShowNotificationPopup(false)}
        onMarkAsRead={onMarkAsRead}
        onToggleRead={onToggleRead}
        onMarkAllAsRead={onMarkAllAsRead}
        onDeleteNotification={onDeleteNotification}
        onClearAllRead={onClearAllReadNotifications}
        onSelectNotification={(notif) => {
          setShowNotificationPopup(false);
          if (onNavigateFromNotification) {
            onNavigateFromNotification(notif);
          }
        }}
        onViewAllLogs={() => {
          setShowNotificationPopup(false);
          setActiveTab('logs');
        }}
        onReloadActiveAlerts={onReloadActiveAlerts}
        onTriggerTestPush={onTriggerTestPush}
        onOpenMobileSimulator={onOpenMobileSimulator}
      />
    </header>
  );
};
