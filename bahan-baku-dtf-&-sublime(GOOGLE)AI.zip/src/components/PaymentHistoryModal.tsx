import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wallet, 
  CreditCard, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Trash2, 
  Printer, 
  MessageSquare, 
  Plus, 
  Calendar, 
  FileText,
  User,
  ArrowRight,
  Receipt,
  Share2,
  Building2,
  Check,
  FileDown,
  Loader2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Invoice, PaymentRecord, User as AppUser } from '../types';
import { 
  formatRupiah, 
  formatDateIndo, 
  formatWaPhone,
  generatePaymentHistoryWaMessage 
} from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';
import { DueDateSelector } from './DueDateSelector';

interface PaymentHistoryModalProps {
  invoice: Invoice;
  isOpen: boolean;
  onClose: () => void;
  currentUser: AppUser;
  onRecordPayment?: (
    invoiceId: string,
    paymentData: {
      amount: number;
      paymentMethod: string;
      referenceNumber?: string;
      notes?: string;
      date?: string;
      nextDueDate?: string;
      receivedByUser?: AppUser;
    }
  ) => void;
  onDeletePayment?: (invoiceId: string, paymentId: string) => void;
  onViewInvoice?: (invoice: Invoice) => void;
}

export const PaymentHistoryModal: React.FC<PaymentHistoryModalProps> = ({
  invoice,
  isOpen,
  onClose,
  currentUser,
  onRecordPayment,
  onDeletePayment,
  onViewInvoice,
}) => {
  const currentHistory: PaymentRecord[] = invoice?.paymentHistory || (
    invoice && invoice.paidAmount > 0 ? [
      {
        id: `pay-init-${invoice.id}`,
        date: invoice.date + ' 10:00',
        amount: invoice.paidAmount,
        paymentMethod: invoice.paymentMethod,
        notes: invoice.paymentStatus === 'dp' ? 'Uang Muka (DP) Awal' : 'Pembayaran Awal Faktur',
        receivedBy: invoice.createdBy,
      }
    ] : []
  );

  const totalPaid = currentHistory.reduce((sum, p) => sum + p.amount, 0);
  const unpaid = Math.max(0, (invoice?.grandTotal || 0) - totalPaid);
  const paidPercent = Math.min(100, Math.round((totalPaid / (invoice?.grandTotal || 1)) * 100));

  // Form State for new payment installment
  const [amount, setAmount] = useState<number | ''>(unpaid > 0 ? unpaid : '');
  const [paymentMethod, setPaymentMethod] = useState<string>('Transfer Bank');
  const [bankName, setBankName] = useState<string>('BCA');
  const [referenceNumber, setReferenceNumber] = useState<string>('');
  const [paymentDate, setPaymentDate] = useState<string>(() => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}T${pad(now.getHours())}:${pad(now.getMinutes())}`;
  });
  const [notes, setNotes] = useState<string>('');
  const [nextDueDate, setNextDueDate] = useState<string>(invoice?.dueDate || 'tidak_terbatas');
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (invoice) {
      setNextDueDate(invoice.dueDate || 'tidak_terbatas');
    }
  }, [invoice?.id, invoice?.dueDate]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Single Receipt Modal
  const [selectedReceipt, setSelectedReceipt] = useState<PaymentRecord | null>(null);
  const [isSavingReceiptPdf, setIsSavingReceiptPdf] = useState(false);

  const handleSaveReceiptPdf = async (receipt: PaymentRecord) => {
    setIsSavingReceiptPdf(true);
    try {
      const cleanInvNum = invoice.invoiceNumber.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Kuitansi_${cleanInvNum}_KUI_${(receipt?.id || 'REC000').slice(-6).toUpperCase()}_${new Date().toISOString().slice(0, 10)}.pdf`;
      await exportElementToPdf('printable-receipt', filename);
    } finally {
      setIsSavingReceiptPdf(false);
    }
  };

  const handlePrintReceipt = () => {
    printElementDirect('printable-receipt');
  };

  // Quick Amount Presets
  const setQuickAmount = (val: number) => {
    setAmount(Math.min(unpaid, Math.max(1, Math.round(val))));
    setFormError(null);
  };

  const handleSavePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const numAmount = typeof amount === 'number' ? amount : parseFloat(String(amount));
    if (!numAmount || numAmount <= 0) {
      setFormError('Masukkan nominal pembayaran cicilan yang valid (lebih dari Rp 0).');
      return;
    }

    if (numAmount > unpaid) {
      const confirmOverpay = window.confirm(
        `Nominal pembayaran (${formatRupiah(numAmount)}) melebihi sisa tagihan (${formatRupiah(unpaid)}). Tetap simpan?`
      );
      if (!confirmOverpay) return;
    }

    if (!onRecordPayment) {
      setFormError('Fungsi pencatatan pembayaran tidak tersedia.');
      return;
    }

    setIsSubmitting(true);
    const finalMethod = paymentMethod === 'Transfer Bank' ? `Transfer Bank (${bankName})` : paymentMethod;
    const formattedDate = paymentDate.replace('T', ' ');

    try {
      onRecordPayment(invoice.id, {
        amount: numAmount,
        paymentMethod: finalMethod,
        referenceNumber: referenceNumber.trim() || undefined,
        notes: notes.trim() || (numAmount >= unpaid ? 'Pelunasan Faktur' : `Cicilan Ke-${currentHistory.length + 1}`),
        date: formattedDate,
        nextDueDate: numAmount < unpaid ? nextDueDate : undefined,
        receivedByUser: currentUser,
      });

      // If this payment settles or nearly settles the invoice, throw confetti!
      if (numAmount >= unpaid) {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {
          // ignore
        }
      }

      // Reset form
      setAmount('');
      setReferenceNumber('');
      setNotes('');
      setFormError(null);
    } catch {
      setFormError('Gagal menyimpan pembayaran cicilan.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = (paymentId: string) => {
    if (!onDeletePayment) return;
    onDeletePayment(invoice.id, paymentId);
    setDeleteConfirmId(null);
  };

  const handleSendWhatsApp = () => {
    const phone = formatWaPhone(invoice.customerPhone);
    const text = encodeURIComponent(
      generatePaymentHistoryWaMessage({
        invoiceNumber: invoice.invoiceNumber,
        customerName: invoice.customerName,
        grandTotal: invoice.grandTotal,
        paidAmount: totalPaid,
        paymentStatus: invoice.paymentStatus,
        paymentHistory: currentHistory.map((p) => ({
          date: p.date,
          amount: p.amount,
          paymentMethod: p.paymentMethod,
          referenceNumber: p.referenceNumber,
          notes: p.notes,
        })),
      })
    );
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  const handleSendReceiptWhatsApp = (p: PaymentRecord) => {
    const phone = formatWaPhone(invoice.customerPhone);
    const text = encodeURIComponent(
      `*BUKTI TANDA TERIMA PEMBAYARAN CICILAN*\n` +
      `Gudang Bahan DTF & Sublime Pro\n\n` +
      `No. Kuitansi: KUI-${p.id}\n` +
      `No. Invoice: *${invoice.invoiceNumber}*\n` +
      `Konsumen: *${invoice.customerName}*\n` +
      `Tanggal: ${p.date}\n` +
      `Nominal Pembayaran: *${formatRupiah(p.amount)}*\n` +
      `Metode: ${p.paymentMethod}${p.referenceNumber ? ` (Ref: ${p.referenceNumber})` : ''}\n` +
      `Keterangan: ${p.notes || '-'}\n` +
      `Penerima (Kasir): ${p.receivedBy?.userName || currentUser.name}\n\n` +
      `*Posisi Tagihan Saat Ini:*\n` +
      `• Total Invoice: ${formatRupiah(invoice.grandTotal)}\n` +
      `• Total Terbayar: ${formatRupiah(totalPaid)}\n` +
      `• Sisa Tagihan: *${formatRupiah(unpaid)}*\n` +
      `• Status: *${unpaid <= 0 ? 'LUNAS' : 'SEBAGIAN / DICICIL'}*\n\n` +
      `Terima kasih atas pembayaran Anda! 🙏`
    );
    window.open(`https://wa.me/${phone}?text=${text}`, '_blank');
  };

  if (!isOpen || !invoice) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-2 sm:p-4 md:p-6 bg-slate-950/90 backdrop-blur-xs flex justify-center items-start">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl max-w-3xl w-full shadow-2xl text-slate-100 my-2 sm:my-6 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Top Header */}
        <div className="sticky top-0 z-30 bg-slate-900/98 backdrop-blur-md px-4 sm:px-6 py-4 border-b border-slate-800 flex items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-sm sm:text-base text-white truncate">
                  Histori Pembayaran & Cicilan
                </h3>
                <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-cyan-950/70 border border-cyan-500/40 text-cyan-300">
                  {invoice.invoiceNumber}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  unpaid <= 0 
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                    : totalPaid > 0
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                }`}>
                  {unpaid <= 0 ? 'LUNAS' : totalPaid > 0 ? 'DP / DICICIL' : 'BELUM DIBAYAR'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 truncate">
                Konsumen: <span className="font-semibold text-slate-200">{invoice.customerName}</span> ({invoice.customerPhone})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {onViewInvoice && (
              <button
                type="button"
                onClick={() => onViewInvoice(invoice)}
                className="hidden sm:inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-all active:scale-95"
                title="Lihat Nota Faktur Penuh"
              >
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span>Lihat Faktur</span>
              </button>
            )}
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="inline-flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-semibold transition-all active:scale-95"
              title="Kirim Rekap Histori Cicilan via WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Kirim WA</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              title="Tutup Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">

          {/* 1. FINANCIAL SUMMARY CARDS & PROGRESS */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Total Tagihan */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                Total Tagihan Faktur
              </span>
              <div className="mt-1">
                <span className="font-mono text-lg sm:text-xl font-extrabold text-white">
                  {formatRupiah(invoice.grandTotal)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Tgl Faktur: {invoice.date}
                </span>
              </div>
            </div>

            {/* Total Terbayar */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Total Telah Terbayar
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {paidPercent}%
                </span>
              </div>
              <div className="mt-1">
                <span className="font-mono text-lg sm:text-xl font-extrabold text-emerald-400">
                  {formatRupiah(totalPaid)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {currentHistory.length} kali pembayaran masuk
                </span>
              </div>
            </div>

            {/* Sisa Tagihan (Piutang) */}
            <div className={`border rounded-xl p-3.5 flex flex-col justify-between ${
              unpaid <= 0
                ? 'bg-emerald-950/20 border-emerald-500/30'
                : 'bg-rose-950/20 border-rose-500/30'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Sisa Tagihan (Kekurangan)
                </span>
                {unpaid <= 0 ? (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Lunas
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-[10px] font-bold text-rose-400">
                    <Clock className="w-3.5 h-3.5" /> Belum Lunas
                  </span>
                )}
              </div>
              <div className="mt-1">
                <span className={`font-mono text-lg sm:text-xl font-extrabold ${
                  unpaid <= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}>
                  {formatRupiah(unpaid)}
                </span>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  {unpaid <= 0 ? 'Tidak ada sisa piutang' : `Jatuh Tempo: ${invoice.dueDate || '-'}`}
                </span>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
            <div className="flex justify-between items-center text-xs mb-1.5">
              <span className="text-slate-400 font-medium">Progres Pelunasan Tagihan</span>
              <span className="font-mono font-bold text-cyan-300">{paidPercent}% Terbayar</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${
                  unpaid <= 0 ? 'bg-emerald-500' : 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                }`}
                style={{ width: `${paidPercent}%` }}
              />
            </div>
          </div>

          {/* 2. FORM CATAT PEMBAYARAN CICILAN BARU */}
          {unpaid > 0 ? (
            <div className="bg-slate-950/80 border border-cyan-500/30 rounded-2xl p-4 sm:p-5 shadow-inner">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold">
                    <Plus className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-white">Catat Pembayaran Cicilan Baru</h4>
                    <p className="text-[11px] text-slate-400">
                      Masukkan cicilan yang baru saja disetorkan oleh konsumen {invoice.customerName}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold text-rose-300 bg-rose-950/50 border border-rose-500/30 px-2.5 py-1 rounded-lg">
                  Sisa: {formatRupiah(unpaid)}
                </span>
              </div>

              {formError && (
                <div className="mb-4 p-3 bg-rose-500/10 border border-rose-500/40 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              <form onSubmit={handleSavePayment} className="space-y-4">
                {/* Nominal Input & Quick Presets */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-200">
                      Nominal Pembayaran Cicilan (Rp) <span className="text-rose-400">*</span>
                    </label>
                    {typeof amount === 'number' && amount > 0 && (
                      <span className="text-xs font-mono text-cyan-400 font-bold">
                        Terbilang: {formatRupiah(amount)}
                      </span>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono font-bold text-slate-400 text-sm">
                      Rp
                    </span>
                    <input
                      type="number"
                      min="1000"
                      step="1000"
                      value={amount}
                      onChange={(e) => {
                        const val = e.target.value === '' ? '' : Number(e.target.value);
                        setAmount(val);
                        setFormError(null);
                      }}
                      placeholder={`Contoh: ${unpaid}`}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono font-bold text-base focus:border-cyan-500 focus:outline-hidden transition-all shadow-inner"
                      required
                    />
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap text-xs">
                    <span className="text-[11px] text-slate-400 mr-1">Pilihan Cepat:</span>
                    <button
                      type="button"
                      onClick={() => setQuickAmount(unpaid)}
                      className="px-2.5 py-1 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg font-semibold active:scale-95 transition-all"
                    >
                      Pelunasan Penuh ({formatRupiah(unpaid)})
                    </button>
                    {unpaid >= 100000 && (
                      <button
                        type="button"
                        onClick={() => setQuickAmount(unpaid / 2)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg active:scale-95 transition-all"
                      >
                        50% Sisa ({formatRupiah(Math.round(unpaid / 2))})
                      </button>
                    )}
                    {unpaid > 250000 && (
                      <button
                        type="button"
                        onClick={() => setQuickAmount(250000)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg active:scale-95 transition-all"
                      >
                        Rp 250.000
                      </button>
                    )}
                    {unpaid > 500000 && (
                      <button
                        type="button"
                        onClick={() => setQuickAmount(500000)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg active:scale-95 transition-all"
                      >
                        Rp 500.000
                      </button>
                    )}
                  </div>
                </div>

                {/* Grid for Method, Bank/Details, Date */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {/* Metode */}
                  <div>
                    <label className="text-xs font-semibold text-slate-200 block mb-1">
                      Metode Pembayaran
                    </label>
                    <select
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                    >
                      <option value="Transfer Bank">Transfer Bank</option>
                      <option value="Tunai">Tunai (Cash di Kasir)</option>
                      <option value="QRIS">QRIS / E-Wallet</option>
                    </select>
                  </div>

                  {/* If Transfer Bank, choose bank */}
                  {paymentMethod === 'Transfer Bank' ? (
                    <div>
                      <label className="text-xs font-semibold text-slate-200 block mb-1">
                        Bank Rekening Tujuan
                      </label>
                      <select
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                      >
                        <option value="BCA">BCA (Operasional)</option>
                        <option value="Mandiri">Mandiri</option>
                        <option value="BRI">BRI</option>
                        <option value="BNI">BNI</option>
                        <option value="Bank Lain">Bank Lain / Virtual Account</option>
                      </select>
                    </div>
                  ) : (
                    <div>
                      <label className="text-xs font-semibold text-slate-200 block mb-1">
                        No. Referensi / Bukti
                      </label>
                      <input
                        type="text"
                        value={referenceNumber}
                        onChange={(e) => setReferenceNumber(e.target.value)}
                        placeholder="Opsional (No. Struk/Trx)"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                      />
                    </div>
                  )}

                  {/* Tanggal & Waktu */}
                  <div>
                    <label className="text-xs font-semibold text-slate-200 block mb-1">
                      Tanggal & Jam Bayar
                    </label>
                    <input
                      type="datetime-local"
                      value={paymentDate}
                      onChange={(e) => setPaymentDate(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                {/* Row 2: Reference (if Bank) and Notes */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {paymentMethod === 'Transfer Bank' && (
                    <div>
                      <label className="text-xs font-semibold text-slate-200 block mb-1">
                        No. Referensi / Bukti Transfer
                      </label>
                      <input
                        type="text"
                        value={referenceNumber}
                        onChange={(e) => setReferenceNumber(e.target.value)}
                        placeholder="Contoh: TRF-BCA-92841"
                        className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                      />
                    </div>
                  )}

                  <div className={paymentMethod === 'Transfer Bank' ? '' : 'sm:col-span-2'}>
                    <label className="text-xs font-semibold text-slate-200 block mb-1">
                      Catatan / Keterangan Pembayaran
                    </label>
                    <input
                      type="text"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Contoh: Pembayaran cicilan tahap 2, bukti di WA"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-slate-100 text-xs focus:border-cyan-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                {/* Batas Jatuh Tempo untuk Sisa Tagihan (Tidak Terbatas, 2 Minggu, 1 Bulan, 2 Bulan) */}
                {(typeof amount !== 'number' || amount < unpaid) && (
                  <div className="pt-2 border-t border-slate-800/80 bg-slate-900/50 p-3.5 rounded-xl border border-slate-800">
                    <DueDateSelector
                      value={nextDueDate}
                      onChange={setNextDueDate}
                      label="Batas Jatuh Tempo Sisa Tagihan"
                      helperText="Atur tanggal jatuh tempo untuk sisa piutang: Bisa tidak terbatas, atau pilih aksi cepat 2 minggu, 1 bulan, 2 bulan."
                      colorTheme="cyan"
                      compact={false}
                    />
                  </div>
                )}

                {/* Submit Button */}
                <div className="flex items-center justify-between pt-2">
                  <span className="text-[11px] text-slate-400">
                    Kasir Penerima: <strong className="text-slate-200">{currentUser.name}</strong>
                  </span>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md active:scale-95 transition-all disabled:opacity-50"
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>{isSubmitting ? 'Menyimpan...' : 'Simpan Pembayaran Cicilan'}</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-sm text-emerald-300">Invoice Telah Lunas Sepenuhnya</h4>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Seluruh tagihan senilai <strong className="text-white">{formatRupiah(invoice.grandTotal)}</strong> telah berhasil dilunasi oleh {invoice.customerName}.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleSendWhatsApp}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 shadow-sm active:scale-95 transition-all"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Kirim Bukti Lunas WA</span>
              </button>
            </div>
          )}

          {/* 3. DAFTAR RIWAYAT CICILAN & PEMBAYARAN */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                <h4 className="font-bold text-sm text-white">
                  Rincian Riwayat Pembayaran Masuk ({currentHistory.length})
                </h4>
              </div>
              <span className="text-xs text-slate-400">
                Total Masuk: <strong className="text-emerald-400 font-mono">{formatRupiah(totalPaid)}</strong>
              </span>
            </div>

            {currentHistory.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/40 rounded-xl border border-slate-800 text-slate-500 text-xs">
                Belum ada catatan riwayat pembayaran untuk invoice ini.
              </div>
            ) : (
              <div className="space-y-2.5">
                {currentHistory.map((record, index) => {
                  const isFirst = index === 0;
                  const isLast = index === currentHistory.length - 1;
                  return (
                    <div
                      key={record.id || index}
                      className="bg-slate-950 border border-slate-800 hover:border-slate-700/80 rounded-xl p-3.5 transition-all"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                        
                        {/* Left: Index badge & Date & Method */}
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-xs text-cyan-300 shrink-0">
                            #{index + 1}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-xs text-white">
                                {isFirst && invoice.paymentStatus === 'dp'
                                  ? 'Uang Muka (DP)'
                                  : isLast && unpaid <= 0
                                  ? 'Pelunasan Akhir'
                                  : `Cicilan Ke-${index + 1}`}
                              </span>
                              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                                {record.paymentMethod}
                              </span>
                              {record.referenceNumber && (
                                <span className="text-[10px] text-cyan-400 font-mono">
                                  Ref: {record.referenceNumber}
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                              <span>{formatDateIndo(record.date.slice(0, 10))} • {record.date.slice(11, 16) || '10:00'}</span>
                              <span>•</span>
                              <span>Kasir: {record.receivedBy?.userName || invoice.createdBy.userName}</span>
                            </div>
                            {record.notes && (
                              <p className="text-[11px] text-slate-400 mt-1 italic">
                                "{record.notes}"
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Right: Amount & Actions */}
                        <div className="flex items-center justify-between sm:justify-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                          <div className="text-left sm:text-right">
                            <span className="text-[10px] text-slate-500 block uppercase font-medium">Nominal Dibayar</span>
                            <span className="font-mono text-sm sm:text-base font-extrabold text-emerald-400">
                              {formatRupiah(record.amount)}
                            </span>
                          </div>

                          <div className="flex items-center gap-1">
                            {/* Struk Kuitansi Mini */}
                            <button
                              type="button"
                              onClick={() => setSelectedReceipt(record)}
                              title="Cetak Kuitansi Cicilan Ini"
                              className="p-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-1 active:scale-95 transition-all"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                              <span className="text-[11px]">Kuitansi</span>
                            </button>

                            {/* Share this single payment to WA */}
                            <button
                              type="button"
                              onClick={() => handleSendReceiptWhatsApp(record)}
                              title="Kirim Bukti Cicilan ke WhatsApp"
                              className="p-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-xs font-semibold active:scale-95 transition-all"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete Payment */}
                            {onDeletePayment && (
                              deleteConfirmId === record.id ? (
                                <div className="flex items-center gap-1 bg-rose-950/80 p-1 rounded-lg border border-rose-500/40">
                                  <button
                                    type="button"
                                    onClick={() => handleDelete(record.id)}
                                    className="px-2 py-0.5 bg-rose-600 text-white rounded text-[10px] font-bold"
                                  >
                                    Ya, Hapus
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setDeleteConfirmId(null)}
                                    className="px-1.5 py-0.5 text-slate-300 hover:text-white text-[10px]"
                                  >
                                    Batal
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setDeleteConfirmId(record.id)}
                                  title="Hapus Catatan Pembayaran"
                                  className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

        </div>

        {/* Modal Bottom Footer */}
        <div className="bg-slate-900 px-4 sm:px-6 py-3 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-400">
            Total Sisa: <strong className={unpaid <= 0 ? 'text-emerald-400' : 'text-rose-400 font-mono font-bold'}>{formatRupiah(unpaid)}</strong>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSendWhatsApp}
              className="px-3.5 py-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Kirim Rekap WA</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>

      </div>

      {/* MODAL PRINT / KUITANSI TANDA TERIMA PEMBAYARAN CICILAN MINI */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-60 overflow-y-auto p-4 bg-slate-950/95 backdrop-blur-md flex justify-center items-center">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-cyan-400" />
                <h4 className="font-bold text-sm text-white">Kuitansi Pembayaran Cicilan</h4>
              </div>
              <button
                type="button"
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Paper */}
            <div className="p-4 sm:p-6">
              <div id="printable-receipt" className="bg-white text-slate-900 p-6 rounded-xl shadow font-sans text-xs space-y-4">
                {/* Header Kuitansi */}
                <div className="border-b-2 border-slate-900 pb-3 text-center">
                  <h2 className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
                    GUDANG BAHAN DTF & SUBLIME
                  </h2>
                  <p className="text-[10px] text-slate-600">
                    Tanda Terima Penerimaan Kas & Pembayaran Cicilan
                  </p>
                  <div className="mt-2 inline-block px-3 py-0.5 bg-slate-900 text-white font-mono font-bold text-[10px] uppercase rounded">
                    KUITANSI: KUI-{(selectedReceipt?.id || 'REC000').slice(-6).toUpperCase()}
                  </div>
                </div>

                {/* Data Kuitansi */}
                <div className="space-y-2 text-xs divide-y divide-slate-100">
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Tanggal & Jam:</span>
                    <span className="font-mono font-semibold text-slate-800">{selectedReceipt.date}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Telah Diterima Dari:</span>
                    <span className="font-bold text-slate-900">{invoice.customerName}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">No. Invoice Tagihan:</span>
                    <span className="font-mono font-bold text-slate-900">{invoice.invoiceNumber}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-slate-500">Metode Pembayaran:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedReceipt.paymentMethod} {selectedReceipt.referenceNumber ? `(Ref: ${selectedReceipt.referenceNumber})` : ''}
                    </span>
                  </div>
                  {selectedReceipt.notes && (
                    <div className="flex justify-between py-1">
                      <span className="text-slate-500">Keterangan:</span>
                      <span className="text-slate-700 italic">{selectedReceipt.notes}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center py-2 bg-slate-100 px-2 rounded-lg font-bold">
                    <span className="text-slate-700 uppercase">Jumlah Dibayar:</span>
                    <span className="font-mono text-base text-emerald-800">
                      {formatRupiah(selectedReceipt.amount)}
                    </span>
                  </div>
                </div>

                {/* Posisi Tagihan Saat Ini */}
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-[11px] space-y-1">
                  <div className="flex justify-between text-slate-600">
                    <span>Total Tagihan Invoice:</span>
                    <span className="font-mono">{formatRupiah(invoice.grandTotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600">
                    <span>Total Sudah Terbayar:</span>
                    <span className="font-mono text-emerald-700 font-bold">{formatRupiah(totalPaid)}</span>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 pt-1 font-bold text-slate-800">
                    <span>Sisa Tagihan Berjalan:</span>
                    <span className={`font-mono ${unpaid <= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                      {formatRupiah(unpaid)} {unpaid <= 0 ? '(LUNAS)' : ''}
                    </span>
                  </div>
                </div>

                {/* Tanda Tangan */}
                <div className="grid grid-cols-2 gap-4 pt-4 text-center text-[10px] text-slate-600">
                  <div>
                    <p>Pembayar / Konsumen,</p>
                    <div className="h-10"></div>
                    <p className="font-semibold text-slate-900 border-t border-slate-300 pt-0.5">
                      {invoice.customerName}
                    </p>
                  </div>
                  <div>
                    <p>Penerima / Kasir Gudang,</p>
                    <div className="h-10"></div>
                    <p className="font-semibold text-slate-900 border-t border-slate-300 pt-0.5">
                      {selectedReceipt.receivedBy?.userName || currentUser.name}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Receipt Modal Footer */}
            <div className="p-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => handleSendReceiptWhatsApp(selectedReceipt)}
                className="px-3 py-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>Kirim WA</span>
              </button>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedReceipt(null)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveReceiptPdf(selectedReceipt)}
                  disabled={isSavingReceiptPdf}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all"
                  title="Simpan lembar kuitansi sebagai file PDF"
                >
                  {isSavingReceiptPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isSavingReceiptPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
