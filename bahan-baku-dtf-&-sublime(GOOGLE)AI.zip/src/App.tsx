import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_USERS, 
  INITIAL_MOVEMENTS, 
  INITIAL_INVOICES, 
  INITIAL_LOGS, 
  INITIAL_PUSH_NOTIFICATIONS,
  INITIAL_COMPANY_PROFILE
} from './data/initialData';
import { 
  Product, 
  User, 
  UserRole,
  StockMovement, 
  Invoice, 
  InvoiceItem,
  ActivityLog, 
  PushNotification,
  CategoryItem,
  SupplierItem,
  CustomerItem,
  PaymentRecord,
  SystemCheckpoint,
  BackupFileData,
  CompanyProfile
} from './types';
import { 
  DEFAULT_CATEGORIES, 
  DEFAULT_UNITS, 
  DEFAULT_LOCATIONS,
  DEFAULT_SUPPLIERS,
  DEFAULT_CUSTOMERS,
  DEFAULT_DIVISIONS
} from './data/masterData';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { StockList } from './components/StockList';
import { PurchasesView } from './components/PurchasesView';
import { ProductionView } from './components/ProductionView';
import { SalesInvoiceView } from './components/SalesInvoiceView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { ReportsView } from './components/ReportsView';
import { ActivityLogsView } from './components/ActivityLogsView';
import { MobilePushSimulator } from './components/MobilePushSimulator';
import { RestockModal } from './components/RestockModal';
import { MasterDataModal } from './components/MasterDataModal';
import { LoginView } from './components/LoginView';
import { AccessControlView } from './components/AccessControlView';
import { StockOpnameView } from './components/StockOpnameView';
import { BackupCheckpointModal } from './components/BackupCheckpointModal';
import { CompanyProfileModal } from './components/CompanyProfileModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { ShieldAlert, Database, Bell, X } from 'lucide-react';
import { 
  playPushNotificationSound, 
  requestAndSendBrowserNotification, 
  getInvoiceDueInfo, 
  formatRupiah,
  getWIBNow,
  getWIBDateOnly,
  formatTimestampWIB
} from './utils/helpers';
import { 
  auth, 
  logoutFirebase, 
  testConnection 
} from './firebase';
import { 
  saveDocument, 
  removeDocument, 
  saveSetting, 
  seedInitialFirestoreData, 
  subscribeToCollection, 
  subscribeToSetting,
  batchSaveDocuments,
  batchRemoveDocuments,
  fetchCollectionOnce,
  replaceCollectionInFirestore,
  clearOperationalCloudData,
  deduplicateById
} from './services/firestoreService';
import { onAuthStateChanged } from 'firebase/auth';

export default function App() {
  // One-time purge of legacy browser-cached dummy data
  if (typeof window !== 'undefined') {
    const PURGE_KEY = 'dtf_sublime_dummy_purged_v2';
    if (!localStorage.getItem(PURGE_KEY)) {
      localStorage.setItem('dtf_sublime_products', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_movements', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_invoices', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_logs', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_push', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_suppliers', JSON.stringify([]));
      localStorage.setItem('dtf_sublime_customers', JSON.stringify([]));
      localStorage.removeItem('dtf_sublime_checkpoints');
      localStorage.setItem(PURGE_KEY, 'true');
    }
  }

  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const saved = localStorage.getItem('dtf_sublime_auth_active');
    return saved === 'true';
  });

  // Cloud Synchronization States
  const [isCloudLoading, setIsCloudLoading] = useState<boolean>(() => {
    // If device has no local cache, keep loading true to wait for cloud snapshot
    return !localStorage.getItem('dtf_sublime_products');
  });
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'connected' | 'syncing' | 'offline'>('syncing');
  const [lastSyncTime, setLastSyncTime] = useState<string>('');

  // Persistence via localStorage
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // Dynamic Users & Permissions state with persistence and migration fallback
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_users');
      if (saved) {
        const parsed: User[] = JSON.parse(saved);
        return parsed.map((u) => {
          if (u.id === 'user-1' || u.role === 'owner') {
            return {
              ...u,
              name: 'Owner',
              email: u.email || 'owner@cetakprint.com',
              password: '10203040',
              canViewFinancials: true,
              canManageProducts: true,
              canDeleteProducts: true,
              canRestock: true,
              canEditPurchases: true,
              canDeletePurchases: true,
              canUseForProduction: true,
              canEditProductionUsage: true,
              canDeleteProductionUsage: true,
              canCreateSalesInvoice: true,
              canEditSalesInvoice: true,
              canDeleteSalesInvoice: true,
              canManagePayments: true,
              canManageMasterData: true,
              canManageAccessControl: true,
              canManageCompanyProfile: true,
              canDeleteLogs: true,
              canExportReports: true,
              canStockOpname: true,
            };
          }
          if (u.id === 'user-2' && (u.email === 'gepratama18441@gmail.com' || u.name === 'Ge')) {
            return {
              ...u,
              name: 'Supervisor Gudang',
              email: 'spv@cetakprint.com',
              password: 'spv123',
            };
          }
          return {
            ...u,
            password: u.password || (
              u.id === 'user-2' ? 'spv123' :
              u.id === 'user-3' ? '123456' :
              u.id === 'user-4' ? '123456' : '123456'
            ),
            canViewFinancials: u.canViewFinancials ?? false,
            canManageProducts: u.canManageProducts ?? true,
            canDeleteProducts: u.canDeleteProducts ?? (u.role === 'warehouse_admin'),
            canRestock: u.canRestock ?? true,
            canEditPurchases: u.canEditPurchases ?? (u.role === 'warehouse_admin'),
            canDeletePurchases: u.canDeletePurchases ?? (u.role === 'warehouse_admin'),
            canUseForProduction: u.canUseForProduction ?? false,
            canEditProductionUsage: u.canEditProductionUsage ?? (u.role === 'warehouse_admin'),
            canDeleteProductionUsage: u.canDeleteProductionUsage ?? (u.role === 'warehouse_admin'),
            canCreateSalesInvoice: u.canCreateSalesInvoice ?? false,
            canEditSalesInvoice: u.canEditSalesInvoice ?? (u.role === 'warehouse_admin' || u.role === 'cashier_sales'),
            canDeleteSalesInvoice: u.canDeleteSalesInvoice ?? (u.role === 'warehouse_admin'),
            canManagePayments: u.canManagePayments ?? true,
            canManageMasterData: u.canManageMasterData ?? true,
            canManageAccessControl: u.canManageAccessControl ?? false,
            canManageCompanyProfile: u.canManageCompanyProfile ?? (u.role === 'warehouse_admin'),
            canDeleteLogs: u.canDeleteLogs ?? false,
            canExportReports: u.canExportReports ?? true,
            canStockOpname: u.canStockOpname ?? (u.role === 'warehouse_admin'),
          };
        });
      }
    } catch {
      // fallback
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    const isAuthActive = localStorage.getItem('dtf_sublime_auth_active') === 'true';
    const savedUserId = localStorage.getItem('dtf_sublime_auth_user_id');
    const savedUserStr = localStorage.getItem('dtf_sublime_current_user');

    try {
      const savedUsers = localStorage.getItem('dtf_sublime_users');
      const userList: User[] = savedUsers ? JSON.parse(savedUsers) : INITIAL_USERS;

      // Priority 1: Match active user by ID from registered user list
      if (isAuthActive && savedUserId) {
        const matched = userList.find((u) => u.id === savedUserId);
        if (matched) return matched;
      }

      // Priority 2: Use saved user object if active
      if (isAuthActive && savedUserStr) {
        const parsed = JSON.parse(savedUserStr);
        if (parsed && parsed.id) return parsed;
      }

      // Priority 3: Fallback match by saved user ID
      if (savedUserId) {
        const matched = userList.find((u) => u.id === savedUserId);
        if (matched) return matched;
      }
    } catch {}

    return INITIAL_USERS[0];
  });

  // Reference always holding the freshest active user to avoid stale closures in callbacks
  const currentUserRef = useRef<User>(currentUser);
  useEffect(() => {
    currentUserRef.current = currentUser;
    if (currentUser && currentUser.id) {
      localStorage.setItem('dtf_sublime_current_user', JSON.stringify(currentUser));
      localStorage.setItem('dtf_sublime_auth_user_id', currentUser.id);
    }
  }, [currentUser]);

  const [movements, setMovements] = useState<StockMovement[]>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_movements');
      const list: StockMovement[] = saved ? JSON.parse(saved) : INITIAL_MOVEMENTS;
      // Filter out PO-IN-2026-041 / mov-5
      const filtered = list.filter((m) => m.id !== 'mov-5' && m.referenceNo !== 'PO-IN-2026-041');
      if (saved && filtered.length !== list.length) {
        localStorage.setItem('dtf_sublime_movements', JSON.stringify(filtered));
      }
      return filtered;
    } catch {
      return INITIAL_MOVEMENTS.filter((m) => m.id !== 'mov-5' && m.referenceNo !== 'PO-IN-2026-041');
    }
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_invoices');
      const parsed: Invoice[] = saved ? JSON.parse(saved) : INITIAL_INVOICES;
      return parsed.map((inv) => {
        if (!inv.paymentHistory || inv.paymentHistory.length === 0) {
          if (inv.paidAmount > 0) {
            return {
              ...inv,
              paymentHistory: [
                {
                  id: `pay-init-${inv.id}`,
                  date: inv.date ? `${inv.date} 10:00` : '2026-09-18 10:00',
                  amount: inv.paidAmount,
                  paymentMethod: inv.paymentMethod || 'Transfer Bank',
                  notes: inv.paymentStatus === 'dp' ? 'Uang Muka (DP) Awal' : 'Pelunasan Awal Faktur',
                  receivedBy: inv.createdBy,
                },
              ],
            };
          }
          return { ...inv, paymentHistory: [] };
        }
        return inv;
      });
    } catch {
      return INITIAL_INVOICES;
    }
  });

  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [notifications, setNotifications] = useState<PushNotification[]>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_push');
      const list: PushNotification[] = saved ? JSON.parse(saved) : INITIAL_PUSH_NOTIFICATIONS;
      // Deduplicate by ID and ensure no corrupted duplicate keys from previous sessions
      const seen = new Set<string>();
      const deduped: PushNotification[] = [];
      for (const item of list) {
        if (item && item.id && !seen.has(item.id)) {
          seen.add(item.id);
          deduped.push(item);
        }
      }
      return deduped.length > 0 ? deduped : INITIAL_PUSH_NOTIFICATIONS;
    } catch {
      return INITIAL_PUSH_NOTIFICATIONS;
    }
  });

  // Real-time Multi-Device Notification Tracking
  const knownNotificationIdsRef = useRef<Set<string>>(new Set());
  const isFirstNotificationLoadRef = useRef<boolean>(true);
  const [realtimeNotificationToast, setRealtimeNotificationToast] = useState<PushNotification | null>(null);

  // Initialize known notification IDs on mount
  useEffect(() => {
    notifications.forEach((n) => {
      if (n && n.id) {
        knownNotificationIdsRef.current.add(n.id);
      }
    });
  }, []);

  // Dismiss floating notification toast if logged out
  useEffect(() => {
    if (!isAuthenticated) {
      setRealtimeNotificationToast(null);
    }
  }, [isAuthenticated]);

  // Master Data: Categories, Units, Locations (customizable by user)
  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_categories');
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  });

  const [units, setUnits] = useState<string[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_units');
    return saved ? JSON.parse(saved) : DEFAULT_UNITS;
  });

  const [locations, setLocations] = useState<string[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_locations');
    return saved ? JSON.parse(saved) : DEFAULT_LOCATIONS;
  });

  const [suppliers, setSuppliers] = useState<SupplierItem[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_suppliers');
    return saved ? JSON.parse(saved) : DEFAULT_SUPPLIERS;
  });

  const [customers, setCustomers] = useState<CustomerItem[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_customers');
    return saved ? JSON.parse(saved) : DEFAULT_CUSTOMERS;
  });

  const [divisions, setDivisions] = useState<string[]>(() => {
    const saved = localStorage.getItem('dtf_sublime_divisions');
    return saved ? JSON.parse(saved) : DEFAULT_DIVISIONS;
  });

  // Company Profile & Application Identity State
  const [companyProfile, setCompanyProfile] = useState<CompanyProfile>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_company_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        const resolvedBankAccounts = Array.isArray(parsed.bankAccounts) && parsed.bankAccounts.length > 0
          ? parsed.bankAccounts
          : (parsed.bankAccountNo ? [{
              id: 'bank-1',
              bankName: parsed.bankName || 'BCA',
              accountNumber: parsed.bankAccountNo,
              holderName: parsed.bankAccountHolder || parsed.companyName || INITIAL_COMPANY_PROFILE.bankAccountHolder,
              isPrimary: true,
              notes: 'Rekening Utama Operasional',
            }] : INITIAL_COMPANY_PROFILE.bankAccounts);

        return {
          ...INITIAL_COMPANY_PROFILE,
          ...parsed,
          bankAccounts: resolvedBankAccounts,
        };
      }
    } catch {
      // fallback
    }
    return INITIAL_COMPANY_PROFILE;
  });

  const [isCompanyProfileModalOpen, setIsCompanyProfileModalOpen] = useState(false);

  // Sync document title and meta with customized company & app branding
  useEffect(() => {
    if (typeof document !== 'undefined') {
      const appName = companyProfile.appName || 'DTF & Sublime';
      const companyName = companyProfile.companyName || 'Gudang Stok Sablon';
      document.title = `${appName} - ${companyName}`;
    }
  }, [companyProfile]);

  // Centralized, bulletproof Actor Resolver ensuring 100% accurate user name, role, and roleTitle
  const getEffectiveActor = (
    explicitActor?: User | { id: string; name?: string; role?: UserRole; roleTitle?: string } | null
  ): { id: string; name: string; role: UserRole; roleTitle: string } => {
    let base = explicitActor || currentUserRef.current || currentUser;
    if (!base || !base.id) {
      const activeUserId = localStorage.getItem('dtf_sublime_auth_user_id');
      if (activeUserId) {
        const found = users.find((u) => u.id === activeUserId);
        if (found) base = found;
      }
    }
    const matched = users.find((u) => u.id === base?.id);
    const id = base?.id || 'user-1';
    const name = matched?.name || base?.name || (id === 'user-1' ? 'Owner' : 'Pengguna');
    const role = (matched?.role || base?.role || (id === 'user-1' ? 'owner' : 'warehouse_admin')) as UserRole;
    const roleTitle = matched?.roleTitle || ('roleTitle' in (base || {}) && (base as any).roleTitle) || (
      role === 'owner' ? 'Pemilik Usaha (Owner)' :
      role === 'warehouse_admin' ? 'Supervisor Gudang (SPV)' :
      role === 'cashier_sales' ? 'Kasir & Sales Bahan' :
      role === 'production_staff' ? 'Operator Produksi Sablon' : role
    );
    return { id, name, role, roleTitle };
  };

  // Centralized, bulletproof Activity Logger that guarantees accurate user attribution
  const logActivity = (
    actionType: ActivityLog['actionType'],
    title: string,
    details: string,
    severity: 'info' | 'success' | 'warning' | 'critical' = 'info',
    explicitActor?: User | { id: string; name?: string; role?: UserRole; roleTitle?: string } | null
  ) => {
    const actor = getEffectiveActor(explicitActor);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType,
      title,
      details,
      severity,
    };

    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return newLog;
  };

  const handleSaveCompanyProfile = (updated: CompanyProfile) => {
    setCompanyProfile(updated);
    localStorage.setItem('dtf_sublime_company_profile', JSON.stringify(updated));
    saveSetting('company_profile', updated);

    const actor = currentUserRef.current || currentUser;
    const actorRoleTitle = actor.roleTitle || users.find((u) => u.id === actor.id)?.roleTitle || actor.role;

    logActivity(
      'SETTINGS_UPDATE',
      'Pembaruan Identitas Usaha & Aplikasi',
      `Profil perusahaan (${updated.companyName}) dan identitas aplikasi diperbarui oleh ${actor.name} (${actorRoleTitle}).`,
      'info',
      actor
    );

    addPushNotification({
      title: '🏢 Identitas Usaha Diperbarui',
      message: `Profil "${updated.companyName}" dan kop nota/laporan resmi telah disimpan.`,
      type: 'system',
    });
  };

  const handleResetCompanyProfileToDefault = () => {
    setCompanyProfile(INITIAL_COMPANY_PROFILE);
    localStorage.setItem('dtf_sublime_company_profile', JSON.stringify(INITIAL_COMPANY_PROFILE));

    const actor = currentUserRef.current || currentUser;
    const actorRoleTitle = actor.roleTitle || users.find((u) => u.id === actor.id)?.roleTitle || actor.role;

    logActivity(
      'SETTINGS_UPDATE',
      'Reset Identitas ke Bawaan Sistem',
      `Profil perusahaan dikembalikan ke setelan default pabrik oleh ${actor.name} (${actorRoleTitle}).`,
      'warning',
      actor
    );

    addPushNotification({
      title: '🔄 Identitas Direset Default',
      message: 'Profil perusahaan dan branding aplikasi telah dikembalikan ke setelan awal bawaan pabrik.',
      type: 'system',
    });
  };

  // UI Navigation states
  const [activeTab, setActiveTab] = useState<'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname'>('inventory');
  const [isMobileSimulatorOpen, setIsMobileSimulatorOpen] = useState(false);
  const [isRestockModalOpen, setIsRestockModalOpen] = useState(false);
  const [isGlobalMasterDataModalOpen, setIsGlobalMasterDataModalOpen] = useState(false);
  const [globalMasterDataTab, setGlobalMasterDataTab] = useState<'category' | 'unit' | 'location' | 'supplier' | 'customer' | 'division'>('category');
  const [selectedProductForAction, setSelectedProductForAction] = useState<Product | null>(null);
  const [initialFilterCritical, setInitialFilterCritical] = useState(false);
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);

  // Periodic Auto-Checkpoint (every 5 minutes)
  useEffect(() => {
    const runAutoCheckpoint = () => {
      if (products.length === 0 && movements.length === 0 && invoices.length === 0) return;
      try {
        const saved = localStorage.getItem('dtf_sublime_checkpoints');
        const existing: SystemCheckpoint[] = saved ? JSON.parse(saved) : [];
        const now = new Date();
        const formatted = now.toLocaleString('id-ID', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        });

        const restockCount = movements.filter((m) => m.type === 'restock').length;
        const productionCount = movements.filter((m) => m.type === 'production').length;
        const saleCount = movements.filter((m) => m.type === 'sale').length;
        const adjustmentCount = movements.filter((m) => m.type === 'adjustment').length;

        const autoCp: SystemCheckpoint = {
          id: `cp-auto-${Date.now()}`,
          timestamp: now.toISOString(),
          formattedTime: formatted,
          type: 'auto',
          label: 'Checkpoint Otomatis Berkala',
          creatorName: 'Sistem Otomatis',
          creatorRole: 'Auto-Backup Service',
          summary: {
            productsCount: products.length,
            movementsCount: movements.length,
            movementsBreakdown: {
              restockCount,
              productionCount,
              saleCount,
              adjustmentCount,
            },
            invoicesCount: invoices.length,
            logsCount: logs.length,
            totalStockValue: products.reduce((acc, p) => acc + (p.currentStock * p.costPrice), 0),
          },
          snapshot: {
            products: JSON.parse(JSON.stringify(products)),
            movements: JSON.parse(JSON.stringify(movements)),
            invoices: JSON.parse(JSON.stringify(invoices)),
            categories: JSON.parse(JSON.stringify(categories)),
            units: JSON.parse(JSON.stringify(units)),
            locations: JSON.parse(JSON.stringify(locations)),
            suppliers: JSON.parse(JSON.stringify(suppliers)),
            customers: JSON.parse(JSON.stringify(customers)),
            divisions: JSON.parse(JSON.stringify(divisions)),
            logs: JSON.parse(JSON.stringify(logs)),
            users: JSON.parse(JSON.stringify(users)),
            companyProfile: JSON.parse(JSON.stringify(companyProfile)),
          },
        };

        const updated = [autoCp, ...existing.slice(0, 14)];
        localStorage.setItem('dtf_sublime_checkpoints', JSON.stringify(updated));
      } catch (err) {
        console.warn('Auto checkpoint failed:', err);
      }
    };

    const interval = setInterval(runAutoCheckpoint, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [products, movements, invoices, categories, units, locations, suppliers, customers, divisions, logs, users, companyProfile]);

  // Firebase Firestore Real-Time Cloud Synchronization
  useEffect(() => {
    // 1. Connection check
    testConnection().then((connected) => {
      setCloudSyncStatus(connected ? 'connected' : 'offline');
    });

    // 2. Initial cloud seed if Firestore is brand new
    seedInitialFirestoreData({
      products,
      categories,
      suppliers,
      customers,
      users,
      companyProfile,
      units,
      locations,
      divisions,
      movements,
      invoices,
      notifications,
    });

    // Fallback safety timer: stop full-screen cloud loading after 2.5s if network is slow
    const safetyTimer = setTimeout(() => {
      setIsCloudLoading(false);
    }, 2500);

    const markCloudLoaded = () => {
      setIsCloudLoading(false);
      setCloudSyncStatus('connected');
      setLastSyncTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }));
    };

    // 3. Setup real-time listeners for live updates across clients
    const unsubProducts = subscribeToCollection<Product>('products', (cloudProducts) => {
      if (Array.isArray(cloudProducts)) {
        setProducts(cloudProducts);
        localStorage.setItem('dtf_sublime_products', JSON.stringify(cloudProducts));
        markCloudLoaded();
      }
    });

    const unsubMovements = subscribeToCollection<StockMovement>('movements', (cloudMovements) => {
      if (Array.isArray(cloudMovements)) {
        const sorted = [...cloudMovements].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
        setMovements(sorted);
        localStorage.setItem('dtf_sublime_movements', JSON.stringify(sorted));
        markCloudLoaded();
      }
    });

    const unsubInvoices = subscribeToCollection<Invoice>('invoices', (cloudInvoices) => {
      if (Array.isArray(cloudInvoices)) {
        const sorted = [...cloudInvoices].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
        setInvoices(sorted);
        localStorage.setItem('dtf_sublime_invoices', JSON.stringify(sorted));
        markCloudLoaded();
      }
    });

    const unsubCategories = subscribeToCollection<CategoryItem>('categories', (cloudCats) => {
      if (Array.isArray(cloudCats)) {
        setCategories(cloudCats);
        localStorage.setItem('dtf_sublime_categories', JSON.stringify(cloudCats));
      }
    });

    const unsubSuppliers = subscribeToCollection<SupplierItem>('suppliers', (cloudSups) => {
      if (Array.isArray(cloudSups)) {
        setSuppliers(cloudSups);
        localStorage.setItem('dtf_sublime_suppliers', JSON.stringify(cloudSups));
      }
    });

    const unsubCustomers = subscribeToCollection<CustomerItem>('customers', (cloudCusts) => {
      if (Array.isArray(cloudCusts)) {
        setCustomers(cloudCusts);
        localStorage.setItem('dtf_sublime_customers', JSON.stringify(cloudCusts));
      }
    });

    const unsubUsers = subscribeToCollection<User>('users', (cloudUsers) => {
      if (Array.isArray(cloudUsers) && cloudUsers.length > 0) {
        setUsers(cloudUsers);
        localStorage.setItem('dtf_sublime_users', JSON.stringify(cloudUsers));
        markCloudLoaded();

        // Ensure active logged-in user is updated with latest permissions and name from Cloud
        const activeUserId = localStorage.getItem('dtf_sublime_auth_user_id');
        if (activeUserId) {
          const freshUser = cloudUsers.find((u) => u.id === activeUserId);
          if (freshUser) {
            setCurrentUser(freshUser);
            currentUserRef.current = freshUser;
            localStorage.setItem('dtf_sublime_current_user', JSON.stringify(freshUser));
          }
        }
      }
    });

    const unsubLogs = subscribeToCollection<ActivityLog>('activity_logs', (cloudLogs) => {
      if (Array.isArray(cloudLogs)) {
        const sorted = [...cloudLogs].sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
        setLogs(sorted);
        localStorage.setItem('dtf_sublime_logs', JSON.stringify(sorted));
      }
    });

    // Real-time Push Notifications across all devices
    const unsubNotifications = subscribeToCollection<PushNotification>('notifications', (cloudNotifs) => {
      if (Array.isArray(cloudNotifs)) {
        const sorted = [...cloudNotifs].sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));

        // Identify new notifications from other devices
        // CRITICAL REQUIREMENT: "dan notifikasi muncul hanya jika login untuk semua perangkat"
        const isAuthActive = localStorage.getItem('dtf_sublime_auth_active') === 'true';

        if (isAuthActive && !isFirstNotificationLoadRef.current) {
          const newArrivals = sorted.filter((n) => !knownNotificationIdsRef.current.has(n.id));
          if (newArrivals.length > 0) {
            // New notification from another device!
            playPushNotificationSound();
            const newest = newArrivals[0];
            requestAndSendBrowserNotification(newest.title, newest.message);
            setRealtimeNotificationToast(newest);
            setTimeout(() => {
              setRealtimeNotificationToast((cur) => (cur?.id === newest.id ? null : cur));
            }, 6500);
          }
        }

        // Register all received IDs as known
        sorted.forEach((n) => knownNotificationIdsRef.current.add(n.id));
        isFirstNotificationLoadRef.current = false;

        setNotifications(sorted);
        localStorage.setItem('dtf_sublime_push', JSON.stringify(sorted));
      }
    });

    const unsubCompanyProfile = subscribeToSetting('company_profile', (profileData) => {
      if (profileData && profileData.companyName) {
        setCompanyProfile(profileData);
        localStorage.setItem('dtf_sublime_company_profile', JSON.stringify(profileData));
      }
    });

    const unsubMasterLists = subscribeToSetting('master_lists', (listData) => {
      if (listData) {
        if (Array.isArray(listData.units) && listData.units.length > 0) {
          setUnits(listData.units);
          localStorage.setItem('dtf_sublime_units', JSON.stringify(listData.units));
        }
        if (Array.isArray(listData.locations) && listData.locations.length > 0) {
          setLocations(listData.locations);
          localStorage.setItem('dtf_sublime_locations', JSON.stringify(listData.locations));
        }
        if (Array.isArray(listData.divisions) && listData.divisions.length > 0) {
          setDivisions(listData.divisions);
          localStorage.setItem('dtf_sublime_divisions', JSON.stringify(listData.divisions));
        }
      }
    });

    const unsubAuth = onAuthStateChanged(auth, (fbUser) => {
      if (fbUser) {
        console.log('Firebase user authenticated:', fbUser.email);
        setCloudSyncStatus('connected');
      }
    });

    return () => {
      clearTimeout(safetyTimer);
      unsubProducts();
      unsubMovements();
      unsubInvoices();
      unsubCategories();
      unsubSuppliers();
      unsubCustomers();
      unsubUsers();
      unsubLogs();
      unsubNotifications();
      unsubCompanyProfile();
      unsubMasterLists();
      unsubAuth();
    };
  }, []);

  // Helper Anti Data Ganda: Menggabungkan data cloud dan data lokal tanpa duplikasi ID
  const mergeAndDeduplicateById = <T extends { id: string }>(cloudItems: T[], localItems: T[]): T[] => {
    const map = new Map<string, T>();
    if (Array.isArray(cloudItems)) {
      cloudItems.forEach((item) => {
        if (item && item.id) map.set(item.id, item);
      });
    }
    if (Array.isArray(localItems)) {
      localItems.forEach((item) => {
        if (item && item.id && !map.has(item.id)) {
          map.set(item.id, item);
        }
      });
    }
    return Array.from(map.values());
  };

  // Force Push Current Local Storage Data into Cloud Database (Firestore) dengan Anti Data Ganda
  const handlePushLocalToCloud = async (): Promise<{ success: boolean; message: string }> => {
    setIsCloudLoading(true);
    setCloudSyncStatus('syncing');
    try {
      // Anti Data Ganda: Bersihkan seluruh array lokal sebelum diunggah
      const cleanProducts = deduplicateById(products);
      const cleanMovements = deduplicateById(movements);
      const cleanInvoices = deduplicateById(invoices);
      const cleanCategories = deduplicateById(categories);
      const cleanSuppliers = deduplicateById(suppliers);
      const cleanCustomers = deduplicateById(customers);
      const cleanUsers = deduplicateById(users);
      const cleanLogs = deduplicateById(logs);
      const cleanNotifications = deduplicateById(notifications);

      await Promise.all([
        replaceCollectionInFirestore('products', cleanProducts),
        replaceCollectionInFirestore('movements', cleanMovements),
        replaceCollectionInFirestore('invoices', cleanInvoices),
        replaceCollectionInFirestore('categories', cleanCategories),
        replaceCollectionInFirestore('suppliers', cleanSuppliers),
        replaceCollectionInFirestore('customers', cleanCustomers),
        replaceCollectionInFirestore('users', cleanUsers),
        replaceCollectionInFirestore('activity_logs', cleanLogs),
        replaceCollectionInFirestore('notifications', cleanNotifications),
        saveSetting('company_profile', companyProfile),
        saveSetting('master_lists', { units, locations, divisions }),
      ]);
      setCloudSyncStatus('connected');
      const timeStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      setLastSyncTime(timeStr);
      addPushNotification({
        title: '☁️ Data Lokal Berhasil Diunggah ke Cloud',
        message: `Seluruh data lokal (${cleanProducts.length} bahan, ${cleanInvoices.length} faktur, ${cleanMovements.length} mutasi) telah diunggah dan disimpan ke database cloud tanpa duplikasi.`,
        type: 'system',
      });
      return {
        success: true,
        message: `Berhasil mengunggah ${cleanProducts.length} bahan baku, ${cleanInvoices.length} faktur, dan ${cleanMovements.length} mutasi stok ke cloud database!`,
      };
    } catch (err: any) {
      console.warn('handlePushLocalToCloud error:', err);
      setCloudSyncStatus('offline');
      return {
        success: false,
        message: err?.message || 'Gagal mengunggah data lokal ke cloud. Pastikan koneksi internet aktif.',
      };
    } finally {
      setIsCloudLoading(false);
    }
  };

  // Force Manual Refresh / Sync with Cloud Database dengan Proteksi Anti Data Ganda
  const handleManualSyncCloud = async () => {
    setIsCloudLoading(true);
    setCloudSyncStatus('syncing');
    try {
      const [cloudProds, cloudMovs, cloudInvs, cloudUsers, cloudCats, cloudSups, cloudCusts, cloudLogs, cloudNotifs] = await Promise.all([
        fetchCollectionOnce<Product>('products'),
        fetchCollectionOnce<StockMovement>('movements'),
        fetchCollectionOnce<Invoice>('invoices'),
        fetchCollectionOnce<User>('users'),
        fetchCollectionOnce<CategoryItem>('categories'),
        fetchCollectionOnce<SupplierItem>('suppliers'),
        fetchCollectionOnce<CustomerItem>('customers'),
        fetchCollectionOnce<ActivityLog>('activity_logs'),
        fetchCollectionOnce<PushNotification>('notifications'),
      ]);

      // Guard Proteksi Reset Database: Jika cloud database kosong (misal baru di-reset)
      // tetapi memori lokal memiliki data, jangan menimpa data lokal!
      // Sebaliknya, otomatis unggah data lokal kita kembali ke cloud!
      if (Array.isArray(cloudProds) && cloudProds.length === 0 && products.length > 0) {
        console.log('Database cloud terdeteksi kosong/telah di-reset. Mengunggah data lokal ke cloud...');
        await handlePushLocalToCloud();
        return;
      }

      // Smart Merge Anti Data Ganda: Gabungkan data cloud dan data transaksi lokal offline
      const mergedProds = mergeAndDeduplicateById(cloudProds || [], products);
      const mergedMovs = mergeAndDeduplicateById(cloudMovs || [], movements);
      const mergedInvs = mergeAndDeduplicateById(cloudInvs || [], invoices);
      const mergedUsers = mergeAndDeduplicateById(cloudUsers || [], users);
      const mergedCats = mergeAndDeduplicateById(cloudCats || [], categories);
      const mergedSups = mergeAndDeduplicateById(cloudSups || [], suppliers);
      const mergedCusts = mergeAndDeduplicateById(cloudCusts || [], customers);
      const mergedLogs = mergeAndDeduplicateById(cloudLogs || [], logs);
      const mergedNotifs = mergeAndDeduplicateById(cloudNotifs || [], notifications);

      const hasUnsyncedOfflineData =
        mergedProds.length > (cloudProds?.length || 0) ||
        mergedMovs.length > (cloudMovs?.length || 0) ||
        mergedInvs.length > (cloudInvs?.length || 0);

      const sortedNotifs = [...mergedNotifs].sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
      sortedNotifs.forEach((n) => knownNotificationIdsRef.current.add(n.id));
      setNotifications(sortedNotifs);
      localStorage.setItem('dtf_sublime_push', JSON.stringify(sortedNotifs));

      setProducts(mergedProds);
      localStorage.setItem('dtf_sublime_products', JSON.stringify(mergedProds));

      const sortedMovs = [...mergedMovs].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setMovements(sortedMovs);
      localStorage.setItem('dtf_sublime_movements', JSON.stringify(sortedMovs));

      const sortedInvs = [...mergedInvs].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
      setInvoices(sortedInvs);
      localStorage.setItem('dtf_sublime_invoices', JSON.stringify(sortedInvs));

      if (mergedUsers.length > 0) {
        setUsers(mergedUsers);
        localStorage.setItem('dtf_sublime_users', JSON.stringify(mergedUsers));
        const activeUserId = localStorage.getItem('dtf_sublime_auth_user_id');
        if (activeUserId) {
          const freshUser = mergedUsers.find((u) => u.id === activeUserId);
          if (freshUser) {
            setCurrentUser(freshUser);
            localStorage.setItem('dtf_sublime_current_user', JSON.stringify(freshUser));
          }
        }
      }

      setCategories(mergedCats);
      localStorage.setItem('dtf_sublime_categories', JSON.stringify(mergedCats));

      setSuppliers(mergedSups);
      localStorage.setItem('dtf_sublime_suppliers', JSON.stringify(mergedSups));

      setCustomers(mergedCusts);
      localStorage.setItem('dtf_sublime_customers', JSON.stringify(mergedCusts));

      const sortedLogs = [...mergedLogs].sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''));
      setLogs(sortedLogs);
      localStorage.setItem('dtf_sublime_logs', JSON.stringify(sortedLogs));

      // Jika ada transaksi lokal offline yang belum ada di cloud, otomatis simpan ke cloud
      if (hasUnsyncedOfflineData) {
        console.log('Mendeteksi transaksi offline lokal. Otomatis menyinkronkan data baru ke Cloud...');
        await Promise.all([
          batchSaveDocuments('products', mergedProds),
          batchSaveDocuments('movements', sortedMovs),
          batchSaveDocuments('invoices', sortedInvs),
        ]);
      }

      setCloudSyncStatus('connected');
      const timeStr = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
      setLastSyncTime(timeStr);
      setIsCloudLoading(false);
      addPushNotification({
        title: '☁️ Sinkronisasi Cloud Berhasil',
        message: `Data telah diselaraskan dengan cloud: ${cloudProds.length} bahan, ${cloudMovs.length} mutasi, ${cloudInvs.length} nota faktur.`,
        type: 'system',
      });
    } catch (err) {
      console.warn('Manual cloud sync failed:', err);
      setCloudSyncStatus('offline');
      setIsCloudLoading(false);
    }
  };

  // Sidebar states (Collapsible & Auto-Hide)
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(() => {
    const saved = localStorage.getItem('dtf_sublime_sidebar_collapsed');
    return saved ? JSON.parse(saved) : false;
  });
  const [sidebarAutoHide, setSidebarAutoHide] = useState(() => {
    const saved = localStorage.getItem('dtf_sublime_sidebar_autohide');
    return saved ? JSON.parse(saved) : false;
  });

  useEffect(() => {
    localStorage.setItem('dtf_sublime_sidebar_collapsed', JSON.stringify(isSidebarCollapsed));
  }, [isSidebarCollapsed]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_sidebar_autohide', JSON.stringify(sidebarAutoHide));
  }, [sidebarAutoHide]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('dtf_sublime_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_units', JSON.stringify(units));
  }, [units]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_locations', JSON.stringify(locations));
  }, [locations]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_customers', JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_divisions', JSON.stringify(divisions));
  }, [divisions]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_movements', JSON.stringify(movements));
  }, [movements]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('dtf_sublime_push', JSON.stringify(notifications));
  }, [notifications]);

  // Scan unpaid/DP invoices for due dates and auto-generate reminders in notifications
  useEffect(() => {
    const unpaidList = invoices.filter(
      (inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp'
    );

    setNotifications((prev) => {
      // Find which invoice reminders are already present in prev
      const existingIds = new Set(prev.map((n) => n.id));
      const existingInvoiceMetaIds = new Set(
        prev
          .filter((n) => n.type === 'invoice_due' && n.meta?.invoiceId)
          .map((n) => n.meta!.invoiceId)
      );

      const newNotifs: PushNotification[] = [];

      unpaidList.forEach((inv) => {
        const dueInfo = getInvoiceDueInfo(inv);
        if (dueInfo.isOverdue || dueInfo.isDueToday || dueInfo.isUpcoming) {
          const reminderId = `push-due-${inv.id}`;
          const isAlreadyNotified =
            existingIds.has(reminderId) || existingInvoiceMetaIds.has(inv.id);

          if (!isAlreadyNotified) {
            const urgencyPrefix = dueInfo.isOverdue
              ? '🚨 LEWAT TEMPO'
              : dueInfo.isDueToday
              ? '⏰ JATUH TEMPO HARI INI'
              : '📅 PENGINGAT TEMPO';

            const title = `${urgencyPrefix}: Invoice ${inv.invoiceNumber}`;
            const message = `Pelanggan ${inv.customerName} memiliki sisa tagihan ${formatRupiah(dueInfo.unpaidAmount)} (Jatuh tempo: ${inv.dueDate}). Segera lakukan penagihan via WhatsApp!`;

            const reminderNotif: PushNotification = {
              id: reminderId,
              type: 'invoice_due',
              title,
              message,
              timestamp: getWIBNow(false, true),
              read: false,
              meta: {
                invoiceId: inv.id,
                customerName: inv.customerName,
                dueDate: inv.dueDate,
                unpaidAmount: dueInfo.unpaidAmount,
              },
            };

            newNotifs.push(reminderNotif);
            saveDocument('notifications', reminderNotif);

            // Prevent adding twice in the same pass
            existingIds.add(reminderId);
            existingInvoiceMetaIds.add(inv.id);
          }
        }
      });

      // Deduplicate prev notifications by id just in case localStorage had duplicates
      const seen = new Set<string>();
      const combined = [...newNotifs, ...prev];
      const deduped: PushNotification[] = [];
      for (const item of combined) {
        if (!seen.has(item.id)) {
          seen.add(item.id);
          deduped.push(item);
        }
      }

      return deduped;
    });
  }, [invoices]);

  // Push notification helper
  const addPushNotification = (newNotif: Omit<PushNotification, 'id' | 'timestamp' | 'read'>) => {
    const now = new Date();
    const timeStr = getWIBNow(false, true);
    const fullNotif: PushNotification = {
      ...newNotif,
      id: `push-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: timeStr,
      read: false,
    };

    knownNotificationIdsRef.current.add(fullNotif.id);
    setNotifications((prev) => [fullNotif, ...prev]);

    // Save to Firestore so all other devices receive this notification in real time!
    saveDocument('notifications', fullNotif);

    // Only alert on this device if authenticated
    if (isAuthenticated) {
      playPushNotificationSound();
      requestAndSendBrowserNotification(fullNotif.title, fullNotif.message);
      setRealtimeNotificationToast(fullNotif);
      setTimeout(() => {
        setRealtimeNotificationToast((cur) => (cur?.id === fullNotif.id ? null : cur));
      }, 6500);
    }
  };

  // 1. Record Production Consumption
  const handleRecordProduction = (data: {
    productId: string;
    quantity: number;
    spkNumber: string;
    divisionOrRequester: string;
    recipientName: string;
    notes: string;
    billingRequired?: boolean;
    paymentStatus?: 'lunas' | 'belum_lunas' | 'beban_internal';
    paymentMethod?: string;
    paidAmount?: number;
    billingDueDate?: string;
    operatorUser?: User;
  }) => {
    const targetProd = products.find((p) => p.id === data.productId);
    if (!targetProd) return;

    const prevStock = targetProd.currentStock;
    const finalStock = Math.max(0, prevStock - data.quantity);
    const dateNow = getWIBNow(false);

    // Update Product Stock
    setProducts((prev) =>
      prev.map((p) =>
        p.id === data.productId
          ? { ...p, currentStock: finalStock, lastUpdated: dateNow }
          : p
      )
    );

    const costPrice = targetProd.costPrice;
    const totalCost = Number(data.quantity) * costPrice;
    const billingReq = data.billingRequired ?? false;
    const pStatus = billingReq ? (data.paymentStatus || 'belum_lunas') : 'beban_internal';
    const effectivePaid = pStatus === 'lunas' ? (data.paidAmount ?? totalCost) : (data.paidAmount ?? 0);

    const actor = getEffectiveActor(data.operatorUser);

    // Add Movement Record
    const newMovement: StockMovement = {
      id: `mov-${Date.now()}`,
      date: dateNow,
      productId: targetProd.id,
      productName: targetProd.name,
      productCode: targetProd.code,
      category: targetProd.category,
      type: 'production',
      quantity: data.quantity,
      unit: targetProd.unit,
      previousStock: prevStock,
      finalStock: finalStock,
      referenceNo: data.spkNumber,
      unitPrice: costPrice,
      totalValue: totalCost,
      divisionOrRequester: data.divisionOrRequester,
      recipientName: data.recipientName,
      notes: data.notes,
      billingRequired: billingReq,
      paymentStatus: pStatus,
      paymentMethod: billingReq ? (data.paymentMethod || 'Kas Internal / Tunai') : undefined,
      paidAmount: effectivePaid,
      billingDueDate: data.billingDueDate,
      paidAt: pStatus === 'lunas' ? dateNow : undefined,
      performedBy: {
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
      },
    };
    setMovements((prev) => [newMovement, ...prev]);

    // Save to Firestore Cloud
    saveDocument('products', { ...targetProd, currentStock: finalStock, lastUpdated: dateNow });
    saveDocument('movements', newMovement);

    // Add Activity Log
    const billingDesc = billingReq
      ? ` • [TAGIHAN ${pStatus === 'lunas' ? 'LUNAS' : 'MENUNGGU PEMBAYARAN'}] ${pStatus === 'lunas' ? formatRupiah(effectivePaid) : `Sisa: ${formatRupiah(totalCost - effectivePaid)} (Tempo: ${data.billingDueDate || '-'})`}`
      : ' • [BEBAN INTERNAL]';

    logActivity(
      'PRODUCTION_USE',
      `Pemakaian Produksi ${targetProd.name}`,
      `${actor.name} (${actor.roleTitle}) mencatat pemakaian ${data.quantity} ${targetProd.unit} untuk SPK ${data.spkNumber} (${data.divisionOrRequester}${data.recipientName ? ` • Petugas/Penerima: ${data.recipientName}` : ''}). Beban HPP: ${formatRupiah(totalCost)}${billingDesc}. Sisa stok: ${prevStock} → ${finalStock}.`,
      finalStock <= targetProd.minStockAlert ? 'warning' : 'info',
      actor
    );

    // Check minimum stock alert
    if (finalStock <= targetProd.minStockAlert) {
      addPushNotification({
        title: `⚠️ Stok Kritis: ${targetProd.name}`,
        message: `Stok bahan baku ${targetProd.name} sisa ${finalStock} ${targetProd.unit} (batas minimum: ${targetProd.minStockAlert}). Segera lakukan reorder!`,
        type: 'stock_warning',
        meta: {
          productName: targetProd.name,
          currentStock: finalStock,
          referenceNo: data.spkNumber,
        },
      });
    } else {
      addPushNotification({
        title: `📦 Produksi: ${targetProd.name}`,
        message: `${actor.name} mengeluarkan ${data.quantity} ${targetProd.unit} untuk ${data.spkNumber} (${data.divisionOrRequester})${billingReq ? ` [Status: ${pStatus === 'lunas' ? 'Lunas' : 'Belum Lunas'}]` : ''}.`,
        type: 'production_alert',
        meta: {
          productName: targetProd.name,
          currentStock: finalStock,
        },
      });
    }
  };

  // 1b. Update Production Movement Payment Status
  const handleUpdateProductionPaymentStatus = (
    movementId: string,
    status: 'lunas' | 'belum_lunas' | 'beban_internal',
    paidAmount?: number,
    paymentMethod?: string,
    billingDueDate?: string,
    operatorUser?: User
  ) => {
    const nowStr = getWIBNow(false);
    let updatedMov: StockMovement | undefined;

    setMovements((prev) =>
      prev.map((m) => {
        if (m.id !== movementId) return m;
        const targetCost = m.totalValue ?? (m.quantity * (m.unitPrice ?? 0));
        const effectivePaid =
          status === 'lunas'
            ? (paidAmount ?? targetCost)
            : status === 'beban_internal'
            ? 0
            : (paidAmount ?? 0);

        updatedMov = {
          ...m,
          billingRequired: status !== 'beban_internal',
          paymentStatus: status,
          paidAmount: effectivePaid,
          paymentMethod: paymentMethod || m.paymentMethod || 'Kas Internal / Tunai',
          billingDueDate: billingDueDate || m.billingDueDate,
          paidAt: status === 'lunas' ? nowStr : (status === 'belum_lunas' ? undefined : m.paidAt),
        };
        return updatedMov;
      })
    );

    if (updatedMov) {
      saveDocument('movements', updatedMov);
      const isLunas = status === 'lunas';
      const actor = getEffectiveActor(operatorUser);

      logActivity(
        'SALES_INVOICE',
        isLunas ? `Pelunasan Tagihan Divisi: ${(updatedMov as StockMovement).referenceNo}` : `Update Tagihan Divisi: ${(updatedMov as StockMovement).referenceNo}`,
        `${actor.name} (${actor.roleTitle}) memperbarui tagihan Divisi ${(updatedMov as StockMovement).divisionOrRequester || 'Produksi'} - Status: ${(status || '').toUpperCase()} (${paymentMethod || 'Kas Internal'}). Terbayar: ${formatRupiah(paidAmount ?? 0)}.`,
        isLunas ? 'success' : 'info',
        actor
      );

      if (isLunas) {
        addPushNotification({
          title: `💰 Tagihan Divisi Lunas: ${(updatedMov as StockMovement).referenceNo}`,
          message: `Divisi ${(updatedMov as StockMovement).divisionOrRequester || 'Internal'} telah melunasi tagihan pemakaian bahan sebesar ${formatRupiah(paidAmount || (updatedMov as StockMovement).totalValue || 0)}.`,
          type: 'sale_alert',
        });
      }
    }
  };

  // 2. Create Sales Invoice
  const handleCreateInvoice = (newInvoice: Invoice) => {
    const dateNow = getWIBNow(false);

    // Auto-save customer if not exist or update if phone/address provided
    if (newInvoice.customerName && newInvoice.customerName.trim()) {
      const trimmedName = newInvoice.customerName.trim();
      const trimmedPhone = (newInvoice.customerPhone || '').trim();
      const trimmedAddress = (newInvoice.customerAddress || '').trim();

      setCustomers((prev) => {
        const existingIdx = prev.findIndex(
          (c) =>
            c.name.toLowerCase() === trimmedName.toLowerCase() ||
            (trimmedPhone && c.phone && c.phone === trimmedPhone)
        );

        if (existingIdx >= 0) {
          // Update missing info
          const updated = [...prev];
          const updatedCust = {
            ...updated[existingIdx],
            name: trimmedName,
            phone: updated[existingIdx].phone || trimmedPhone,
            address: updated[existingIdx].address || (trimmedAddress ? trimmedAddress : undefined),
          };
          updated[existingIdx] = updatedCust;
          saveDocument('customers', updatedCust);
          return updated;
        } else {
          // Add new customer automatically
          const newCust: CustomerItem = {
            id: `cust-${Date.now()}`,
            name: trimmedName,
            phone: trimmedPhone || '-',
            address: trimmedAddress || undefined,
            notes: `Otomatis ditambahkan dari faktur ${newInvoice.invoiceNumber}`,
            createdAt: new Date().toISOString().slice(0, 10),
          };
          saveDocument('customers', newCust);
          return [...prev, newCust];
        }
      });
    }

    // Deduct stock for all items
    setProducts((prev) => {
      return prev.map((p) => {
        const boughtItem = newInvoice.items.find((item) => item.productId === p.id);
        if (!boughtItem) return p;
        const finalStock = Math.max(0, p.currentStock - boughtItem.quantity);
        return {
          ...p,
          currentStock: finalStock,
          lastUpdated: dateNow,
        };
      });
    });

    const actor = getEffectiveActor(newInvoice.createdBy?.userId ? {
      id: newInvoice.createdBy.userId,
      name: newInvoice.createdBy.userName,
      role: newInvoice.createdBy.userRole,
      roleTitle: newInvoice.createdBy.userRoleTitle,
    } : null);

    // Add Invoice with guaranteed paymentHistory
    const initialPaymentHistory: PaymentRecord[] = 
      newInvoice.paymentHistory && newInvoice.paymentHistory.length > 0
        ? newInvoice.paymentHistory
        : newInvoice.paidAmount > 0
        ? [
            {
              id: `pay-${Date.now()}`,
              date: getWIBNow(false),
              amount: newInvoice.paidAmount,
              paymentMethod: newInvoice.paymentMethod || 'Transfer Bank',
              notes: newInvoice.paymentStatus === 'lunas' ? 'Pembayaran Penuh (Lunas)' : 'Uang Muka (DP)',
              receivedBy: {
                userId: actor.id,
                userName: actor.name,
                userRole: actor.role,
                userRoleTitle: actor.roleTitle,
              },
            }
          ]
        : [];

    const finalizedInvoice: Invoice = {
      ...newInvoice,
      createdBy: {
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
      },
      paymentHistory: initialPaymentHistory,
    };

    setInvoices((prev) => [finalizedInvoice, ...prev]);

    // Add movements for each bought item
    const newMovements: StockMovement[] = newInvoice.items.map((item, idx) => {
      const prod = products.find((p) => p.id === item.productId);
      const prevStock = prod ? prod.currentStock : item.quantity;
      return {
        id: `mov-${Date.now()}-${idx}`,
        date: dateNow,
        productId: item.productId,
        productName: item.productName,
        productCode: item.productCode,
        category: prod?.category || 'dtf',
        type: 'sale',
        quantity: item.quantity,
        unit: item.unit,
        previousStock: prevStock,
        finalStock: Math.max(0, prevStock - item.quantity),
        referenceNo: newInvoice.invoiceNumber,
        notes: `Penjualan bahan ke ${newInvoice.customerName}`,
        performedBy: {
          userId: actor.id,
          userName: actor.name,
          userRole: actor.role,
          userRoleTitle: actor.roleTitle,
        },
        totalValue: item.subtotal,
      };
    });
    setMovements((prev) => [...newMovements, ...prev]);

    // Save Invoice and movements to Firestore Cloud
    saveDocument('invoices', finalizedInvoice);
    newMovements.forEach((m) => saveDocument('movements', m));
    newInvoice.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        saveDocument('products', {
          ...prod,
          currentStock: Math.max(0, prod.currentStock - item.quantity),
          lastUpdated: dateNow,
        });
      }
    });

    // Add Activity Log
    logActivity(
      'SALES_INVOICE',
      `Invoice Penjualan ${newInvoice.invoiceNumber}`,
      `${actor.name} (${actor.roleTitle}) menerbitkan faktur penjualan ${newInvoice.invoiceNumber} kepada ${newInvoice.customerName} senilai ${formatRupiah(newInvoice.grandTotal)} (${newInvoice.items.length} item). Kasir: ${actor.name}.`,
      'success',
      actor
    );

    // Push notification
    addPushNotification({
      title: `🛍️ Penjualan Baru (${newInvoice.invoiceNumber})`,
      message: `${newInvoice.customerName} membeli ${newInvoice.items.length} jenis bahan senilai ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(newInvoice.grandTotal)}. Stok bahan otomatis terpotong.`,
      type: 'sale_alert',
      meta: {
        referenceNo: newInvoice.invoiceNumber,
        amount: newInvoice.grandTotal,
      },
    });

    // Check if any product reached low stock after sale
    newInvoice.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        const remaining = prod.currentStock - item.quantity;
        if (remaining <= prod.minStockAlert) {
          setTimeout(() => {
            addPushNotification({
              title: `⚠️ Stok Kritis Pasca Penjualan: ${prod.name}`,
              message: `Stok ${prod.name} tersisa ${remaining} ${prod.unit} setelah invoice ${newInvoice.invoiceNumber}. Segera restock!`,
              type: 'stock_warning',
              meta: {
                productName: prod.name,
                currentStock: remaining,
              },
            });
          }, 600);
        }
      }
    });
  };

  // 3. Confirm Restock
  const handleConfirmRestock = (data: {
    productId: string;
    quantity: number;
    supplierName: string;
    poNumber: string;
    costPrice?: number;
    notes: string;
    operatorUser?: User;
  }) => {
    const prod = products.find((p) => p.id === data.productId);
    if (!prod) return;

    const prevStock = prod.currentStock;
    const finalStock = prevStock + data.quantity;
    const dateNow = getWIBNow(false);

    const effectiveCostPrice = data.costPrice !== undefined ? data.costPrice : prod.costPrice;
    const totalPurchaseValue = effectiveCostPrice * data.quantity;

    setProducts((prev) =>
      prev.map((p) =>
        p.id === data.productId
          ? {
              ...p,
              currentStock: finalStock,
              costPrice: effectiveCostPrice,
              lastUpdated: dateNow,
            }
          : p
      )
    );

    const actor = getEffectiveActor(data.operatorUser);

    // Movement
    const newMovement: StockMovement = {
      id: `mov-${Date.now()}`,
      date: dateNow,
      productId: prod.id,
      productName: prod.name,
      productCode: prod.code,
      category: prod.category,
      type: 'restock',
      quantity: data.quantity,
      unit: prod.unit,
      previousStock: prevStock,
      finalStock: finalStock,
      referenceNo: data.poNumber,
      supplierName: data.supplierName,
      unitPrice: effectiveCostPrice,
      totalValue: totalPurchaseValue,
      notes: `Restock dari ${data.supplierName} — ${data.notes}`,
      performedBy: {
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
      },
    };
    setMovements((prev) => [newMovement, ...prev]);

    // Save to Firestore Cloud
    saveDocument('products', {
      ...prod,
      currentStock: finalStock,
      costPrice: effectiveCostPrice,
      lastUpdated: dateNow,
    });
    saveDocument('movements', newMovement);

    // Activity Log
    logActivity(
      'RESTOCK_IN',
      `Penerimaan Stok Masuk ${prod.name}`,
      `${actor.name} (${actor.roleTitle}) mencatat stok masuk ${data.quantity} ${prod.unit} dari supplier ${data.supplierName} (${data.poNumber}) senilai ${formatRupiah(totalPurchaseValue)}. Stok: ${prevStock} → ${finalStock}.`,
      'info',
      actor
    );

    // Push notification
    addPushNotification({
      title: `📦 Stok Masuk: ${prod.name}`,
      message: `Berhasil menerima ${data.quantity} ${prod.unit} dari ${data.supplierName}. Total stok gudang sekarang ${finalStock} ${prod.unit}.`,
      type: 'restock',
      meta: {
        productName: prod.name,
        currentStock: finalStock,
        referenceNo: data.poNumber,
      },
    });
  };

  // 3b. Edit Purchase Mutation
  const handleEditPurchase = (
    movementId: string,
    updatedData: {
      quantity: number;
      unitPrice: number;
      supplierName: string;
      referenceNo: string;
      date: string;
      notes: string;
    }
  ): { success: boolean; message?: string } => {
    const canEdit = currentUser.canEditPurchases !== undefined
      ? Boolean(currentUser.canEditPurchases)
      : (currentUser.role === 'owner' || currentUser.role === 'warehouse_admin');

    if (!canEdit) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Edit Mutasi Pembelian Bahan". Izin ini dapat diaktifkan oleh Pemilik di menu Hak Akses & Pengguna.',
      };
    }

    const targetMovement = movements.find((m) => m.id === movementId);
    if (!targetMovement) {
      return { success: false, message: 'Data mutasi pembelian tidak ditemukan.' };
    }

    const targetProduct = products.find((p) => p.id === targetMovement.productId);
    if (!targetProduct) {
      return { success: false, message: 'Bahan baku terkait tidak ditemukan di inventaris gudang.' };
    }

    const oldQty = targetMovement.quantity;
    const newQty = updatedData.quantity;
    const qtyDiff = newQty - oldQty; // e.g. was 10, now 15 -> +5 stock. was 10, now 7 -> -3 stock.

    // Validate that reducing purchased quantity won't cause negative current stock
    if (targetProduct.currentStock + qtyDiff < 0) {
      return {
        success: false,
        message: `Tidak dapat mengubah kuantiti pembelian menjadi ${newQty} ${targetProduct.unit}. Stok saat ini di gudang (${targetProduct.currentStock} ${targetProduct.unit}) akan menjadi negatif (${targetProduct.currentStock + qtyDiff}). Sebagian bahan mungkin telah dipakai produksi atau terjual.`,
      };
    }

    const dateNow = getWIBNow(false);
    const newStock = targetProduct.currentStock + qtyDiff;
    const newTotalValue = updatedData.quantity * updatedData.unitPrice;

    const updatedProd: Product = {
      ...targetProduct,
      currentStock: newStock,
      costPrice: updatedData.unitPrice,
      lastUpdated: dateNow,
    };
    saveDocument('products', updatedProd);

    // 1. Update Product stock and costPrice
    setProducts((prev) =>
      prev.map((p) => p.id === targetProduct.id ? updatedProd : p)
    );

    const updatedMov: StockMovement = {
      ...targetMovement,
      date: updatedData.date || targetMovement.date,
      quantity: newQty,
      unitPrice: updatedData.unitPrice,
      totalValue: newTotalValue,
      supplierName: updatedData.supplierName,
      referenceNo: updatedData.referenceNo,
      notes: updatedData.notes,
      finalStock: targetMovement.previousStock + newQty,
    };
    saveDocument('movements', updatedMov);

    // 2. Update Movement record
    setMovements((prev) =>
      prev.map((m) => m.id === movementId ? updatedMov : m)
    );

    const actor = currentUserRef.current || currentUser;

    // 3. Activity Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT',
      title: `Edit Mutasi Pembelian: ${updatedData.referenceNo}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) mengubah mutasi pembelian ${targetProduct.name} (${updatedData.referenceNo}). Qty: ${oldQty} → ${newQty} ${targetProduct.unit} (Penyesuaian stok: ${qtyDiff >= 0 ? `+${qtyDiff}` : qtyDiff}), HPP: ${formatRupiah(updatedData.unitPrice)}, Pemasok: ${updatedData.supplierName}.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 4. Push Notification
    addPushNotification({
      title: `✏️ Pembelian Bahan Diperbarui`,
      message: `Mutasi pembelian ${updatedData.referenceNo} (${targetProduct.name}) diubah oleh ${actor.name}. Stok fisik sekarang: ${newStock} ${targetProduct.unit}.`,
      type: 'system',
    });

    return {
      success: true,
      message: `Mutasi pembelian ${updatedData.referenceNo} berhasil diperbarui. Stok ${targetProduct.name} disesuaikan menjadi ${newStock} ${targetProduct.unit}.`,
    };
  };

  // 3c. Delete Purchase Mutation & Revert Stock (Aksi khusus SPV & Owner)
  const handleDeletePurchase = (
    movementId: string
  ): { success: boolean; message?: string } => {
    const canDelete = currentUser.role === 'owner' || currentUser.role === 'warehouse_admin';

    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Aksi hapus mutasi pembelian hanya diizinkan untuk Supervisor Gudang (SPV) dan Pemilik Usaha (Owner).',
      };
    }

    const targetMovement = movements.find((m) => m.id === movementId);
    if (!targetMovement) {
      return { success: false, message: 'Data mutasi pembelian tidak ditemukan.' };
    }

    const targetProduct = products.find((p) => p.id === targetMovement.productId);
    if (!targetProduct) {
      return { success: false, message: 'Bahan baku terkait tidak ditemukan di inventaris gudang.' };
    }

    const purchasedQty = targetMovement.quantity;
    const rawNewStock = targetProduct.currentStock - purchasedQty;
    // Floor stock at 0 if already consumed/depleted
    const finalStock = Math.max(0, rawNewStock);

    const dateNow = getWIBNow(false);

    const updatedProd: Product = {
      ...targetProduct,
      currentStock: finalStock,
      lastUpdated: dateNow,
    };
    saveDocument('products', updatedProd);
    removeDocument('movements', movementId);

    // 1. Revert Product Stock
    setProducts((prev) =>
      prev.map((p) => p.id === targetProduct.id ? updatedProd : p)
    );

    // 2. Remove Movement Record
    setMovements((prev) => prev.filter((m) => m.id !== movementId));

    const actor = currentUserRef.current || currentUser;

    // 3. Activity Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT',
      title: `Hapus Pembelian: ${targetMovement.referenceNo}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) menghapus mutasi pembelian ${targetProduct.name} (${targetMovement.referenceNo}) sebesar ${purchasedQty} ${targetProduct.unit}. Stok fisik disesuaikan dari ${targetProduct.currentStock} menjadi ${finalStock} ${targetProduct.unit}.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 4. Push Notification
    addPushNotification({
      title: `🗑️ Mutasi Pembelian Dihapus`,
      message: `Catatan pembelian ${targetMovement.referenceNo} (${targetProduct.name}) telah dihapus oleh ${actor.name}. Stok fisik disesuaikan menjadi ${finalStock} ${targetProduct.unit}.`,
      type: 'stock_warning',
    });

    return {
      success: true,
      message: `Mutasi pembelian ${targetMovement.referenceNo} berhasil dihapus dan stok fisik ${targetProduct.name} telah disesuaikan menjadi ${finalStock} ${targetProduct.unit}.`,
    };
  };

  // 3d. Edit Production Usage (SPK)
  const handleEditProductionUsage = (
    movementId: string,
    updatedData: {
      referenceNo?: string;
      divisionOrRequester?: string;
      recipientName?: string;
      date?: string;
      quantity?: number;
      notes?: string;
      billingRequired?: boolean;
      paymentStatus?: 'lunas' | 'belum_lunas' | 'beban_internal';
      paymentMethod?: string;
      paidAmount?: number;
      billingDueDate?: string;
    }
  ): { success: boolean; message?: string } => {
    const canEdit = currentUser.role === 'owner' || Boolean(currentUser.canEditProductionUsage);
    if (!canEdit) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Edit Riwayat Pemakaian Produksi". Izin ini dapat diaktifkan di menu Hak Akses & Pengguna.',
      };
    }

    const targetMovement = movements.find((m) => m.id === movementId);
    if (!targetMovement) {
      return { success: false, message: 'Data catatan pemakaian produksi tidak ditemukan.' };
    }

    const targetProduct = products.find((p) => p.id === targetMovement.productId);
    if (!targetProduct) {
      return { success: false, message: 'Bahan baku terkait tidak ditemukan di gudang.' };
    }

    const oldQty = targetMovement.quantity;
    const newQty = updatedData.quantity !== undefined ? Number(updatedData.quantity) : oldQty;
    const qtyDiff = newQty - oldQty;

    if (qtyDiff > 0 && targetProduct.currentStock < qtyDiff) {
      return {
        success: false,
        message: `Stok fisik ${targetProduct.name} tidak mencukupi untuk penambahan pemakaian. Stok tersedia: ${targetProduct.currentStock} ${targetProduct.unit}, dibutuhkan tambahan: ${qtyDiff} ${targetProduct.unit}.`,
      };
    }

    const newStock = Math.max(0, targetProduct.currentStock - qtyDiff);
    const dateNow = getWIBNow(false);

    const updatedProd: Product = {
      ...targetProduct,
      currentStock: newStock,
      lastUpdated: dateNow,
    };
    saveDocument('products', updatedProd);

    // 1. Update Product Stock
    setProducts((prev) =>
      prev.map((p) => p.id === targetProduct.id ? updatedProd : p)
    );

    const costPrice = targetMovement.unitPrice ?? targetProduct.costPrice;
    const newTotalCost = newQty * costPrice;
    const billingReq = updatedData.billingRequired !== undefined ? updatedData.billingRequired : (targetMovement.billingRequired ?? false);
    const pStatus = billingReq ? (updatedData.paymentStatus || targetMovement.paymentStatus || 'belum_lunas') : 'beban_internal';
    const effectivePaid = pStatus === 'lunas' ? (updatedData.paidAmount ?? newTotalCost) : (updatedData.paidAmount ?? targetMovement.paidAmount ?? 0);

    const updatedMovObj: StockMovement = {
      ...targetMovement,
      referenceNo: updatedData.referenceNo || targetMovement.referenceNo,
      divisionOrRequester: updatedData.divisionOrRequester !== undefined ? updatedData.divisionOrRequester : targetMovement.divisionOrRequester,
      recipientName: updatedData.recipientName !== undefined ? updatedData.recipientName : targetMovement.recipientName,
      date: updatedData.date || targetMovement.date,
      quantity: newQty,
      totalValue: newTotalCost,
      notes: updatedData.notes !== undefined ? updatedData.notes : targetMovement.notes,
      billingRequired: billingReq,
      paymentStatus: pStatus,
      paymentMethod: billingReq ? (updatedData.paymentMethod || targetMovement.paymentMethod || 'Kas Internal / Tunai') : undefined,
      paidAmount: effectivePaid,
      billingDueDate: updatedData.billingDueDate !== undefined ? updatedData.billingDueDate : targetMovement.billingDueDate,
      finalStock: newStock,
    };
    saveDocument('movements', updatedMovObj);

    // 2. Update Movement Record
    setMovements((prev) =>
      prev.map((m) => m.id === movementId ? updatedMovObj : m)
    );

    const actor = currentUserRef.current || currentUser;

    // 3. Activity Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT',
      title: `Edit SPK Produksi: ${updatedData.referenceNo || targetMovement.referenceNo}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) mengubah data pemakaian produksi ${targetProduct.name} (${updatedData.referenceNo || targetMovement.referenceNo}). Qty: ${oldQty} → ${newQty} ${targetProduct.unit}, Pemesan: ${updatedData.divisionOrRequester || targetMovement.divisionOrRequester}.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 4. Notification
    addPushNotification({
      title: `✏️ SPK Pemakaian Produksi Diperbarui`,
      message: `Data pemakaian ${targetMovement.referenceNo} (${targetProduct.name}) diubah oleh ${actor.name}. Stok fisik sekarang: ${newStock} ${targetProduct.unit}.`,
      type: 'production_alert',
    });

    return {
      success: true,
      message: `Data pemakaian produksi SPK ${updatedData.referenceNo || targetMovement.referenceNo} berhasil diperbarui. Stok ${targetProduct.name} disesuaikan ke ${newStock} ${targetProduct.unit}.`,
    };
  };

  // 3e. Delete Production Usage (SPK) & Revert Stock
  const handleDeleteProductionUsage = (
    movementId: string
  ): { success: boolean; message?: string } => {
    const canDelete = currentUser.role === 'owner' || Boolean(currentUser.canDeleteProductionUsage);
    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Hapus Riwayat Pemakaian Produksi". Izin ini dapat diaktifkan di menu Hak Akses & Pengguna.',
      };
    }

    const targetMovement = movements.find((m) => m.id === movementId);
    if (!targetMovement) {
      return { success: false, message: 'Data catatan pemakaian produksi tidak ditemukan.' };
    }

    const targetProduct = products.find((p) => p.id === targetMovement.productId);
    const dateNow = getWIBNow(false);

    // 1. Revert Stock
    if (targetProduct) {
      const revertedStock = targetProduct.currentStock + targetMovement.quantity;
      const updatedProd: Product = { ...targetProduct, currentStock: revertedStock, lastUpdated: dateNow };
      saveDocument('products', updatedProd);
      setProducts((prev) =>
        prev.map((p) => p.id === targetProduct.id ? updatedProd : p)
      );
    }

    // 2. Remove Movement Record
    removeDocument('movements', movementId);
    setMovements((prev) => prev.filter((m) => m.id !== movementId));

    const actor = currentUserRef.current || currentUser;

    // 3. Activity Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT',
      title: `Hapus SPK Pemakaian: ${targetMovement.referenceNo}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) menghapus catatan pemakaian produksi ${targetMovement.productName} (${targetMovement.referenceNo}) sebesar ${targetMovement.quantity} ${targetMovement.unit}. Stok fisik gudang telah dikembalikan (+${targetMovement.quantity} ${targetMovement.unit}).`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 4. Push Notification
    addPushNotification({
      title: `🗑️ Pemakaian Produksi Dihapus`,
      message: `Catatan pemakaian ${targetMovement.referenceNo} (${targetMovement.productName}) dihapus oleh ${actor.name}. Stok fisik bahan dikembalikan ke gudang (+${targetMovement.quantity} ${targetMovement.unit}).`,
      type: 'production_alert',
    });

    return {
      success: true,
      message: `Catatan pemakaian SPK ${targetMovement.referenceNo} berhasil dihapus dan ${targetMovement.quantity} ${targetMovement.unit} stok ${targetMovement.productName} telah dikembalikan ke inventaris gudang.`,
    };
  };

  // 3f. Edit Sales Invoice
  const handleEditInvoice = (
    invoiceId: string,
    updatedData: {
      customerName?: string;
      customerPhone?: string;
      customerAddress?: string;
      date?: string;
      dueDate?: string;
      paymentMethod?: string;
      notes?: string;
      taxPercent?: number;
      items?: InvoiceItem[];
    }
  ): { success: boolean; message?: string } => {
    const canEdit = currentUser.role === 'owner' || Boolean(currentUser.canEditSalesInvoice);
    if (!canEdit) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Edit Data Faktur Penjualan". Izin ini dapat diaktifkan di menu Hak Akses & Pengguna.',
      };
    }

    const targetInvoice = invoices.find((inv) => inv.id === invoiceId);
    if (!targetInvoice) {
      return { success: false, message: 'Data faktur invoice tidak ditemukan.' };
    }

    const dateNow = getWIBNow(false);

    // If items changed, calculate stock differences
    if (updatedData.items && updatedData.items.length > 0) {
      const stockMap = new Map<string, number>();
      targetInvoice.items.forEach((item) => {
        stockMap.set(item.productId, (stockMap.get(item.productId) || 0) + item.quantity);
      });
      updatedData.items.forEach((item) => {
        stockMap.set(item.productId, (stockMap.get(item.productId) || 0) - item.quantity);
      });

      // Apply changes to products
      setProducts((prev) =>
        prev.map((p) => {
          const diff = stockMap.get(p.id);
          if (diff !== undefined) {
            const updatedProd = {
              ...p,
              currentStock: Math.max(0, p.currentStock + diff),
              lastUpdated: dateNow,
            };
            saveDocument('products', updatedProd);
            return updatedProd;
          }
          return p;
        })
      );

      // Also update movements for this invoice
      setMovements((prev) => {
        const withoutThis = prev.filter((m) => m.referenceNo !== targetInvoice.invoiceNumber);
        prev.filter((m) => m.referenceNo === targetInvoice.invoiceNumber).forEach((m) => removeDocument('movements', m.id));
        const newMovements: StockMovement[] = (updatedData.items || []).map((item, idx) => {
          const prod = products.find((p) => p.id === item.productId);
          const prevStock = prod ? prod.currentStock : item.quantity;
          const newMov: StockMovement = {
            id: `mov-${Date.now()}-${idx}`,
            date: updatedData.date || targetInvoice.date,
            productId: item.productId,
            productName: item.productName,
            productCode: item.productCode,
            category: prod?.category || 'dtf',
            type: 'sale',
            quantity: item.quantity,
            unit: item.unit,
            previousStock: prevStock,
            finalStock: Math.max(0, prevStock - item.quantity),
            referenceNo: targetInvoice.invoiceNumber,
            notes: `Penjualan bahan ke ${updatedData.customerName || targetInvoice.customerName}`,
            performedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              userRole: currentUser.role,
            },
            totalValue: item.subtotal,
          };
          saveDocument('movements', newMov);
          return newMov;
        });
        return [...newMovements, ...withoutThis];
      });
    }

    const items = updatedData.items || targetInvoice.items;
    const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
    const taxPercent = updatedData.taxPercent !== undefined ? updatedData.taxPercent : targetInvoice.taxPercent;
    const taxAmount = (subtotal * taxPercent) / 100;
    const grandTotal = subtotal + taxAmount;
    const paidAmount = targetInvoice.paidAmount;
    const paymentStatus: 'lunas' | 'belum_lunas' | 'dp' =
      paidAmount >= grandTotal ? 'lunas' : paidAmount > 0 ? 'dp' : 'belum_lunas';

    const finalizedInvoiceObj: Invoice = {
      ...targetInvoice,
      customerName: updatedData.customerName || targetInvoice.customerName,
      customerPhone: updatedData.customerPhone !== undefined ? updatedData.customerPhone : targetInvoice.customerPhone,
      customerAddress: updatedData.customerAddress !== undefined ? updatedData.customerAddress : targetInvoice.customerAddress,
      date: updatedData.date || targetInvoice.date,
      dueDate: updatedData.dueDate || targetInvoice.dueDate,
      paymentMethod: updatedData.paymentMethod || targetInvoice.paymentMethod,
      notes: updatedData.notes !== undefined ? updatedData.notes : targetInvoice.notes,
      items,
      subtotal,
      taxPercent,
      taxAmount,
      grandTotal,
      paymentStatus,
    };

    saveDocument('invoices', finalizedInvoiceObj);

    setInvoices((prev) =>
      prev.map((inv) => inv.id === invoiceId ? finalizedInvoiceObj : inv)
    );

    const actor = currentUserRef.current || currentUser;

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'SALES_INVOICE',
      title: `Edit Faktur: ${targetInvoice.invoiceNumber}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) memperbarui data faktur ${targetInvoice.invoiceNumber} (${updatedData.customerName || targetInvoice.customerName}), total tagihan: ${formatRupiah(grandTotal)}.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    return {
      success: true,
      message: `Faktur penjualan ${targetInvoice.invoiceNumber} berhasil diperbarui.`,
    };
  };

  // 3g. Delete Sales Invoice & Revert Stock
  const handleDeleteInvoice = (
    invoiceId: string
  ): { success: boolean; message?: string } => {
    const actor = currentUserRef.current || currentUser;
    const isOwnerOrSpv = 
      actor.role === 'owner' || 
      actor.role === 'warehouse_admin' || 
      actor.roleTitle?.toLowerCase().includes('spv') || 
      actor.roleTitle?.toLowerCase().includes('supervisor');
    const canDelete = isOwnerOrSpv || Boolean(actor.canDeleteSalesInvoice);
    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Aksi hapus faktur hanya diizinkan untuk Pemilik Usaha (Owner) dan Supervisor (SPV).',
      };
    }

    const targetInvoice = invoices.find((inv) => inv.id === invoiceId);
    if (!targetInvoice) {
      return { success: false, message: 'Data faktur invoice tidak ditemukan.' };
    }

    const dateNow = getWIBNow(false);

    // 1. Revert product stock for all items
    setProducts((prev) =>
      prev.map((p) => {
        const matchedItem = targetInvoice.items.find((item) => item.productId === p.id);
        if (matchedItem) {
          return {
            ...p,
            currentStock: p.currentStock + matchedItem.quantity,
            lastUpdated: dateNow,
          };
        }
        return p;
      })
    );

    // 2. Remove corresponding sale movements
    setMovements((prev) => prev.filter((m) => m.referenceNo !== targetInvoice.invoiceNumber));
    movements.filter((m) => m.referenceNo === targetInvoice.invoiceNumber).forEach((m) => removeDocument('movements', m.id));

    // 3. Remove Invoice Record
    setInvoices((prev) => prev.filter((inv) => inv.id !== invoiceId));
    removeDocument('invoices', invoiceId);

    // Save replenished products to Firestore
    targetInvoice.items.forEach((item) => {
      const prod = products.find((p) => p.id === item.productId);
      if (prod) {
        saveDocument('products', {
          ...prod,
          currentStock: prod.currentStock + item.quantity,
          lastUpdated: dateNow,
        });
      }
    });

    // 4. Activity Log
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'SALES_INVOICE',
      title: `Hapus Faktur Penjualan: ${targetInvoice.invoiceNumber}`,
      details: `${actor.name} (${actor.roleTitle || actor.role}) menghapus faktur ${targetInvoice.invoiceNumber} (${targetInvoice.customerName}) senilai ${formatRupiah(targetInvoice.grandTotal)}. Seluruh stok bahan terkait (${targetInvoice.items.length} item) telah dikembalikan ke gudang.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 5. Push Notification
    addPushNotification({
      title: `🗑️ Faktur Penjualan Dihapus`,
      message: `Faktur ${targetInvoice.invoiceNumber} (${targetInvoice.customerName}) telah dihapus oleh ${actor.name}. Stok bahan terkait dikembalikan ke inventaris gudang.`,
      type: 'sale_alert',
    });

    return {
      success: true,
      message: `Faktur penjualan ${targetInvoice.invoiceNumber} berhasil dihapus dan seluruh stok bahan telah dikembalikan ke gudang.`,
    };
  };

  // 4. Save (Create or Update) Product
  const handleSaveProduct = (prod: Product) => {
    // Write to Firestore Cloud
    saveDocument('products', prod);

    const actor = currentUserRef.current || currentUser;
    const isExisting = products.some((p) => p.id === prod.id);
    if (isExisting) {
      const prevProd = products.find((p) => p.id === prod.id);
      const stockChanged = prevProd && prevProd.currentStock !== prod.currentStock;
      setProducts((prev) => prev.map((p) => (p.id === prod.id ? prod : p)));
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
        actionType: 'PRODUCT_UPDATED',
        title: `Perubahan Data Bahan: ${prod.name}`,
        details: `${actor.name} (${actor.roleTitle || actor.role}) memperbarui data bahan baku ${prod.name} (${prod.code}).${stockChanged ? ` Stok diubah langsung: ${prevProd?.currentStock} → ${prod.currentStock} ${prod.unit}.` : ''} Min Alert: ${prod.minStockAlert}, HPP: ${formatRupiah(prod.costPrice)}, Jual: ${formatRupiah(prod.sellingPrice)}.`,
        severity: 'info',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    } else {
      setProducts((prev) => [prod, ...prev]);
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
        actionType: 'PRODUCT_ADDED',
        title: `Pendaftaran Bahan Baru: ${prod.name}`,
        details: `${actor.name} (${actor.roleTitle || actor.role}) mendaftarkan bahan baru ${prod.name} (${prod.code}) ke master inventaris gudang dengan stok awal ${prod.currentStock} ${prod.unit} (HPP: ${formatRupiah(prod.costPrice)}, Jual: ${formatRupiah(prod.sellingPrice)}).`,
        severity: 'info',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    }
  };

  // 4b. Delete Product (Hanya untuk SPV & Owner)
  const handleDeleteProduct = (productId: string): { success: boolean; message?: string } => {
    const actor = currentUserRef.current || currentUser;
    const canDelete = actor.role === 'owner' || actor.role === 'warehouse_admin' || actor.roleTitle?.toLowerCase().includes('spv') || actor.roleTitle?.toLowerCase().includes('supervisor');

    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Aksi hapus bahan baku hanya diizinkan untuk Supervisor Gudang (SPV) dan Pemilik Usaha (Owner).',
      };
    }

    const targetProd = products.find((p) => p.id === productId);
    if (!targetProd) {
      return { success: false, message: 'Bahan baku tidak ditemukan.' };
    }

    // Delete from Firestore Cloud
    removeDocument('products', productId);

    setProducts((prev) => prev.filter((p) => p.id !== productId));

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT',
      title: `Hapus Bahan Baku: ${targetProd.name}`,
      details: `Bahan baku ${targetProd.name} (${targetProd.code}) telah dihapus dari sistem gudang oleh ${actor.name} (${actor.roleTitle || actor.role}). Stok terakhir: ${targetProd.currentStock} ${targetProd.unit}.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    addPushNotification({
      title: `🗑️ Bahan Baku Dihapus`,
      message: `${targetProd.name} (${targetProd.code}) dihapus oleh ${actor.name} (${actor.roleTitle || actor.role}).`,
      type: 'stock_warning',
      meta: {
        productName: targetProd.name,
      },
    });

    return { success: true, message: `Bahan ${targetProd.name} berhasil dihapus dari inventaris gudang.` };
  };

  // 4bb. Restore from Checkpoint & Local Backup
  const handleRestoreCheckpoint = async (
    snapshot: SystemCheckpoint['snapshot'],
    label: string
  ) => {
    setCloudSyncStatus('syncing');
    setIsCloudLoading(true);
    try {
      if (snapshot.products !== undefined) {
        setProducts(snapshot.products);
        localStorage.setItem('dtf_sublime_products', JSON.stringify(snapshot.products));
        await replaceCollectionInFirestore('products', snapshot.products);
      }
      if (snapshot.movements !== undefined) {
        setMovements(snapshot.movements);
        localStorage.setItem('dtf_sublime_movements', JSON.stringify(snapshot.movements));
        await replaceCollectionInFirestore('movements', snapshot.movements);
      }
      if (snapshot.invoices !== undefined) {
        setInvoices(snapshot.invoices);
        localStorage.setItem('dtf_sublime_invoices', JSON.stringify(snapshot.invoices));
        await replaceCollectionInFirestore('invoices', snapshot.invoices);
      }
      if (snapshot.categories !== undefined) {
        setCategories(snapshot.categories);
        localStorage.setItem('dtf_sublime_categories', JSON.stringify(snapshot.categories));
        await replaceCollectionInFirestore('categories', snapshot.categories);
      }
      if (snapshot.units || snapshot.locations || snapshot.divisions) {
        if (snapshot.units) {
          setUnits(snapshot.units);
          localStorage.setItem('dtf_sublime_units', JSON.stringify(snapshot.units));
        }
        if (snapshot.locations) {
          setLocations(snapshot.locations);
          localStorage.setItem('dtf_sublime_locations', JSON.stringify(snapshot.locations));
        }
        if (snapshot.divisions) {
          setDivisions(snapshot.divisions);
          localStorage.setItem('dtf_sublime_divisions', JSON.stringify(snapshot.divisions));
        }
        await saveSetting('master_lists', {
          units: snapshot.units || units,
          locations: snapshot.locations || locations,
          divisions: snapshot.divisions || divisions,
        });
      }
      if (snapshot.suppliers !== undefined) {
        setSuppliers(snapshot.suppliers);
        localStorage.setItem('dtf_sublime_suppliers', JSON.stringify(snapshot.suppliers));
        await replaceCollectionInFirestore('suppliers', snapshot.suppliers);
      }
      if (snapshot.customers !== undefined) {
        setCustomers(snapshot.customers);
        localStorage.setItem('dtf_sublime_customers', JSON.stringify(snapshot.customers));
        await replaceCollectionInFirestore('customers', snapshot.customers);
      }
      if (snapshot.users !== undefined && snapshot.users.length > 0) {
        setUsers(snapshot.users);
        localStorage.setItem('dtf_sublime_users', JSON.stringify(snapshot.users));
        await replaceCollectionInFirestore('users', snapshot.users);
      }
      if (snapshot.logs !== undefined) {
        setLogs(snapshot.logs);
        localStorage.setItem('dtf_sublime_logs', JSON.stringify(snapshot.logs));
        await replaceCollectionInFirestore('activity_logs', snapshot.logs);
      }
      if (snapshot.companyProfile) {
        setCompanyProfile(snapshot.companyProfile);
        localStorage.setItem('dtf_sublime_company_profile', JSON.stringify(snapshot.companyProfile));
        await saveSetting('company_profile', snapshot.companyProfile);
      }

      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'CHECKPOINT_RESTORED',
        title: `Pemulihan Checkpoint: ${label}`,
        details: `Data sistem berhasil dipulihkan ke titik snapshot "${label}" oleh ${currentUser.name} (${currentUser.roleTitle}) dan tersinkron ke semua perangkat.`,
        severity: 'warning',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);

      addPushNotification({
        title: `🔄 Sistem Berhasil Dipulihkan`,
        message: `Data inventaris telah dikembalikan ke snapshot: ${label} dan tersinkron ke cloud.`,
        type: 'system',
      });
      setLastSyncTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }));
    } catch (err) {
      console.error('handleRestoreCheckpoint error:', err);
    } finally {
      setCloudSyncStatus('connected');
      setIsCloudLoading(false);
    }
  };

  const handleRestoreBackupFile = async (
    data: BackupFileData['data'],
    backupInfo: { date: string; by: string }
  ) => {
    setCloudSyncStatus('syncing');
    setIsCloudLoading(true);
    try {
      if (data.products !== undefined) {
        setProducts(data.products);
        localStorage.setItem('dtf_sublime_products', JSON.stringify(data.products));
        await replaceCollectionInFirestore('products', data.products);
      }
      if (data.movements !== undefined) {
        setMovements(data.movements);
        localStorage.setItem('dtf_sublime_movements', JSON.stringify(data.movements));
        await replaceCollectionInFirestore('movements', data.movements);
      }
      if (data.invoices !== undefined) {
        setInvoices(data.invoices);
        localStorage.setItem('dtf_sublime_invoices', JSON.stringify(data.invoices));
        await replaceCollectionInFirestore('invoices', data.invoices);
      }
      if (data.categories !== undefined) {
        setCategories(data.categories);
        localStorage.setItem('dtf_sublime_categories', JSON.stringify(data.categories));
        await replaceCollectionInFirestore('categories', data.categories);
      }
      if (data.units || data.locations || data.divisions) {
        if (data.units) {
          setUnits(data.units);
          localStorage.setItem('dtf_sublime_units', JSON.stringify(data.units));
        }
        if (data.locations) {
          setLocations(data.locations);
          localStorage.setItem('dtf_sublime_locations', JSON.stringify(data.locations));
        }
        if (data.divisions) {
          setDivisions(data.divisions);
          localStorage.setItem('dtf_sublime_divisions', JSON.stringify(data.divisions));
        }
        await saveSetting('master_lists', {
          units: data.units || units,
          locations: data.locations || locations,
          divisions: data.divisions || divisions,
        });
      }
      if (data.suppliers !== undefined) {
        setSuppliers(data.suppliers);
        localStorage.setItem('dtf_sublime_suppliers', JSON.stringify(data.suppliers));
        await replaceCollectionInFirestore('suppliers', data.suppliers);
      }
      if (data.customers !== undefined) {
        setCustomers(data.customers);
        localStorage.setItem('dtf_sublime_customers', JSON.stringify(data.customers));
        await replaceCollectionInFirestore('customers', data.customers);
      }
      if (data.users !== undefined && data.users.length > 0) {
        setUsers(data.users);
        localStorage.setItem('dtf_sublime_users', JSON.stringify(data.users));
        await replaceCollectionInFirestore('users', data.users);
      }
      if (data.logs !== undefined) {
        setLogs(data.logs);
        localStorage.setItem('dtf_sublime_logs', JSON.stringify(data.logs));
        await replaceCollectionInFirestore('activity_logs', data.logs);
      }
      if (data.companyProfile) {
        setCompanyProfile(data.companyProfile);
        localStorage.setItem('dtf_sublime_company_profile', JSON.stringify(data.companyProfile));
        await saveSetting('company_profile', data.companyProfile);
      }

      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'BACKUP_RESTORED',
        title: `Pemulihan File Cadangan Lokal`,
        details: `Basis data dipulihkan dari file backup bertanggal ${backupInfo.date} (dibuat oleh ${backupInfo.by}) oleh ${currentUser.name} dan tersinkron ke semua perangkat.`,
        severity: 'warning',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);

      addPushNotification({
        title: `📂 File Cadangan Dipulihkan`,
        message: `Seluruh data sistem berhasil dipulihkan dari file backup eksternal (${backupInfo.date}) dan tersinkron ke semua perangkat.`,
        type: 'system',
      });
      setLastSyncTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }));
    } catch (err) {
      console.error('handleRestoreBackupFile error:', err);
    } finally {
      setCloudSyncStatus('connected');
      setIsCloudLoading(false);
    }
  };

  // 4bc. Clear Operational Data (Products, Movements, Invoices)
  const handleClearOperationalData = async () => {
    setCloudSyncStatus('syncing');
    setIsCloudLoading(true);
    try {
      setProducts([]);
      localStorage.setItem('dtf_sublime_products', JSON.stringify([]));

      setMovements([]);
      localStorage.setItem('dtf_sublime_movements', JSON.stringify([]));

      setInvoices([]);
      localStorage.setItem('dtf_sublime_invoices', JSON.stringify([]));

      await clearOperationalCloudData();

      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'BACKUP_RESTORED',
        title: `Pengosongan Data Operasional Gudang`,
        details: `Seluruh data stok bahan baku, riwayat mutasi, dan faktur penjualan telah dikosongkan oleh ${currentUser.name} (${currentUser.roleTitle}) dan tersinkron ke seluruh perangkat.`,
        severity: 'warning',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);

      addPushNotification({
        title: `🗑️ Data Operasional Dikosongkan`,
        message: `Seluruh data stok dan transaksi telah berhasil dikosongkan dan disinkronkan ke seluruh perangkat.`,
        type: 'system',
      });
      setLastSyncTime(new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }));
    } catch (err) {
      console.error('handleClearOperationalData error:', err);
    } finally {
      setCloudSyncStatus('connected');
      setIsCloudLoading(false);
    }
  };

  // 4e. Delete Individual Activity Log (dikelola lewat canDeleteLogs)
  const handleDeleteLog = (logId: string): { success: boolean; message?: string } => {
    const canDelete = currentUser.role === 'owner' || Boolean(currentUser.canDeleteLogs);
    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Hapus Riwayat Log Aktivitas". Izin ini dapat diaktifkan oleh Pemilik di menu Hak Akses & Pengguna.',
      };
    }

    const targetLog = logs.find((l) => l.id === logId);
    if (!targetLog) {
      return { success: false, message: 'Data log tidak ditemukan.' };
    }

    setLogs((prev) => prev.filter((l) => l.id !== logId));
    removeDocument('activity_logs', logId);
    return {
      success: true,
      message: `Catatan log "${targetLog.title}" berhasil dihapus.`,
    };
  };

  // 4f. Clear All Activity Logs (dikelola lewat canDeleteLogs)
  const handleClearAllLogs = (): { success: boolean; message?: string } => {
    const canDelete = currentUser.role === 'owner' || Boolean(currentUser.canDeleteLogs);
    if (!canDelete) {
      return {
        success: false,
        message: 'Aksi ditolak: Anda tidak memiliki hak akses "Hapus Riwayat Log Aktivitas". Izin ini dapat diaktifkan oleh Pemilik di menu Hak Akses & Pengguna.',
      };
    }

    batchRemoveDocuments('activity_logs', logs.map((l) => l.id));
    setLogs([]);
    return {
      success: true,
      message: 'Seluruh riwayat log aktivitas telah dibersihkan.',
    };
  };

  // 4c. Apply Stock Opname & Physical Reconciliation Adjustments
  const handleApplyOpname = (
    adjustments: {
      productId: string;
      productName: string;
      productCode: string;
      category: string;
      unit: string;
      systemStock: number;
      physicalStock: number;
      difference: number;
      costPrice: number;
      reasonCategory: string;
      notes: string;
    }[],
    sessionNotes: string
  ) => {
    if (!adjustments || adjustments.length === 0) return;

    const dateNow = getWIBNow(false);
    const sessionRef = `OPN-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;

    // 1. Update Product Stocks
    setProducts((prev) => {
      const adjMap = new Map(adjustments.map((a) => [a.productId, a.physicalStock]));
      return prev.map((p) => {
        if (adjMap.has(p.id)) {
          const updatedProd = {
            ...p,
            currentStock: adjMap.get(p.id)!,
            lastUpdated: dateNow,
          };
          saveDocument('products', updatedProd);
          return updatedProd;
        }
        return p;
      });
    });

    const actor = currentUserRef.current || currentUser;

    // 2. Add Stock Movement Records (type: 'adjustment')
    const newMovements: StockMovement[] = adjustments.map((adj, idx) => {
      const newMov: StockMovement = {
        id: `mov-opn-${Date.now()}-${idx}`,
        date: dateNow,
        productId: adj.productId,
        productName: adj.productName,
        productCode: adj.productCode,
        category: adj.category as any,
        type: 'adjustment',
        quantity: Math.abs(adj.difference),
        unit: adj.unit as any,
        previousStock: adj.systemStock,
        finalStock: adj.physicalStock,
        referenceNo: sessionRef,
        notes: `[Stok Opname - ${adj.reasonCategory}] ${adj.notes || sessionNotes || 'Penyesuaian audit fisik gudang'}`,
        performedBy: {
          userId: actor.id,
          userName: actor.name,
          userRole: actor.role,
          userRoleTitle: actor.roleTitle,
        },
        unitPrice: adj.costPrice,
        totalValue: Math.abs(adj.difference) * adj.costPrice,
      };
      saveDocument('movements', newMov);
      return newMov;
    });

    setMovements((prev) => [...newMovements, ...prev]);

    // Save stock opnames session to Firestore
    saveDocument('stock_opnames', {
      id: sessionRef,
      date: dateNow,
      referenceNo: sessionRef,
      auditedBy: {
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
      },
      totalItems: adjustments.length,
      matchedItems: adjustments.filter((a) => a.difference === 0).length,
      discrepancyItems: adjustments.filter((a) => a.difference !== 0).length,
      totalVarianceValue: adjustments.reduce((sum, a) => sum + (a.difference * a.costPrice), 0),
      notes: sessionNotes || 'Audit fisik inventaris gudang',
      items: adjustments,
    });

    // 3. Add Activity Log
    const totalDiffValue = adjustments.reduce((sum, a) => sum + (a.difference * a.costPrice), 0);
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: actor.id,
      userName: actor.name,
      userRole: actor.role,
      userRoleTitle: actor.roleTitle,
      actionType: 'STOCK_ADJUSTMENT' as any,
      title: `Stok Opname Selesai (${adjustments.length} Bahan)`,
      details: `Audit fisik (${sessionRef}) diselesaikan oleh ${actor.name} (${actor.roleTitle || actor.role}). ${adjustments.length} item disesuaikan dengan selisih nominal bersih ${formatRupiah(totalDiffValue)}. Catatan: ${sessionNotes || '-'}`,
      severity: totalDiffValue < 0 ? 'warning' : 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    // 4. Send Push Notification
    addPushNotification({
      title: `📋 Audit Stok Opname Berhasil (${sessionRef})`,
      message: `Petugas ${actor.name} telah menyelesaikan audit fisik untuk ${adjustments.length} bahan baku DTF & Sublimasi.`,
      type: 'system',
    });
  };

  // Master Data Handlers: Category, Unit, Location
  const handleAddCategory = (newCat: CategoryItem) => {
    setCategories((prev) => [...prev, newCat]);
    saveDocument('categories', newCat);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_ADDED',
      title: `Tambah Kategori: ${newCat.name}`,
      details: `Kategori baru "${newCat.name}" dengan prefix kode "${newCat.prefix}" berhasil ditambahkan ke master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
  };

  const handleDeleteCategory = (catId: string): { success: boolean; message?: string } => {
    const inUse = products.filter((p) => p.category === catId);
    if (inUse.length > 0) {
      return {
        success: false,
        message: `Kategori ini masih digunakan oleh ${inUse.length} bahan baku di gudang. Silakan ubah kategori bahan baku terkait terlebih dahulu.`,
      };
    }
    const catToDelete = categories.find((c) => c.id === catId);
    setCategories((prev) => prev.filter((c) => c.id !== catId));
    removeDocument('categories', catId);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Hapus Kategori: ${catToDelete?.name || catId}`,
      details: `Kategori "${catToDelete?.name || catId}" dihapus dari master data.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleAddUnit = (newUnit: string) => {
    const trimmed = newUnit.trim();
    if (!trimmed) return;
    if (!units.includes(trimmed)) {
      const updated = [...units, trimmed];
      setUnits(updated);
      saveSetting('master_lists', { units: updated, locations, divisions });
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'PRODUCT_ADDED',
        title: `Tambah Satuan: ${trimmed}`,
        details: `Satuan ukuran "${trimmed}" berhasil ditambahkan ke master data.`,
        severity: 'info',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    }
  };

  const handleDeleteUnit = (unit: string): { success: boolean; message?: string } => {
    const inUse = products.filter((p) => p.unit === unit);
    if (inUse.length > 0) {
      return {
        success: false,
        message: `Satuan "${unit}" masih digunakan oleh ${inUse.length} bahan baku di gudang.`,
      };
    }
    const updated = units.filter((u) => u !== unit);
    setUnits(updated);
    saveSetting('master_lists', { units: updated, locations, divisions });
    return { success: true };
  };

  const handleAddLocation = (newLoc: string) => {
    const trimmed = newLoc.trim();
    if (!trimmed) return;
    if (!locations.includes(trimmed)) {
      const updated = [...locations, trimmed];
      setLocations(updated);
      saveSetting('master_lists', { units, locations: updated, divisions });
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'PRODUCT_ADDED',
        title: `Tambah Lokasi: ${trimmed}`,
        details: `Lokasi rak/gudang "${trimmed}" berhasil didaftarkan ke master data.`,
        severity: 'info',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    }
  };

  const handleDeleteLocation = (loc: string): { success: boolean; message?: string } => {
    const inUse = products.filter((p) => p.location === loc);
    if (inUse.length > 0) {
      return {
        success: false,
        message: `Lokasi "${loc}" masih digunakan oleh ${inUse.length} bahan baku di gudang.`,
      };
    }
    const updated = locations.filter((l) => l !== loc);
    setLocations(updated);
    saveSetting('master_lists', { units, locations: updated, divisions });
    return { success: true };
  };

  const handleAddSupplier = (newSup: SupplierItem) => {
    setSuppliers((prev) => [...prev, newSup]);
    saveDocument('suppliers', newSup);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_ADDED',
      title: `Tambah Suplier: ${newSup.name}`,
      details: `Mitra suplier "${newSup.name}"${newSup.address ? ` (${newSup.address})` : ''} berhasil didaftarkan ke master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
  };

  const handleDeleteSupplier = (supId: string): { success: boolean; message?: string } => {
    const supToDelete = suppliers.find((s) => s.id === supId);
    if (!supToDelete) return { success: false, message: 'Suplier tidak ditemukan' };

    setSuppliers((prev) => prev.filter((s) => s.id !== supId));
    removeDocument('suppliers', supId);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Hapus Suplier: ${supToDelete.name}`,
      details: `Mitra suplier "${supToDelete.name}" dihapus dari master data.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleAddCustomer = (newCust: CustomerItem) => {
    saveDocument('customers', newCust);
    setCustomers((prev) => {
      // Check if already exists
      const existing = prev.find(
        (c) => c.name.toLowerCase() === newCust.name.toLowerCase() || (newCust.phone && c.phone === newCust.phone)
      );
      if (existing) {
        // Update details if missing
        return prev.map((c) =>
          c.id === existing.id
            ? {
                ...c,
                phone: c.phone || newCust.phone,
                address: c.address || newCust.address,
                notes: c.notes || newCust.notes,
              }
            : c
        );
      }
      return [...prev, newCust];
    });

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_ADDED',
      title: `Tambah Pelanggan: ${newCust.name}`,
      details: `Pelanggan "${newCust.name}" (${newCust.phone}) berhasil disimpan ke master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
  };

  const handleDeleteCustomer = (custId: string): { success: boolean; message?: string } => {
    const custToDelete = customers.find((c) => c.id === custId);
    if (!custToDelete) return { success: false, message: 'Pelanggan tidak ditemukan' };

    setCustomers((prev) => prev.filter((c) => c.id !== custId));
    removeDocument('customers', custId);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Hapus Pelanggan: ${custToDelete.name}`,
      details: `Data pelanggan "${custToDelete.name}" dihapus dari master data.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleUpdateCategory = (
    oldCatId: string,
    updatedCat: CategoryItem
  ): { success: boolean; message?: string } => {
    if (!updatedCat.name.trim()) {
      return { success: false, message: 'Nama kategori tidak boleh kosong' };
    }
    if (!updatedCat.prefix.trim()) {
      return { success: false, message: 'Prefix kode tidak boleh kosong' };
    }

    const prefixDuplicate = categories.some(
      (c) => c.id !== oldCatId && (c.prefix || '').toUpperCase() === (updatedCat.prefix || '').toUpperCase()
    );
    if (prefixDuplicate) {
      return { success: false, message: `Prefix "${updatedCat.prefix}" sudah digunakan oleh kategori lain` };
    }

    setCategories((prev) =>
      prev.map((c) => (c.id === oldCatId ? updatedCat : c))
    );
    saveDocument('categories', updatedCat);

    // If ID changed, sync products & movements
    if (oldCatId !== updatedCat.id) {
      removeDocument('categories', oldCatId);
      setProducts((prev) =>
        prev.map((p) => {
          if (p.category === oldCatId) {
            const updated = { ...p, category: updatedCat.id };
            saveDocument('products', updated);
            return updated;
          }
          return p;
        })
      );
      setMovements((prev) =>
        prev.map((m) => {
          if (m.category === oldCatId) {
            const updated = { ...m, category: updatedCat.id as any };
            saveDocument('movements', updated);
            return updated;
          }
          return m;
        })
      );
    }

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Kategori: ${updatedCat.name}`,
      details: `Kategori "${updatedCat.name}" (Prefix: ${updatedCat.prefix}) berhasil diperbarui di master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleUpdateUnit = (
    oldUnit: string,
    newUnit: string
  ): { success: boolean; message?: string } => {
    const trimmed = newUnit.trim();
    if (!trimmed) {
      return { success: false, message: 'Nama satuan tidak boleh kosong' };
    }
    if (trimmed.toLowerCase() !== oldUnit.toLowerCase() && units.some((u) => u.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: `Satuan "${trimmed}" sudah terdaftar` };
    }

    const updatedUnits = units.map((u) => (u === oldUnit ? trimmed : u));
    setUnits(updatedUnits);
    saveSetting('master_lists', { units: updatedUnits, locations, divisions });

    // Cascade update to products
    setProducts((prev) =>
      prev.map((p) => {
        if (p.unit === oldUnit) {
          const updated = { ...p, unit: trimmed };
          saveDocument('products', updated);
          return updated;
        }
        return p;
      })
    );

    // Cascade to movements
    setMovements((prev) =>
      prev.map((m) => {
        if (m.unit === oldUnit) {
          const updated = { ...m, unit: trimmed };
          saveDocument('movements', updated);
          return updated;
        }
        return m;
      })
    );

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Satuan: ${oldUnit} ➔ ${trimmed}`,
      details: `Satuan "${oldUnit}" diubah menjadi "${trimmed}". Semua bahan baku terkait otomatis diselaraskan.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleUpdateLocation = (
    oldLoc: string,
    newLoc: string
  ): { success: boolean; message?: string } => {
    const trimmed = newLoc.trim();
    if (!trimmed) {
      return { success: false, message: 'Nama lokasi rak tidak boleh kosong' };
    }
    if (trimmed.toLowerCase() !== oldLoc.toLowerCase() && locations.some((l) => l.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: `Lokasi "${trimmed}" sudah terdaftar` };
    }

    const updatedLocs = locations.map((l) => (l === oldLoc ? trimmed : l));
    setLocations(updatedLocs);
    saveSetting('master_lists', { units, locations: updatedLocs, divisions });

    // Cascade update to products
    setProducts((prev) =>
      prev.map((p) => {
        if (p.location === oldLoc) {
          const updated = { ...p, location: trimmed };
          saveDocument('products', updated);
          return updated;
        }
        return p;
      })
    );

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Lokasi: ${oldLoc} ➔ ${trimmed}`,
      details: `Lokasi rak/gudang "${oldLoc}" diubah menjadi "${trimmed}". Semua bahan baku terkait otomatis diselaraskan.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleUpdateSupplier = (
    updatedSup: SupplierItem
  ): { success: boolean; message?: string } => {
    const name = updatedSup.name.trim();
    if (!name) {
      return { success: false, message: 'Nama suplier tidak boleh kosong' };
    }
    const duplicate = suppliers.some(
      (s) => s.id !== updatedSup.id && s.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      return { success: false, message: `Suplier dengan nama "${name}" sudah terdaftar` };
    }

    const oldSup = suppliers.find((s) => s.id === updatedSup.id);
    const oldName = oldSup?.name;

    const finalizedSup = { ...updatedSup, name };
    setSuppliers((prev) =>
      prev.map((s) => (s.id === updatedSup.id ? finalizedSup : s))
    );
    saveDocument('suppliers', finalizedSup);

    // If supplier name changed, update movements
    if (oldName && oldName !== name) {
      setMovements((prev) =>
        prev.map((m) => {
          if (m.supplierName === oldName) {
            const updated = { ...m, supplierName: name };
            saveDocument('movements', updated);
            return updated;
          }
          return m;
        })
      );
    }

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Suplier: ${name}`,
      details: `Informasi mitra suplier "${name}" berhasil diperbarui di master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleUpdateCustomer = (
    updatedCust: CustomerItem
  ): { success: boolean; message?: string } => {
    const name = updatedCust.name.trim();
    const phone = updatedCust.phone.trim();
    if (!name) {
      return { success: false, message: 'Nama pelanggan tidak boleh kosong' };
    }
    if (!phone) {
      return { success: false, message: 'Nomor WhatsApp pelanggan tidak boleh kosong' };
    }

    const duplicate = customers.some(
      (c) => c.id !== updatedCust.id && c.name.toLowerCase() === name.toLowerCase()
    );
    if (duplicate) {
      return { success: false, message: `Pelanggan dengan nama "${name}" sudah terdaftar` };
    }

    const oldCust = customers.find((c) => c.id === updatedCust.id);
    const oldName = oldCust?.name;

    const finalizedCust = { ...updatedCust, name, phone };
    setCustomers((prev) =>
      prev.map((c) => (c.id === updatedCust.id ? finalizedCust : c))
    );
    saveDocument('customers', finalizedCust);

    if (oldName && oldName !== name) {
      setInvoices((prev) =>
        prev.map((inv) => {
          if (inv.customerName.toLowerCase() === oldName.toLowerCase()) {
            const updated = {
              ...inv,
              customerName: name,
              customerPhone: phone,
              customerAddress: updatedCust.address || inv.customerAddress,
            };
            saveDocument('invoices', updated);
            return updated;
          }
          return inv;
        })
      );
    }

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Pelanggan: ${name}`,
      details: `Data pelanggan "${name}" (${phone}) berhasil diperbarui di master data.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleAddDivision = (newDiv: string) => {
    const trimmed = newDiv.trim();
    if (!trimmed) return;
    if (!divisions.includes(trimmed)) {
      const updated = [...divisions, trimmed];
      setDivisions(updated);
      saveSetting('master_lists', { units, locations, divisions: updated });
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'PRODUCT_ADDED',
        title: `Tambah Divisi: ${trimmed}`,
        details: `Divisi / Unit Pemohon "${trimmed}" berhasil didaftarkan ke master data.`,
        severity: 'info',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    }
  };

  const handleUpdateDivision = (
    oldDiv: string,
    newDiv: string
  ): { success: boolean; message?: string } => {
    const trimmed = newDiv.trim();
    if (!trimmed) {
      return { success: false, message: 'Nama divisi tidak boleh kosong' };
    }
    if (trimmed.toLowerCase() !== oldDiv.toLowerCase() && divisions.some((d) => d.toLowerCase() === trimmed.toLowerCase())) {
      return { success: false, message: `Divisi "${trimmed}" sudah terdaftar` };
    }

    const updatedDivs = divisions.map((d) => (d === oldDiv ? trimmed : d));
    setDivisions(updatedDivs);
    saveSetting('master_lists', { units, locations, divisions: updatedDivs });

    // Cascade update to movements so reports stay 100% consistent!
    setMovements((prev) =>
      prev.map((m) => {
        if (m.divisionOrRequester === oldDiv) {
          const updated = { ...m, divisionOrRequester: trimmed };
          saveDocument('movements', updated);
          return updated;
        }
        return m;
      })
    );

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Edit Divisi: ${oldDiv} ➔ ${trimmed}`,
      details: `Nama divisi "${oldDiv}" diubah menjadi "${trimmed}". Riwayat mutasi dan laporan pemakaian divisi otomatis diselaraskan.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  const handleDeleteDivision = (div: string): { success: boolean; message?: string } => {
    const inUse = movements.filter((m) => m.type === 'production' && m.divisionOrRequester === div);
    if (inUse.length > 0) {
      return {
        success: false,
        message: `Divisi "${div}" masih memiliki riwayat di ${inUse.length} transaksi SPK produksi.`,
      };
    }
    const updatedDivs = divisions.filter((d) => d !== div);
    setDivisions(updatedDivs);
    saveSetting('master_lists', { units, locations, divisions: updatedDivs });
    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'PRODUCT_UPDATED',
      title: `Hapus Divisi: ${div}`,
      details: `Divisi "${div}" dihapus dari master data.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);
    return { success: true };
  };

  // 5. Update invoice payment status
  const handleUpdateInvoiceStatus = (
    invoiceId: string,
    status: 'lunas' | 'belum_lunas' | 'dp',
    paidAmount: number
  ) => {
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.id !== invoiceId) return inv;

        let updatedHistory = inv.paymentHistory ? [...inv.paymentHistory] : [];
        if (status === 'lunas' && paidAmount > (inv.paidAmount || 0)) {
          const remainder = paidAmount - (inv.paidAmount || 0);
          updatedHistory.push({
            id: `pay-${Date.now()}`,
            date: getWIBNow(false),
            amount: remainder,
            paymentMethod: inv.paymentMethod || 'Transfer Bank',
            notes: 'Pelunasan Cepat Faktur',
            receivedBy: {
              userId: currentUser.id,
              userName: currentUser.name,
              userRole: currentUser.role,
            },
          });
        }

        const updatedInvoice: Invoice = {
          ...inv,
          paymentStatus: status,
          paidAmount,
          paymentHistory: updatedHistory,
        };
        saveDocument('invoices', updatedInvoice);
        return updatedInvoice;
      })
    );
  };

  // 5b. Record detailed payment installment
  const handleRecordInvoicePayment = (
    invoiceId: string,
    paymentData: {
      amount: number;
      paymentMethod: string;
      referenceNumber?: string;
      notes?: string;
      date?: string;
      nextDueDate?: string;
    }
  ) => {
    const targetInv = invoices.find((i) => i.id === invoiceId);
    if (!targetInv) return;

    const newPaymentRecord: PaymentRecord = {
      id: `pay-${Date.now()}`,
      date: paymentData.date || getWIBNow(false),
      amount: paymentData.amount,
      paymentMethod: paymentData.paymentMethod,
      referenceNumber: paymentData.referenceNumber?.trim() || undefined,
      notes: paymentData.notes?.trim() || undefined,
      receivedBy: {
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
      },
    };

    const currentHistory = targetInv.paymentHistory || (targetInv.paidAmount > 0 ? [
      {
        id: `pay-prev-${targetInv.id}`,
        date: targetInv.date + ' 10:00',
        amount: targetInv.paidAmount,
        paymentMethod: targetInv.paymentMethod,
        notes: targetInv.paymentStatus === 'dp' ? 'Uang Muka (DP) Awal' : 'Pembayaran Awal',
        receivedBy: targetInv.createdBy,
      }
    ] : []);

    const updatedHistory = [...currentHistory, newPaymentRecord];
    const totalPaidNow = updatedHistory.reduce((sum, p) => sum + p.amount, 0);
    const newStatus: 'lunas' | 'belum_lunas' | 'dp' = 
      totalPaidNow >= targetInv.grandTotal
        ? 'lunas'
        : totalPaidNow > 0
        ? 'dp'
        : 'belum_lunas';

    const finalizedDueDate = paymentData.nextDueDate !== undefined ? paymentData.nextDueDate : targetInv.dueDate;

    const finalizedUpdatedInvoice: Invoice = {
      ...targetInv,
      dueDate: finalizedDueDate,
      paidAmount: totalPaidNow,
      paymentStatus: newStatus,
      paymentHistory: updatedHistory,
    };
    saveDocument('invoices', finalizedUpdatedInvoice);

    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invoiceId
          ? {
              ...inv,
              dueDate: finalizedDueDate,
              paidAmount: Math.min(totalPaidNow, inv.grandTotal),
              paymentStatus: newStatus,
              paymentHistory: updatedHistory,
            }
          : inv
      )
    );

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'SALES_INVOICE',
      title: `Catat Cicilan ${targetInv.invoiceNumber}: ${formatRupiah(paymentData.amount)}`,
      details: `Menerima cicilan sebesar ${formatRupiah(paymentData.amount)} via ${paymentData.paymentMethod} dari ${targetInv.customerName}. Total terbayar: ${formatRupiah(totalPaidNow)} / ${formatRupiah(targetInv.grandTotal)} (Status: ${(newStatus || '').toUpperCase()}).`,
      severity: newStatus === 'lunas' ? 'success' : 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    if (newStatus === 'lunas') {
      addPushNotification({
        title: `✅ LUNAS: Invoice ${targetInv.invoiceNumber}`,
        message: `Pelanggan ${targetInv.customerName} telah melunasi seluruh tagihan invoice ${targetInv.invoiceNumber} (${formatRupiah(targetInv.grandTotal)}).`,
        type: 'sale_alert',
        meta: {
          referenceNo: targetInv.invoiceNumber,
          amount: targetInv.grandTotal,
        },
      });
    } else {
      addPushNotification({
        title: `💵 Cicilan Masuk (${targetInv.invoiceNumber})`,
        message: `${targetInv.customerName} membayar cicilan ${formatRupiah(paymentData.amount)} via ${paymentData.paymentMethod}. Sisa tagihan: ${formatRupiah(targetInv.grandTotal - totalPaidNow)}.`,
        type: 'sale_alert',
        meta: {
          referenceNo: targetInv.invoiceNumber,
          amount: paymentData.amount,
        },
      });
    }
  };

  // 5c. Delete payment record from history
  const handleDeleteInvoicePayment = (invoiceId: string, paymentId: string) => {
    const targetInv = invoices.find((i) => i.id === invoiceId);
    if (!targetInv) return;

    const currentHistory = targetInv.paymentHistory || [];
    const removedPayment = currentHistory.find((p) => p.id === paymentId);
    const updatedHistory = currentHistory.filter((p) => p.id !== paymentId);
    const totalPaidNow = updatedHistory.reduce((sum, p) => sum + p.amount, 0);
    const newStatus: 'lunas' | 'belum_lunas' | 'dp' = 
      totalPaidNow >= targetInv.grandTotal
        ? 'lunas'
        : totalPaidNow > 0
        ? 'dp'
        : 'belum_lunas';

    const updatedInvoiceObj: Invoice = {
      ...targetInv,
      paidAmount: totalPaidNow,
      paymentStatus: newStatus,
      paymentHistory: updatedHistory,
    };
    saveDocument('invoices', updatedInvoiceObj);

    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invoiceId
          ? updatedInvoiceObj
          : inv
      )
    );

    if (removedPayment) {
      const newLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        actionType: 'SALES_INVOICE',
        title: `Hapus Cicilan ${targetInv.invoiceNumber}`,
        details: `Menghapus catatan cicilan ${formatRupiah(removedPayment.amount)} pada invoice ${targetInv.invoiceNumber}. Total terbayar menjadi ${formatRupiah(totalPaidNow)}.`,
        severity: 'warning',
      };
      setLogs((prev) => [newLog, ...prev]);
      saveDocument('activity_logs', newLog);
    }
  };

  // 5b. User & Access Control Management Handlers (Hak Akses Granular)
  const handleUpdateUser = (updatedUser: User) => {
    setUsers((prev) => {
      return prev.map((u) => (u.id === updatedUser.id ? updatedUser : u));
    });

    // If updating currently logged in user, update immediately
    if (currentUser.id === updatedUser.id) {
      setCurrentUser(updatedUser);
      localStorage.setItem('dtf_sublime_auth_user_id', updatedUser.id);
    }
    saveDocument('users', updatedUser);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'SETTINGS_UPDATE',
      title: `Perubahan Hak Akses: ${updatedUser.name}`,
      details: `Hak akses & profil pengguna ${updatedUser.name} (${updatedUser.roleTitle}) diperbarui melalui checklist izin oleh ${currentUser.name}. Izin Hapus Bahan: ${updatedUser.canDeleteProducts ? 'Aktif' : 'Nonaktif'}, Kelola Produk: ${updatedUser.canManageProducts ? 'Aktif' : 'Nonaktif'}, Lihat Keuangan: ${updatedUser.canViewFinancials ? 'Aktif' : 'Nonaktif'}.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    addPushNotification({
      title: `🛡️ Hak Akses Diperbarui`,
      message: `Hak akses untuk ${updatedUser.name} (${updatedUser.roleTitle}) telah disesuaikan di Manajemen Hak Akses.`,
      type: 'system',
      meta: {
        userId: updatedUser.id,
      },
    });
  };

  const handleAddUser = (newUser: User) => {
    setUsers((prev) => [...prev, newUser]);
    saveDocument('users', newUser);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'USER_CREATED',
      title: `Pendaftaran Pengguna Baru: ${newUser.name}`,
      details: `Pengguna baru ${newUser.name} (${newUser.roleTitle}) ditambahkan dengan hak akses checklist tersimpan oleh ${currentUser.name}.`,
      severity: 'info',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    addPushNotification({
      title: `👤 Pengguna Baru Terdaftar`,
      message: `${newUser.name} (${newUser.roleTitle}) berhasil ditambahkan ke sistem.`,
      type: 'system',
    });
  };

  const handleDeleteUser = (userId: string): { success: boolean; message?: string } => {
    if (userId === currentUser.id) {
      return { success: false, message: 'Tidak dapat menghapus akun yang sedang Anda gunakan saat ini.' };
    }
    const targetUser = users.find((u) => u.id === userId);
    if (!targetUser) {
      return { success: false, message: 'Pengguna tidak ditemukan.' };
    }

    setUsers((prev) => prev.filter((u) => u.id !== userId));
    removeDocument('users', userId);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'USER_DELETED',
      title: `Hapus Pengguna: ${targetUser.name}`,
      details: `Akun ${targetUser.name} (${targetUser.roleTitle}) dihapus dari sistem oleh ${currentUser.name}.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
    saveDocument('activity_logs', newLog);

    return { success: true, message: `Pengguna ${targetUser.name} berhasil dihapus.` };
  };

  const handleResetUsersToDefault = () => {
    setUsers(INITIAL_USERS);
    const matched = INITIAL_USERS.find((u) => u.id === currentUser.id) || INITIAL_USERS[0];
    setCurrentUser(matched);
    localStorage.setItem('dtf_sublime_auth_user_id', matched.id);

    const newLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      actionType: 'SETTINGS_UPDATE',
      title: `Reset Hak Akses ke Standar Default`,
      details: `Semua data pengguna dan pengaturan izin hak akses telah dikembalikan ke pengaturan awal pabrik.`,
      severity: 'warning',
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // 6. Test push trigger from mobile simulator
  const handleTriggerTestPush = (type: 'sale' | 'production' | 'critical' | 'invoice_due') => {
    if (type === 'sale') {
      addPushNotification({
        title: '🛍️ Simulasi Penjualan (INV-202609-088)',
        message: 'Konsumen baru telah membeli 2 Roll PET Film 30cm & 1 Botol Tinta DTF senilai Rp 1.500.000.',
        type: 'sale_alert',
      });
    } else if (type === 'critical') {
      addPushNotification({
        title: '🚨 Peringatan: Tinta DTF White Sisa 2 Botol!',
        message: 'Stok Tinta Putih DTF telah melampaui batas kritis minimum (6 botol). Segera lakukan pemesanan ke supplier!',
        type: 'stock_warning',
      });
    } else if (type === 'invoice_due') {
      const unpaidFirst = invoices.find((inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp');
      const invNum = unpaidFirst ? unpaidFirst.invoiceNumber : 'INV-202609-003';
      const custName = unpaidFirst ? unpaidFirst.customerName : 'Konveksi Kaos Berkah';
      const dueStr = unpaidFirst ? unpaidFirst.dueDate : '2026-09-18';
      const unpaidAmt = unpaidFirst ? (unpaidFirst.grandTotal - unpaidFirst.paidAmount) : 1050000;

      addPushNotification({
        title: `🚨 PENGINGAT JATUH TEMPO: ${invNum}`,
        message: `Pelanggan ${custName} memiliki sisa tagihan ${formatRupiah(unpaidAmt)} (Jatuh tempo: ${dueStr}). Segera lakukan penagihan via WhatsApp!`,
        type: 'invoice_due',
        meta: {
          invoiceId: unpaidFirst ? unpaidFirst.id : 'inv-3',
          customerName: custName,
          dueDate: dueStr,
          unpaidAmount: unpaidAmt,
        },
      });
    } else {
      addPushNotification({
        title: '⚙️ Produksi Baru SPK-PRD-102',
        message: 'Operator Dani telah mengeluarkan 2 Kg Powder TPU Lem Putih untuk sablon jersey futsal.',
        type: 'production_alert',
      });
    }
  };

  const criticalProductsCount = products.filter((p) => p.currentStock <= p.minStockAlert).length;
  const unpaidInvoices = invoices.filter((inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp');
  const overdueInvoices = unpaidInvoices.filter((inv) => getInvoiceDueInfo(inv).isOverdue);
  const unpaidCustomersCount = useMemo(() => {
    const debtSet = new Set<string>();
    invoices.forEach((inv) => {
      const due = getInvoiceDueInfo(inv);
      if (inv.paymentStatus !== 'lunas' && due.unpaidAmount > 0) {
        debtSet.add(inv.customerName.trim().toLowerCase());
      }
    });
    return debtSet.size;
  }, [invoices]);

  const handleMarkNotificationAsRead = (id: string) => {
    const target = notifications.find((n) => n.id === id);
    if (target) {
      const updated = { ...target, read: true };
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? updated : n))
      );
      saveDocument('notifications', updated);
    }
  };

  const handleToggleNotificationRead = (id: string) => {
    const target = notifications.find((n) => n.id === id);
    if (target) {
      const updated = { ...target, read: !target.read };
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? updated : n))
      );
      saveDocument('notifications', updated);
    }
  };

  const handleMarkAllNotificationsAsRead = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }));
    setNotifications(updated);
    batchSaveDocuments('notifications', updated);
  };

  const handleDeleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    removeDocument('notifications', id);
  };

  const handleClearAllReadNotifications = () => {
    const readList = notifications.filter((n) => n.read);
    setNotifications((prev) => prev.filter((n) => !n.read));
    if (readList.length > 0) {
      batchRemoveDocuments('notifications', readList.map((n) => n.id));
    }
  };

  const handleReloadActiveAlerts = () => {
    const alerts: PushNotification[] = [];
    const dateNow = getWIBNow(false);

    // 1. Scan critical products
    const criticalProds = products.filter((p) => p.currentStock <= p.minStockAlert);
    criticalProds.forEach((p) => {
      alerts.push({
        id: `push-crit-${p.id}`,
        timestamp: p.lastUpdated || dateNow,
        title: `🚨 Peringatan: Stok ${p.name} Menipis!`,
        message: `Stok saat ini tersisa ${p.currentStock} ${p.unit} (batas minimum aman: ${p.minStockAlert} ${p.unit}). Segera lakukan pesanan ke supplier!`,
        type: 'stock_warning',
        read: false,
        meta: {
          productName: p.name,
          currentStock: p.currentStock,
        },
      });
    });

    // 2. Scan unpaid/DP invoices
    const unpaidList = invoices.filter(
      (inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp'
    );
    unpaidList.forEach((inv) => {
      const dueInfo = getInvoiceDueInfo(inv);
      alerts.push({
        id: `push-due-${inv.id}`,
        timestamp: dateNow,
        title: dueInfo.isOverdue
          ? `🚨 LEWAT JATUH TEMPO: ${inv.invoiceNumber}`
          : `⏰ PENGINGAT TEMPO: ${inv.invoiceNumber}`,
        message: `Pelanggan ${inv.customerName} memiliki sisa tagihan ${formatRupiah(dueInfo.unpaidAmount)} (Jatuh tempo: ${inv.dueDate}). Segera lakukan penagihan via WhatsApp!`,
        type: 'invoice_due',
        read: false,
        meta: {
          referenceNo: inv.invoiceNumber,
          amount: inv.grandTotal,
          customerName: inv.customerName,
          dueDate: inv.dueDate,
          unpaidAmount: dueInfo.unpaidAmount,
          invoiceId: inv.id,
        },
      });
    });

    if (alerts.length === 0) {
      addPushNotification({
        title: '✅ Sistem Berjalan Normal',
        message: 'Tidak ada stok kritis atau tagihan jatuh tempo yang memerlukan perhatian saat ini.',
        type: 'system',
      });
      return;
    }

    setNotifications(alerts);
    playPushNotificationSound();
  };

  const handleTriggerTestPushDirectly = () => {
    addPushNotification({
      title: '🔔 Tes Notifikasi Push Web & Audio Chime',
      message: 'Sistem DTF & Sublime berhasil menguji notifikasi push real-time dengan audio chime interaktif!',
      type: 'sale_alert',
    });
  };

  const handleNavigateFromNotification = (notif: PushNotification) => {
    handleMarkNotificationAsRead(notif.id);
    if (notif.type === 'stock_warning') {
      setInitialFilterCritical(true);
      setActiveTab('inventory');
    } else if (notif.type === 'invoice_due' || notif.type === 'sale_alert') {
      setActiveTab('sales');
    } else if (notif.type === 'production_alert') {
      setActiveTab('production');
    } else if (notif.type === 'restock') {
      setActiveTab('purchases');
    }
  };

  // Authentication Handlers
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    currentUserRef.current = user;
    setIsAuthenticated(true);
    localStorage.setItem('dtf_sublime_auth_active', 'true');
    localStorage.setItem('dtf_sublime_auth_user_id', user.id);
    localStorage.setItem('dtf_sublime_current_user', JSON.stringify(user));

    // Register all existing notifications as known so login doesn't replay alerts for historical notifications
    notifications.forEach((n) => {
      if (n && n.id) {
        knownNotificationIdsRef.current.add(n.id);
      }
    });

    const loginLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      userRoleTitle: user.roleTitle,
      actionType: 'USER_LOGIN',
      title: 'Sesi Masuk (Login) Berhasil',
      details: `${user.name} (${user.roleTitle || user.role}) berhasil masuk ke sistem DTF & Sublime Inventory Pro.`,
      severity: 'info',
    };
    setLogs((prev) => [loginLog, ...prev]);
    saveDocument('activity_logs', loginLog);
  };

  const handleSwitchUser = (user: User) => {
    setCurrentUser(user);
    currentUserRef.current = user;
    setIsAuthenticated(true);
    localStorage.setItem('dtf_sublime_auth_active', 'true');
    localStorage.setItem('dtf_sublime_auth_user_id', user.id);
    localStorage.setItem('dtf_sublime_current_user', JSON.stringify(user));

    const switchLog: ActivityLog = {
      id: `log-${Date.now()}`,
      timestamp: getWIBNow(true, true),
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      userRoleTitle: user.roleTitle,
      actionType: 'USER_LOGIN',
      title: `Beralih Akun Pengguna: ${user.name}`,
      details: `Sistem beralih ke sesi ${user.name} (${user.roleTitle || user.role}). Seluruh transaksi selanjutnya dicatat atas nama pengguna ini.`,
      severity: 'info',
    };
    setLogs((prev) => [switchLog, ...prev]);
    saveDocument('activity_logs', switchLog);

    addPushNotification({
      title: `👤 Pengguna Aktif: ${user.name}`,
      message: `Anda sekarang bertransaksi sebagai ${user.name} (${user.roleTitle || user.role}).`,
      type: 'system',
    });
  };

  const handleLogout = async () => {
    try {
      await logoutFirebase();
    } catch (err) {
      console.warn('Firebase logout notice:', err);
    }
    const actor = currentUserRef.current || currentUser;
    if (actor) {
      const logoutLog: ActivityLog = {
        id: `log-${Date.now()}`,
        timestamp: getWIBNow(true, true),
        userId: actor.id,
        userName: actor.name,
        userRole: actor.role,
        userRoleTitle: actor.roleTitle,
        actionType: 'USER_LOGOUT',
        title: 'Sesi Keluar (Logout)',
        details: `${actor.name} (${actor.roleTitle || actor.role}) telah keluar dari sistem.`,
        severity: 'info',
      };
      setLogs((prev) => [logoutLog, ...prev]);
      saveDocument('activity_logs', logoutLog);
    }
    setIsAuthenticated(false);
    localStorage.removeItem('dtf_sublime_auth_active');
    localStorage.removeItem('dtf_sublime_auth_user_id');
    localStorage.removeItem('dtf_sublime_current_user');
  };

  // Fresh device initial cloud fetch loading screen (Prevents flash of dummy data on new device)
  const isFreshDevice = !localStorage.getItem('dtf_sublime_products');
  if (isFreshDevice && isCloudLoading) {
    return (
      <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-6 font-sans">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-xl shadow-cyan-500/20 mb-6 animate-pulse">
          <Database className="w-8 h-8" />
        </div>
        <div className="w-8 h-8 border-3 border-cyan-500/20 border-t-cyan-500 rounded-full animate-spin mb-4" />
        <h2 className="text-base sm:text-lg font-bold text-white text-center">
          Menghubungkan ke Cloud Database Gudang...
        </h2>
        <p className="text-xs text-slate-400 mt-2 text-center max-w-sm">
          Menyelaraskan data bahan baku, mutasi SPK produksi, dan invoice real-time antar perangkat.
        </p>
        <span className="mt-4 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-mono text-cyan-400">
          Firebase Firestore: ai-studio-dtfsublimegudang
        </span>
      </div>
    );
  }

  // Render Login Page if not authenticated
  if (!isAuthenticated) {
    return (
      <LoginView
        allUsers={users}
        onLogin={handleLogin}
        isCloudLoading={isCloudLoading}
      />
    );
  }

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-slate-950 text-slate-100 font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Real-time Multi-Device Notification Floating Toast */}
      {isAuthenticated && realtimeNotificationToast && (
        <div 
          className="fixed top-16 right-4 z-50 max-w-sm w-full bg-slate-900/95 backdrop-blur-md border border-cyan-500/50 rounded-2xl p-4 shadow-2xl shadow-cyan-950/60 animate-in slide-in-from-top-3 duration-300 transition-all cursor-pointer"
          onClick={() => {
            handleNavigateFromNotification(realtimeNotificationToast);
            setRealtimeNotificationToast(null);
          }}
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0 mt-0.5">
              <Bell className="w-4 h-4 animate-bounce" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">
                  Notifikasi Real-time
                </span>
                <span className="text-[10px] text-slate-400 font-mono">
                  {realtimeNotificationToast.timestamp.slice(11, 16)}
                </span>
              </div>
              <h4 className="text-xs font-bold text-white mt-0.5 truncate">
                {realtimeNotificationToast.title}
              </h4>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-2">
                {realtimeNotificationToast.message}
              </p>
            </div>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setRealtimeNotificationToast(null);
              }}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        allUsers={users}
        companyProfile={companyProfile}
        onOpenCompanyModal={() => setIsCompanyProfileModalOpen(true)}
        onSelectUser={handleSwitchUser}
        onLogout={handleLogout}
        onOpenBackupModal={() => setIsBackupModalOpen(true)}
        lowStockCount={criticalProductsCount}
        unpaidInvoicesCount={unpaidInvoices.length}
        overdueInvoicesCount={overdueInvoices.length}
        notifications={notifications}
        isCloudSyncing={isCloudLoading || cloudSyncStatus === 'syncing'}
        cloudSyncStatus={cloudSyncStatus}
        onManualSyncCloud={handleManualSyncCloud}
        lastSyncTime={lastSyncTime}
        onOpenNotifications={() => {}}
        onOpenMobileSimulator={() => setIsMobileSimulatorOpen(true)}
        onQuickLowStockClick={() => {
          setInitialFilterCritical(true);
          setActiveTab('inventory');
        }}
        onQuickInvoiceDueClick={() => {
          setActiveTab('analytics');
        }}
        onToggleSidebar={() => {
          if (typeof window !== 'undefined' && window.innerWidth < 1024) {
            setIsMobileSidebarOpen(!isMobileSidebarOpen);
          } else {
            setIsSidebarCollapsed(!isSidebarCollapsed);
          }
        }}
        isSidebarOpen={!isSidebarCollapsed}
        autoHideMode={sidebarAutoHide}
        onToggleAutoHide={() => setSidebarAutoHide(!sidebarAutoHide)}
        onMarkAsRead={handleMarkNotificationAsRead}
        onToggleRead={handleToggleNotificationRead}
        onMarkAllAsRead={handleMarkAllNotificationsAsRead}
        onDeleteNotification={handleDeleteNotification}
        onClearAllReadNotifications={handleClearAllReadNotifications}
        onNavigateFromNotification={handleNavigateFromNotification}
        onReloadActiveAlerts={handleReloadActiveAlerts}
        onTriggerTestPush={handleTriggerTestPushDirectly}
      />

      {/* Main Body with Sidebar & Content */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          currentUser={currentUser}
          companyProfile={companyProfile}
          onOpenCompanyModal={() => setIsCompanyProfileModalOpen(true)}
          onLogout={handleLogout}
          lowStockCount={criticalProductsCount}
          unpaidInvoicesCount={unpaidInvoices.length}
          overdueInvoicesCount={overdueInvoices.length}
          unpaidCustomersCount={unpaidCustomersCount}
          isMobileOpen={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
          autoHideMode={sidebarAutoHide}
          onToggleAutoHide={() => setSidebarAutoHide(!sidebarAutoHide)}
        />

        {/* Main Content View with Smooth Independent Scrolling */}
        <main className="flex-1 min-w-0 overflow-y-auto p-3 sm:p-5 lg:p-6 pb-24 md:pb-12">
          <div className="max-w-7xl mx-auto w-full space-y-6">
        {activeTab === 'inventory' && (
          <StockList
            products={products}
            currentUser={currentUser}
            categories={categories}
            units={units}
            locations={locations}
            suppliers={suppliers}
            customers={customers}
            invoices={invoices}
            movements={movements}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
            onAddUnit={handleAddUnit}
            onDeleteUnit={handleDeleteUnit}
            onAddLocation={handleAddLocation}
            onDeleteLocation={handleDeleteLocation}
            onAddSupplier={handleAddSupplier}
            onDeleteSupplier={handleDeleteSupplier}
            onAddCustomer={handleAddCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onUpdateCategory={handleUpdateCategory}
            onUpdateUnit={handleUpdateUnit}
            onUpdateLocation={handleUpdateLocation}
            onUpdateSupplier={handleUpdateSupplier}
            onUpdateCustomer={handleUpdateCustomer}
            divisions={divisions}
            onAddDivision={handleAddDivision}
            onDeleteDivision={handleDeleteDivision}
            onUpdateDivision={handleUpdateDivision}
            initialFilterCritical={initialFilterCritical}
            onOpenProductionModal={(prod) => {
              setSelectedProductForAction(prod || null);
              setActiveTab('production');
            }}
            onOpenRestockModal={(prod) => {
              setSelectedProductForAction(prod || null);
              setIsRestockModalOpen(true);
            }}
            onOpenSaleModal={(prod) => {
              setSelectedProductForAction(prod || null);
              setActiveTab('sales');
            }}
            onNavigateToPurchases={() => setActiveTab('purchases')}
            onNavigateToOpname={() => setActiveTab('opname')}
            onSaveProduct={handleSaveProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        )}

        {activeTab === 'purchases' && (
          <PurchasesView
            movements={movements}
            products={products}
            currentUser={currentUser}
            categories={categories}
            suppliers={suppliers}
            onOpenMasterData={(tab) => {
              setGlobalMasterDataTab(tab || 'supplier');
              setIsGlobalMasterDataModalOpen(true);
            }}
            onOpenRestockModal={() => {
              setSelectedProductForAction(null);
              setIsRestockModalOpen(true);
            }}
            onEditPurchase={handleEditPurchase}
            onDeletePurchase={handleDeletePurchase}
          />
        )}

        {activeTab === 'production' && (
          <ProductionView
            products={products}
            movements={movements}
            currentUser={currentUser}
            divisions={divisions}
            onOpenMasterData={(tab) => {
              setGlobalMasterDataTab(tab || 'division');
              setIsGlobalMasterDataModalOpen(true);
            }}
            selectedPreProduct={selectedProductForAction}
            onRecordProduction={handleRecordProduction}
            onUpdatePaymentStatus={handleUpdateProductionPaymentStatus}
            onEditProductionUsage={handleEditProductionUsage}
            onDeleteProductionUsage={handleDeleteProductionUsage}
          />
        )}

        {activeTab === 'sales' && (
          <SalesInvoiceView
            products={products}
            invoices={invoices}
            customers={customers}
            companyProfile={companyProfile}
            onAddCustomer={handleAddCustomer}
            onOpenMasterDataCustomer={() => {
              setGlobalMasterDataTab('customer');
              setIsGlobalMasterDataModalOpen(true);
            }}
            currentUser={currentUser}
            selectedPreProduct={selectedProductForAction}
            onCreateInvoice={handleCreateInvoice}
            onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
            onRecordPayment={handleRecordInvoicePayment}
            onDeletePayment={handleDeleteInvoicePayment}
            onEditInvoice={handleEditInvoice}
            onDeleteInvoice={handleDeleteInvoice}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            products={products}
            invoices={invoices}
            movements={movements}
            onOpenRestockModal={(prod) => {
              setSelectedProductForAction(prod || null);
              setIsRestockModalOpen(true);
            }}
            onNavigateToSales={() => setActiveTab('sales')}
            onUpdateInvoiceStatus={handleUpdateInvoiceStatus}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsView
            products={products}
            invoices={invoices}
            movements={movements}
            currentUser={currentUser}
            categories={categories}
            companyProfile={companyProfile}
          />
        )}

        {activeTab === 'logs' && (
          <ActivityLogsView
            logs={logs}
            currentUser={currentUser}
            onDeleteLog={handleDeleteLog}
            onClearAllLogs={handleClearAllLogs}
          />
        )}

        {activeTab === 'access' && (
          (currentUser.role === 'owner' || Boolean(currentUser.canManageAccessControl)) ? (
            <AccessControlView
              users={users}
              currentUser={currentUser}
              onUpdateUser={handleUpdateUser}
              onAddUser={handleAddUser}
              onDeleteUser={handleDeleteUser}
              onResetUsersToDefault={handleResetUsersToDefault}
              onSwitchUser={handleSwitchUser}
            />
          ) : (
            <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl max-w-lg mx-auto mt-12 text-slate-400">
              <ShieldAlert className="w-12 h-12 text-amber-400 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white mb-1">Akses Terbatas</h3>
              <p className="text-xs text-slate-400 mb-4">
                Halaman Manajemen Hak Akses & Pengguna hanya dapat diakses oleh Pemilik Usaha (Owner) atau akun dengan izin "Atur Hak Akses".
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('inventory')}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold cursor-pointer"
              >
                Kembali ke Data Stok
              </button>
            </div>
          )
        )}

        {activeTab === 'opname' && (
          <StockOpnameView
            products={products}
            movements={movements}
            categories={categories}
            currentUser={currentUser}
            onApplyOpname={handleApplyOpname}
            onOpenMasterData={() => {
              setGlobalMasterDataTab('category');
              setIsGlobalMasterDataModalOpen(true);
            }}
          />
        )}
          </div>
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (Sticky Thumb Navigation for Phones) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        onOpenMobileMenu={() => setIsMobileSidebarOpen(true)}
        lowStockCount={criticalProductsCount}
        unpaidInvoicesCount={unpaidInvoices.length}
        overdueInvoicesCount={overdueInvoices.length}
      />

      {/* Restock Modal */}
      <RestockModal
        key={selectedProductForAction ? `restock-${selectedProductForAction.id}` : 'restock-general'}
        isOpen={isRestockModalOpen}
        onClose={() => {
          setIsRestockModalOpen(false);
          setSelectedProductForAction(null);
        }}
        products={products}
        targetProduct={selectedProductForAction}
        currentUser={currentUser}
        suppliers={suppliers}
        onOpenMasterData={(tab) => {
          setGlobalMasterDataTab(tab || 'supplier');
          setIsGlobalMasterDataModalOpen(true);
        }}
        onConfirmRestock={handleConfirmRestock}
      />

      {/* Global Master Data Customization Modal */}
      {isGlobalMasterDataModalOpen && (
        <MasterDataModal
          isOpen={isGlobalMasterDataModalOpen}
          onClose={() => setIsGlobalMasterDataModalOpen(false)}
          categories={categories}
          units={units}
          locations={locations}
          suppliers={suppliers}
          customers={customers}
          products={products}
          invoices={invoices}
          movements={movements}
          onAddCategory={handleAddCategory}
          onDeleteCategory={handleDeleteCategory}
          onAddUnit={handleAddUnit}
          onDeleteUnit={handleDeleteUnit}
          onAddLocation={handleAddLocation}
          onDeleteLocation={handleDeleteLocation}
          onAddSupplier={handleAddSupplier}
          onDeleteSupplier={handleDeleteSupplier}
          onAddCustomer={handleAddCustomer}
          onDeleteCustomer={handleDeleteCustomer}
          onUpdateCategory={handleUpdateCategory}
          onUpdateUnit={handleUpdateUnit}
          onUpdateLocation={handleUpdateLocation}
          onUpdateSupplier={handleUpdateSupplier}
          onUpdateCustomer={handleUpdateCustomer}
          divisions={divisions}
          onAddDivision={handleAddDivision}
          onDeleteDivision={handleDeleteDivision}
          onUpdateDivision={handleUpdateDivision}
          initialTab={globalMasterDataTab}
        />
      )}

      {/* Smartphone Mockup Push Simulator */}
      <MobilePushSimulator
        isOpen={isMobileSimulatorOpen}
        onClose={() => setIsMobileSimulatorOpen(false)}
        notifications={notifications}
        onTriggerTestPush={handleTriggerTestPush}
      />

      {/* Backup & Periodic Checkpoint Modal */}
      <BackupCheckpointModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
        currentUser={currentUser}
        products={products}
        movements={movements}
        invoices={invoices}
        categories={categories}
        units={units}
        locations={locations}
        suppliers={suppliers}
        customers={customers}
        divisions={divisions}
        logs={logs}
        users={users}
        companyProfile={companyProfile}
        onRestoreCheckpoint={handleRestoreCheckpoint}
        onRestoreBackupFile={handleRestoreBackupFile}
        onClearOperationalData={handleClearOperationalData}
        onUploadLocalToCloud={handlePushLocalToCloud}
        cloudSyncStatus={cloudSyncStatus}
        lastSyncTime={lastSyncTime}
      />

      {/* Modal Pengaturan Identitas Perusahaan & Branding Aplikasi */}
      <CompanyProfileModal
        isOpen={isCompanyProfileModalOpen}
        onClose={() => setIsCompanyProfileModalOpen(false)}
        companyProfile={companyProfile}
        onSaveCompanyProfile={handleSaveCompanyProfile}
        onResetToDefault={handleResetCompanyProfileToDefault}
        currentUser={currentUser}
      />

      {/* Simple Footer */}
      <footer className="border-t border-slate-900 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>{companyProfile?.companyName ? `${companyProfile.companyName} • ${companyProfile.appName || 'DTF & Sublime'}` : 'Gudang Stok DTF & Sublime Pro • Terintegrasi Produksi, Penjualan & Invoice'}</span>
          <span className="font-mono text-[11px] text-slate-400">
            Peran Aktif: <strong className="text-cyan-400">{currentUser.roleTitle}</strong>
          </span>
        </div>
      </footer>
    </div>
  );
}
