export type ProductCategory = string;
export type ProductUnit = string;

export interface CategoryItem {
  id: string;
  name: string;
  prefix: string;
  icon?: string;
  description?: string;
}

export interface SupplierItem {
  id: string;
  name: string;
  phone?: string;
  address?: string;
  notes?: string;
}

export interface CustomerItem {
  id: string;
  name: string;
  phone: string;
  address?: string;
  notes?: string;
  createdAt?: string;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  category: ProductCategory;
  unit: ProductUnit;
  currentStock: number;
  minStockAlert: number;
  costPrice: number; // HPP / Harga Beli Modal
  sellingPrice: number; // Harga Jual Konsumen
  description: string;
  location: string; // Lokasi Rak/Gudang (e.g. Rak A-01, Rak B-02)
  lastUpdated: string;
}

export type UserRole = 'owner' | 'warehouse_admin' | 'cashier_sales' | 'production_staff' | 'custom';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  roleTitle: string; // Predikat / Jabatan identitas (e.g. "Pemilik Usaha (Owner)", "Supervisor Gudang (SPV)", dll.)
  email: string;
  password?: string; // Kata sandi plain text (non-hash) untuk autentikasi sistem
  avatarColor: string;
  // Hak Akses Granular (ditentukan lewat checklist dinamis):
  canViewFinancials: boolean; // Omset, Laba & Dasbor Analitik
  canManageProducts: boolean; // Tambah & Edit Bahan Baku
  canDeleteProducts?: boolean; // Hapus Bahan Baku dari Gudang (Aksi Delete)
  canRestock: boolean; // Tambah Stok Masuk / Pembelian Supplier
  canEditPurchases?: boolean; // Edit Catatan Mutasi Pembelian Bahan Baku
  canDeletePurchases?: boolean; // Hapus Catatan Mutasi Pembelian Bahan Baku (Revert Stok)
  canUseForProduction: boolean; // Catat Pakai Produksi Sablon (Internal / Divisi)
  canEditProductionUsage?: boolean; // Edit Catatan Pemakaian Produksi Sendiri
  canDeleteProductionUsage?: boolean; // Hapus Pemakaian Produksi Sendiri & Revert Stok Gudang
  canCreateSalesInvoice: boolean; // Jual Bahan ke Konsumen & Buat Faktur
  canEditSalesInvoice?: boolean; // Edit Data Faktur Penjualan (Konsumen, Harga, Qty)
  canDeleteSalesInvoice?: boolean; // Hapus Faktur Penjualan & Revert Stok Bahan Baku
  canManagePayments?: boolean; // Catat Cicilan & Pelunasan Piutang
  canManageMasterData?: boolean; // Kelola Master Data (Kategori, Satuan, Rak, Supplier, Konsumen, Divisi)
  canManageAccessControl?: boolean; // Kelola Pengguna & Pengaturan Hak Akses
  canManageCompanyProfile?: boolean; // Kelola Identitas Perusahaan & Branding Aplikasi (Kop Surat, Nota, Bank, Pejabat)
  canDeleteLogs: boolean; // Hapus Riwayat Log Aktivitas
  canExportReports?: boolean; // Ekspor Laporan Excel / CSV
  canStockOpname?: boolean; // Melakukan Stok Opname & Penyesuaian Fisik Gudang
}

export interface StockOpnameItem {
  productId: string;
  productCode: string;
  productName: string;
  category: ProductCategory;
  unit: ProductUnit;
  location: string;
  costPrice: number;
  systemStock: number;
  physicalStock: number;
  difference: number;
  totalVarianceValue: number;
  reasonCategory: 'Sesuai' | 'Rusak/Cacat' | 'Susut/Cutting' | 'Salah Catat' | 'Kadaluarsa' | 'Stok Terselip' | 'Lainnya';
  notes?: string;
}

export interface StockOpnameSession {
  id: string;
  date: string;
  referenceNo: string;
  auditedBy: {
    userId: string;
    userName: string;
    userRole: UserRole;
  };
  totalItems: number;
  matchedItems: number;
  discrepancyItems: number;
  totalVarianceValue: number;
  notes?: string;
  items: StockOpnameItem[];
}

export type StockMovementType = 'restock' | 'production' | 'sale' | 'adjustment';

export interface StockMovement {
  id: string;
  date: string;
  productId: string;
  productName: string;
  productCode: string;
  category: ProductCategory;
  type: StockMovementType;
  quantity: number;
  unit: ProductUnit;
  previousStock: number;
  finalStock: number;
  referenceNo: string; // e.g., SPK-PRD-014 atau INV-2026-003 atau PO-MSK-02
  notes: string;
  performedBy: {
    userId: string;
    userName: string;
    userRole: UserRole;
    userRoleTitle?: string;
  };
  totalValue?: number; // Total nilai transaksi (jual / beli)
  supplierName?: string; // Nama supplier untuk mutasi pembelian / restok
  unitPrice?: number; // Harga satuan beli (HPP) atau jual
  recipientName?: string; // Petugas yang mengambil / menerima bahan (PIC Produksi / Pengambil)
  divisionOrRequester?: string; // Nama Pemesan / Divisi Pemohon
  // Fitur Tagihan & Pembayaran Pemakaian Divisi
  billingRequired?: boolean; // Apakah pemakaian bahan oleh divisi ini wajib ditagih/dibayar
  paymentStatus?: 'lunas' | 'belum_lunas' | 'beban_internal'; // Status tagihan: Lunas, Belum Lunas, atau Beban Internal
  paymentMethod?: string; // Metode pembayaran misal 'Kas Internal / Tunai', 'Transfer Bank', 'Giro Divisi', 'Potong Anggaran Divisi'
  paidAmount?: number; // Nominal yang sudah dibayar oleh divisi
  billingDueDate?: string; // Tanggal jatuh tempo pelunasan tagihan divisi (YYYY-MM-DD)
  paidAt?: string; // Waktu pelunasan tagihan
}

export interface InvoiceItem {
  productId: string;
  productCode: string;
  productName: string;
  unit: ProductUnit;
  quantity: number;
  unitPrice: number;
  costPrice: number;
  discount: number; // nominal diskon per item
  subtotal: number;
}

export interface PaymentRecord {
  id: string;
  date: string;
  amount: number;
  paymentMethod: 'Tunai' | 'Transfer Bank' | 'QRIS' | string;
  referenceNumber?: string;
  notes?: string;
  receivedBy?: {
    userId: string;
    userName: string;
    userRole?: UserRole;
    userRoleTitle?: string;
  };
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  customerName: string;
  customerPhone: string;
  customerAddress?: string;
  items: InvoiceItem[];
  subtotal: number;
  discountTotal: number;
  taxPercent: number;
  taxAmount: number;
  grandTotal: number;
  paidAmount: number;
  paymentStatus: 'lunas' | 'belum_lunas' | 'dp';
  paymentMethod: 'Tunai' | 'Transfer Bank' | 'QRIS' | string;
  notes?: string;
  paymentHistory?: PaymentRecord[];
  createdBy: {
    userId: string;
    userName: string;
    userRole: UserRole;
    userRoleTitle?: string;
  };
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  userRoleTitle?: string;
  actionType:
    | 'RESTOCK_IN'
    | 'PRODUCTION_USE'
    | 'SALES_INVOICE'
    | 'STOCK_ADJUSTMENT'
    | 'PRODUCT_ADDED'
    | 'PRODUCT_UPDATED'
    | 'ROLE_SWITCHED'
    | 'SETTINGS_UPDATE'
    | 'USER_CREATED'
    | 'USER_DELETED'
    | 'USER_LOGIN'
    | 'USER_LOGOUT'
    | 'CHECKPOINT_CREATED'
    | 'CHECKPOINT_RESTORED'
    | 'BACKUP_DOWNLOADED'
    | 'BACKUP_RESTORED';
  title: string;
  details: string;
  severity: 'info' | 'success' | 'warning' | 'critical';
}

export interface SystemCheckpoint {
  id: string;
  timestamp: string; // ISO string
  formattedTime: string;
  type: 'auto' | 'manual';
  label: string;
  creatorName: string;
  creatorRole: string;
  summary: {
    productsCount: number;
    movementsCount: number;
    movementsBreakdown?: {
      restockCount: number;
      productionCount: number;
      saleCount: number;
      adjustmentCount: number;
    };
    invoicesCount: number;
    logsCount?: number;
    totalStockValue: number;
  };
  snapshot: {
    products: Product[];
    movements: StockMovement[];
    invoices: Invoice[];
    categories: CategoryItem[];
    units: string[];
    locations: string[];
    suppliers: SupplierItem[];
    customers: CustomerItem[];
    divisions: string[];
    logs?: ActivityLog[];
    users?: User[];
    companyProfile?: CompanyProfile;
  };
}

export interface BackupFileData {
  appName: string;
  appVersion: string;
  backupDate: string;
  exportedBy: string;
  exportedRole: string;
  summary: {
    productsCount: number;
    movementsCount: number;
    movementsBreakdown?: {
      restockCount: number;
      productionCount: number;
      saleCount: number;
      adjustmentCount: number;
    };
    invoicesCount: number;
    logsCount: number;
    totalStockValue: number;
  };
  data: {
    products: Product[];
    movements: StockMovement[];
    invoices: Invoice[];
    categories: CategoryItem[];
    units: string[];
    locations: string[];
    suppliers: SupplierItem[];
    customers: CustomerItem[];
    divisions: string[];
    logs?: ActivityLog[];
    users?: User[];
    companyProfile?: CompanyProfile;
  };
}

export interface BankAccountItem {
  id: string;
  bankName: string;
  accountNumber: string;
  holderName: string;
  isPrimary?: boolean;
  notes?: string;
}

export interface CompanyProfile {
  companyName: string;
  shortName: string;
  tagline: string;
  address: string;
  city: string;
  phone: string;
  email: string;
  website?: string;
  
  // Rekening Bank Pembayaran (Mendukung multi rekening > 2 rekening)
  bankAccounts?: BankAccountItem[];

  // Fallback single bank fields for full backward compatibility
  bankName: string;
  bankAccountNo: string;
  bankAccountHolder: string;
  invoiceNotes: string;
  invoiceFooterNotice: string;

  // Tanda Tangan & Pejabat Laporan
  signerTitle1: string;
  signerSub1: string;
  signerTitle2: string;
  signerSub2: string;
  signerTitle3: string;
  signerSub3: string;

  // Identitas & Tampilan Aplikasi
  appName: string;
  appSubtitle: string;
  appVersion: string;
  appLogoBadge: string;
  logoUrl?: string; // Data URL Base64 atau URL gambar logo resmi perusahaan untuk kop nota & invoice
}

export interface PushNotification {
  id: string;
  timestamp: string;
  title: string;
  message: string;
  type: 'stock_warning' | 'sale_alert' | 'production_alert' | 'restock' | 'invoice_due' | 'system';
  read: boolean;
  meta?: {
    productName?: string;
    currentStock?: number;
    referenceNo?: string;
    amount?: number;
    invoiceId?: string;
    customerName?: string;
    dueDate?: string;
    unpaidAmount?: number;
    userId?: string;
  };
}
