import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDoc,
  getDocs, 
  onSnapshot, 
  writeBatch,
  Unsubscribe 
} from 'firebase/firestore';
import { 
  db, 
  auth, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { 
  Product, 
  StockMovement, 
  Invoice, 
  ActivityLog, 
  CategoryItem, 
  SupplierItem, 
  CustomerItem, 
  User, 
  CompanyProfile,
  StockOpnameSession,
  PushNotification 
} from '../types';

// Anti Data Ganda: Helper universal untuk menyaring data ganda berdasarkan Primary Key id
export function deduplicateById<T extends { id: string }>(items: T[]): T[] {
  if (!Array.isArray(items)) return [];
  const map = new Map<string, T>();
  for (const item of items) {
    if (item && item.id) {
      map.set(item.id, item);
    }
  }
  return Array.from(map.values());
}

// Generic helper to save or update document
export async function saveDocument<T extends { id: string }>(
  collectionName: string, 
  item: T
): Promise<void> {
  const path = `${collectionName}/${item.id}`;
  try {
    const docRef = doc(db, collectionName, item.id);
    await setDoc(docRef, JSON.parse(JSON.stringify(item)), { merge: true });
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.WRITE, path);
    } catch (e) {
      console.warn(`Firestore save notice for [${path}]:`, e);
    }
  }
}

// Batch save multiple documents (dengan proteksi Anti Data Ganda agar ID tidak ganda dalam batch)
export async function batchSaveDocuments<T extends { id: string }>(
  collectionName: string,
  items: T[]
): Promise<void> {
  const cleanItems = deduplicateById(items);
  if (!cleanItems || cleanItems.length === 0) return;
  try {
    // Firestore writeBatch has a limit of 500 ops per batch
    const chunkSize = 400;
    for (let i = 0; i < cleanItems.length; i += chunkSize) {
      const chunk = cleanItems.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      for (const item of chunk) {
        const docRef = doc(db, collectionName, item.id);
        batch.set(docRef, JSON.parse(JSON.stringify(item)), { merge: true });
      }
      await batch.commit();
    }
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.WRITE, collectionName);
    } catch (e) {
      console.warn(`Firestore batch save error [${collectionName}]:`, e);
    }
  }
}

// Generic helper to delete document
export async function removeDocument(collectionName: string, id: string): Promise<void> {
  const path = `${collectionName}/${id}`;
  try {
    const docRef = doc(db, collectionName, id);
    await deleteDoc(docRef);
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.DELETE, path);
    } catch (e) {
      console.warn(`Firestore delete notice for [${path}]:`, e);
    }
  }
}

// Batch remove multiple documents
export async function batchRemoveDocuments(
  collectionName: string,
  ids: string[]
): Promise<void> {
  if (!ids || ids.length === 0) return;
  try {
    // Firestore writeBatch has a limit of 500 ops per batch
    const chunkSize = 400;
    for (let i = 0; i < ids.length; i += chunkSize) {
      const chunk = ids.slice(i, i + chunkSize);
      const batch = writeBatch(db);
      for (const id of chunk) {
        batch.delete(doc(db, collectionName, id));
      }
      await batch.commit();
    }
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.DELETE, collectionName);
    } catch (e) {
      console.warn(`Firestore batch delete error [${collectionName}]:`, e);
    }
  }
}

// Atomically replaces an entire collection in Firestore with the provided items.
// Any existing document not present in newItems will be DELETED.
// If newItems is empty, all documents in the collection are removed.
export async function replaceCollectionInFirestore<T extends { id: string }>(
  collectionName: string,
  newItems: T[]
): Promise<void> {
  try {
    // Anti Data Ganda: Saring duplikat ID sebelum diproses ke cloud
    const cleanItems = deduplicateById(newItems);
    const currentSnap = await getDocs(collection(db, collectionName));
    const currentIds = new Set<string>();
    currentSnap.forEach((d) => currentIds.add(d.id));

    const newIds = new Set(cleanItems.map((item) => item.id));

    // Delete documents that are NOT in the incoming dataset
    const idsToDelete = Array.from(currentIds).filter((id) => !newIds.has(id));
    if (idsToDelete.length > 0) {
      await batchRemoveDocuments(collectionName, idsToDelete);
    }

    // Save/update items tanpa ada duplikasi
    if (cleanItems.length > 0) {
      await batchSaveDocuments(collectionName, cleanItems);
    }

    // Ensure system is marked as initialized so empty collections aren't auto-reseeded
    await setDoc(doc(db, 'settings', 'system_init'), {
      id: 'system_init',
      initialized: true,
      lastUpdated: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    console.warn(`replaceCollectionInFirestore error for [${collectionName}]:`, error);
  }
}

// Completely clear operational data (products, movements, invoices, logs, opnames)
export async function clearOperationalCloudData(): Promise<void> {
  try {
    await Promise.all([
      replaceCollectionInFirestore('products', []),
      replaceCollectionInFirestore('movements', []),
      replaceCollectionInFirestore('invoices', []),
      replaceCollectionInFirestore('activity_logs', []),
      replaceCollectionInFirestore('stock_opnames', []),
      replaceCollectionInFirestore('notifications', []),
    ]);
  } catch (error) {
    console.warn('clearOperationalCloudData error:', error);
  }
}

// Fetch collection once (force pull)
export async function fetchCollectionOnce<T extends { id: string }>(
  collectionName: string
): Promise<T[]> {
  try {
    const snap = await getDocs(collection(db, collectionName));
    const items: T[] = [];
    snap.forEach((docSnap) => {
      items.push({ ...docSnap.data(), id: docSnap.id } as T);
    });
    return items;
  } catch (error) {
    console.warn(`Firestore fetchCollectionOnce error [${collectionName}]:`, error);
    return [];
  }
}

// Save system setting (e.g. company_profile, master_lists)
export async function saveSetting(settingKey: string, data: any): Promise<void> {
  const path = `settings/${settingKey}`;
  try {
    const docRef = doc(db, 'settings', settingKey);
    await setDoc(docRef, { id: settingKey, data: JSON.parse(JSON.stringify(data)), updatedAt: new Date().toISOString() }, { merge: true });
  } catch (error) {
    try {
      handleFirestoreError(error, OperationType.WRITE, path);
    } catch (e) {
      console.warn(`Firestore setting save notice for [${path}]:`, e);
    }
  }
}

// Initial Seeding to Firestore with system_init guard so user-emptied databases are NEVER re-seeded
export async function seedInitialFirestoreData(initialData: {
  products: Product[];
  categories: CategoryItem[];
  suppliers: SupplierItem[];
  customers: CustomerItem[];
  users: User[];
  companyProfile: CompanyProfile;
  units: string[];
  locations: string[];
  divisions: string[];
  movements?: StockMovement[];
  invoices?: Invoice[];
  activityLogs?: ActivityLog[];
  notifications?: PushNotification[];
}): Promise<boolean> {
  try {
    // 1. Check system_init flag. If already initialized, DO NOT SEED!
    const initRef = doc(db, 'settings', 'system_init');
    const initDocSnap = await getDoc(initRef);
    if (initDocSnap.exists() && initDocSnap.data()?.initialized) {
      return false;
    }

    // 2. Check if products or users already exist in cloud
    const productsSnap = await getDocs(collection(db, 'products'));
    const usersSnap = await getDocs(collection(db, 'users'));
    if (!productsSnap.empty || !usersSnap.empty) {
      // Mark as initialized so we don't re-seed
      await setDoc(initRef, { id: 'system_init', initialized: true, initializedAt: new Date().toISOString() });
      return false;
    }

    console.log('Database brand new. Seeding initial dataset to Firestore...');
    let anySeeded = false;

    // 1. Products
    if (initialData.products.length > 0) {
      await batchSaveDocuments('products', initialData.products);
      anySeeded = true;
    }

    // 2. Categories
    const catSnap = await getDocs(collection(db, 'categories'));
    if (catSnap.empty && initialData.categories.length > 0) {
      await batchSaveDocuments('categories', initialData.categories);
      anySeeded = true;
    }

    // 3. Suppliers
    const supSnap = await getDocs(collection(db, 'suppliers'));
    if (supSnap.empty && initialData.suppliers.length > 0) {
      await batchSaveDocuments('suppliers', initialData.suppliers);
      anySeeded = true;
    }

    // 4. Customers
    const custSnap = await getDocs(collection(db, 'customers'));
    if (custSnap.empty && initialData.customers.length > 0) {
      await batchSaveDocuments('customers', initialData.customers);
      anySeeded = true;
    }

    // 5. Users
    const userSnap = await getDocs(collection(db, 'users'));
    if (userSnap.empty && initialData.users.length > 0) {
      await batchSaveDocuments('users', initialData.users);
      anySeeded = true;
    }

    // 6. Settings
    const settingCompanySnap = await getDocs(collection(db, 'settings'));
    if (settingCompanySnap.empty) {
      const batch = writeBatch(db);
      batch.set(doc(db, 'settings', 'company_profile'), {
        id: 'company_profile',
        data: JSON.parse(JSON.stringify(initialData.companyProfile)),
        updatedAt: new Date().toISOString()
      });
      batch.set(doc(db, 'settings', 'master_lists'), {
        id: 'master_lists',
        data: {
          units: initialData.units,
          locations: initialData.locations,
          divisions: initialData.divisions
        },
        updatedAt: new Date().toISOString()
      });
      await batch.commit();
      anySeeded = true;
    }

    // 7. Movements (only seed if both products and movements were empty initially)
    if (initialData.movements && initialData.movements.length > 0) {
      const movSnap = await getDocs(collection(db, 'movements'));
      if (movSnap.empty) {
        await batchSaveDocuments('movements', initialData.movements);
        anySeeded = true;
      }
    }

    // 8. Invoices (only seed if empty)
    if (initialData.invoices && initialData.invoices.length > 0) {
      const invSnap = await getDocs(collection(db, 'invoices'));
      if (invSnap.empty) {
        await batchSaveDocuments('invoices', initialData.invoices);
        anySeeded = true;
      }
    }

    // 9. Notifications (only seed if empty)
    if (initialData.notifications && initialData.notifications.length > 0) {
      const notifSnap = await getDocs(collection(db, 'notifications'));
      if (notifSnap.empty) {
        await batchSaveDocuments('notifications', initialData.notifications);
        anySeeded = true;
      }
    }

    return anySeeded;
  } catch (error) {
    console.warn('Seeding initial data notice (cloud may already be active):', error);
    return false;
  }
}

// Real-time collection listener (dengan Anti Data Ganda via itemsMap)
export function subscribeToCollection<T extends { id: string }>(
  collectionName: string,
  onUpdate: (items: T[]) => void,
  onError?: (err: any) => void
): Unsubscribe {
  const colRef = collection(db, collectionName);
  return onSnapshot(
    colRef,
    (snapshot) => {
      // Anti Data Ganda: gunakan Map keyed by ID agar setiap dokumen dipastikan unik
      const itemsMap = new Map<string, T>();
      snapshot.forEach((docSnap) => {
        itemsMap.set(docSnap.id, { ...docSnap.data(), id: docSnap.id } as T);
      });
      onUpdate(Array.from(itemsMap.values()));
    },
    (error) => {
      console.warn(`Firestore collection subscription notice [${collectionName}]:`, error);
      if (error && error.message && error.message.toLowerCase().includes('permission')) {
        try {
          handleFirestoreError(error, OperationType.GET, collectionName);
        } catch {}
      }
      if (onError) {
        onError(error);
      }
    }
  );
}

// Setting document listener
export function subscribeToSetting(
  settingKey: string,
  onUpdate: (data: any) => void,
  onError?: (err: any) => void
): Unsubscribe {
  const docRef = doc(db, 'settings', settingKey);
  return onSnapshot(
    docRef,
    (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.data();
        if (val && val.data) {
          onUpdate(val.data);
        }
      }
    },
    (error) => {
      console.warn(`Firestore setting subscription notice [${settingKey}]:`, error);
      if (onError) {
        onError(error);
      }
    }
  );
}
