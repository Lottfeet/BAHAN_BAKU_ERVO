import React, { useState, useRef, useEffect } from 'react';
import {
  Boxes,
  ShoppingBag,
  Layers,
  FileText,
  BarChart3,
  FileSpreadsheet,
  History,
  X,
  Sparkles,
  LogOut,
  ShieldCheck,
  ClipboardCheck,
  Building2,
  CreditCard,
  Sun,
  Moon
} from 'lucide-react';
import { User, CompanyProfile } from '../types';
import { useTheme } from '../context/ThemeContext';

export interface SidebarProps {
  activeTab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname';
  setActiveTab: (tab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname') => void;
  currentUser: User;
  companyProfile?: CompanyProfile;
  onOpenCompanyModal?: () => void;
  onLogout?: () => void;
  lowStockCount: number;
  unpaidInvoicesCount?: number;
  overdueInvoicesCount?: number;
  unpaidCustomersCount?: number;
  isMobileOpen: boolean;
  onCloseMobile: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  autoHideMode: boolean;
  onToggleAutoHide: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  companyProfile,
  onOpenCompanyModal,
  onLogout,
  lowStockCount,
  unpaidInvoicesCount = 0,
  overdueInvoicesCount = 0,
  unpaidCustomersCount = 0,
  isMobileOpen,
  onCloseMobile,
  isCollapsed,
  onToggleCollapse,
  autoHideMode,
  onToggleAutoHide,
}) => {
  const { theme, toggleTheme, isDark } = useTheme();
  const [isHovered, setIsHovered] = useState(false);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
    if (autoHideMode || isCollapsed) {
      setIsHovered(true);
    }
  };

  const handleMouseLeave = () => {
    if (autoHideMode || isCollapsed) {
      hoverTimeoutRef.current = setTimeout(() => {
        setIsHovered(false);
      }, 200);
    }
  };

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
    };
  }, []);

  // Visual expansion state on desktop
  const isVisuallyExpanded = autoHideMode 
    ? isHovered 
    : isCollapsed 
    ? isHovered 
    : true;

  interface NavItem {
    id: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname';
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    allowed?: boolean;
    badge?: number | string | null;
    badgeColor?: string;
  }

  const navItems: NavItem[] = [
    {
      id: 'analytics',
      label: 'Dasbor Analitik',
      description: 'Grafik omset, profit & piutang',
      icon: BarChart3,
      badge: overdueInvoicesCount > 0 ? overdueInvoicesCount : null,
      badgeColor: 'bg-rose-500 text-white animate-pulse',
      allowed: currentUser.canViewFinancials,
    },
    {
      id: 'inventory',
      label: 'Stok Bahan',
      description: 'Inventaris & stok minimum',
      icon: Boxes,
      badge: lowStockCount > 0 ? lowStockCount : null,
      badgeColor: 'bg-rose-500 text-white',
      allowed: true,
    },
    {
      id: 'sales',
      label: 'Penjualan & Invoice',
      description: 'Kasir POS & faktur tempo',
      icon: FileText,
      allowed: currentUser.canCreateSalesInvoice || currentUser.canViewFinancials,
    },
    {
      id: 'production',
      label: 'Pakai Produksi',
      description: 'Pemakaian sablon sendiri',
      icon: Layers,
      allowed: currentUser.canUseForProduction,
    },
    {
      id: 'purchases',
      label: 'Pembelian Bahan',
      description: 'Restock masuk & supplier',
      icon: ShoppingBag,
      allowed: true,
    },
    {
      id: 'opname',
      label: 'Stok Opname',
      description: 'Audit fisik & rekonsiliasi',
      icon: ClipboardCheck,
      allowed: currentUser.canStockOpname ?? true,
    },
    {
      id: 'reports',
      label: 'Laporan Stok',
      description: 'Rekap mutasi & ekspor data',
      icon: FileSpreadsheet,
      allowed: true,
    },
    {
      id: 'logs',
      label: 'Log Aktivitas',
      description: 'Riwayat audit operator',
      icon: History,
      allowed: true,
    },
    {
      id: 'access',
      label: 'Hak Akses & Pengguna',
      description: 'Checklist izin & kelola peran',
      icon: ShieldCheck,
      allowed: currentUser.role === 'owner' || Boolean(currentUser.canManageAccessControl),
    },
  ];

  const handleItemClick = (id: NavItem['id']) => {
    setActiveTab(id);
    onCloseMobile();
    if (autoHideMode) {
      setIsHovered(false);
    }
  };

  return (
    <>
      {/* ================= MOBILE DRAWER OVERLAY & ASIDE ================= */}
      {isMobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs lg:hidden transition-opacity"
        />
      )}

      <aside
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 border-r border-slate-800 text-slate-100 flex flex-col shadow-2xl transition-transform duration-300 ease-in-out lg:hidden ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Mobile Drawer Header */}
        <div className="h-16 px-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-500 via-indigo-500 to-rose-500 p-0.5 shadow-sm flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[6px] flex items-center justify-center overflow-hidden">
                {companyProfile?.logoUrl ? (
                  <img
                    src={companyProfile.logoUrl}
                    alt={companyProfile.appName || 'Logo'}
                    className="w-full h-full object-contain p-0.5 bg-white/10"
                  />
                ) : (
                  <Boxes className="w-4 h-4 text-cyan-400" />
                )}
              </div>
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-white block truncate max-w-[150px]">
                {companyProfile?.appName || 'Menu Gudang'}
              </span>
              <span className="text-[10px] text-cyan-400 font-medium truncate block max-w-[150px]">
                {companyProfile?.shortName ? `Gudang ${companyProfile.shortName}` : 'Navigasi Fitur'}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            className="p-2 text-slate-400 hover:text-white rounded-lg bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile Items List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
          {navItems.map((item) => {
            const isAllowed = item.allowed !== false;
            if (!isAllowed) return null;
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl transition-all text-left ${
                  isActive
                    ? 'bg-cyan-600 text-white font-semibold shadow-md shadow-cyan-950/50'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80 font-medium'
                }`}
              >
                <div className="relative shrink-0">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  {item.badge && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-slate-900 animate-pulse" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-sm truncate">{item.label}</span>
                    {item.badge && (
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${item.badgeColor}`}>
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <p className={`text-[11px] truncate mt-0.5 ${isActive ? 'text-cyan-100' : 'text-slate-400'}`}>
                    {item.description}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Mobile Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center justify-between gap-2.5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className={`w-8 h-8 rounded-lg ${currentUser.avatarColor} text-white flex items-center justify-center text-xs font-bold shrink-0`}>
                {currentUser.name.charAt(0)}
              </div>
              <div className="min-w-0 flex-1 leading-tight">
                <p className="text-xs font-semibold text-white truncate">{currentUser.name}</p>
                <p className="text-[10px] text-slate-400 truncate">{currentUser.roleTitle}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold shrink-0 cursor-pointer shadow-xs"
              title={isDark ? 'Beralih ke Mode Terang' : 'Beralih ke Mode Gelap'}
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-cyan-400" />}
            </button>
          </div>
        </div>
      </aside>

      {/* ================= DESKTOP DOCKED SIDEBAR ================= */}
      <div
        className={`hidden lg:block shrink-0 transition-all duration-300 ease-in-out relative h-full select-none ${
          autoHideMode || isCollapsed ? 'w-16' : 'w-60'
        }`}
      >
        <aside
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          className={`h-full bg-slate-900 border-r border-slate-800 text-slate-100 flex flex-col transition-all duration-300 ease-in-out ${
            isVisuallyExpanded
              ? autoHideMode || isCollapsed
                ? 'w-60 absolute top-0 bottom-0 left-0 z-30 shadow-2xl bg-slate-900/98 backdrop-blur-md'
                : 'w-60 relative'
              : 'w-16 relative'
          }`}
        >
          {/* Navigation Items List */}
          <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1.5 scrollbar-thin scrollbar-thumb-slate-800">
            {navItems.map((item) => {
              const isAllowed = item.allowed !== false;
              if (!isAllowed) return null;
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  id={`sidebar-item-${item.id}`}
                  onClick={() => handleItemClick(item.id)}
                  title={!isVisuallyExpanded ? item.label : undefined}
                  className={`w-full group relative flex items-center rounded-xl transition-all ${
                    isVisuallyExpanded ? 'px-2.5 py-2 gap-2.5' : 'p-2.5 justify-center'
                  } ${
                    isActive
                      ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950/50 font-semibold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/70 font-medium'
                  }`}
                >
                  {/* Left indicator bar when collapsed & active */}
                  {isActive && !isVisuallyExpanded && (
                    <span className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-cyan-400 rounded-r-full shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                  )}

                  <div className="relative shrink-0 flex items-center justify-center">
                    <Icon
                      className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                        isActive ? 'text-white' : 'text-slate-400 group-hover:text-cyan-400'
                      }`}
                    />
                    {!isVisuallyExpanded && item.badge && (
                      <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-slate-900 animate-pulse" />
                    )}
                  </div>

                  {/* Expanded Labels */}
                  {isVisuallyExpanded && (
                    <div className="flex-1 text-left min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs truncate">{item.label}</span>
                        {item.badge && (
                          <span
                            className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full shrink-0 ${item.badgeColor}`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <p
                        className={`text-[10px] truncate ${
                          isActive ? 'text-cyan-100' : 'text-slate-400'
                        }`}
                      >
                        {item.description}
                      </p>
                    </div>
                  )}

                  {/* Hover tooltip when slim */}
                  {!isVisuallyExpanded && (
                    <div className="hidden lg:group-hover:flex absolute left-full ml-2 px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs font-semibold text-white whitespace-nowrap shadow-xl z-50 items-center gap-1.5 pointer-events-none">
                      <span>{item.label}</span>
                      {item.badge && (
                        <span className={`px-1.5 py-0.2 text-[9px] font-bold rounded-full ${item.badgeColor}`}>
                          {item.badge}
                        </span>
                      )}
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* Desktop Footer inside Sidebar */}
          <div className="p-2 border-t border-slate-800/80 shrink-0 bg-slate-950/40 space-y-2">
            {onLogout && isVisuallyExpanded && (
              <button
                type="button"
                onClick={onLogout}
                className="w-full flex items-center justify-between px-2 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-500/15 text-slate-400 hover:text-rose-300 border border-slate-800 transition-colors text-xs cursor-pointer group"
                title="Keluar dari sesi akun saat ini"
              >
                <div className="flex items-center gap-2 truncate">
                  <div className={`w-5 h-5 rounded-md ${currentUser.avatarColor} text-white flex items-center justify-center text-[10px] font-bold shrink-0 shadow-xs`}>
                    {currentUser.name.charAt(0)}
                  </div>
                  <span className="truncate font-medium text-slate-300 group-hover:text-rose-200">{currentUser.name}</span>
                </div>
                <LogOut className="w-3.5 h-3.5 shrink-0 text-slate-500 group-hover:text-rose-400" />
              </button>
            )}

            {onLogout && !isVisuallyExpanded && (
              <div className="flex flex-col items-center gap-1.5">
                <button
                  type="button"
                  onClick={toggleTheme}
                  title={isDark ? 'Mode Terang' : 'Mode Gelap'}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 flex items-center justify-center transition-colors cursor-pointer"
                >
                  {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
                <button
                  type="button"
                  onClick={onLogout}
                  title={`Keluar / Logout (${currentUser.name})`}
                  className="w-7 h-7 rounded-lg bg-slate-900 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 border border-slate-800 flex items-center justify-center transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {isVisuallyExpanded && (
              <div className="space-y-1">
                {/* Theme Mode Toggle Button */}
                <button
                  type="button"
                  onClick={toggleTheme}
                  className="w-full flex items-center justify-between px-2 py-1 rounded-lg text-left text-[11px] text-slate-400 hover:text-cyan-300 hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
                  title={isDark ? 'Beralih ke Mode Terang' : 'Beralih ke Mode Gelap'}
                >
                  <span className="flex items-center gap-1.5 truncate">
                    {isDark ? <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" /> : <Moon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                    <span className="truncate">Tema: {isDark ? 'Gelap' : 'Terang'}</span>
                  </span>
                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-medium">
                    {isDark ? 'Terang' : 'Gelap'}
                  </span>
                </button>
                {(currentUser.role === 'owner' || Boolean(currentUser.canManageCompanyProfile) || Boolean(currentUser.canManageAccessControl)) && onOpenCompanyModal && (
                  <button
                    type="button"
                    onClick={onOpenCompanyModal}
                    className="w-full flex items-center justify-between px-2 py-1 rounded-lg text-left text-[11px] text-slate-400 hover:text-cyan-300 hover:bg-slate-900 border border-transparent hover:border-slate-800 transition-colors cursor-pointer"
                    title="Buka Pengaturan Identitas Perusahaan & Aplikasi"
                  >
                    <span className="flex items-center gap-1.5 truncate">
                      <Building2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">Profil Perusahaan</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">&rarr;</span>
                  </button>
                )}
                <div className="flex items-center justify-between text-[10px] text-slate-400 px-1 pt-0.5 border-t border-slate-900">
                  <span className="flex items-center gap-1 font-medium truncate max-w-[130px]">
                    <Sparkles className="w-3 h-3 text-cyan-400 shrink-0" />
                    <span className="truncate">{companyProfile?.appName || 'DTF & Sublime'}</span>
                  </span>
                  <span className="text-[9px] px-1 py-0.5 rounded bg-slate-800 text-slate-400 font-mono shrink-0">
                    {companyProfile?.appVersion || 'v2.5 Pro'}
                  </span>
                </div>
              </div>
            )}
          </div>
        </aside>
      </div>
    </>
  );
};
