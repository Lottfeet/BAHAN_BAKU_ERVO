import React, { useState, useMemo } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Printer, 
  Calendar, 
  Filter, 
  TrendingDown, 
  TrendingUp, 
  Layers, 
  ShoppingCart,
  Boxes,
  CheckCircle2,
  FileDown,
  Loader2,
  Eye,
  X,
  ShieldCheck,
  Package,
  Clock,
  Sparkles,
  SlidersHorizontal,
  LayoutGrid,
  FileText,
  Check,
  Building2,
  UserCheck,
  ChevronDown,
  ChevronUp,
  AlertCircle
} from 'lucide-react';
import { Product, Invoice, StockMovement, User, CategoryItem, CompanyProfile } from '../types';
import { formatRupiah, exportToCSV, formatDateIndo } from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';

interface ReportsViewProps {
  products: Product[];
  invoices: Invoice[];
  movements: StockMovement[];
  currentUser: User;
  categories?: CategoryItem[];
  companyProfile?: CompanyProfile;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  products,
  invoices,
  movements,
  currentUser,
  categories,
  companyProfile,
}) => {
  const [filterPeriod, setFilterPeriod] = useState<'today' | '7days' | 'month' | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isSavingPdf, setIsSavingPdf] = useState(false);
  const [showPdfModal, setShowPdfModal] = useState(false);
  const [pdfSuccessMessage, setPdfSuccessMessage] = useState<string | null>(null);

  // Harmonized PDF Export Customization States
  const [pdfOrientation, setPdfOrientation] = useState<'landscape' | 'portrait'>('landscape');
  const [includeInitialStock, setIncludeInitialStock] = useState<boolean>(true);
  const [includeDailySales, setIncludeDailySales] = useState<boolean>(true);
  const [includeSignatures, setIncludeSignatures] = useState<boolean>(true);
  const [includeFinancials, setIncludeFinancials] = useState<boolean>(Boolean(currentUser.canViewFinancials));
  const [includeDocHeader, setIncludeDocHeader] = useState<boolean>(true);
  const [auditDocStatus, setAuditDocStatus] = useState<string>('Tervalidasi Resmi');
  const [reportNote, setReportNote] = useState<string>('Data mutasi dan saldo fisik stok telah diverifikasi secara sistematis sesuai rekonsiliasi transaksi operasional gudang.');
  const [showConfigPanel, setShowConfigPanel] = useState<boolean>(false);

  // Period label
  const periodLabel = useMemo(() => {
    switch (filterPeriod) {
      case 'today': return 'Hari Ini';
      case '7days': return '7 Hari Terakhir';
      case 'month': return '30 Hari Terakhir';
      default: return 'Semua Periode Transaksi';
    }
  }, [filterPeriod]);

  // Category label
  const categoryLabel = useMemo(() => {
    if (selectedCategory === 'all') return 'Seluruh Kategori Bahan';
    const match = categories?.find((c) => c.id === selectedCategory);
    return match ? match.name : (selectedCategory ? selectedCategory.toUpperCase() : 'SEMUA');
  }, [selectedCategory, categories]);

  // Filter movements by selected period
  const filteredMovements = useMemo(() => {
    if (filterPeriod === 'all') return movements;
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);

    return movements.filter((m) => {
      const mDate = m.date.slice(0, 10);
      if (filterPeriod === 'today') {
        return mDate === todayStr;
      }
      if (filterPeriod === '7days') {
        const d = new Date(mDate);
        const diffDays = (now.getTime() - d.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 7;
      }
      if (filterPeriod === 'month') {
        const d = new Date(mDate);
        const diffDays = (now.getTime() - d.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 30;
      }
      return true;
    });
  }, [movements, filterPeriod]);

  // Filter invoices by selected period
  const filteredInvoices = useMemo(() => {
    if (filterPeriod === 'all') return invoices;
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);

    return invoices.filter((inv) => {
      const invDate = inv.date.slice(0, 10);
      if (filterPeriod === 'today') {
        return invDate === todayStr;
      }
      if (filterPeriod === '7days') {
        const d = new Date(invDate);
        const diffDays = (now.getTime() - d.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 7;
      }
      if (filterPeriod === 'month') {
        const d = new Date(invDate);
        const diffDays = (now.getTime() - d.getTime()) / (1000 * 3600 * 24);
        return diffDays >= 0 && diffDays <= 30;
      }
      return true;
    });
  }, [invoices, filterPeriod]);

  // Compute harmonized stock mutations per product with Initial Stock Reconciliation
  const reportData = useMemo(() => {
    return products.map((prod) => {
      const prodMovements = filteredMovements.filter((m) => m.productId === prod.id);

      const restockQty = prodMovements
        .filter((m) => m.type === 'restock')
        .reduce((sum, m) => sum + m.quantity, 0);

      const productionQty = prodMovements
        .filter((m) => m.type === 'production')
        .reduce((sum, m) => sum + m.quantity, 0);

      const saleQty = prodMovements
        .filter((m) => m.type === 'sale')
        .reduce((sum, m) => sum + m.quantity, 0);

      const totalOut = productionQty + saleQty;
      
      // Universal inventory reconciliation: Saldo Awal = Saldo Akhir - Masuk + Keluar
      const initialStock = Math.max(0, prod.currentStock - restockQty + totalOut);
      const totalCostValue = prod.currentStock * prod.costPrice;
      const initialCostValue = initialStock * prod.costPrice;
      const productionCostValue = productionQty * prod.costPrice;

      return {
        product: prod,
        initialStock,
        initialCostValue,
        restockQty,
        productionQty,
        saleQty,
        totalOut,
        currentStock: prod.currentStock,
        totalCostValue,
        productionCostValue,
      };
    });
  }, [products, filteredMovements]);

  // Filtered by Category for Display & PDF
  const displayedReportData = useMemo(() => {
    if (selectedCategory === 'all') return reportData;
    return reportData.filter((r) => r.product.category === selectedCategory);
  }, [reportData, selectedCategory]);

  // Harmonized Aggregate totals
  const totalInitialStockAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.initialStock, 0), [displayedReportData]);
  const totalInitialAssetValue = useMemo(() => displayedReportData.reduce((s, r) => s + r.initialCostValue, 0), [displayedReportData]);
  const totalRestockAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.restockQty, 0), [displayedReportData]);
  const totalProductionAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.productionQty, 0), [displayedReportData]);
  const totalSaleAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.saleQty, 0), [displayedReportData]);
  const totalOutAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.totalOut, 0), [displayedReportData]);
  const totalCurrentStockAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.currentStock, 0), [displayedReportData]);
  const totalProductionCostAll = useMemo(() => displayedReportData.reduce((s, r) => s + r.productionCostValue, 0), [displayedReportData]);
  const totalStockAssetValue = useMemo(() => displayedReportData.reduce((s, r) => s + r.totalCostValue, 0), [displayedReportData]);

  // Daily sales integrated summary
  const dailySalesMap = useMemo(() => {
    const map: Record<string, { date: string; invoiceCount: number; totalOmset: number; totalItemsSold: number }> = {};
    filteredInvoices.forEach((inv) => {
      if (!map[inv.date]) {
        map[inv.date] = {
          date: inv.date,
          invoiceCount: 0,
          totalOmset: 0,
          totalItemsSold: 0,
        };
      }
      map[inv.date].invoiceCount += 1;
      map[inv.date].totalOmset += inv.grandTotal;
      map[inv.date].totalItemsSold += inv.items.reduce((s, i) => s + i.quantity, 0);
    });
    return Object.values(map).sort((a, b) => b.date.localeCompare(a.date));
  }, [filteredInvoices]);

  const handleSavePdf = async () => {
    setIsSavingPdf(true);
    setPdfSuccessMessage(null);
    try {
      if (!showPdfModal) {
        setShowPdfModal(true);
        await new Promise((r) => setTimeout(r, 250));
      }

      const dateStr = new Date().toISOString().slice(0, 10);
      const catClean = selectedCategory === 'all' ? 'Semua' : selectedCategory;
      const filename = `Laporan_Mutasi_Stok_${catClean}_${dateStr}.pdf`;

      const targetWidth = pdfOrientation === 'landscape' ? 1120 : 794;
      const success = await exportElementToPdf('printable-inventory-report', filename, {
        orientation: pdfOrientation,
        customWidthPx: targetWidth,
        includePageNumbers: true,
        footerText: 'Sistem Manajemen Gudang & Logistik Sablon DTF & Sublime Pro',
      });

      if (success) {
        setPdfSuccessMessage(`Berkas PDF Laporan Mutasi Stok (${pdfOrientation === 'landscape' ? 'Lanskap' : 'Potret'}) berhasil disimpan & diunduh!`);
        setTimeout(() => setPdfSuccessMessage(null), 4500);
      }
    } catch (err) {
      console.error('[ReportsView] Gagal menyimpan PDF:', err);
    } finally {
      setIsSavingPdf(false);
    }
  };

  const handlePrint = () => {
    if (!showPdfModal) {
      setShowPdfModal(true);
      setTimeout(() => {
        printElementDirect('printable-inventory-report', pdfOrientation);
      }, 300);
    } else {
      printElementDirect('printable-inventory-report', pdfOrientation);
    }
  };

  const handleExportCSV = () => {
    const rows: (string | number)[][] = [
      ['LAPORAN REKONSILIASI & MUTASI STOK BAHAN BAKU DTF DAN SUBLIME'],
      ['Tanggal Cetak', new Date().toISOString().slice(0, 10)],
      ['Dicetak Oleh', currentUser.name],
      ['Periode', periodLabel],
      ['Kategori', categoryLabel],
      ['Formula Validasi', 'Saldo Awal + Masuk - Total Keluar = Saldo Akhir'],
      [],
      [
        'No',
        'Kode Bahan',
        'Nama Bahan Baku',
        'Kategori',
        'Satuan',
        'Saldo Awal',
        'Stok Masuk (+)',
        'Pakai Produksi SPK (-)',
        'Penjualan Konsumen (-)',
        'Total Keluar (-)',
        'Sisa Stok Fisik (Saldo Akhir)',
        'Harga Modal Satuan (HPP)',
        'Nilai Aset Modal Terakhir',
      ],
    ];

    displayedReportData.forEach((row, idx) => {
      rows.push([
        idx + 1,
        row.product.code,
        row.product.name,
        (row.product.category || '-').toUpperCase(),
        row.product.unit,
        row.initialStock,
        row.restockQty,
        row.productionQty,
        row.saleQty,
        row.totalOut,
        row.currentStock,
        row.product.costPrice,
        row.totalCostValue,
      ]);
    });

    rows.push([]);
    rows.push([
      'TOTAL KESELURUHAN',
      '',
      '',
      '',
      '',
      totalInitialStockAll,
      totalRestockAll,
      totalProductionAll,
      totalSaleAll,
      totalOutAll,
      totalCurrentStockAll,
      '',
      totalStockAssetValue,
    ]);

    exportToCSV(`Laporan_Stok_DTF_Sublime_${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-start sm:items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shrink-0 mt-0.5 sm:mt-0">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-bold text-white truncate">
                Laporan Stok Otomatis Terintegrasi Penjualan
              </h2>
              <p className="text-xs text-slate-400 mt-0.5 line-clamp-2 sm:line-clamp-none">
                Mutasi stok masuk & keluar terintegrasi real-time dari pengadaan pembelian, SPK produksi, dan invoice penjualan.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full xl:w-auto flex-wrap sm:flex-nowrap shrink-0">
          <button
            type="button"
            onClick={handleExportCSV}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold active:scale-95 transition-all cursor-pointer whitespace-nowrap"
            title="Unduh data dalam format CSV Spreadsheet"
          >
            <Download className="w-4 h-4 text-slate-300" />
            <span>Ekspor CSV</span>
          </button>
          <button
            type="button"
            onClick={() => setShowPdfModal(true)}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-slate-700 rounded-xl text-xs font-bold active:scale-95 transition-all cursor-pointer shadow-xs whitespace-nowrap"
            title="Buka pratinjau lembar A4 sebelum unduh/cetak"
          >
            <Eye className="w-4 h-4 text-cyan-400" />
            <span>Pratinjau PDF</span>
          </button>
          <button
            type="button"
            onClick={handleSavePdf}
            disabled={isSavingPdf}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold active:scale-95 transition-all shadow-sm cursor-pointer whitespace-nowrap"
            title="Simpan lembar laporan sebagai file PDF resmi"
          >
            {isSavingPdf ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
            <span>{isSavingPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold active:scale-95 transition-all shadow-sm cursor-pointer whitespace-nowrap"
            title="Cetak langsung lewat printer bawaan"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak</span>
          </button>
        </div>
      </div>

      {/* On-screen Filter Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Period Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs text-slate-400 font-semibold flex items-center gap-1 mr-1">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Periode:</span>
          </span>
          {[
            { id: 'all', label: 'Semua Periode' },
            { id: 'today', label: 'Hari Ini' },
            { id: '7days', label: '7 Hari Terakhir' },
            { id: 'month', label: '30 Hari Terakhir' },
          ].map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setFilterPeriod(p.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                filterPeriod === p.id
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-xs text-slate-400 font-semibold flex items-center gap-1 mr-1 shrink-0">
            <Filter className="w-3.5 h-3.5 text-amber-400" />
            <span>Kategori:</span>
          </span>
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Semua Bahan
          </button>
          {categories && categories.length > 0 ? (
            categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1 ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <span>{cat.icon || '📦'}</span>
                <span>{cat.name}</span>
              </button>
            ))
          ) : (
            ['dtf', 'sublime'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {cat === 'dtf' ? 'DTF' : 'Sublimasi'}
              </button>
            ))
          )}
        </div>
      </div>

      {/* On-screen Executive Metric Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Masuk (PO)</span>
            <div className="p-1.5 rounded-lg bg-emerald-500/15 text-emerald-400">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-emerald-400 font-mono">
            +{totalRestockAll} <span className="text-xs font-normal text-slate-400">Unit</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Pengadaan barang masuk</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Pakai Produksi SPK</span>
            <div className="p-1.5 rounded-lg bg-blue-500/15 text-blue-400">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-blue-400 font-mono">
            -{totalProductionAll} <span className="text-xs font-normal text-slate-400">Unit</span>
          </div>
          {currentUser.canViewFinancials ? (
            <span className="text-[10px] text-blue-300 mt-1 block font-mono">
              Beban HPP: {formatRupiah(totalProductionCostAll)}
            </span>
          ) : (
            <span className="text-[10px] text-slate-500 mt-1 block">Pemakaian cetak internal</span>
          )}
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Jual Konsumen</span>
            <div className="p-1.5 rounded-lg bg-amber-500/15 text-amber-400">
              <ShoppingCart className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-amber-400 font-mono">
            -{totalSaleAll} <span className="text-xs font-normal text-slate-400">Unit</span>
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">Faktur penjualan kasir</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Aset Stok Fisik</span>
            <div className="p-1.5 rounded-lg bg-cyan-500/15 text-cyan-400">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="text-xl font-extrabold text-cyan-300 font-mono">
            {totalCurrentStockAll} <span className="text-xs font-normal text-slate-400">Unit</span>
          </div>
          {currentUser.canViewFinancials ? (
            <span className="text-[10px] text-emerald-400 mt-1 block font-mono font-bold">
              Valuasi: {formatRupiah(totalStockAssetValue)}
            </span>
          ) : (
            <span className="text-[10px] text-slate-500 mt-1 block">{displayedReportData.length} Jenis Bahan</span>
          )}
        </div>
      </div>

      {/* Daily Sales Integrated Summary Cards */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-emerald-400" />
            <span>Rekapitulasi Penjualan Harian Bahan Baku</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">{periodLabel}</span>
        </div>

        {dailySalesMap.length === 0 ? (
          <p className="text-xs text-slate-500 italic py-2">
            Tidak ada transaksi penjualan invoice pada periode terpilih ({periodLabel}).
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {dailySalesMap.slice(0, 3).map((day) => (
              <div key={day.date} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 font-mono block">{day.date}</span>
                  <span className="text-sm font-bold text-white mt-0.5 block">{day.invoiceCount} Transaksi Invoice</span>
                  <span className="text-[11px] text-slate-400">Total {day.totalItemsSold} unit bahan terjual</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-medium">Omset</span>
                  <span className="text-base font-extrabold text-emerald-400 font-mono">
                    {formatRupiah(day.totalOmset)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Stock Movement Report Table (Onscreen View) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm space-y-3 p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Boxes className="w-4 h-4 text-cyan-400" />
            <span>Tabel Mutasi Stok Bahan Baku</span>
            <span className="text-xs text-slate-400 font-mono font-normal">({displayedReportData.length} Item)</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            {categoryLabel} • {periodLabel}
          </span>
        </div>

        {/* MOBILE PORTRAIT MUTATION CARDS */}
        <div className="md:hidden space-y-2.5">
          {displayedReportData.map((row) => (
            <div key={row.product.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2.5 text-xs">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="font-bold text-white block">{row.product.name}</span>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] text-cyan-400 font-mono">{row.product.code}</span>
                    <span className="text-[10px] text-slate-400">• {row.product.unit}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Sisa Stok</span>
                  <span className={`font-mono font-extrabold text-sm ${
                    row.currentStock <= row.product.minStockAlert ? 'text-amber-400' : 'text-cyan-300'
                  }`}>
                    {row.currentStock} {row.product.unit.split(' ')[0]}
                  </span>
                </div>
              </div>

              {/* 5-way movement mini grid including Saldo Awal */}
              <div className="grid grid-cols-5 gap-1.5 pt-1 border-t border-slate-850 text-center text-[10px]">
                <div className="bg-slate-900/90 p-1 rounded-lg border border-slate-700/60">
                  <span className="text-[8.5px] text-slate-400 block uppercase">Awal</span>
                  <span className="font-mono font-bold text-slate-200">
                    {row.initialStock}
                  </span>
                </div>
                <div className="bg-slate-900/90 p-1 rounded-lg border border-emerald-500/20">
                  <span className="text-[8.5px] text-emerald-400/80 block uppercase">Masuk</span>
                  <span className="font-mono font-bold text-emerald-400">
                    +{row.restockQty}
                  </span>
                </div>
                <div className="bg-slate-900/90 p-1 rounded-lg border border-blue-500/20">
                  <span className="text-[8.5px] text-blue-400/80 block uppercase">SPK</span>
                  <span className="font-mono font-bold text-blue-300">
                    -{row.productionQty}
                  </span>
                </div>
                <div className="bg-slate-900/90 p-1 rounded-lg border border-amber-500/20">
                  <span className="text-[8.5px] text-amber-400/80 block uppercase">Jual</span>
                  <span className="font-mono font-bold text-amber-300">
                    -{row.saleQty}
                  </span>
                </div>
                <div className="bg-slate-900/90 p-1 rounded-lg border border-rose-500/20">
                  <span className="text-[8.5px] text-rose-400/80 block uppercase">Keluar</span>
                  <span className="font-mono font-bold text-rose-400">
                    -{row.totalOut}
                  </span>
                </div>
              </div>

              {currentUser.canViewFinancials && (
                <div className="pt-1.5 border-t border-slate-850 space-y-1 text-[11px]">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Beban Pakai Produksi (HPP):</span>
                    <span className="font-mono text-blue-300 font-semibold">{formatRupiah(row.productionCostValue)}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Nilai Aset Modal Tersisa:</span>
                    <span className="font-mono text-slate-200 font-semibold">{formatRupiah(row.totalCostValue)}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* DESKTOP TABLE */}
        <div className="hidden md:block bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
            <table className="w-full min-w-[1040px] text-left text-xs sm:text-sm border-collapse">
              <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] sm:text-[11px] tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="py-3.5 px-3 min-w-[180px]">Bahan Baku</th>
                  <th className="py-3.5 px-2 min-w-[70px]">Satuan</th>
                  <th className="py-3.5 px-2 text-center min-w-[85px] text-slate-300">Saldo Awal</th>
                  <th className="py-3.5 px-2 text-center min-w-[95px] text-emerald-400">Masuk (+)</th>
                  <th className="py-3.5 px-2 text-center min-w-[100px] text-blue-400">Pakai SPK (-)</th>
                  {currentUser.canViewFinancials && (
                    <th className="py-3.5 px-2 text-right min-w-[120px] text-blue-300">Beban HPP</th>
                  )}
                  <th className="py-3.5 px-2 text-center min-w-[95px] text-amber-400">Jual (-)</th>
                  <th className="py-3.5 px-2 text-center min-w-[95px] text-rose-400">Total Keluar</th>
                  <th className="py-3.5 px-2.5 text-center min-w-[90px] text-cyan-400">Sisa Stok</th>
                  {currentUser.canViewFinancials && (
                    <th className="py-3.5 px-3 text-right min-w-[130px]">Nilai Aset Stok</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {displayedReportData.map((row) => (
                  <tr key={row.product.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-3">
                      <span className="font-semibold text-slate-100 block text-xs sm:text-sm">{row.product.name}</span>
                      <span className="text-[10px] text-cyan-400 font-mono">{row.product.code}</span>
                    </td>
                    <td className="py-3.5 px-2 text-slate-400 text-xs whitespace-nowrap">{row.product.unit}</td>
                    <td className="py-3.5 px-2 text-center font-bold text-slate-300 tabular-nums">
                      {row.initialStock}
                    </td>
                    <td className="py-3.5 px-2 text-center font-bold text-emerald-400 tabular-nums">
                      {row.restockQty > 0 ? `+${row.restockQty}` : '0'}
                    </td>
                    <td className="py-3.5 px-2 text-center font-bold text-blue-400 tabular-nums">
                      {row.productionQty > 0 ? `-${row.productionQty}` : '0'}
                    </td>
                    {currentUser.canViewFinancials && (
                      <td className="py-3.5 px-2 text-right font-mono tabular-nums text-blue-300 text-xs whitespace-nowrap">
                        {formatRupiah(row.productionCostValue)}
                      </td>
                    )}
                    <td className="py-3.5 px-2 text-center font-bold text-amber-400 tabular-nums">
                      {row.saleQty > 0 ? `-${row.saleQty}` : '0'}
                    </td>
                    <td className="py-3.5 px-2 text-center font-bold text-rose-400 tabular-nums">
                      {row.totalOut > 0 ? `-${row.totalOut}` : '0'}
                    </td>
                    <td className="py-3.5 px-2.5 text-center whitespace-nowrap">
                      <span className={`font-mono font-bold text-sm tabular-nums ${
                        row.currentStock <= row.product.minStockAlert ? 'text-amber-400' : 'text-cyan-300'
                      }`}>
                        {row.currentStock}
                      </span>
                    </td>
                    {currentUser.canViewFinancials && (
                      <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-300 text-xs whitespace-nowrap">
                        {formatRupiah(row.totalCostValue)}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* DEDICATED OPTIMIZED & HARMONIZED MODAL: PRATINJAU DOKUMEN LAPORAN STOK CETAK A4 & SIMPAN PDF */}
      {showPdfModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-1 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-6xl max-h-[96vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Sticky Top Action Bar */}
            <div className="p-3 sm:p-4 bg-slate-950/95 border-b border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between shrink-0 gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="p-1.5 sm:p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shrink-0">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-xs sm:text-base text-white truncate">
                      Pratinjau Dokumen Laporan Stok (Standar A4)
                    </h3>
                    <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                      {pdfOrientation === 'landscape' ? 'Lanskap (297×210 mm)' : 'Potret (210×297 mm)'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 font-mono truncate">
                    {categoryLabel} • {periodLabel} • {displayedReportData.length} Bahan
                  </p>
                </div>
              </div>

              {/* Action Controls & Orientation Switcher */}
              <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap justify-end">
                {/* Orientation Selector Tabs */}
                <div className="flex items-center bg-slate-900 border border-slate-750 p-0.5 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setPdfOrientation('landscape')}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      pdfOrientation === 'landscape'
                        ? 'bg-cyan-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Tata letak mendatar (Landscape) - Sangat cocok untuk tabel banyak kolom"
                  >
                    <LayoutGrid className="w-3.5 h-3.5" />
                    <span>Lanskap</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPdfOrientation('portrait')}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-all ${
                      pdfOrientation === 'portrait'
                        ? 'bg-cyan-600 text-white shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Tata letak tegak (Portrait) - Format formal vertikal"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Potret</span>
                  </button>
                </div>

                {/* Harmonized Layout Settings Toggle */}
                <button
                  type="button"
                  onClick={() => setShowConfigPanel(!showConfigPanel)}
                  className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 border rounded-xl text-xs font-semibold cursor-pointer transition-all ${
                    showConfigPanel
                      ? 'bg-indigo-600/30 border-indigo-500/50 text-indigo-300'
                      : 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-300'
                  }`}
                  title="Buka pengaturan filter & elemen dokumen cetak"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="hidden sm:inline">Pengaturan</span>
                  {showConfigPanel ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {/* Primary Save PDF Button */}
                <button
                  type="button"
                  onClick={handleSavePdf}
                  disabled={isSavingPdf}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md hover:shadow-emerald-600/25 active:scale-95 transition-all"
                  title="Simpan dokumen sebagai file PDF A4 berkualitas tinggi"
                >
                  {isSavingPdf ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileDown className="w-3.5 h-3.5" />}
                  <span>{isSavingPdf ? 'Memproses PDF...' : 'Simpan PDF'}</span>
                </button>

                {/* Direct Print Button */}
                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                  title="Cetak langsung melalui dialog browser printer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Cetak</span>
                </button>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={() => setShowPdfModal(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup Pratinjau Dokumen"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Expandable Document Customization & Harmonization Toolbar */}
            {showConfigPanel && (
              <div className="bg-slate-950 p-3 sm:p-4 border-b border-slate-800 space-y-3 shrink-0 animate-in slide-in-from-top-2 duration-150">
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
                  <span className="text-slate-400 font-semibold flex items-center gap-1 mr-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Elemen Dokumen:</span>
                  </span>

                  <label className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeInitialStock}
                      onChange={(e) => setIncludeInitialStock(e.target.checked)}
                      className="rounded border-slate-700 text-cyan-600 focus:ring-0 cursor-pointer"
                    />
                    <span className="text-slate-200">Saldo Awal</span>
                  </label>

                  <label className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeDailySales}
                      onChange={(e) => setIncludeDailySales(e.target.checked)}
                      className="rounded border-slate-700 text-cyan-600 focus:ring-0 cursor-pointer"
                    />
                    <span className="text-slate-200">Rekap Penjualan Harian</span>
                  </label>

                  <label className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeSignatures}
                      onChange={(e) => setIncludeSignatures(e.target.checked)}
                      className="rounded border-slate-700 text-cyan-600 focus:ring-0 cursor-pointer"
                    />
                    <span className="text-slate-200">Lembar Pengesahan (3 TTD)</span>
                  </label>

                  {currentUser.canViewFinancials && (
                    <label className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg cursor-pointer hover:border-slate-700 transition-colors">
                      <input
                        type="checkbox"
                        checked={includeFinancials}
                        onChange={(e) => setIncludeFinancials(e.target.checked)}
                        className="rounded border-slate-700 text-emerald-600 focus:ring-0 cursor-pointer"
                      />
                      <span className="text-emerald-400">Valuasi HPP & Aset Modal</span>
                    </label>
                  )}

                  <label className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 px-2.5 py-1.5 rounded-lg cursor-pointer hover:border-slate-700 transition-colors">
                    <input
                      type="checkbox"
                      checked={includeDocHeader}
                      onChange={(e) => setIncludeDocHeader(e.target.checked)}
                      className="rounded border-slate-700 text-cyan-600 focus:ring-0 cursor-pointer"
                    />
                    <span className="text-slate-200">Kop Surat Resmi Gudang</span>
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-850">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-semibold shrink-0">Status Dokumen:</span>
                    <select
                      value={auditDocStatus}
                      onChange={(e) => setAuditDocStatus(e.target.value)}
                      className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 cursor-pointer"
                    >
                      <option value="Tervalidasi Resmi">Tervalidasi Resmi (Final Sah)</option>
                      <option value="Hasil Rekonsiliasi Gudang">Hasil Rekonsiliasi Gudang</option>
                      <option value="Draft Audit Internal">Draft Audit Internal</option>
                      <option value="Opname Bulanan">Hasil Opname Bulanan</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 font-semibold shrink-0">Catatan Khusus:</span>
                    <input
                      type="text"
                      value={reportNote}
                      onChange={(e) => setReportNote(e.target.value)}
                      placeholder="Tulis catatan verifikasi untuk dicetak pada dokumen..."
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 placeholder:text-slate-600"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Notification Banner */}
            {pdfSuccessMessage && (
              <div className="px-4 py-2.5 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between font-medium shrink-0 animate-in fade-in">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{pdfSuccessMessage}</span>
                </div>
                <button 
                  type="button" 
                  onClick={() => setPdfSuccessMessage(null)}
                  className="text-emerald-400 hover:text-white cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Printable Document Sheet Viewer */}
            <div className="p-3 sm:p-6 pb-14 overflow-y-auto bg-slate-950/75 flex-1 flex justify-center items-start">
              {/* HARMONIZED A4 PRINTABLE DOCUMENT CONTAINER */}
              <div
                id="printable-inventory-report"
                className={`bg-white text-slate-900 p-6 sm:p-8 pb-8 sm:pb-10 rounded-xl shadow-2xl font-sans text-xs w-full h-auto min-h-fit space-y-4 ${
                  pdfOrientation === 'landscape' ? 'max-w-5xl' : 'max-w-3xl'
                }`}
              >
                {/* 1. Official Letterhead / Kop Laporan Resmi */}
                {includeDocHeader && (
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-4 border-b-2 border-slate-900">
                    <div className="flex items-start gap-3">
                      {companyProfile?.logoUrl ? (
                        <div className="w-14 h-14 rounded-xl border border-slate-200 bg-white p-1 flex items-center justify-center shrink-0 shadow-xs overflow-hidden mt-0.5">
                          <img
                            src={companyProfile.logoUrl}
                            alt={companyProfile.companyName || 'Logo Perusahaan'}
                            className="w-full h-full object-contain"
                          />
                        </div>
                      ) : (
                        <div className="w-12 h-12 rounded-xl bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-xl border-2 border-slate-850 shrink-0 mt-0.5">
                          {companyProfile?.shortName || companyProfile?.appLogoBadge || 'DTF'}
                        </div>
                      )}
                      <div>
                        <span className="text-[9.5px] font-extrabold uppercase tracking-widest text-slate-500 block">
                          SISTEM LOGISTIK & MANAJEMEN INVENTARIS
                        </span>
                        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight leading-tight uppercase">
                          {companyProfile?.companyName || 'GUDANG SUPLAI SABLON DTF & SUBLIME'}
                        </h1>
                        <p className="text-xs text-slate-600 mt-0.5 font-medium">
                          {companyProfile?.tagline || 'Pusat Pengadaan Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise'}
                        </p>
                        <p className="text-[10.5px] text-slate-500">
                          {companyProfile?.address || 'Kawasan Industri Kreatif No. 88'}, {companyProfile?.city || 'Bandung'} • Telp/WA: {companyProfile?.phone || '0812-9988-7766'} • Email: {companyProfile?.email || 'logistik@dtfsublime.id'}
                        </p>
                      </div>
                    </div>

                    <div className="text-left sm:text-right shrink-0">
                      <div className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-black text-[11px] tracking-wider uppercase">
                        LAPORAN REKONSILIASI & MUTASI STOK
                      </div>
                      <p className="font-mono font-bold text-xs text-slate-800 mt-1.5">
                        REF: LAP-STK-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
                      </p>
                      <p className="text-[10.5px] text-slate-600">
                        Tanggal Cetak: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </p>
                      <p className="text-[10.5px] text-slate-600">
                        Oleh: <strong>{currentUser.name}</strong> ({currentUser.roleTitle || (currentUser.role === 'owner' ? 'Pemilik Usaha' : 'Admin Gudang')})
                      </p>
                      <span className="inline-block px-2 py-0.5 mt-1 rounded bg-emerald-100 text-emerald-800 font-bold text-[9.5px] border border-emerald-300">
                        Status: {auditDocStatus}
                      </span>
                    </div>
                  </div>
                )}

                {/* 2. Executive Parameter & Audit Filter Box */}
                <div className="bg-slate-50 rounded-xl border border-slate-300 p-3 sm:p-3.5 space-y-2">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div>
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block tracking-wider">Cakupan Kategori</span>
                      <span className="font-bold text-slate-900 text-xs block truncate mt-0.5">
                        {categoryLabel}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block tracking-wider">Periode Rekapitulasi</span>
                      <span className="font-semibold text-slate-800 text-xs block mt-0.5">
                        {periodLabel}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block tracking-wider">Jumlah Bahan Terdata</span>
                      <span className="font-semibold text-slate-800 text-xs block mt-0.5">
                        {displayedReportData.length} Jenis Produk
                      </span>
                    </div>
                    <div>
                      <span className="text-[9.5px] font-bold text-slate-500 uppercase block tracking-wider">Formula Rekonsiliasi</span>
                      <span className="font-bold text-emerald-800 text-xs block mt-0.5">
                        Awal + Masuk - Keluar = Sisa
                      </span>
                    </div>
                  </div>
                </div>

                {/* 3. Executive Metrics Summary Bar (Harmonized Accounting Strip) */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                  {includeInitialStock && (
                    <div className="p-2.5 rounded-lg border border-slate-200 bg-slate-50">
                      <span className="text-[9px] font-bold uppercase text-slate-500 block">1. Saldo Awal</span>
                      <span className="font-mono font-bold text-slate-800 text-sm block mt-0.5">
                        {totalInitialStockAll} Unit
                      </span>
                    </div>
                  )}
                  <div className="p-2.5 rounded-lg border border-emerald-200 bg-emerald-50/50">
                    <span className="text-[9px] font-bold uppercase text-emerald-800 block">2. Masuk (PO/Restock)</span>
                    <span className="font-mono font-bold text-emerald-700 text-sm block mt-0.5">
                      +{totalRestockAll} Unit
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-blue-200 bg-blue-50/50">
                    <span className="text-[9px] font-bold uppercase text-blue-800 block">3. Pakai SPK Prod</span>
                    <span className="font-mono font-bold text-blue-700 text-sm block mt-0.5">
                      -{totalProductionAll} Unit
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-amber-200 bg-amber-50/50">
                    <span className="text-[9px] font-bold uppercase text-amber-800 block">4. Jual Konsumen</span>
                    <span className="font-mono font-bold text-amber-700 text-sm block mt-0.5">
                      -{totalSaleAll} Unit
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border border-rose-200 bg-rose-50/50">
                    <span className="text-[9px] font-bold uppercase text-rose-800 block">5. Total Keluar</span>
                    <span className="font-mono font-bold text-rose-700 text-sm block mt-0.5">
                      -{totalOutAll} Unit
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg border-2 border-slate-900 bg-slate-100">
                    <span className="text-[9px] font-bold uppercase text-slate-700 block">6. Saldo Akhir (Sisa)</span>
                    <span className="font-mono font-black text-slate-950 text-sm block mt-0.5">
                      {totalCurrentStockAll} Unit
                    </span>
                  </div>
                </div>

                {/* 4. Rekapitulasi Penjualan Harian (Harmonized Clean Table) */}
                {includeDailySales && dailySalesMap.length > 0 && (
                  <div className="space-y-1 pt-1">
                    <h4 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                      <span>• Rekapitulasi Penjualan Harian ({dailySalesMap.length} Hari Aktif)</span>
                    </h4>
                    <div className="border border-slate-300 rounded-lg overflow-hidden">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-slate-100 text-slate-700 font-semibold text-[9.5px] uppercase border-b border-slate-300">
                          <tr>
                            <th className="py-1.5 px-3">Tanggal Transaksi</th>
                            <th className="py-1.5 px-3 text-center">Jumlah Invoice Penjualan</th>
                            <th className="py-1.5 px-3 text-center">Bahan Baku Terjual</th>
                            <th className="py-1.5 px-3 text-right">Total Nilai Omset Penjualan</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                          {dailySalesMap.slice(0, 6).map((day) => (
                            <tr key={day.date}>
                              <td className="py-1.5 px-3 font-semibold text-slate-800">{day.date}</td>
                              <td className="py-1.5 px-3 text-center text-slate-700">{day.invoiceCount} Faktur</td>
                              <td className="py-1.5 px-3 text-center text-slate-700">{day.totalItemsSold} Unit</td>
                              <td className="py-1.5 px-3 text-right font-bold text-emerald-700">{formatRupiah(day.totalOmset)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 5. Main Stock Movement Report Table (Fit to A4 Width with NO Horizontal Crop) */}
                <div className="space-y-1.5 pt-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-800 text-[11px] uppercase tracking-wider flex items-center gap-1.5">
                      <span>• Tabel Rekonsiliasi Mutasi & Saldo Stok Fisik</span>
                    </h4>
                    <span className="text-[10px] text-slate-500 font-mono">
                      Format: {pdfOrientation === 'landscape' ? 'A4 Lanskap' : 'A4 Potret'}
                    </span>
                  </div>

                  <div className="border border-slate-300 rounded-lg overflow-hidden">
                    <table className="w-full text-left text-[10.5px] border-collapse">
                      <thead className="bg-slate-100 text-slate-800 font-bold uppercase text-[9px] tracking-wider border-b-2 border-slate-300">
                        <tr>
                          <th className="py-2 px-1.5 text-center" style={{ width: '4%' }}>No</th>
                          <th className="py-2 px-2" style={{ width: pdfOrientation === 'landscape' ? '22%' : '26%' }}>
                            Bahan Baku
                          </th>
                          <th className="py-2 px-1 text-center" style={{ width: '8%' }}>Kategori</th>
                          <th className="py-2 px-1 text-center" style={{ width: '6%' }}>Satuan</th>
                          {includeInitialStock && (
                            <th className="py-2 px-1.5 text-center text-slate-700" style={{ width: '8%' }}>
                              Saldo Awal
                            </th>
                          )}
                          <th className="py-2 px-1.5 text-center text-emerald-800" style={{ width: '8%' }}>
                            Masuk (+)
                          </th>
                          <th className="py-2 px-1.5 text-center text-blue-800" style={{ width: '8%' }}>
                            Pakai SPK (-)
                          </th>
                          <th className="py-2 px-1.5 text-center text-amber-800" style={{ width: '8%' }}>
                            Jual (-)
                          </th>
                          <th className="py-2 px-1.5 text-center text-rose-800" style={{ width: '8%' }}>
                            Total Keluar
                          </th>
                          <th className="py-2 px-1.5 text-center text-slate-950 font-black" style={{ width: '9%' }}>
                            Sisa Stok
                          </th>
                          {includeFinancials && currentUser.canViewFinancials && (
                            <th className="py-2 px-2 text-right text-emerald-900" style={{ width: '13%' }}>
                              Nilai Aset Modal
                            </th>
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {displayedReportData.map((row, idx) => (
                          <tr key={row.product.id} className={idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                            <td className="py-1.5 px-1.5 text-center font-mono text-slate-500 text-[9.5px]">
                              {idx + 1}
                            </td>
                            <td className="py-1.5 px-2">
                              <span className="font-bold text-slate-900 block leading-tight">{row.product.name}</span>
                              <span className="text-[9px] text-slate-500 font-mono">{row.product.code}</span>
                            </td>
                            <td className="py-1.5 px-1 text-center text-[9.5px] uppercase font-semibold text-slate-600">
                              {row.product.category}
                            </td>
                            <td className="py-1.5 px-1 text-center text-slate-600 text-[9.5px] whitespace-nowrap">
                              {row.product.unit}
                            </td>
                            {includeInitialStock && (
                              <td className="py-1.5 px-1.5 text-center font-mono font-semibold text-slate-700">
                                {row.initialStock}
                              </td>
                            )}
                            <td className="py-1.5 px-1.5 text-center font-mono font-bold text-emerald-700">
                              {row.restockQty > 0 ? `+${row.restockQty}` : '0'}
                            </td>
                            <td className="py-1.5 px-1.5 text-center font-mono font-bold text-blue-700">
                              {row.productionQty > 0 ? `-${row.productionQty}` : '0'}
                            </td>
                            <td className="py-1.5 px-1.5 text-center font-mono font-bold text-amber-700">
                              {row.saleQty > 0 ? `-${row.saleQty}` : '0'}
                            </td>
                            <td className="py-1.5 px-1.5 text-center font-mono font-bold text-rose-700">
                              {row.totalOut > 0 ? `-${row.totalOut}` : '0'}
                            </td>
                            <td className="py-1.5 px-1.5 text-center font-mono font-black text-slate-950">
                              {row.currentStock}
                            </td>
                            {includeFinancials && currentUser.canViewFinancials && (
                              <td className="py-1.5 px-2 text-right font-mono font-bold text-slate-800 whitespace-nowrap text-[10px]">
                                {formatRupiah(row.totalCostValue)}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>

                      {/* 6. Grand Total Footer with Double Accounting Underline */}
                      <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-900 border-b-2">
                        <tr className="text-slate-900 font-mono text-[9.5px]">
                          <td colSpan={includeInitialStock ? 4 : 3} className="py-2 px-2 text-center uppercase tracking-wider font-sans font-black">
                            TOTAL KESELURUHAN
                          </td>
                          {includeInitialStock && (
                            <td className="py-2 px-1.5 text-center font-black text-slate-900">
                              {totalInitialStockAll}
                            </td>
                          )}
                          <td className="py-2 px-1.5 text-center text-emerald-800 font-black">
                            +{totalRestockAll}
                          </td>
                          <td className="py-2 px-1.5 text-center text-blue-800 font-black">
                            -{totalProductionAll}
                          </td>
                          <td className="py-2 px-1.5 text-center text-amber-800 font-black">
                            -{totalSaleAll}
                          </td>
                          <td className="py-2 px-1.5 text-center text-rose-800 font-black">
                            -{totalOutAll}
                          </td>
                          <td className="py-2 px-1.5 text-center text-slate-950 font-black">
                            {totalCurrentStockAll}
                          </td>
                          {includeFinancials && currentUser.canViewFinancials && (
                            <td className="py-2 px-2 text-right text-slate-950 font-black whitespace-nowrap text-[10.5px]">
                              {formatRupiah(totalStockAssetValue)}
                            </td>
                          )}
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>

                {/* Catatan Dokumen Khusus / Auditor Notes */}
                {reportNote && (
                  <div className="bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-[10px] text-slate-700 space-y-0.5">
                    <span className="font-bold uppercase tracking-wider text-slate-500 block text-[9px]">
                      Catatan & Keterangan Khusus Rekonsiliasi:
                    </span>
                    <p className="italic">{reportNote}</p>
                  </div>
                )}

                {/* 7. Official Sign-off / Lembar Pengesahan Resmi (3 Signatures) */}
                {includeSignatures && (
                  <div className="pt-4 border-t border-slate-300">
                    <div className="grid grid-cols-3 gap-4 text-center text-xs">
                      <div>
                        <span className="text-[9.5px] text-slate-500 font-semibold block uppercase">Dibuat Oleh,</span>
                        <span className="text-[10.5px] font-bold text-slate-800 block mt-0.5">
                          {companyProfile?.signerTitle1 || 'Petugas Logistik Gudang'}
                        </span>
                        <div className="h-14 flex items-end justify-center">
                          <div className="w-32 border-b border-slate-900 pb-0.5">
                            <span className="font-bold text-slate-900 text-xs block">{currentUser.name}</span>
                          </div>
                        </div>
                        <span className="text-[8.5px] text-slate-500 font-mono mt-0.5 block">
                          {companyProfile?.signerSub1 || 'Staff Logistik & Kasir'}
                        </span>
                      </div>

                      <div>
                        <span className="text-[9.5px] text-slate-500 font-semibold block uppercase">Diperiksa Oleh,</span>
                        <span className="text-[10.5px] font-bold text-slate-800 block mt-0.5">
                          {companyProfile?.signerTitle2 || 'Supervisor Gudang (SPV)'}
                        </span>
                        <div className="h-14 flex items-end justify-center">
                          <div className="w-32 border-b border-slate-900 pb-0.5">
                            <span className="font-bold text-slate-900 text-xs block">( .............................. )</span>
                          </div>
                        </div>
                        <span className="text-[8.5px] text-slate-500 font-mono mt-0.5 block">
                          {companyProfile?.signerSub2 || 'Supervisor Operasional'}
                        </span>
                      </div>

                      <div>
                        <span className="text-[9.5px] text-slate-500 font-semibold block uppercase">Disetujui Oleh,</span>
                        <span className="text-[10.5px] font-bold text-slate-800 block mt-0.5">
                          {companyProfile?.signerTitle3 || 'Pemilik Usaha (Owner)'}
                        </span>
                        <div className="h-14 flex items-end justify-center">
                          <div className="w-32 border-b border-slate-900 pb-0.5">
                            <span className="font-bold text-slate-900 text-xs block">( .............................. )</span>
                          </div>
                        </div>
                        <span className="text-[8.5px] text-slate-500 font-mono mt-0.5 block">
                          {companyProfile?.signerSub3 || 'Pimpinan Manajemen'}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* 8. Formal Footer Line */}
                <div className="pt-3 text-[9.5px] text-slate-500 flex items-center justify-between border-t border-slate-200 font-mono mt-2">
                  <span>Dokumen Laporan Sah • {companyProfile?.appName ? `Sistem ${companyProfile.appName}` : 'Sistem Manajemen Gudang Sablon DTF & Sublime Pro'}</span>
                  <span>Rekonsiliasi Transaksi Riil • Status: {auditDocStatus}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
