import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Users, 
  UserPlus, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  RotateCcw, 
  Lock, 
  KeyRound, 
  Boxes, 
  ShoppingCart, 
  Layers, 
  FileText, 
  CreditCard, 
  BarChart3, 
  FileSpreadsheet, 
  History, 
  AlertCircle,
  Sparkles,
  Sliders,
  CheckCircle2,
  HelpCircle,
  ExternalLink,
  Search,
  Eye,
  EyeOff,
  Building2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { User, UserRole } from '../types';

interface AccessControlViewProps {
  users: User[];
  currentUser: User;
  onUpdateUser: (updatedUser: User) => void;
  onAddUser: (newUser: User) => void;
  onDeleteUser: (userId: string) => { success: boolean; message?: string };
  onResetUsersToDefault: () => void;
  onSwitchUser?: (user: User) => void;
}

export const AccessControlView: React.FC<AccessControlViewProps> = ({
  users,
  currentUser,
  onUpdateUser,
  onAddUser,
  onDeleteUser,
  onResetUsersToDefault,
  onSwitchUser,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deleteConfirmUser, setDeleteConfirmUser] = useState<User | null>(null);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Password visibility toggles
  const [showEditPassword, setShowEditPassword] = useState(false);
  const [showNewUserPassword, setShowNewUserPassword] = useState(false);
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});

  const togglePasswordVisibility = (userId: string) => {
    setVisiblePasswords((prev) => ({
      ...prev,
      [userId]: !prev[userId],
    }));
  };

  // New user form state
  const [newUserName, setNewUserName] = useState('');
  const [newUserRoleTitle, setNewUserRoleTitle] = useState('Staff Gudang / Operasional');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('123456');
  const [newUserRole, setNewUserRole] = useState<UserRole>('warehouse_admin');
  const [newUserAvatarColor, setNewUserAvatarColor] = useState('bg-teal-600');
  const [newUserPermissions, setNewUserPermissions] = useState<{
    canViewFinancials: boolean;
    canManageProducts: boolean;
    canDeleteProducts: boolean;
    canRestock: boolean;
    canEditPurchases: boolean;
    canDeletePurchases: boolean;
    canUseForProduction: boolean;
    canEditProductionUsage: boolean;
    canDeleteProductionUsage: boolean;
    canCreateSalesInvoice: boolean;
    canEditSalesInvoice: boolean;
    canDeleteSalesInvoice: boolean;
    canManagePayments: boolean;
    canManageMasterData: boolean;
    canManageAccessControl: boolean;
    canManageCompanyProfile: boolean;
    canDeleteLogs: boolean;
    canExportReports: boolean;
    canStockOpname: boolean;
  }>({
    canViewFinancials: false,
    canManageProducts: true,
    canDeleteProducts: true,
    canRestock: true,
    canEditPurchases: true,
    canDeletePurchases: true,
    canUseForProduction: false,
    canEditProductionUsage: false,
    canDeleteProductionUsage: false,
    canCreateSalesInvoice: false,
    canEditSalesInvoice: false,
    canDeleteSalesInvoice: false,
    canManagePayments: true,
    canManageMasterData: true,
    canManageAccessControl: false,
    canManageCompanyProfile: false,
    canDeleteLogs: false,
    canExportReports: true,
    canStockOpname: true,
  });

  const filteredUsers = users.filter((u) =>
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.roleTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Quick Preset Handlers
  const applyPresetToEditing = (presetType: 'owner' | 'spv' | 'cashier' | 'production' | 'readonly') => {
    if (!editingUser) return;
    switch (presetType) {
      case 'owner':
        setEditingUser({
          ...editingUser,
          canViewFinancials: true,
          canManageProducts: true,
          canDeleteProducts: true,
          canRestock: true,
          canEditPurchases: true,
          canDeletePurchases: true,
          canUseForProduction: true,
          canEditProductionUsage: true,
          canDeleteProductionUsage: true,
          canCreateSalesInvoice: true,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: true,
          canManagePayments: true,
          canManageMasterData: true,
          canManageAccessControl: true,
          canManageCompanyProfile: true,
          canDeleteLogs: true,
          canExportReports: true,
          canStockOpname: true,
        });
        break;
      case 'spv':
        setEditingUser({
          ...editingUser,
          canViewFinancials: false,
          canManageProducts: true,
          canDeleteProducts: true, // SPV can delete
          canRestock: true,
          canEditPurchases: true,
          canDeletePurchases: true,
          canUseForProduction: true,
          canEditProductionUsage: true,
          canDeleteProductionUsage: true,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: true,
          canManagePayments: true,
          canManageMasterData: true,
          canManageAccessControl: false,
          canManageCompanyProfile: true,
          canDeleteLogs: false,
          canExportReports: true,
          canStockOpname: true,
        });
        break;
      case 'cashier':
        setEditingUser({
          ...editingUser,
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: false,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: true,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: false,
          canManagePayments: true,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: true,
          canStockOpname: false,
        });
        break;
      case 'production':
        setEditingUser({
          ...editingUser,
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: true,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: false,
          canDeleteSalesInvoice: false,
          canManagePayments: false,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: false,
          canStockOpname: false,
        });
        break;
      case 'readonly':
        setEditingUser({
          ...editingUser,
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: false,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: false,
          canDeleteSalesInvoice: false,
          canManagePayments: false,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: false,
          canStockOpname: false,
        });
        break;
    }
  };

  const applyPresetToNewUser = (presetType: 'owner' | 'spv' | 'cashier' | 'production' | 'readonly') => {
    switch (presetType) {
      case 'owner':
        setNewUserRoleTitle('Pemilik Usaha (Owner)');
        setNewUserPermissions({
          canViewFinancials: true,
          canManageProducts: true,
          canDeleteProducts: true,
          canRestock: true,
          canEditPurchases: true,
          canDeletePurchases: true,
          canUseForProduction: true,
          canEditProductionUsage: true,
          canDeleteProductionUsage: true,
          canCreateSalesInvoice: true,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: true,
          canManagePayments: true,
          canManageMasterData: true,
          canManageAccessControl: true,
          canManageCompanyProfile: true,
          canDeleteLogs: true,
          canExportReports: true,
          canStockOpname: true,
        });
        break;
      case 'spv':
        setNewUserRoleTitle('Supervisor Gudang (SPV)');
        setNewUserPermissions({
          canViewFinancials: false,
          canManageProducts: true,
          canDeleteProducts: true,
          canRestock: true,
          canEditPurchases: true,
          canDeletePurchases: true,
          canUseForProduction: true,
          canEditProductionUsage: true,
          canDeleteProductionUsage: true,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: true,
          canManagePayments: true,
          canManageMasterData: true,
          canManageAccessControl: false,
          canManageCompanyProfile: true,
          canDeleteLogs: false,
          canExportReports: true,
          canStockOpname: true,
        });
        break;
      case 'cashier':
        setNewUserRoleTitle('Kasir & Sales Bahan');
        setNewUserPermissions({
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: false,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: true,
          canEditSalesInvoice: true,
          canDeleteSalesInvoice: false,
          canManagePayments: true,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: true,
          canStockOpname: false,
        });
        break;
      case 'production':
        setNewUserRoleTitle('Operator Produksi Sablon');
        setNewUserPermissions({
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: true,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: false,
          canDeleteSalesInvoice: false,
          canManagePayments: false,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: false,
          canStockOpname: false,
        });
        break;
      case 'readonly':
        setNewUserRoleTitle('Staff Pemantau (Read-Only)');
        setNewUserPermissions({
          canViewFinancials: false,
          canManageProducts: false,
          canDeleteProducts: false,
          canRestock: false,
          canEditPurchases: false,
          canDeletePurchases: false,
          canUseForProduction: false,
          canEditProductionUsage: false,
          canDeleteProductionUsage: false,
          canCreateSalesInvoice: false,
          canEditSalesInvoice: false,
          canDeleteSalesInvoice: false,
          canManagePayments: false,
          canManageMasterData: false,
          canManageAccessControl: false,
          canManageCompanyProfile: false,
          canDeleteLogs: false,
          canExportReports: false,
          canStockOpname: false,
        });
        break;
    }
  };

  const handleSaveEditingUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    if (!editingUser.name.trim()) {
      setErrorMessage('Nama pengguna tidak boleh kosong.');
      return;
    }

    onUpdateUser(editingUser);
    setSaveSuccessNotice(`Hak akses & profil untuk ${editingUser.name} berhasil diperbarui.`);
    setTimeout(() => setSaveSuccessNotice(null), 4000);
    setEditingUser(null);
    setErrorMessage(null);
    try {
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
    } catch {
      // ignore
    }
  };

  const handleCreateNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim()) {
      setErrorMessage('Nama pengguna baru wajib diisi.');
      return;
    }

    const newUser: User = {
      id: `user-${Date.now()}`,
      name: newUserName.trim(),
      role: newUserRole,
      roleTitle: newUserRoleTitle.trim() || 'Staff Gudang / Operasional',
      email: newUserEmail.trim() || `${newUserName.toLowerCase().replace(/\s+/g, '')}@cetakprint.com`,
      password: newUserPassword.trim() || '123456',
      avatarColor: newUserAvatarColor,
      canViewFinancials: newUserPermissions.canViewFinancials,
      canManageProducts: newUserPermissions.canManageProducts,
      canDeleteProducts: newUserPermissions.canDeleteProducts,
      canRestock: newUserPermissions.canRestock,
      canEditPurchases: newUserPermissions.canEditPurchases,
      canDeletePurchases: newUserPermissions.canDeletePurchases,
      canUseForProduction: newUserPermissions.canUseForProduction,
      canEditProductionUsage: newUserPermissions.canEditProductionUsage,
      canDeleteProductionUsage: newUserPermissions.canDeleteProductionUsage,
      canCreateSalesInvoice: newUserPermissions.canCreateSalesInvoice,
      canEditSalesInvoice: newUserPermissions.canEditSalesInvoice,
      canDeleteSalesInvoice: newUserPermissions.canDeleteSalesInvoice,
      canManagePayments: newUserPermissions.canManagePayments,
      canManageMasterData: newUserPermissions.canManageMasterData,
      canManageAccessControl: newUserPermissions.canManageAccessControl,
      canManageCompanyProfile: newUserPermissions.canManageCompanyProfile,
      canDeleteLogs: newUserPermissions.canDeleteLogs,
      canExportReports: newUserPermissions.canExportReports,
      canStockOpname: newUserPermissions.canStockOpname,
    };

    onAddUser(newUser);
    setSaveSuccessNotice(`Pengguna baru ${newUser.name} berhasil ditambahkan dengan hak akses tersimpan.`);
    setTimeout(() => setSaveSuccessNotice(null), 4000);
    setIsAddModalOpen(false);
    setNewUserName('');
    setNewUserEmail('');
    setErrorMessage(null);
  };

  const handleDeleteUserConfirm = () => {
    if (!deleteConfirmUser) return;
    const res = onDeleteUser(deleteConfirmUser.id);
    if (res.success) {
      setSaveSuccessNotice(`Pengguna ${deleteConfirmUser.name} telah dihapus.`);
      setTimeout(() => setSaveSuccessNotice(null), 4000);
      setDeleteConfirmUser(null);
    } else {
      setErrorMessage(res.message || 'Gagal menghapus pengguna.');
    }
  };

  // Counting active permissions for quick badge
  const countActivePermissions = (u: User) => {
    let count = 0;
    if (u.canManageProducts) count++;
    if (u.canDeleteProducts) count++;
    if (u.canRestock) count++;
    if (u.canEditPurchases) count++;
    if (u.canDeletePurchases) count++;
    if (u.canStockOpname) count++;
    if (u.canUseForProduction) count++;
    if (u.canEditProductionUsage) count++;
    if (u.canDeleteProductionUsage) count++;
    if (u.canCreateSalesInvoice) count++;
    if (u.canEditSalesInvoice) count++;
    if (u.canDeleteSalesInvoice) count++;
    if (u.canManagePayments) count++;
    if (u.canViewFinancials) count++;
    if (u.canManageMasterData) count++;
    if (u.canManageAccessControl) count++;
    if (u.canDeleteLogs) count++;
    if (u.canExportReports) count++;
    return count;
  };

  return (
    <div className="space-y-6 pt-1 sm:pt-2">
      {/* SUCCESS / ERROR TOASTS */}
      {saveSuccessNotice && (
        <div className="p-4 bg-emerald-500/15 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-emerald-300 text-xs shadow-lg animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-semibold">{saveSuccessNotice}</span>
          </div>
          <button onClick={() => setSaveSuccessNotice(null)} className="text-emerald-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-500/15 border border-rose-500/40 rounded-2xl flex items-center justify-between text-rose-300 text-xs shadow-lg animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-400 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TOP HEADER & EXPLANATION BANNER */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-400 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                Manajemen Hak Akses & Pengguna
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-cyan-950 text-cyan-300 border border-cyan-800">
                Sistem Granular Checklist
              </span>
            </div>
            <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
              Predikat seperti <strong>Owner</strong> atau <strong>SPV</strong> hanyalah label identitas / jabatan nama. Seluruh hak akses fungsional sistem (seperti <em>Aksi Hapus Bahan</em>, <em>Tambah/Edit Bahan</em>, <em>Lihat Omset & Laba</em>, <em>Kasir Faktur</em>, dll.) ditentukan secara mandiri melalui <strong>kotak centang checklist</strong> yang Anda aktifkan pada masing-masing akun.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap shrink-0">
            <button
              type="button"
              onClick={() => {
                if (window.confirm('Reset semua hak akses pengguna kembali ke pengaturan standar pabrik?')) {
                  onResetUsersToDefault();
                  setSaveSuccessNotice('Hak akses semua akun telah dikembalikan ke pengaturan default.');
                  setTimeout(() => setSaveSuccessNotice(null), 4000);
                }
              }}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 active:scale-95 transition-all"
              title="Kembalikan semua izin ke default awal"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
              <span>Reset Default</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setIsAddModalOpen(true);
                setErrorMessage(null);
              }}
              className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-cyan-900/30 active:scale-95 transition-all"
            >
              <UserPlus className="w-4 h-4" />
              <span>+ Tambah Pengguna Baru</span>
            </button>
          </div>
        </div>

        {/* ACTIVE SESSION BANNER */}
        <div className="mt-5 p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-lg ${currentUser.avatarColor} text-white flex items-center justify-center font-bold text-xs shrink-0 shadow`}>
              {currentUser.name.charAt(0)}
            </div>
            <div>
              <span className="text-slate-400 text-[11px] block">Sedang login saat ini:</span>
              <div className="flex items-center gap-2 flex-wrap">
                <strong className="text-white font-semibold">{currentUser.name}</strong>
                <span className="font-mono text-cyan-300 text-[11px]">({currentUser.roleTitle})</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-slate-400">Status Akses Hapus Bahan:</span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
              currentUser.canDeleteProducts
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
            }`}>
              {currentUser.canDeleteProducts ? 'Aktif (Bisa Hapus)' : 'Nonaktif (Terkunci)'}
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-slate-400 font-mono">
              {countActivePermissions(currentUser)} / 11 Izin Aktif
            </span>
          </div>
        </div>
      </div>

      {/* SEARCH BAR & USERS COUNT */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari pengguna berdasarkan nama, predikat/jabatan, atau email..."
            className="w-full pl-10 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
          />
        </div>
        <span className="text-xs text-slate-400">
          Total Terdaftar: <strong className="text-white font-mono">{users.length} Akun Pengguna</strong>
        </span>
      </div>

      {/* USERS LIST CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredUsers.map((user) => {
          const isCurrent = user.id === currentUser.id;
          const activeCount = countActivePermissions(user);

          return (
            <div
              key={user.id}
              className={`bg-slate-900 border rounded-2xl p-4 sm:p-5 flex flex-col justify-between transition-all ${
                isCurrent
                  ? 'border-cyan-500/50 shadow-lg shadow-cyan-950/40 ring-1 ring-cyan-500/20'
                  : 'border-slate-800 hover:border-slate-700'
              }`}
            >
              <div>
                {/* Header card */}
                <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-11 h-11 rounded-2xl ${user.avatarColor} text-white flex items-center justify-center font-bold text-base shadow-md shrink-0`}>
                      {user.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-bold text-sm text-white truncate">{user.name}</h4>
                        {isCurrent && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                            AKUN ANDA
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-semibold text-cyan-400 mt-0.5 truncate">
                        {user.roleTitle}
                      </p>
                      <p className="text-[11px] text-slate-400 font-mono truncate">
                        {user.email}
                      </p>
                      
                      {/* Password Info with strict RBAC protection */}
                      {(() => {
                        const isOwnerViewer = currentUser.role === 'owner';
                        const isTargetOwner = user.role === 'owner';

                        // Case 1: Target is Owner, but viewer is NOT Owner (e.g. SPV is logged in)
                        if (isTargetOwner && !isOwnerViewer) {
                          return (
                            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-slate-400">
                              <Lock className="w-3 h-3 text-amber-400 shrink-0" />
                              <span className="text-slate-400">Sandi:</span>
                              <span className="text-amber-300 font-semibold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-500/30 text-[10px]">
                                •••••••• (Terproteksi Khusus Owner)
                              </span>
                            </div>
                          );
                        }

                        // Case 2: Target is another colleague, and viewer is NOT Owner
                        if (!isOwnerViewer && !isCurrent) {
                          return (
                            <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-slate-400">
                              <Lock className="w-3 h-3 text-slate-500 shrink-0" />
                              <span className="text-slate-400">Sandi:</span>
                              <span className="text-slate-500 bg-slate-950 px-2 py-0.5 rounded border border-slate-800 text-[10px]">
                                •••••••• (Dirahasiakan)
                              </span>
                            </div>
                          );
                        }

                        // Case 3: Viewer is Owner (can view any user with toggle), OR viewer is looking at their OWN account
                        const isVisible = Boolean(visiblePasswords[user.id]);
                        const pass = user.password || (
                          user.id === 'user-1' ? 'budi123' :
                          user.id === 'user-2' ? 'agus123' :
                          user.id === 'user-3' ? 'rina123' :
                          user.id === 'user-4' ? 'dani123' : '123456'
                        );

                        return (
                          <div className="flex items-center gap-1.5 mt-1 text-[11px] font-mono text-slate-300">
                            <KeyRound className="w-3 h-3 text-emerald-400 shrink-0" />
                            <span>Sandi:</span>
                            <strong className="text-white bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                              {isVisible ? pass : '••••••••'}
                            </strong>
                            <button
                              type="button"
                              onClick={() => togglePasswordVisibility(user.id)}
                              className="text-slate-400 hover:text-cyan-300 p-0.5 transition-colors cursor-pointer"
                              title={isVisible ? "Sembunyikan sandi" : (isCurrent ? "Lihat sandi akun Anda" : "Tampilkan sandi (Hak Akses Owner)")}
                            >
                              {isVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-cyan-400" />}
                            </button>
                          </div>
                        );
                      })()}
                    </div>
                  </div>

                  <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 shrink-0">
                    {activeCount}/14 Izin
                  </span>
                </div>

                {/* Permissions Breakdown Preview */}
                <div className="py-3 space-y-2 text-xs">
                  <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Status Hak Akses Utama:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {/* Hapus Bahan */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canDeleteProducts
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Hapus Bahan Gudang</span>
                    </span>

                    {/* Edit Mutasi Pembelian */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canEditPurchases
                        ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Edit3 className="w-2.5 h-2.5" />
                      <span>Edit Mutasi Pembelian</span>
                    </span>

                    {/* Hapus Mutasi Pembelian */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canDeletePurchases
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Hapus Mutasi Pembelian</span>
                    </span>

                    {/* Kelola Produk */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canManageProducts
                        ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Boxes className="w-2.5 h-2.5" />
                      <span>Tambah/Edit Bahan</span>
                    </span>

                    {/* Lihat Keuangan */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canViewFinancials
                        ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <BarChart3 className="w-2.5 h-2.5" />
                      <span>Omset & Laba</span>
                    </span>

                    {/* Restok Supplier */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canRestock
                        ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <span>Restok Masuk</span>
                    </span>

                    {/* Pakai Produksi */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canUseForProduction
                        ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Layers className="w-2.5 h-2.5" />
                      <span>Pakai Produksi</span>
                    </span>

                    {/* Edit Pemakaian Produksi */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canEditProductionUsage
                        ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Edit3 className="w-2.5 h-2.5" />
                      <span>Edit SPK Produksi</span>
                    </span>

                    {/* Hapus Pemakaian Produksi */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canDeleteProductionUsage
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Hapus SPK Produksi</span>
                    </span>

                    {/* Buat Faktur Invoice */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canCreateSalesInvoice
                        ? 'bg-teal-500/15 text-teal-300 border-teal-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <FileText className="w-2.5 h-2.5" />
                      <span>Faktur Penjualan</span>
                    </span>

                    {/* Edit Faktur Invoice */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canEditSalesInvoice
                        ? 'bg-teal-500/15 text-teal-300 border-teal-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Edit3 className="w-2.5 h-2.5" />
                      <span>Edit Faktur</span>
                    </span>

                    {/* Hapus Faktur Invoice */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canDeleteSalesInvoice
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Hapus Faktur</span>
                    </span>

                    {/* Kelola Cicilan & Pembayaran */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canManagePayments
                        ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <CreditCard className="w-2.5 h-2.5" />
                      <span>Cicilan & Piutang</span>
                    </span>

                    {/* Master Data */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canManageMasterData
                        ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <span>Master Data</span>
                    </span>

                    {/* Identitas Usaha & Profil */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canManageCompanyProfile
                        ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Building2 className="w-2.5 h-2.5" />
                      <span>Identitas Usaha</span>
                    </span>

                    {/* Atur Hak Akses */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canManageAccessControl
                        ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <ShieldCheck className="w-2.5 h-2.5" />
                      <span>Atur Hak Akses</span>
                    </span>

                    {/* Hapus Log Audit */}
                    <span className={`px-2 py-0.5 rounded-lg text-[10px] font-semibold flex items-center gap-1 border ${
                      user.canDeleteLogs
                        ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                        : 'bg-slate-950 text-slate-600 border-slate-800 line-through opacity-60'
                    }`}>
                      <Trash2 className="w-2.5 h-2.5" />
                      <span>Hapus Log</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-1.5">
                  {users.length > 1 && !isCurrent && currentUser.role === 'owner' && (
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmUser(user)}
                      className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors cursor-pointer"
                      title="Hapus Akun Pengguna"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {currentUser.role !== 'owner' && user.role === 'owner' ? (
                  <span
                    className="px-3 py-1.5 bg-slate-950/70 border border-slate-800 text-slate-500 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-not-allowed"
                    title="Akun Pemilik Usaha (Owner) terproteksi dan hanya dapat dikelola oleh Pemilik"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-500" />
                    <span>Akun Owner Terproteksi</span>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingUser({ ...user });
                      setErrorMessage(null);
                    }}
                    className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 active:scale-95 transition-all shadow-sm cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Ubah Hak Akses & Profil</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* ================= MODAL EDIT HAK AKSES PENGGUNA ================= */}
      {editingUser && (
        <div className="fixed inset-0 z-60 overflow-y-auto p-3 sm:p-6 bg-slate-950/90 backdrop-blur-md flex justify-center items-start">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full shadow-2xl text-slate-100 my-4 sm:my-8 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="px-5 py-4 border-b border-slate-800 bg-slate-900/98 sticky top-0 z-20 flex items-center justify-between gap-3 shadow-xs">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${editingUser.avatarColor} text-white flex items-center justify-center font-bold text-sm shadow shrink-0`}>
                  {editingUser.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    Kelola Hak Akses: {editingUser.name}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Aktifkan atau nonaktifkan fitur sistem dengan memberi centang checklist.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveEditingUser} className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              
              {/* 1. Profil & Predikat Identitas */}
              <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  1. Identitas Akun & Predikat Jabatan
                </span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Nama Pengguna <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={editingUser.name}
                      onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Predikat / Label Jabatan <span className="text-cyan-400 font-normal">(Identitas)</span>
                    </label>
                    <input
                      type="text"
                      value={editingUser.roleTitle}
                      onChange={(e) => setEditingUser({ ...editingUser, roleTitle: e.target.value })}
                      placeholder="Contoh: Owner, SPV Gudang, Kasir Toko..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Email</label>
                    <input
                      type="email"
                      value={editingUser.email}
                      onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Kata Sandi <span className="text-emerald-400 font-normal">(Non-Hash)</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showEditPassword ? 'text' : 'password'}
                        value={editingUser.password || ''}
                        onChange={(e) => setEditingUser({ ...editingUser, password: e.target.value })}
                        placeholder="Sandi login..."
                        className="w-full pl-3 pr-8 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowEditPassword(!showEditPassword)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                        tabIndex={-1}
                      >
                        {showEditPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Warna Avatar</label>
                    <div className="flex items-center gap-2 pt-1">
                      {['bg-indigo-600', 'bg-emerald-600', 'bg-amber-600', 'bg-blue-600', 'bg-rose-600', 'bg-purple-600', 'bg-teal-600'].map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => setEditingUser({ ...editingUser, avatarColor: color })}
                          className={`w-6 h-6 rounded-full ${color} transition-transform ${
                            editingUser.avatarColor === color ? 'ring-2 ring-white scale-110 shadow' : 'opacity-70 hover:opacity-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Quick Presets Templates */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                    2. Terapkan Template Cepat (Preset Otomatis)
                  </span>
                  <span className="text-[10px] text-slate-500">Klik untuk mengisi checklist otomatis:</span>
                </div>

                <div className="flex items-center gap-2 flex-wrap text-xs">
                  <button
                    type="button"
                    onClick={() => applyPresetToEditing('owner')}
                    className="px-2.5 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    👑 Template Owner (Semua Izin Aktif)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToEditing('spv')}
                    className="px-2.5 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    📦 Template SPV Gudang (Hapus & Kelola Bahan Aktif)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToEditing('cashier')}
                    className="px-2.5 py-1.5 bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    🛍️ Template Kasir (Faktur & Cicilan)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToEditing('production')}
                    className="px-2.5 py-1.5 bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 border border-blue-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    ⚙️ Template Operator Produksi
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToEditing('readonly')}
                    className="px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all active:scale-95"
                  >
                    👁️ Kosongkan / Read-Only
                  </button>
                </div>
              </div>

              {/* 3. Granular Checklist Matrix */}
              <div className="space-y-4">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  3. Checklist Hak Akses Granular
                </span>

                {/* GRUP A: Master Bahan & Inventaris Gudang */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs">
                    <Boxes className="w-4 h-4" />
                    <span>Modul Master Inventaris & Bahan Baku</span>
                  </div>

                  {/* canDeleteProducts: HIGHLIGHTED PER USER REQUEST */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl bg-rose-950/20 border border-rose-500/30 hover:bg-rose-950/30 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(editingUser.canDeleteProducts)}
                      onChange={(e) => setEditingUser({ ...editingUser, canDeleteProducts: e.target.checked })}
                      className="mt-0.5 rounded text-rose-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-white text-xs">Aksi Hapus Bahan Baku (Delete Stok)</strong>
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                          AKSI KRUSIAL
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengaktifkan tombol <strong>"Hapus Bahan"</strong> pada tabel, kartu stok, dan modal edit. Pengguna dengan centang ini diizinkan menghapus bahan baku dari master inventaris gudang.
                      </p>
                    </div>
                  </label>

                  {/* canManageProducts */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canManageProducts}
                      onChange={(e) => setEditingUser({ ...editingUser, canManageProducts: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Tambah & Edit Data Bahan Baku</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat mendaftarkan bahan baru, mengubah spesifikasi, harga beli (HPP), harga jual, dan batas stok minimum.
                      </p>
                    </div>
                  </label>

                  {/* canManageMasterData */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(editingUser.canManageMasterData)}
                      onChange={(e) => setEditingUser({ ...editingUser, canManageMasterData: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Master Data Kategori, Unit & Rak</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat membuka modal Master Data untuk menambah, mengubah, atau menghapus kategori, satuan, rak gudang, supplier, dan divisi.
                      </p>
                    </div>
                  </label>
                </div>

                {/* GRUP B: Transaksi Operasional Gudang & Kasir */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <ShoppingCart className="w-4 h-4" />
                    <span>Modul Mutasi Transaksi & Kasir Penjualan</span>
                  </div>

                  {/* canRestock */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canRestock}
                      onChange={(e) => setEditingUser({ ...editingUser, canRestock: e.target.checked })}
                      className="mt-0.5 rounded text-emerald-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Input Restok Bahan Masuk (Pembelian Supplier)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan pencatatan mutasi barang masuk yang menambah stok fisik gudang.
                      </p>
                    </div>
                  </label>

                  {/* canEditPurchases */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canEditPurchases ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canEditPurchases: e.target.checked })}
                      className="mt-0.5 rounded text-amber-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Catatan Mutasi Pembelian Bahan Baku</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan pengubahan kuantiti, harga beli/HPP, supplier, dan PO pada mutasi pembelian dengan penyesuaian stok otomatis.
                      </p>
                    </div>
                  </label>

                  {/* canDeletePurchases */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canDeletePurchases ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canDeletePurchases: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Catatan Mutasi Pembelian (Revert Stok)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan penghapusan catatan pembelian dan otomatis mengembalikan (mengurangi) stok fisik di gudang.
                      </p>
                    </div>
                  </label>

                  {/* canStockOpname */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canStockOpname ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canStockOpname: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Stok Opname & Penyesuaian Fisik Gudang</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan akses modul Stok Opname, pengisian stok fisik, dan eksekusi berita acara rekonsiliasi.
                      </p>
                    </div>
                  </label>

                  {/* canUseForProduction */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canUseForProduction}
                      onChange={(e) => setEditingUser({ ...editingUser, canUseForProduction: e.target.checked })}
                      className="mt-0.5 rounded text-blue-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Catat Pemakaian Produksi Sablon (Internal / Divisi)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat mengakses modul Pakai Produksi untuk mengurangi stok bahan baku sesuai kebutuhan pesanan cetak.
                      </p>
                    </div>
                  </label>

                  {/* canEditProductionUsage */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canEditProductionUsage ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canEditProductionUsage: e.target.checked })}
                      className="mt-0.5 rounded text-indigo-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Riwayat Pemakaian Produksi Sendiri</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan pengubahan nomor SPK, divisi pemesan, nama pengambil, kuantiti, dan status tagihan pemakaian internal dengan penyesuaian stok otomatis.
                      </p>
                    </div>
                  </label>

                  {/* canDeleteProductionUsage */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canDeleteProductionUsage ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canDeleteProductionUsage: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Riwayat Pemakaian Produksi & Revert Stok Gudang</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan penghapusan catatan pemakaian produksi SPK dan otomatis mengembalikan (menambah kembali) stok bahan baku ke gudang.
                      </p>
                    </div>
                  </label>

                  {/* canCreateSalesInvoice */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canCreateSalesInvoice}
                      onChange={(e) => setEditingUser({ ...editingUser, canCreateSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-teal-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Buat & Terbitkan Faktur Penjualan Bahan</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat menjual bahan baku ke konsumen luar dan menerbitkan invoice resmi.
                      </p>
                    </div>
                  </label>

                  {/* canEditSalesInvoice */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canEditSalesInvoice ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canEditSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-teal-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Data Faktur Penjualan (Invoice)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan pengubahan data konsumen, tanggal jatuh tempo, rincian barang, dan harga pada faktur yang telah terbit.
                      </p>
                    </div>
                  </label>

                  {/* canDeleteSalesInvoice */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canDeleteSalesInvoice ?? false}
                      onChange={(e) => setEditingUser({ ...editingUser, canDeleteSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Faktur Penjualan & Revert Stok Bahan</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan pembatalan/penghapusan faktur invoice penjualan dan otomatis mengembalikan seluruh stok bahan baku terkait ke gudang.
                      </p>
                    </div>
                  </label>

                  {/* canManagePayments */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(editingUser.canManagePayments)}
                      onChange={(e) => setEditingUser({ ...editingUser, canManagePayments: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Catat Pembayaran Cicilan & Pelunasan Piutang</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat mencatat penerimaan cicilan bertahap, kuitansi tanda terima kasir, dan mengubah status faktur.
                      </p>
                    </div>
                  </label>
                </div>

                {/* GRUP C: Finansial, Laporan & Pengawasan Sistem */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-purple-400 font-bold text-xs">
                    <BarChart3 className="w-4 h-4" />
                    <span>Modul Finansial, Laporan & Keamanan Sistem</span>
                  </div>

                  {/* canViewFinancials */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canViewFinancials}
                      onChange={(e) => setEditingUser({ ...editingUser, canViewFinancials: e.target.checked })}
                      className="mt-0.5 rounded text-amber-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Lihat Omset, Laba Bersih & Dasbor Analitik</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Menampilkan grafik profit, total omset, nilai rupiah aset stok, dan harga modal (HPP) rahasia.
                      </p>
                    </div>
                  </label>

                  {/* canExportReports */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canExportReports ?? true}
                      onChange={(e) => setEditingUser({ ...editingUser, canExportReports: e.target.checked })}
                      className="mt-0.5 rounded text-emerald-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Ekspor Laporan (Excel / CSV / PDF)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Mengizinkan unduh berkas rekapitulasi inventaris dan histori mutasi.
                      </p>
                    </div>
                  </label>

                  {/* canManageAccessControl */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(editingUser.canManageAccessControl)}
                      onChange={(e) => setEditingUser({ ...editingUser, canManageAccessControl: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Pengguna & Pengaturan Hak Akses (RBAC)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat membuka halaman ini dan mengubah izin checklist pengguna lainnya.
                      </p>
                    </div>
                  </label>

                  {/* canManageCompanyProfile */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={Boolean(editingUser.canManageCompanyProfile)}
                      onChange={(e) => setEditingUser({ ...editingUser, canManageCompanyProfile: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Identitas Perusahaan & Branding Aplikasi</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat mengatur nama usaha, alamat, kontak, rekening bank nota, kop surat faktur, pejabat penandatangan, dan branding aplikasi.
                      </p>
                    </div>
                  </label>

                  {/* canDeleteLogs */}
                  <label className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-900 cursor-pointer transition-colors">
                    <input
                      type="checkbox"
                      checked={editingUser.canDeleteLogs}
                      onChange={(e) => setEditingUser({ ...editingUser, canDeleteLogs: e.target.checked })}
                      className="mt-0.5 rounded text-rose-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Riwayat Log Aktivitas Audit</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Dapat menghapus riwayat pencatatan log aktivitas sistem.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Modal Footer Actions */}
              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-800 sticky bottom-0 bg-slate-900 py-2">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-cyan-900/40 active:scale-95 transition-all"
                >
                  <Check className="w-4 h-4" />
                  <span>Simpan Perubahan Hak Akses</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ================= MODAL TAMBAH PENGGUNA BARU ================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-60 overflow-y-auto p-3 sm:p-6 bg-slate-950/90 backdrop-blur-md flex justify-center items-start">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full shadow-2xl text-slate-100 my-4 sm:my-8 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
            
            <div className="px-5 py-4 border-b border-slate-800 bg-slate-900/98 sticky top-0 z-20 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-sm shadow shrink-0">
                  <UserPlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Tambah Pengguna & Tentukan Hak Akses</h3>
                  <p className="text-xs text-slate-400">Buat identitas akun baru dan centang izin yang diinginkan.</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateNewUser} className="p-5 sm:p-6 space-y-6 overflow-y-auto max-h-[calc(90vh-140px)]">
              {/* Form Input fields */}
              <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Nama Lengkap Pengguna <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                      placeholder="Contoh: Farhan Ardiansyah"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Predikat / Jabatan Identitas <span className="text-cyan-400 font-normal">(Label)</span>
                    </label>
                    <input
                      type="text"
                      value={newUserRoleTitle}
                      onChange={(e) => setNewUserRoleTitle(e.target.value)}
                      placeholder="Contoh: Supervisor Gudang (SPV), Staff QC..."
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Email</label>
                    <input
                      type="email"
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                      placeholder="farhan@cetakprint.com"
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">
                      Kata Sandi <span className="text-emerald-400 font-normal">(Non-Hash)</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showNewUserPassword ? 'text' : 'password'}
                        value={newUserPassword}
                        onChange={(e) => setNewUserPassword(e.target.value)}
                        placeholder="Minimal 3 karakter..."
                        className="w-full pl-3 pr-8 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white focus:border-cyan-500 focus:outline-hidden font-mono"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewUserPassword(!showNewUserPassword)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-1"
                        tabIndex={-1}
                      >
                        {showNewUserPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-300 block mb-1">Warna Avatar</label>
                    <div className="flex items-center gap-2 pt-1">
                      {['bg-teal-600', 'bg-indigo-600', 'bg-emerald-600', 'bg-amber-600', 'bg-blue-600', 'bg-rose-600', 'bg-purple-600'].map((color) => (
                        <button
                          key={color}
                          type="button"
                          onClick={() => setNewUserAvatarColor(color)}
                          className={`w-6 h-6 rounded-full ${color} transition-transform ${
                            newUserAvatarColor === color ? 'ring-2 ring-white scale-110 shadow' : 'opacity-70 hover:opacity-100'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Template Buttons */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Pilihan Cepat Template Checklist:
                </span>
                <div className="flex items-center gap-2 flex-wrap text-xs">
                  <button
                    type="button"
                    onClick={() => applyPresetToNewUser('owner')}
                    className="px-2.5 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    👑 Preset Owner
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToNewUser('spv')}
                    className="px-2.5 py-1.5 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    📦 Preset SPV (Hapus Bahan Aktif)
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToNewUser('cashier')}
                    className="px-2.5 py-1.5 bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    🛍️ Preset Kasir
                  </button>
                  <button
                    type="button"
                    onClick={() => applyPresetToNewUser('production')}
                    className="px-2.5 py-1.5 bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 border border-blue-500/30 rounded-xl font-semibold transition-all active:scale-95"
                  >
                    ⚙️ Preset Produksi
                  </button>
                </div>
              </div>

              {/* Checklist Switches */}
              <div className="space-y-4">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Checklist Hak Akses Operasional:
                </span>

                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-2.5 text-xs">
                  {/* canDeleteProducts */}
                  <label className="flex items-start gap-3 p-2 rounded-lg bg-rose-950/20 border border-rose-500/30 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canDeleteProducts}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canDeleteProducts: e.target.checked })}
                      className="mt-0.5 rounded text-rose-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block text-rose-300">Aksi Hapus Bahan Baku (Delete Stok)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">Tombol hapus bahan aktif di tabel & kartu stok.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canManageProducts}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canManageProducts: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Tambah & Edit Data Bahan Baku</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">Menambah dan mengedit produk & batas stok.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canRestock}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canRestock: e.target.checked })}
                      className="mt-0.5 rounded text-emerald-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Input Restok Bahan Masuk (Pembelian Supplier)</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canEditPurchases}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canEditPurchases: e.target.checked })}
                      className="mt-0.5 rounded text-amber-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Catatan Mutasi Pembelian Bahan Baku</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">Ubah kuantiti, harga beli, supplier, dan PO mutasi pembelian.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canDeletePurchases}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canDeletePurchases: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Catatan Mutasi Pembelian (Revert Stok)</strong>
                      <p className="text-[11px] text-slate-400 mt-0.5">Hapus pembelian dan kembalikan stok gudang secara otomatis.</p>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canStockOpname}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canStockOpname: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Stok Opname & Penyesuaian Fisik Gudang</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canUseForProduction}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canUseForProduction: e.target.checked })}
                      className="mt-0.5 rounded text-blue-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Catat Pemakaian Produksi Sablon</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canEditProductionUsage}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canEditProductionUsage: e.target.checked })}
                      className="mt-0.5 rounded text-indigo-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Riwayat Pemakaian Produksi Sendiri</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canDeleteProductionUsage}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canDeleteProductionUsage: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block text-rose-300">Hapus Pemakaian Produksi & Revert Stok Gudang</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canCreateSalesInvoice}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canCreateSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-teal-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Buat Faktur Penjualan Bahan ke Konsumen</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canEditSalesInvoice}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canEditSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-teal-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Edit Data Faktur Penjualan (Invoice)</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canDeleteSalesInvoice}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canDeleteSalesInvoice: e.target.checked })}
                      className="mt-0.5 rounded text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block text-rose-300">Hapus Faktur Penjualan & Revert Stok Bahan</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canManagePayments}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canManagePayments: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Catat Pembayaran Cicilan & Pelunasan Piutang</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canViewFinancials}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canViewFinancials: e.target.checked })}
                      className="mt-0.5 rounded text-amber-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Lihat Omset, Laba Bersih & Dasbor Analitik</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canManageMasterData}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canManageMasterData: e.target.checked })}
                      className="mt-0.5 rounded text-purple-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Master Data (Kategori, Unit, Rak, Supplier)</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canManageAccessControl}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canManageAccessControl: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Pengguna & Pengaturan Hak Akses (RBAC)</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canManageCompanyProfile}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canManageCompanyProfile: e.target.checked })}
                      className="mt-0.5 rounded text-cyan-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Kelola Identitas Perusahaan & Branding Aplikasi</strong>
                    </div>
                  </label>

                  <label className="flex items-start gap-3 p-2 rounded-lg hover:bg-slate-900 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newUserPermissions.canDeleteLogs}
                      onChange={(e) => setNewUserPermissions({ ...newUserPermissions, canDeleteLogs: e.target.checked })}
                      className="mt-0.5 rounded text-rose-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <div>
                      <strong className="text-white text-xs block">Hapus Riwayat Log Aktivitas Audit</strong>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Izinkan akun ini menghapus catatan pada Log Aktivitas.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-cyan-900/40 active:scale-95 transition-all"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Daftarkan Pengguna Baru</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* ================= MODAL KONFIRMASI HAPUS PENGGUNA ================= */}
      {deleteConfirmUser && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Hapus Akun Pengguna</h3>
                <p className="text-xs text-rose-300">Tindakan ini permanen dan tidak dapat dibatalkan.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 my-4 leading-relaxed">
              Apakah Anda yakin ingin menghapus akun pengguna <strong>{deleteConfirmUser.name}</strong> ({deleteConfirmUser.roleTitle})? Pengguna ini tidak akan dapat login lagi ke sistem.
            </p>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmUser(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleDeleteUserConfirm}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all active:scale-95 shadow-md shadow-rose-900/30"
              >
                Ya, Hapus Pengguna
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
