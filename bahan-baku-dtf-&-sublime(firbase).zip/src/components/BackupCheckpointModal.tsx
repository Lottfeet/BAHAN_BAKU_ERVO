import React, { useState, useEffect, useRef } from 'react';
import { 
  Database, 
  Download, 
  Upload, 
  RotateCcw, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Trash2, 
  HardDrive, 
  ShieldCheck, 
  FileJson, 
  Plus, 
  Calendar, 
  User as UserIcon,
  Layers,
  ShoppingBag,
  FileText,
  X,
  Sparkles,
  ArrowRight,
  Eye,
  Check, 
  History,
  Cloud,
  RefreshCw,
  Wifi,
  WifiOff
} from 'lucide-react';
import { 
  Product, 
  StockMovement, 
  Invoice, 
  CategoryItem, 
  SupplierItem, 
  CustomerItem, 
  ActivityLog, 
  User, 
  SystemCheckpoint, 
  BackupFileData,
  CompanyProfile
} from '../types';
import { formatRupiah } from '../utils/helpers';

interface BackupCheckpointModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  products: Product[];
  movements: StockMovement[];
  invoices: Invoice[];
  categories: CategoryItem[];
  units: string[];
  locations: string[];
  suppliers: SupplierItem[];
  customers: CustomerItem[];
  divisions: string[];
  logs: ActivityLog[];
  users?: User[];
  companyProfile?: CompanyProfile;
  onRestoreCheckpoint: (snapshot: SystemCheckpoint['snapshot'], label: string) => void;
  onRestoreBackupFile: (data: BackupFileData['data'], backupInfo: { date: string; by: string }) => void;
  onClearOperationalData?: () => Promise<void> | void;
  onUploadLocalToCloud?: () => Promise<{ success: boolean; message: string }>;
  cloudSyncStatus?: 'connected' | 'syncing' | 'offline';
  lastSyncTime?: string;
}

export const BackupCheckpointModal: React.FC<BackupCheckpointModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  products,
  movements,
  invoices,
  categories,
  units,
  locations,
  suppliers,
  customers,
  divisions,
  logs,
  users,
  companyProfile,
  onRestoreCheckpoint,
  onRestoreBackupFile,
  onClearOperationalData,
  onUploadLocalToCloud,
  cloudSyncStatus = 'connected',
  lastSyncTime,
}) => {
  const [activeTab, setActiveTab] = useState<'checkpoint' | 'backup' | 'cloud'>('checkpoint');
  const [isUploadingCloud, setIsUploadingCloud] = useState(false);
  const [checkpoints, setCheckpoints] = useState<SystemCheckpoint[]>(() => {
    try {
      const saved = localStorage.getItem('dtf_sublime_checkpoints');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [manualNote, setManualNote] = useState('');
  const [isCreatingCheckpoint, setIsCreatingCheckpoint] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  
  // Restore Confirmation state
  const [confirmRestoreCheckpoint, setConfirmRestoreCheckpoint] = useState<SystemCheckpoint | null>(null);
  const [uploadedBackupData, setUploadedBackupData] = useState<BackupFileData | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  const [confirmClearText, setConfirmClearText] = useState('');

  // Dedicated Checkpoint Snapshot Detail Inspection
  const [viewingCheckpoint, setViewingCheckpoint] = useState<SystemCheckpoint | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState<'movements' | 'invoices' | 'products' | 'master'>('movements');

  // Auto-hide toast
  useEffect(() => {
    if (toastMessage) {
      const t = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(t);
    }
  }, [toastMessage]);

  // Save checkpoints to localStorage
  const saveCheckpointsToStorage = (updated: SystemCheckpoint[]) => {
    setCheckpoints(updated);
    localStorage.setItem('dtf_sublime_checkpoints', JSON.stringify(updated));
  };

  const calculateTotalStockValue = (prodList: Product[]) => {
    return prodList.reduce((acc, p) => acc + (p.currentStock * p.costPrice), 0);
  };

  // Create Checkpoint handler
  const handleCreateManualCheckpoint = () => {
    setIsCreatingCheckpoint(true);
    try {
      const now = new Date();
      const formatted = now.toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });

      const restockCount = movements.filter((m) => m.type === 'restock').length;
      const productionCount = movements.filter((m) => m.type === 'production').length;
      const saleCount = movements.filter((m) => m.type === 'sale').length;
      const adjustmentCount = movements.filter((m) => m.type === 'adjustment').length;

      const newCheckpoint: SystemCheckpoint = {
        id: `cp-${Date.now()}`,
        timestamp: now.toISOString(),
        formattedTime: formatted,
        type: 'manual',
        label: manualNote.trim() || `Checkpoint Manual (${currentUser.roleTitle})`,
        creatorName: currentUser.name,
        creatorRole: currentUser.roleTitle,
        summary: {
          productsCount: products.length,
          movementsCount: movements.length,
          movementsBreakdown: {
            restockCount,
            productionCount,
            saleCount,
            adjustmentCount,
          },
          invoicesCount: invoices.length,
          logsCount: logs.length,
          totalStockValue: calculateTotalStockValue(products),
        },
        snapshot: {
          products: JSON.parse(JSON.stringify(products)),
          movements: JSON.parse(JSON.stringify(movements)),
          invoices: JSON.parse(JSON.stringify(invoices)),
          categories: JSON.parse(JSON.stringify(categories)),
          units: JSON.parse(JSON.stringify(units)),
          locations: JSON.parse(JSON.stringify(locations)),
          suppliers: JSON.parse(JSON.stringify(suppliers)),
          customers: JSON.parse(JSON.stringify(customers)),
          divisions: JSON.parse(JSON.stringify(divisions)),
          logs: JSON.parse(JSON.stringify(logs)),
          users: users ? JSON.parse(JSON.stringify(users)) : undefined,
          companyProfile: companyProfile ? JSON.parse(JSON.stringify(companyProfile)) : undefined,
        },
      };

      // Keep up to 15 latest checkpoints
      const updated = [newCheckpoint, ...checkpoints.slice(0, 14)];
      saveCheckpointsToStorage(updated);
      setManualNote('');
      setToastMessage({
        type: 'success',
        text: `Checkpoint manual "${newCheckpoint.label}" berhasil disimpan!`,
      });
    } catch {
      setToastMessage({
        type: 'error',
        text: 'Gagal membuat checkpoint: Memori penyimpanan penuh.',
      });
    } finally {
      setIsCreatingCheckpoint(false);
    }
  };

  // Delete Checkpoint
  const handleDeleteCheckpoint = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = checkpoints.filter((c) => c.id !== id);
    saveCheckpointsToStorage(updated);
    setToastMessage({
      type: 'success',
      text: 'Titik checkpoint telah dihapus dari daftar riwayat.',
    });
  };

  // Execute Restore from Checkpoint
  const handleExecuteRestoreCheckpoint = async () => {
    if (!confirmRestoreCheckpoint) return;
    setIsRestoring(true);
    try {
      await onRestoreCheckpoint(confirmRestoreCheckpoint.snapshot, confirmRestoreCheckpoint.label);
      setConfirmRestoreCheckpoint(null);
      setToastMessage({
        type: 'success',
        text: `Sistem berhasil dipulihkan ke titik: "${confirmRestoreCheckpoint.label}" & tersinkron ke semua perangkat!`,
      });
    } catch {
      setToastMessage({
        type: 'error',
        text: 'Gagal memulihkan titik checkpoint.',
      });
    } finally {
      setIsRestoring(false);
    }
  };

  // Download Local Backup File (JSON)
  const handleDownloadBackup = () => {
    try {
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, '-');
      
      const restockCount = movements.filter((m) => m.type === 'restock').length;
      const productionCount = movements.filter((m) => m.type === 'production').length;
      const saleCount = movements.filter((m) => m.type === 'sale').length;
      const adjustmentCount = movements.filter((m) => m.type === 'adjustment').length;

      const backupPayload: BackupFileData = {
        appName: companyProfile?.appName || 'DTF & Sublimation Inventory Pro',
        appVersion: companyProfile?.appVersion || '2.5',
        backupDate: now.toISOString(),
        exportedBy: currentUser.name,
        exportedRole: currentUser.roleTitle,
        summary: {
          productsCount: products.length,
          movementsCount: movements.length,
          movementsBreakdown: {
            restockCount,
            productionCount,
            saleCount,
            adjustmentCount,
          },
          invoicesCount: invoices.length,
          logsCount: logs.length,
          totalStockValue: calculateTotalStockValue(products),
        },
        data: {
          products,
          movements,
          invoices,
          categories,
          units,
          locations,
          suppliers,
          customers,
          divisions,
          logs,
          users,
          companyProfile,
        },
      };

      const jsonStr = JSON.stringify(backupPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_dtf_sublimasi_${dateStr}_${timeStr}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      setToastMessage({
        type: 'success',
        text: 'File cadangan lokal (.json) berhasil diunduh ke perangkat Anda!',
      });
    } catch {
      setToastMessage({
        type: 'error',
        text: 'Gagal mengunduh file cadangan.',
      });
    }
  };

  // Handle File Upload for Restore
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null);
    setUploadedBackupData(null);
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.name.endsWith('.json')) {
      setFileError('Format file tidak valid. Harap pilih file cadangan dengan ekstensi .json.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed: BackupFileData = JSON.parse(text);

        // Validation check
        if (!parsed.data || !Array.isArray(parsed.data.products) || !Array.isArray(parsed.data.movements)) {
          setFileError('Struktur data cadangan tidak sesuai standar DTF & Sublimation Inventory.');
          return;
        }

        setUploadedBackupData(parsed);
      } catch {
        setFileError('Gagal membaca isi file JSON cadangan. File mungkin rusak atau tidak valid.');
      }
    };
    reader.readAsText(file);
  };

  // Execute Restore from File
  const handleExecuteRestoreFile = async () => {
    if (!uploadedBackupData) return;
    setIsRestoring(true);
    try {
      const backupDateFormatted = new Date(uploadedBackupData.backupDate).toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });

      await onRestoreBackupFile(uploadedBackupData.data, {
        date: backupDateFormatted,
        by: uploadedBackupData.exportedBy || 'Cadangan Sistem',
      });

      setUploadedBackupData(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setToastMessage({
        type: 'success',
        text: 'Pemulihan data dari file lokal berhasil diterapkan & tersinkron ke semua perangkat!',
      });
    } catch {
      setToastMessage({
        type: 'error',
        text: 'Gagal memulihkan data dari file cadangan.',
      });
    } finally {
      setIsRestoring(false);
    }
  };

  // Execute Clear Operational Data
  const handleExecuteClearData = async () => {
    if (!onClearOperationalData) return;
    setIsRestoring(true);
    try {
      await onClearOperationalData();
      setShowClearModal(false);
      setConfirmClearText('');
      setToastMessage({
        type: 'success',
        text: 'Seluruh data operasional (stok, mutasi, invoice) berhasil dikosongkan & tersinkron ke semua perangkat!',
      });
    } catch {
      setToastMessage({
        type: 'error',
        text: 'Gagal mengosongkan data operasional.',
      });
    } finally {
      setIsRestoring(false);
    }
  };

  // Execute Upload Local Data to Cloud Firestore
  const handleExecuteUploadCloud = async () => {
    if (!onUploadLocalToCloud) return;
    setIsUploadingCloud(true);
    try {
      const result = await onUploadLocalToCloud();
      setToastMessage({
        type: result.success ? 'success' : 'error',
        text: result.message,
      });
    } catch (err: any) {
      setToastMessage({
        type: 'error',
        text: err?.message || 'Gagal mengunggah data lokal ke cloud database.',
      });
    } finally {
      setIsUploadingCloud(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between shrink-0 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Checkpoint Berkala & Backup Lokal</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-medium">
                  SPV & Owner
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Pencadangan otomatis, titik pemulihan instan, dan ekspor/impor file JSON
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 pb-0 border-b border-slate-800 bg-slate-950/40 flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('checkpoint')}
            className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'checkpoint'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>Titik Checkpoint Berkala ({checkpoints.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'backup'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <HardDrive className="w-4 h-4" />
            <span>Backup & Restore File Lokal (.json)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('cloud')}
            className={`pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'cloud'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cloud className="w-4 h-4" />
            <span>Sinkronisasi Cloud & Unggah Ulang</span>
            {cloudSyncStatus === 'offline' && (
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" title="Database saat ini offline / terkena limit kuota" />
            )}
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* Toast Notification */}
          {toastMessage && (
            <div className={`p-3.5 rounded-2xl border flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-top-2 duration-200 ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/80 border-rose-500/40 text-rose-200'
            }`}>
              {toastMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              )}
              <span>{toastMessage.text}</span>
            </div>
          )}

          {/* TAB 1: CHECKPOINT BERKALA */}
          {activeTab === 'checkpoint' && (
            <div className="space-y-6">
              {/* Checkpoint Status Banner & Manual Creator */}
              <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-xs font-bold text-white">Auto-Checkpoint Berkala Aktif</h4>
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                      Sistem membuat rekaman snapshot otomatis setiap <strong>5 menit</strong> saat terjadi perubahan data, menyimpan hingga 15 rekaman terbaru di browser.
                    </p>
                  </div>
                </div>

                {/* Form Buat Checkpoint Manual */}
                <div className="flex items-center gap-2 shrink-0">
                  <input
                    type="text"
                    placeholder="Catatan checkpoint (opsional)..."
                    value={manualNote}
                    onChange={(e) => setManualNote(e.target.value)}
                    className="px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-full sm:w-56"
                  />
                  <button
                    type="button"
                    onClick={handleCreateManualCheckpoint}
                    disabled={isCreatingCheckpoint}
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 transition-all active:scale-95 shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Buat Checkpoint</span>
                  </button>
                </div>
              </div>

              {/* Checkpoint List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Daftar Titik Pemulihan (Snapshots)</span>
                  </h3>
                  <span className="text-[11px] text-slate-500">
                    {checkpoints.length} Titik Tersimpan
                  </span>
                </div>

                {checkpoints.length === 0 ? (
                  <div className="p-8 text-center rounded-2xl bg-slate-950/40 border border-dashed border-slate-800 text-slate-400">
                    <Database className="w-8 h-8 mx-auto mb-2 text-slate-600 opacity-60" />
                    <p className="text-xs font-semibold text-slate-300">Belum ada titik checkpoint tersimpan</p>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-sm mx-auto">
                      Klik tombol "Buat Checkpoint" di atas untuk menyimpan titik cadangan instan sekarang.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {checkpoints.map((cp) => {
                      const isAuto = cp.type === 'auto';
                      const movementsList = cp.snapshot?.movements || [];
                      const restockCount = cp.summary.movementsBreakdown?.restockCount ?? movementsList.filter((m) => m.type === 'restock').length;
                      const productionCount = cp.summary.movementsBreakdown?.productionCount ?? movementsList.filter((m) => m.type === 'production').length;
                      const saleCount = cp.summary.movementsBreakdown?.saleCount ?? movementsList.filter((m) => m.type === 'sale').length;
                      const adjustmentCount = cp.summary.movementsBreakdown?.adjustmentCount ?? movementsList.filter((m) => m.type === 'adjustment').length;
                      const invoiceCount = cp.summary.invoicesCount ?? cp.snapshot?.invoices?.length ?? 0;

                      return (
                        <div
                          key={cp.id}
                          className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col md:flex-row md:items-center justify-between gap-3"
                        >
                          <div className="flex items-start gap-3 min-w-0">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${
                              isAuto
                                ? 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-400'
                                : 'bg-indigo-500/15 border border-indigo-500/30 text-indigo-400'
                            }`}>
                              {isAuto ? <Clock className="w-4 h-4" /> : <HardDrive className="w-4 h-4" />}
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-bold text-white text-xs truncate">{cp.label}</span>
                                <span className={`text-[10px] px-2 py-0.2 rounded-full font-semibold border ${
                                  isAuto
                                    ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                                    : 'bg-indigo-950/60 text-indigo-400 border-indigo-500/30'
                                }`}>
                                  {isAuto ? 'Otomatis' : 'Manual'}
                                </span>
                              </div>

                              <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1 flex-wrap font-mono">
                                <span className="flex items-center gap-1 text-slate-300">
                                  <Calendar className="w-3 h-3 text-cyan-400" />
                                  {cp.formattedTime}
                                </span>
                                <span>•</span>
                                <span className="flex items-center gap-1 text-slate-400">
                                  <UserIcon className="w-3 h-3 text-amber-400" />
                                  {cp.creatorName}
                                </span>
                              </div>

                              <div className="flex items-center gap-1.5 mt-2 text-[10px] text-slate-400 flex-wrap">
                                <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-cyan-300 font-medium">
                                  📦 {cp.summary.productsCount} Bahan
                                </span>
                                <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-emerald-300 font-medium">
                                  🧾 {invoiceCount} Faktur Invoice
                                </span>
                                <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-amber-300 font-medium">
                                  📝 {cp.summary.movementsCount} Mutasi (📥 {restockCount} Masuk • ⚙️ {productionCount} SPK • 📤 {saleCount} Jual{adjustmentCount > 0 ? ` • 🔄 ${adjustmentCount} Opname` : ''})
                                </span>
                                <span className="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-indigo-300 font-mono">
                                  💰 Nilai: {formatRupiah(cp.summary.totalStockValue)}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 shrink-0 self-end md:self-center pt-2 md:pt-0 border-t md:border-t-0 border-slate-850 w-full md:w-auto justify-end flex-wrap sm:flex-nowrap">
                            <button
                              type="button"
                              onClick={() => {
                                setViewingCheckpoint(cp);
                                setActiveDetailTab('movements');
                              }}
                              className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer shadow-2xs"
                              title="Lihat rincian daftar mutasi, faktur invoice, dan data dalam snapshot ini"
                            >
                              <Eye className="w-3.5 h-3.5 text-cyan-400" />
                              <span>Rincian Snapshot ({cp.summary.movementsCount} Mutasi)</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmRestoreCheckpoint(cp)}
                              className="px-3 py-1.5 bg-cyan-600/20 hover:bg-cyan-600 text-cyan-300 hover:text-white border border-cyan-500/30 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
                              title="Pulihkan data inventaris ke titik ini"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                              <span>Pulihkan</span>
                            </button>
                            <button
                              type="button"
                              onClick={(e) => handleDeleteCheckpoint(cp.id, e)}
                              className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors cursor-pointer"
                              title="Hapus rekaman checkpoint ini"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: BACKUP & RESTORE FILE JSON */}
          {activeTab === 'backup' && (
            <div className="space-y-6">
              {/* Grid 2 Column: Download Backup & Restore File */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* 1. Download Backup */}
                <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
                  <div>
                    <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-3">
                      <Download className="w-5 h-5" />
                    </div>
                    <h3 className="text-sm font-bold text-white mb-1">Unduh Cadangan Lengkap (.json)</h3>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      Simpan salinan cadangan lengkap seluruh master bahan, mutasi stok, faktur kasir, master data, dan riwayat log ke dalam file JSON di komputer atau flashdisk Anda.
                    </p>

                    <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-[11px] text-slate-300 font-mono mb-4">
                      <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider pb-1 border-b border-slate-800 flex items-center justify-between font-sans">
                        <span>Cakupan Data Cadangan</span>
                        <span className="text-emerald-400 font-bold">100% Lengkap (v2.5)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">📦 Bahan Baku:</span>
                        <span className="font-bold text-cyan-400">{products.length} Item</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">📝 Mutasi (PO/SPK/Jual/Opname):</span>
                        <span className="font-bold text-amber-400">{movements.length} Transaksi</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">🧾 Faktur & Riwayat Cicilan:</span>
                        <span className="font-bold text-emerald-400">{invoices.length} Faktur</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">👥 Pengguna & Hak Akses (RBAC):</span>
                        <span className="font-bold text-indigo-400">{users?.length || 0} Akun</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">🏷️ Master (Kategori/Vendor/Klien):</span>
                        <span className="font-bold text-slate-200">{categories.length} Kat • {suppliers.length} Spl • {customers.length} Cst</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">📜 Riwayat Log Audit:</span>
                        <span className="font-bold text-slate-300">{logs.length} Catatan</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">🏢 Identitas Perusahaan & Profil:</span>
                        <span className="font-bold text-cyan-300 truncate max-w-[190px]">{companyProfile?.companyName || 'Default'}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleDownloadBackup}
                    className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download File Cadangan Sekarang</span>
                  </button>
                </div>

                {/* 2. Upload / Restore from File */}
                <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between">
                  <div>
                    <div className="w-10 h-10 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-3">
                      <Upload className="w-5 h-5" />
                    </div>
                    <h3 className="text-sm font-bold text-white mb-1">Pulihkan Data dari File (.json)</h3>
                    <p className="text-xs text-slate-400 leading-relaxed mb-4">
                      Pilih file cadangan JSON yang telah diunduh sebelumnya untuk mengembalikan seluruh basis data inventaris ke kondisi saat file dibuat.
                    </p>

                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".json"
                      onChange={handleFileChange}
                      className="hidden"
                      id="input-backup-file"
                    />

                    <label
                      htmlFor="input-backup-file"
                      className="w-full p-4 rounded-xl border border-dashed border-slate-700 hover:border-cyan-500 bg-slate-900/60 hover:bg-slate-900 text-center flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors mb-3"
                    >
                      <FileJson className="w-6 h-6 text-cyan-400" />
                      <span className="text-xs font-semibold text-slate-200">
                        {fileInputRef.current?.files?.[0]?.name || 'Pilih atau Seret File Cadangan (.json)'}
                      </span>
                      <span className="text-[10px] text-slate-500">Maksimal 20MB • Hanya format .json</span>
                    </label>

                    {fileError && (
                      <div className="p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-[11px] text-rose-300 font-semibold mb-3 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                        <span>{fileError}</span>
                      </div>
                    )}

                    {uploadedBackupData && (
                      <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 space-y-1 text-[11px] text-emerald-200 font-mono mb-3">
                        <div className="flex items-center gap-1.5 font-bold text-emerald-400 mb-1">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>File Valid & Siap Dipulihkan</span>
                        </div>
                        <div>Tanggal Cadangan: {new Date(uploadedBackupData.backupDate).toLocaleString('id-ID')}</div>
                        <div>Oleh: {uploadedBackupData.exportedBy} ({uploadedBackupData.exportedRole})</div>
                        <div className="text-slate-300">
                          Memuat: {uploadedBackupData.summary.productsCount} Bahan • {uploadedBackupData.summary.movementsCount} Mutasi • {uploadedBackupData.summary.invoicesCount || uploadedBackupData.data?.invoices?.length || 0} Faktur • {uploadedBackupData.data?.users?.length || 0} Akun Hak Akses
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleExecuteRestoreFile}
                    disabled={!uploadedBackupData || isRestoring}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all active:scale-95 cursor-pointer"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>{isRestoring ? 'Memulihkan & Sinkron Cloud...' : 'Terapkan Pemulihan dari File Ini'}</span>
                  </button>
                </div>
              </div>

              {/* Safety Notice */}
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-200 leading-relaxed">
                  <strong>Peringatan Keamanan Data:</strong> Memulihkan data dari checkpoint atau file cadangan akan menimpa data yang sedang aktif saat ini. Sangat disarankan untuk membuat satu <em>Checkpoint Manual</em> sebelum melakukan pemulihan file besar.
                </div>
              </div>

              {/* Danger Zone: Kosongkan Seluruh Data Operasional & Stok */}
              {(currentUser.role === 'owner' || currentUser.role === 'warehouse_admin') && onClearOperationalData && (
                <div className="p-4 sm:p-5 rounded-2xl bg-rose-950/25 border border-rose-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
                      <Trash2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
                        <span>Kosongkan Seluruh Data Operasional & Stok</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          Sinkron Cloud & Semua Perangkat
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                        Menghapus seluruh bahan baku ({products.length} item), riwayat mutasi ({movements.length} transaksi), dan faktur invoice ({invoices.length} faktur) di Cloud Firestore dan langsung disinkronkan ke semua perangkat. Akun pengguna dan hak akses tetap utuh.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmClearText('');
                      setShowClearModal(true);
                    }}
                    className="px-4 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shrink-0 transition-all active:scale-95 cursor-pointer shadow-sm"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Kosongkan Data Sekarang</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SINKRONISASI CLOUD & UNGGAH ULANG */}
          {activeTab === 'cloud' && (
            <div className="space-y-6">
              {/* Architecture & Reliability Banner */}
              <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-slate-900 to-indigo-950/40 border border-cyan-500/30 space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
                    <Cloud className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                      <span>Perlindungan Cadangan Offline & Limit Kuota</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        Otomatis Aktif
                      </span>
                    </h3>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      Sistem ini dirancang dengan arsitektur <strong>Offline-First & Local Storage Shield</strong>: Setiap kali Anda menambah stok, mencatat mutasi pembelian, SPK produksi, atau membuat invoice penjualan, data langsung dicatat ke <em>Local Storage</em> browser perangkat ini terlebih dahulu.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                    <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
                      <HardDrive className="w-4 h-4 text-cyan-400" />
                      <span>1. Aman Saat Offline</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Jika internet terputus, operasional kasir dan gudang tetap bekerja 100% tanpa hambatan.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                    <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-400" />
                      <span>2. Perlindungan Limit Kuota</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Jika kuota baca/tulis cloud habis, data lokal tidak akan hilang atau terganggu sama sekali.
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1">
                    <div className="font-semibold text-emerald-300 flex items-center gap-1.5">
                      <RefreshCw className="w-4 h-4 text-emerald-400" />
                      <span>3. Unggah Ulang (Sync)</span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Setelah online atau kuota reset, unggah seluruh data lokal ke cloud dengan 1 klik.
                    </p>
                  </div>
                </div>
              </div>

              {/* Status Real-Time Cloud Firestore */}
              <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div>
                    <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                      <Database className="w-4 h-4 text-cyan-400" />
                      <span>Status Koneksi Database Cloud</span>
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Penyelarasan real-time ke Google Cloud Firestore
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 border ${
                      cloudSyncStatus === 'connected'
                        ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                        : cloudSyncStatus === 'syncing'
                        ? 'bg-cyan-950/60 text-cyan-300 border-cyan-500/40'
                        : 'bg-amber-950/60 text-amber-300 border-amber-500/40'
                    }`}>
                      {cloudSyncStatus === 'connected' ? (
                        <>
                          <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Terhubung & Aktif</span>
                        </>
                      ) : cloudSyncStatus === 'syncing' ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                          <span>Menyelaraskan Data...</span>
                        </>
                      ) : (
                        <>
                          <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                          <span>Offline / Limit Kuota</span>
                        </>
                      )}
                    </div>
                    {lastSyncTime && (
                      <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                        (Terakhir: {lastSyncTime})
                      </span>
                    )}
                  </div>
                </div>

                {/* Local Storage Inventory Summary Ready for Upload */}
                <div>
                  <h5 className="text-xs font-semibold text-slate-300 mb-2">
                    Rincian Data Lokal Tersimpan yang Siap Diunggah ke Cloud:
                  </h5>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Bahan Baku</span>
                      <span className="text-base font-bold text-cyan-400 font-mono mt-0.5 block">{products.length} Item</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Mutasi & SPK</span>
                      <span className="text-base font-bold text-indigo-400 font-mono mt-0.5 block">{movements.length} Transaksi</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Faktur Penjualan</span>
                      <span className="text-base font-bold text-emerald-400 font-mono mt-0.5 block">{invoices.length} Faktur</span>
                    </div>
                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">Mitra & Kontak</span>
                      <span className="text-base font-bold text-amber-400 font-mono mt-0.5 block">{suppliers.length + customers.length} Kontak</span>
                    </div>
                  </div>
                </div>

                {/* Action Card to Trigger Upload */}
                <div className="pt-2">
                  <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="space-y-0.5">
                      <h4 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                        <span>Unggah Seluruh Data Lokal ke Cloud Firestore</span>
                      </h4>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Gunakan tombol ini saat database telah online kembali atau setelah reset database. Data lokal akan diunggah dan disinkronkan ke cloud untuk seluruh perangkat secara instan.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={handleExecuteUploadCloud}
                      disabled={isUploadingCloud || !onUploadLocalToCloud}
                      className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-2 shrink-0 transition-all active:scale-95 shadow-md shadow-cyan-950/40 cursor-pointer"
                    >
                      {isUploadingCloud ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin text-white" />
                          <span>Mengunggah ke Cloud...</span>
                        </>
                      ) : (
                        <>
                          <Cloud className="w-4 h-4 text-white" />
                          <span>Unggah ke Cloud Sekarang</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Hak akses pencadangan: SPV Gudang & Pemilik Usaha</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>

      {/* CONFIRM RESTORE CHECKPOINT MODAL */}
      {confirmRestoreCheckpoint && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-md p-5 shadow-2xl text-left">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-3">
              <RotateCcw className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white mb-1">
              Konfirmasi Pemulihan Checkpoint
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Apakah Anda yakin ingin memulihkan seluruh data sistem ke titik snapshot:
            </p>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs text-slate-300 mb-4 font-mono">
              <div className="font-bold text-cyan-300">{confirmRestoreCheckpoint.label}</div>
              <div className="text-[11px] text-slate-400">Waktu: {confirmRestoreCheckpoint.formattedTime}</div>
              <div className="text-[11px] text-slate-400">Pembuat: {confirmRestoreCheckpoint.creatorName} ({confirmRestoreCheckpoint.creatorRole})</div>
              <div className="pt-1.5 border-t border-slate-850 flex justify-between text-[11px] text-amber-300">
                <span>{confirmRestoreCheckpoint.summary.productsCount} Bahan Baku</span>
                <span>{confirmRestoreCheckpoint.summary.movementsCount} Mutasi PO/Produksi</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setConfirmRestoreCheckpoint(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleExecuteRestoreCheckpoint}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{isRestoring ? 'Memulihkan...' : 'Ya, Pulihkan Sekarang'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM CLEAR OPERATIONAL DATA MODAL */}
      {showClearModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-rose-500/40 rounded-3xl w-full max-w-md p-5 shadow-2xl text-left">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400 mb-3">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3 className="text-base font-bold text-white mb-1">
              Konfirmasi Kosongkan Data Operasional
            </h3>
            <p className="text-xs text-rose-300 leading-relaxed mb-4">
              Tindakan ini akan <strong>MENGHAPUS SEMUA</strong> bahan baku, mutasi stok, dan faktur penjualan di Cloud Database Firestore dan seluruh perangkat yang terhubung.
            </p>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 text-xs text-slate-300 mb-4 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>📦 Bahan Baku:</span>
                <span className="text-rose-400 font-bold">{products.length} Item akan dihapus</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>📝 Mutasi Stok:</span>
                <span className="text-rose-400 font-bold">{movements.length} Transaksi akan dihapus</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>🧾 Faktur Invoice:</span>
                <span className="text-rose-400 font-bold">{invoices.length} Faktur akan dihapus</span>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-[11px] text-slate-400 mb-1.5">
                Ketik <strong className="text-rose-400 font-mono">KOSONGKAN</strong> di bawah ini untuk konfirmasi:
              </label>
              <input
                type="text"
                value={confirmClearText}
                onChange={(e) => setConfirmClearText(e.target.value)}
                placeholder="Ketik KOSONGKAN"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-700 focus:border-rose-500 rounded-xl text-xs text-white uppercase font-mono focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setShowClearModal(false);
                  setConfirmClearText('');
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleExecuteClearData}
                disabled={confirmClearText.trim() !== 'KOSONGKAN' || isRestoring}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>{isRestoring ? 'Mengosongkan Cloud...' : 'Ya, Kosongkan Sekarang'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL RINCIAN DATA SNAPSHOT CHECKPOINT */}
      {viewingCheckpoint && (() => {
        const cp = viewingCheckpoint;
        const movementsList = cp.snapshot?.movements || [];
        const invoicesList = cp.snapshot?.invoices || [];
        const productsList = cp.snapshot?.products || [];
        const logsList = cp.snapshot?.logs || [];

        const restockCount = cp.summary.movementsBreakdown?.restockCount ?? movementsList.filter((m) => m.type === 'restock').length;
        const productionCount = cp.summary.movementsBreakdown?.productionCount ?? movementsList.filter((m) => m.type === 'production').length;
        const saleCount = cp.summary.movementsBreakdown?.saleCount ?? movementsList.filter((m) => m.type === 'sale').length;
        const adjustmentCount = cp.summary.movementsBreakdown?.adjustmentCount ?? movementsList.filter((m) => m.type === 'adjustment').length;

        return (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-xs animate-in fade-in duration-150">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-left">
              {/* Header */}
              <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
                    <Database className="w-5 h-5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-sm sm:text-base text-white truncate">
                        Rincian Data Snapshot Checkpoint
                      </h3>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border ${
                        cp.type === 'auto'
                          ? 'bg-emerald-950/60 text-emerald-400 border-emerald-500/30'
                          : 'bg-indigo-950/60 text-indigo-400 border-indigo-500/30'
                      }`}>
                        {cp.type === 'auto' ? 'Otomatis' : 'Manual'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5 font-mono truncate">
                      {cp.label} • {cp.formattedTime} • Oleh: {cp.creatorName} ({cp.creatorRole})
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setViewingCheckpoint(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Snapshot Metric Badges Banner */}
              <div className="px-5 py-3 bg-slate-950/60 border-b border-slate-800 flex items-center gap-2 flex-wrap text-xs font-mono shrink-0">
                <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300">
                  📦 <strong>{productsList.length}</strong> Bahan Baku
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-emerald-300">
                  🧾 <strong>{invoicesList.length}</strong> Faktur Invoice
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-amber-300">
                  📝 <strong>{movementsList.length}</strong> Mutasi (📥 {restockCount} Beli, ⚙️ {productionCount} SPK, 📤 {saleCount} Jual)
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-indigo-300">
                  💰 Nilai Stok: <strong>{formatRupiah(cp.summary.totalStockValue)}</strong>
                </span>
                {logsList.length > 0 && (
                  <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-400">
                    🛡️ {logsList.length} Log
                  </span>
                )}
              </div>

              {/* Navigation Tabs */}
              <div className="flex items-center gap-1 px-5 pt-3 border-b border-slate-800 bg-slate-900 shrink-0 overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setActiveDetailTab('movements')}
                  className={`px-3 py-2 text-xs font-bold rounded-t-xl border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeDetailTab === 'movements'
                      ? 'border-amber-400 text-amber-300 bg-slate-850'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <History className="w-3.5 h-3.5" />
                  <span>Daftar Mutasi ({movementsList.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveDetailTab('invoices')}
                  className={`px-3 py-2 text-xs font-bold rounded-t-xl border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeDetailTab === 'invoices'
                      ? 'border-emerald-400 text-emerald-300 bg-slate-850'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Daftar Faktur Invoice ({invoicesList.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveDetailTab('products')}
                  className={`px-3 py-2 text-xs font-bold rounded-t-xl border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeDetailTab === 'products'
                      ? 'border-cyan-400 text-cyan-300 bg-slate-850'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Bahan Baku ({productsList.length})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveDetailTab('master')}
                  className={`px-3 py-2 text-xs font-bold rounded-t-xl border-b-2 flex items-center gap-1.5 transition-colors cursor-pointer ${
                    activeDetailTab === 'master'
                      ? 'border-indigo-400 text-indigo-300 bg-slate-850'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>Master Data & Log</span>
                </button>
              </div>

              {/* Tab Content Body */}
              <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4 text-xs">
                {/* TAB 1: MOVEMENTS */}
                {activeDetailTab === 'movements' && (
                  <div className="space-y-3">
                    {/* Explain Movements Composition */}
                    <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 text-slate-200 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-amber-300">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                        <span>Penjelasan Sumber Mutasi pada Checkpoint:</span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-relaxed">
                        Total <strong>{movementsList.length} Mutasi</strong> pada checkpoint ini berasal dari riwayat aktivitas inventaris gudang:
                      </p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1 font-mono">
                        <div className="p-2 rounded-lg bg-slate-900 border border-emerald-500/30 text-emerald-300">
                          📥 <strong>{restockCount}</strong> Pembelian (Masuk)
                        </div>
                        <div className="p-2 rounded-lg bg-slate-900 border border-blue-500/30 text-blue-300">
                          ⚙️ <strong>{productionCount}</strong> Pakai SPK (Keluar)
                        </div>
                        <div className="p-2 rounded-lg bg-slate-900 border border-cyan-500/30 text-cyan-300">
                          📤 <strong>{saleCount}</strong> Jual Faktur (Keluar)
                        </div>
                        <div className="p-2 rounded-lg bg-slate-900 border border-indigo-500/30 text-indigo-300">
                          🔄 <strong>{adjustmentCount}</strong> Opname Stok
                        </div>
                      </div>
                    </div>

                    {/* Table of Movements */}
                    <div className="border border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-slate-950 text-slate-400 font-semibold uppercase text-[10px] border-b border-slate-800">
                          <tr>
                            <th className="py-2.5 px-3">Tanggal</th>
                            <th className="py-2.5 px-3">Tipe Mutasi</th>
                            <th className="py-2.5 px-3">No. Referensi</th>
                            <th className="py-2.5 px-3">Bahan Baku</th>
                            <th className="py-2.5 px-2 text-right">Kuantiti</th>
                            <th className="py-2.5 px-3">Pihak Terkait / Catatan</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {movementsList.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="py-6 text-center text-slate-500">
                                Tidak ada mutasi dalam snapshot ini
                              </td>
                            </tr>
                          ) : (
                            movementsList.map((m, idx) => {
                              const isRestock = m.type === 'restock';
                              const isProd = m.type === 'production';
                              const isSale = m.type === 'sale';

                              return (
                                <tr key={m.id || idx} className="hover:bg-slate-850/50">
                                  <td className="py-2 px-3 text-slate-400 whitespace-nowrap text-[11px]">{m.date}</td>
                                  <td className="py-2 px-3 whitespace-nowrap">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                      isRestock
                                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                        : isProd
                                        ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                                        : isSale
                                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                                        : 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
                                    }`}>
                                      {isRestock ? '📥 Pembelian (Masuk)' : isProd ? '⚙️ Pakai Produksi' : isSale ? '📤 Penjualan Faktur' : '🔄 Penyesuaian'}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 text-indigo-300 font-semibold whitespace-nowrap text-[11px]">
                                    {m.referenceNo}
                                  </td>
                                  <td className="py-2 px-3 text-white font-sans text-xs">
                                    <div className="font-semibold">{m.productName}</div>
                                    <div className="text-[10px] text-cyan-400 font-mono">{m.productCode}</div>
                                  </td>
                                  <td className="py-2 px-2 text-right whitespace-nowrap">
                                    <span className={`font-bold ${isRestock ? 'text-emerald-400' : 'text-rose-400'}`}>
                                      {isRestock ? `+${m.quantity}` : `-${m.quantity}`} {m.unit}
                                    </span>
                                  </td>
                                  <td className="py-2 px-3 text-slate-300 font-sans text-[11px]">
                                    <div>{m.supplierName || m.divisionOrRequester || m.notes || '-'}</div>
                                    <div className="text-[10px] text-slate-500 font-mono">PIC: {m.recipientName || m.performedBy?.userName || '-'}</div>
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 2: INVOICES */}
                {activeDetailTab === 'invoices' && (
                  <div className="space-y-3">
                    <div className="border border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs border-collapse">
                        <thead className="bg-slate-950 text-slate-400 font-semibold uppercase text-[10px] border-b border-slate-800">
                          <tr>
                            <th className="py-2.5 px-3">No. Faktur</th>
                            <th className="py-2.5 px-3">Tanggal / Tempo</th>
                            <th className="py-2.5 px-3">Pelanggan</th>
                            <th className="py-2.5 px-3 text-right">Total Tagihan</th>
                            <th className="py-2.5 px-3">Status Bayar</th>
                            <th className="py-2.5 px-3">Item Produk</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono">
                          {invoicesList.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="py-6 text-center text-slate-500">
                                Tidak ada data invoice dalam snapshot ini
                              </td>
                            </tr>
                          ) : (
                            invoicesList.map((inv, idx) => (
                              <tr key={inv.id || idx} className="hover:bg-slate-850/50">
                                <td className="py-2 px-3 text-cyan-300 font-bold whitespace-nowrap text-[11px]">{inv.invoiceNumber}</td>
                                <td className="py-2 px-3 text-slate-400 whitespace-nowrap text-[11px]">{inv.date}</td>
                                <td className="py-2 px-3 text-white font-sans text-xs">
                                  <div className="font-semibold">{inv.customerName}</div>
                                  <div className="text-[10px] text-slate-400">{inv.customerPhone}</div>
                                </td>
                                <td className="py-2 px-3 text-right text-emerald-400 font-bold whitespace-nowrap">
                                  {formatRupiah(inv.grandTotal)}
                                </td>
                                <td className="py-2 px-3 whitespace-nowrap">
                                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                                    inv.paymentStatus === 'lunas'
                                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                      : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                  }`}>
                                    {inv.paymentStatus === 'lunas' ? 'LUNAS' : 'BELUM LUNAS'}
                                  </span>
                                </td>
                                <td className="py-2 px-3 text-slate-300 font-sans text-[11px]">
                                  {inv.items?.map((it, i) => (
                                    <span key={i} className="inline-block mr-1.5 bg-slate-800 px-1.5 py-0.5 rounded text-[10px] text-slate-200">
                                      {it.productName} ({it.quantity} {it.unit})
                                    </span>
                                  ))}
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TAB 3: PRODUCTS */}
                {activeDetailTab === 'products' && (
                  <div className="border border-slate-800 rounded-xl overflow-hidden">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-slate-950 text-slate-400 font-semibold uppercase text-[10px] border-b border-slate-800">
                        <tr>
                          <th className="py-2.5 px-3">Kode</th>
                          <th className="py-2.5 px-3">Nama Bahan Baku</th>
                          <th className="py-2.5 px-3">Kategori</th>
                          <th className="py-2.5 px-2 text-right">Stok Fisik</th>
                          <th className="py-2.5 px-3 text-right">Harga Modal (HPP)</th>
                          <th className="py-2.5 px-3 text-right">Harga Jual</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono">
                        {productsList.length === 0 ? (
                          <tr>
                            <td colSpan={6} className="py-6 text-center text-slate-500">
                              Tidak ada data bahan baku dalam snapshot ini
                            </td>
                          </tr>
                        ) : (
                          productsList.map((p, idx) => (
                            <tr key={p.id || idx} className="hover:bg-slate-850/50">
                              <td className="py-2 px-3 text-cyan-400 font-semibold text-[11px]">{p.code}</td>
                              <td className="py-2 px-3 text-white font-sans text-xs font-semibold">{p.name}</td>
                              <td className="py-2 px-3 text-slate-400 font-sans uppercase text-[10px]">{p.category}</td>
                              <td className="py-2 px-2 text-right text-emerald-400 font-bold">{p.currentStock} {p.unit}</td>
                              <td className="py-2 px-3 text-right text-slate-300">{formatRupiah(p.costPrice)}</td>
                              <td className="py-2 px-3 text-right text-cyan-300">{formatRupiah(p.sellingPrice)}</td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* TAB 4: MASTER DATA & LOG */}
                {activeDetailTab === 'master' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <h4 className="font-bold text-slate-200 text-xs">Kategori & Satuan Tersimpan</h4>
                      <div className="flex flex-wrap gap-1">
                        {cp.snapshot?.categories?.map((c) => (
                          <span key={c.id} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[11px] text-slate-300">
                            {c.name}
                          </span>
                        ))}
                        {cp.snapshot?.units?.map((u, i) => (
                          <span key={i} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[11px] text-slate-400">
                            {u}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <h4 className="font-bold text-slate-200 text-xs">Mitra Supplier ({cp.snapshot?.suppliers?.length || 0})</h4>
                      <div className="flex flex-wrap gap-1">
                        {cp.snapshot?.suppliers?.map((s) => (
                          <span key={s.id} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[11px] text-cyan-300">
                            {s.name}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <h4 className="font-bold text-slate-200 text-xs">Konsumen / Pelanggan ({cp.snapshot?.customers?.length || 0})</h4>
                      <div className="flex flex-wrap gap-1">
                        {cp.snapshot?.customers?.map((cust) => (
                          <span key={cust.id} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[11px] text-amber-300">
                            {cust.name}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                      <h4 className="font-bold text-slate-200 text-xs">Divisi Pemesan ({cp.snapshot?.divisions?.length || 0})</h4>
                      <div className="flex flex-wrap gap-1">
                        {cp.snapshot?.divisions?.map((d, i) => (
                          <span key={i} className="px-2 py-0.5 bg-slate-900 border border-slate-800 rounded text-[11px] text-emerald-300">
                            {d}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Detail Modal Footer */}
              <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between shrink-0">
                <span className="text-[11px] text-slate-500">
                  Snapshot ID: <span className="font-mono text-slate-400">{cp.id}</span>
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setViewingCheckpoint(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Tutup
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setViewingCheckpoint(null);
                      setConfirmRestoreCheckpoint(cp);
                    }}
                    className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Pulihkan Sistem ke Snapshot Ini</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};
