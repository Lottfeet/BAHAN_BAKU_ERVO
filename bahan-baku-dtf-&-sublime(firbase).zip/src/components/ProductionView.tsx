import React, { useState, useMemo, useEffect } from 'react';
import { 
  Layers, 
  Send, 
  AlertCircle, 
  CheckCircle2, 
  History, 
  FileText, 
  User as UserIcon, 
  Sparkles,
  Search,
  Download,
  Info,
  DollarSign,
  TrendingDown,
  Printer,
  X,
  Eye,
  Calendar,
  Tag,
  PackageCheck,
  Building2,
  UserCheck,
  Filter,
  RotateCcw,
  FileSpreadsheet,
  CreditCard,
  Receipt,
  Wallet,
  Clock,
  Check,
  AlertTriangle,
  CircleDollarSign,
  Settings,
  FileDown,
  Loader2,
  Edit3,
  Trash2,
} from 'lucide-react';
import { Product, StockMovement, User } from '../types';
import { formatRupiah, exportToCSV, formatDateIndo, formatTimestampWIB } from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';
import { DueDateSelector } from './DueDateSelector';

interface ProductionViewProps {
  products: Product[];
  movements: StockMovement[];
  currentUser: User;
  divisions?: string[];
  onOpenMasterData?: (tab?: 'category' | 'unit' | 'location' | 'supplier' | 'customer' | 'division') => void;
  onRecordProduction: (data: {
    productId: string;
    quantity: number;
    spkNumber: string;
    divisionOrRequester: string;
    recipientName: string;
    notes: string;
    billingRequired?: boolean;
    paymentStatus?: 'lunas' | 'belum_lunas' | 'beban_internal';
    paymentMethod?: string;
    paidAmount?: number;
    billingDueDate?: string;
    operatorUser?: User;
  }) => void;
  onUpdatePaymentStatus?: (
    movementId: string,
    status: 'lunas' | 'belum_lunas' | 'beban_internal',
    paidAmount?: number,
    paymentMethod?: string,
    billingDueDate?: string,
    operatorUser?: User
  ) => void;
  onEditProductionUsage?: (
    movementId: string,
    updatedData: {
      referenceNo?: string;
      divisionOrRequester?: string;
      recipientName?: string;
      date?: string;
      quantity?: number;
      notes?: string;
      billingRequired?: boolean;
      paymentStatus?: 'lunas' | 'belum_lunas' | 'beban_internal';
      paymentMethod?: string;
      paidAmount?: number;
      billingDueDate?: string;
    },
    operatorUser?: User
  ) => { success: boolean; message?: string };
  onDeleteProductionUsage?: (movementId: string, operatorUser?: User) => { success: boolean; message?: string };
  selectedPreProduct?: Product | null;
}

export const ProductionView: React.FC<ProductionViewProps> = ({
  products,
  movements,
  currentUser,
  divisions = [],
  onOpenMasterData,
  onRecordProduction,
  onUpdatePaymentStatus,
  onEditProductionUsage,
  onDeleteProductionUsage,
  selectedPreProduct,
}) => {
  const [selectedProductId, setSelectedProductId] = useState<string>(
    selectedPreProduct?.id || (products.length > 0 ? products[0].id : '')
  );
  const [quantity, setQuantity] = useState<number>(1);
  const [spkNumber, setSpkNumber] = useState<string>(
    `SPK-PRD-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`
  );
  const [divisionOrRequester, setDivisionOrRequester] = useState<string>('Divisi Sablon DTF Kaos');
  const [recipientName, setRecipientName] = useState<string>(
    currentUser?.name ? `${currentUser.name} (${currentUser.roleTitle || 'Petugas'})` : ''
  );
  const [notes, setNotes] = useState<string>('Pemakaian bahan batch produksi pesanan sablon');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // Sync default recipient with active logged in user
  useEffect(() => {
    if (currentUser?.name) {
      setRecipientName(`${currentUser.name} (${currentUser.roleTitle || 'Petugas'})`);
    }
  }, [currentUser]);

  // Billing & Payment States for New Production Entry
  const [billingRequired, setBillingRequired] = useState<boolean>(false);
  const [initialPaymentStatus, setInitialPaymentStatus] = useState<'belum_lunas' | 'lunas'>('belum_lunas');
  const [paymentMethod, setPaymentMethod] = useState<string>('Kas Internal / Tunai');
  const [paidAmountInput, setPaidAmountInput] = useState<number>(0);
  
  // Default due date: 7 days from now
  const defaultDueDate = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  }, []);
  const [billingDueDate, setBillingDueDate] = useState<string>(defaultDueDate);
  
  // Filters for History & PDF Print
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [selectedDivisionFilter, setSelectedDivisionFilter] = useState<string>('all');
  const [dateRangeFilter, setDateRangeFilter] = useState<'all' | 'today' | '7days' | '30days'>('all');
  const [paymentStatusFilter, setPaymentStatusFilter] = useState<'all' | 'lunas' | 'belum_lunas' | 'beban_internal'>('all');

  // Modals
  const [selectedDetailMovement, setSelectedDetailMovement] = useState<StockMovement | null>(null);
  const [showPdfPreview, setShowPdfPreview] = useState<boolean>(false);
  const [isSavingProductionPdf, setIsSavingProductionPdf] = useState<boolean>(false);
  const [savePdfSuccess, setSavePdfSuccess] = useState<string | null>(null);
  
  // Payment Modal State (for settling an unpaid movement)
  const [payingMovement, setPayingMovement] = useState<StockMovement | null>(null);
  const [modalPaymentAmount, setModalPaymentAmount] = useState<number>(0);
  const [modalPaymentMethod, setModalPaymentMethod] = useState<string>('Kas Internal / Tunai');
  const [modalPaymentDueDate, setModalPaymentDueDate] = useState<string>('');
  
  // Receipt / Billing Print Modal State
  const [receiptMovement, setReceiptMovement] = useState<StockMovement | null>(null);
  const [isSavingReceiptPdf, setIsSavingReceiptPdf] = useState<boolean>(false);

  // Hak Akses Granular
  const canEditProductionUsage = currentUser.role === 'owner' || Boolean(currentUser.canEditProductionUsage);
  const canDeleteProductionUsage = currentUser.role === 'owner' || Boolean(currentUser.canDeleteProductionUsage);

  // Edit SPK State & Form
  const [editingMovement, setEditingMovement] = useState<StockMovement | null>(null);
  const [editFormData, setEditFormData] = useState<{
    referenceNo: string;
    divisionOrRequester: string;
    recipientName: string;
    date: string;
    quantity: number;
    notes: string;
    billingRequired: boolean;
    paymentStatus: 'lunas' | 'belum_lunas' | 'beban_internal';
    paymentMethod: string;
    paidAmount: number;
    billingDueDate: string;
  }>({
    referenceNo: '',
    divisionOrRequester: '',
    recipientName: '',
    date: '',
    quantity: 1,
    notes: '',
    billingRequired: false,
    paymentStatus: 'beban_internal',
    paymentMethod: 'Kas Internal / Tunai',
    paidAmount: 0,
    billingDueDate: '',
  });

  // Delete SPK State
  const [deletingMovement, setDeletingMovement] = useState<StockMovement | null>(null);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);
  const [actionNotice, setActionNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const showActionToast = (type: 'success' | 'error', message: string) => {
    setActionNotice({ type, message });
    setTimeout(() => setActionNotice(null), 4000);
  };

  const handleOpenEdit = (m: StockMovement) => {
    setEditingMovement(m);
    setEditFormData({
      referenceNo: m.referenceNo,
      divisionOrRequester: m.divisionOrRequester || 'Divisi Produksi Sablon',
      recipientName: m.recipientName || '',
      date: m.date,
      quantity: m.quantity,
      notes: m.notes || '',
      billingRequired: m.billingRequired ?? false,
      paymentStatus: m.paymentStatus || 'beban_internal',
      paymentMethod: m.paymentMethod || 'Kas Internal / Tunai',
      paidAmount: m.paidAmount ?? 0,
      billingDueDate: m.billingDueDate || '',
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMovement || !onEditProductionUsage) return;

    if (!editFormData.referenceNo.trim()) {
      showActionToast('error', 'Nomor SPK tidak boleh kosong.');
      return;
    }
    if (editFormData.quantity <= 0) {
      showActionToast('error', 'Jumlah pemakaian harus lebih besar dari 0.');
      return;
    }

    const res = onEditProductionUsage(editingMovement.id, editFormData, currentUser);
    if (res.success) {
      setEditingMovement(null);
      showActionToast('success', res.message || 'Catatan SPK berhasil diperbarui.');
    } else {
      showActionToast('error', res.message || 'Gagal memperbarui catatan SPK.');
    }
  };

  const handleConfirmDelete = () => {
    if (!deletingMovement || !onDeleteProductionUsage) return;
    setIsDeleting(true);
    try {
      const res = onDeleteProductionUsage(deletingMovement.id, currentUser);
      if (res.success) {
        setDeletingMovement(null);
        showActionToast('success', res.message || 'Catatan pemakaian SPK berhasil dihapus.');
      } else {
        showActionToast('error', res.message || 'Gagal menghapus catatan SPK.');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const currentSelectedProduct = products.find((p) => p.id === selectedProductId);
  const isStockInsufficient = currentSelectedProduct ? currentSelectedProduct.currentStock < quantity : false;

  // Cost calculations
  const unitCostPrice = currentSelectedProduct ? currentSelectedProduct.costPrice : 0;
  const totalCostValue = unitCostPrice * (Number(quantity) || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || quantity <= 0 || isStockInsufficient) return;

    const effectivePaymentStatus = billingRequired ? initialPaymentStatus : 'beban_internal';
    const effectivePaidAmount = billingRequired
      ? (initialPaymentStatus === 'lunas' ? (paidAmountInput || totalCostValue) : (paidAmountInput || 0))
      : 0;

    onRecordProduction({
      productId: selectedProductId,
      quantity: Number(quantity),
      spkNumber: spkNumber.trim(),
      divisionOrRequester: divisionOrRequester.trim(),
      recipientName: recipientName.trim(),
      notes: notes.trim(),
      billingRequired,
      paymentStatus: effectivePaymentStatus,
      paymentMethod: billingRequired ? paymentMethod : undefined,
      paidAmount: effectivePaidAmount,
      billingDueDate: billingRequired ? billingDueDate : undefined,
      operatorUser: currentUser,
    });

    const billNote = billingRequired
      ? ` • [Tagihan ${effectivePaymentStatus === 'lunas' ? 'Lunas' : 'Belum Lunas'}: ${formatRupiah(totalCostValue)}]`
      : ' • [Beban Internal Murni]';

    setSuccessBanner(
      `Sukses mencatat pengeluaran ${quantity} ${currentSelectedProduct?.unit} ${currentSelectedProduct?.name} untuk ${spkNumber} (Pemesan: ${divisionOrRequester.trim()} | Petugas: ${recipientName.trim()}). Total: ${formatRupiah(totalCostValue)}${billNote}.`
    );

    // reset fields
    setSpkNumber(`SPK-PRD-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`);
    setQuantity(1);
    setBillingRequired(false);
    setInitialPaymentStatus('belum_lunas');
    setPaidAmountInput(0);

    setTimeout(() => {
      setSuccessBanner(null);
    }, 6000);
  };

  const handleConfirmPayment = () => {
    if (!payingMovement) return;
    const matchedProd = products.find((p) => p.id === payingMovement.productId);
    const unitCost = payingMovement.unitPrice ?? matchedProd?.costPrice ?? 0;
    const totalCost = payingMovement.totalValue ?? (payingMovement.quantity * unitCost);
    const prevPaid = payingMovement.paidAmount ?? 0;
    const paymentAddition = Number(modalPaymentAmount) || 0;
    const newTotalPaid = Math.min(totalCost, prevPaid + paymentAddition);
    const newStatus: 'lunas' | 'belum_lunas' = newTotalPaid >= totalCost ? 'lunas' : 'belum_lunas';

    onUpdatePaymentStatus?.(
      payingMovement.id,
      newStatus,
      newTotalPaid,
      modalPaymentMethod,
      newStatus === 'lunas' ? '' : modalPaymentDueDate,
      currentUser
    );

    // If detail modal was viewing this, update its state
    if (selectedDetailMovement && selectedDetailMovement.id === payingMovement.id) {
      setSelectedDetailMovement({
        ...selectedDetailMovement,
        paymentStatus: newStatus,
        paidAmount: newTotalPaid,
        paymentMethod: modalPaymentMethod,
        billingDueDate: newStatus === 'lunas' ? '' : modalPaymentDueDate,
        paidAt: newStatus === 'lunas' ? new Date().toISOString().slice(0, 10) : undefined,
      });
    }

    setSuccessBanner(
      `Pembayaran tagihan ${payingMovement.referenceNo} (${payingMovement.divisionOrRequester}) sebesar ${formatRupiah(paymentAddition)} berhasil dicatat! Status: ${newStatus === 'lunas' ? 'LUNAS' : 'SEBAGIAN (BELUM LUNAS)'}.`
    );
    setTimeout(() => {
      setSuccessBanner(null);
    }, 6000);

    setPayingMovement(null);
  };

  const productionMovements = useMemo(() => {
    return movements.filter((m) => m.type === 'production');
  }, [movements]);

  // Distinct list of divisions found in history + master divisions
  const availableDivisions = useMemo(() => {
    const list: string[] = [];
    if (divisions && divisions.length > 0) {
      divisions.forEach((d) => {
        if (!list.includes(d)) list.push(d);
      });
    }
    productionMovements.forEach((m) => {
      const div = m.divisionOrRequester?.trim() || 'Divisi Produksi Internal';
      if (!list.includes(div)) {
        list.push(div);
      }
    });
    // If empty, provide fallbacks
    if (list.length === 0) {
      list.push('Divisi Sablon DTF Kaos', 'Divisi Printing & Finishing Jersey');
    }
    return list.sort();
  }, [productionMovements, divisions]);

  const dateRangeLabel = useMemo(() => {
    switch (dateRangeFilter) {
      case 'today':
        return 'Hari Ini (' + new Date().toISOString().slice(0, 10) + ')';
      case '7days':
        return '7 Hari Terakhir';
      case '30days':
        return 'Bulan Ini (30 Hari Terakhir)';
      default:
        return 'Semua Waktu / Riwayat Lengkap';
    }
  }, [dateRangeFilter]);

  // Filtered movements for history table AND PDF report
  const filteredProductionMovements = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

    return productionMovements.filter((m) => {
      // 1. Division filter
      if (selectedDivisionFilter !== 'all') {
        const divName = m.divisionOrRequester?.trim() || 'Divisi Produksi Internal';
        if (divName.toLowerCase() !== selectedDivisionFilter.toLowerCase()) {
          return false;
        }
      }

      // 2. Date range filter
      if (dateRangeFilter === 'today') {
        if (!m.date.startsWith(todayStr)) return false;
      } else if (dateRangeFilter === '7days') {
        const movDate = m.date.slice(0, 10);
        if (movDate < sevenDaysAgo) return false;
      } else if (dateRangeFilter === '30days') {
        const movDate = m.date.slice(0, 10);
        if (movDate < thirtyDaysAgo) return false;
      }

      // 3. Payment Status Filter
      if (paymentStatusFilter !== 'all') {
        if (paymentStatusFilter === 'lunas' && m.paymentStatus !== 'lunas') return false;
        if (paymentStatusFilter === 'belum_lunas' && m.paymentStatus !== 'belum_lunas') return false;
        if (paymentStatusFilter === 'beban_internal') {
          if (m.billingRequired === true || (m.paymentStatus && m.paymentStatus !== 'beban_internal')) return false;
        }
      }

      // 4. Search query filter
      if (searchFilter.trim()) {
        const q = searchFilter.toLowerCase();
        const match =
          m.productName.toLowerCase().includes(q) ||
          m.productCode.toLowerCase().includes(q) ||
          m.referenceNo.toLowerCase().includes(q) ||
          (m.divisionOrRequester && m.divisionOrRequester.toLowerCase().includes(q)) ||
          (m.recipientName && m.recipientName.toLowerCase().includes(q)) ||
          (m.paymentMethod && m.paymentMethod.toLowerCase().includes(q)) ||
          m.notes.toLowerCase().includes(q) ||
          m.performedBy.userName.toLowerCase().includes(q);
        if (!match) return false;
      }

      return true;
    });
  }, [productionMovements, selectedDivisionFilter, dateRangeFilter, paymentStatusFilter, searchFilter]);

  // Filtered totals
  const filteredTotalCost = useMemo(() => {
    return filteredProductionMovements.reduce((acc, m) => {
      if (typeof m.totalValue === 'number' && m.totalValue > 0) return acc + m.totalValue;
      if (typeof m.unitPrice === 'number' && m.unitPrice > 0) return acc + (m.quantity * m.unitPrice);
      const matchedProd = products.find((p) => p.id === m.productId);
      return acc + (m.quantity * (matchedProd?.costPrice || 0));
    }, 0);
  }, [filteredProductionMovements, products]);

  const filteredTotalQuantity = useMemo(() => {
    return filteredProductionMovements.reduce((acc, m) => acc + m.quantity, 0);
  }, [filteredProductionMovements]);

  // Filtered payment metrics for PDF audit and executive summary
  const filteredPaidBills = useMemo(() => {
    return filteredProductionMovements.reduce((acc, m) => {
      if (m.billingRequired === true) {
        if (m.paymentStatus === 'lunas') {
          const matchedProd = products.find((p) => p.id === m.productId);
          const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
          const cost = m.totalValue ?? (m.quantity * unitCost);
          return acc + (m.paidAmount ?? cost);
        }
        return acc + (m.paidAmount ?? 0);
      }
      return acc;
    }, 0);
  }, [filteredProductionMovements, products]);

  const filteredUnpaidBills = useMemo(() => {
    return filteredProductionMovements.reduce((acc, m) => {
      if (m.billingRequired === true && m.paymentStatus === 'belum_lunas') {
        const matchedProd = products.find((p) => p.id === m.productId);
        const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
        const cost = m.totalValue ?? (m.quantity * unitCost);
        const paid = m.paidAmount ?? 0;
        return acc + Math.max(0, cost - paid);
      }
      return acc;
    }, 0);
  }, [filteredProductionMovements, products]);

  const filteredPureInternalCost = useMemo(() => {
    return filteredProductionMovements.reduce((acc, m) => {
      if (!m.billingRequired || m.paymentStatus === 'beban_internal') {
        const matchedProd = products.find((p) => p.id === m.productId);
        const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
        const cost = m.totalValue ?? (m.quantity * unitCost);
        return acc + cost;
      }
      return acc;
    }, 0);
  }, [filteredProductionMovements, products]);

  const filteredUnpaidCount = useMemo(() => {
    return filteredProductionMovements.filter(
      (m) => m.billingRequired === true && m.paymentStatus === 'belum_lunas'
    ).length;
  }, [filteredProductionMovements]);

  // Breakdown across divisions for comparison in PDF and analytics
  const divisionBreakdown = useMemo(() => {
    const map: Record<
      string,
      {
        count: number;
        totalCost: number;
        totalQty: number;
        recipients: Set<string>;
        billedTotal: number;
        paidTotal: number;
        unpaidTotal: number;
        unpaidCount: number;
      }
    > = {};

    filteredProductionMovements.forEach((m) => {
      const div = m.divisionOrRequester?.trim() || 'Divisi Produksi Internal';
      const matchedProd = products.find((p) => p.id === m.productId);
      const cost = m.totalValue ?? (m.quantity * (m.unitPrice ?? matchedProd?.costPrice ?? 0));
      const isBilled = m.billingRequired === true;
      const isLunas = m.paymentStatus === 'lunas';
      const isBelumLunas = m.paymentStatus === 'belum_lunas';
      const paid = isLunas ? cost : (m.paidAmount ?? 0);
      const unpaid = isBelumLunas ? Math.max(0, cost - paid) : 0;
      
      if (!map[div]) {
        map[div] = {
          count: 0,
          totalCost: 0,
          totalQty: 0,
          recipients: new Set(),
          billedTotal: 0,
          paidTotal: 0,
          unpaidTotal: 0,
          unpaidCount: 0,
        };
      }
      map[div].count += 1;
      map[div].totalCost += cost;
      map[div].totalQty += m.quantity;
      if (m.recipientName) map[div].recipients.add(m.recipientName);
      if (isBilled) {
        map[div].billedTotal += cost;
        map[div].paidTotal += paid;
        map[div].unpaidTotal += unpaid;
        if (isBelumLunas) map[div].unpaidCount += 1;
      }
    });

    return Object.entries(map).map(([division, data]) => ({
      division,
      count: data.count,
      totalCost: data.totalCost,
      totalQty: data.totalQty,
      recipients: Array.from(data.recipients).join(', ') || '-',
      percentage: filteredTotalCost > 0 ? (data.totalCost / filteredTotalCost) * 100 : 0,
      billedTotal: data.billedTotal,
      paidTotal: data.paidTotal,
      unpaidTotal: data.unpaidTotal,
      unpaidCount: data.unpaidCount,
    })).sort((a, b) => b.totalCost - a.totalCost);
  }, [filteredProductionMovements, products, filteredTotalCost]);

  // Aggregate stats across all history
  const totalProductionCost = useMemo(() => {
    return productionMovements.reduce((acc, m) => {
      if (typeof m.totalValue === 'number' && m.totalValue > 0) return acc + m.totalValue;
      if (typeof m.unitPrice === 'number' && m.unitPrice > 0) return acc + (m.quantity * m.unitPrice);
      const matchedProd = products.find((p) => p.id === m.productId);
      return acc + (m.quantity * (matchedProd?.costPrice || 0));
    }, 0);
  }, [productionMovements, products]);

  const totalQuantityUsed = useMemo(() => {
    return productionMovements.reduce((acc, m) => acc + m.quantity, 0);
  }, [productionMovements]);

  // Billing & Payment Totals across all history
  const totalPaidDivisionBills = useMemo(() => {
    return productionMovements.reduce((acc, m) => {
      if (m.billingRequired === true) {
        if (m.paymentStatus === 'lunas') {
          const cost = m.totalValue ?? (m.quantity * (m.unitPrice ?? 0));
          return acc + (m.paidAmount ?? cost);
        }
        return acc + (m.paidAmount ?? 0);
      }
      return acc;
    }, 0);
  }, [productionMovements]);

  const totalUnpaidDivisionBills = useMemo(() => {
    return productionMovements.reduce((acc, m) => {
      if (m.billingRequired === true && m.paymentStatus === 'belum_lunas') {
        const cost = m.totalValue ?? (m.quantity * (m.unitPrice ?? 0));
        const paid = m.paidAmount ?? 0;
        return acc + Math.max(0, cost - paid);
      }
      return acc;
    }, 0);
  }, [productionMovements]);

  const unpaidCount = useMemo(() => {
    return productionMovements.filter(
      (m) => m.billingRequired === true && m.paymentStatus === 'belum_lunas'
    ).length;
  }, [productionMovements]);

  const pureInternalCost = useMemo(() => {
    return productionMovements.reduce((acc, m) => {
      if (!m.billingRequired || m.paymentStatus === 'beban_internal') {
        const cost = m.totalValue ?? (m.quantity * (m.unitPrice ?? 0));
        return acc + cost;
      }
      return acc;
    }, 0);
  }, [productionMovements]);

  const handleExportCSV = () => {
    const rows: (string | number)[][] = [
      ['LAPORAN RINCIAN PEMAKAIAN BAHAN PRODUKSI SENDIRI & STATUS PEMBAYARAN TAGIHAN DIVISI'],
      ['Tanggal Cetak', new Date().toISOString().slice(0, 10)],
      ['Dicetak Oleh', currentUser.name],
      ['Filter Divisi', selectedDivisionFilter === 'all' ? 'Semua Divisi' : selectedDivisionFilter],
      ['Filter Periode', dateRangeLabel],
      ['Filter Status Bayar', paymentStatusFilter === 'all' ? 'Semua Status' : paymentStatusFilter],
      ['Filter Kata Kunci', searchFilter || 'Semua Data'],
      ['Total Beban Pokok Terfilter', filteredTotalCost],
      ['Jumlah Catatan SPK', filteredProductionMovements.length],
      [],
      [
        'Tanggal & Jam',
        'No. SPK',
        'Kode Bahan',
        'Nama Bahan Baku',
        'Kategori',
        'Jumlah Dipakai',
        'Satuan',
        'Harga Beli Satuan (HPP)',
        'Total Nilai Beban HPP',
        'Pemesan / Divisi Pemohon',
        'Petugas Pengambil / Penerima',
        'Wajib Bayar Tagihan?',
        'Status Pembayaran Divisi',
        'Metode Pembayaran',
        'Nominal Terbayar',
        'Sisa Piutang Tagihan',
        'Jatuh Tempo Pembayaran',
        'Tanggal Lunas',
        'Petugas Penyerah Gudang',
        'Sisa Stok Terakhir',
        'Uraian Pekerjaan / Catatan SPK',
      ],
    ];

    filteredProductionMovements.forEach((m) => {
      const matchedProd = products.find((p) => p.id === m.productId);
      const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
      const totalCost = m.totalValue ?? (m.quantity * unitCost);
      const isBilled = m.billingRequired ?? false;
      const isLunas = m.paymentStatus === 'lunas';
      const paid = isLunas ? totalCost : (m.paidAmount ?? 0);
      const remaining = isBilled && !isLunas ? Math.max(0, totalCost - paid) : 0;
      const statusLabel = !isBilled ? 'Beban Internal Murni' : (isLunas ? 'LUNAS' : 'BELUM LUNAS');

      rows.push([
        m.date,
        m.referenceNo,
        m.productCode,
        m.productName,
        m.category || matchedProd?.category || '-',
        m.quantity,
        m.unit,
        unitCost,
        totalCost,
        m.divisionOrRequester || '-',
        m.recipientName || '-',
        isBilled ? 'YA' : 'TIDAK (INTERNAL)',
        statusLabel,
        m.paymentMethod || '-',
        paid,
        remaining,
        m.billingDueDate || '-',
        m.paidAt || '-',
        m.performedBy.userName,
        m.finalStock,
        m.notes || '-',
      ]);
    });

    const safeDivName = selectedDivisionFilter === 'all' ? 'Semua_Divisi' : selectedDivisionFilter.replace(/[^a-zA-Z0-9]/g, '_');
    exportToCSV(`Laporan_Pemakaian_Produksi_${safeDivName}_${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const handleSaveProductionPdf = async () => {
    setIsSavingProductionPdf(true);
    setSavePdfSuccess(null);
    try {
      const safeDiv = selectedDivisionFilter === 'all' ? 'Seluruh_Divisi' : selectedDivisionFilter.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Laporan_Pemakaian_Bahan_${safeDiv}_${new Date().toISOString().slice(0, 10)}.pdf`;
      const success = await exportElementToPdf('printable-production-report', filename);
      if (success) {
        setSavePdfSuccess('File PDF Laporan Pemakaian Bahan berhasil disimpan & diunduh!');
        setTimeout(() => setSavePdfSuccess(null), 4500);
      }
    } finally {
      setIsSavingProductionPdf(false);
    }
  };

  const handlePrintProduction = () => {
    printElementDirect('printable-production-report');
  };

  const handleSaveReceiptPdf = async (m: StockMovement) => {
    setIsSavingReceiptPdf(true);
    try {
      const cleanRef = m.referenceNo.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Kuitansi_Pengeluaran_Produksi_${cleanRef}_${new Date().toISOString().slice(0, 10)}.pdf`;
      await exportElementToPdf('printable-receipt', filename);
    } finally {
      setIsSavingReceiptPdf(false);
    }
  };

  const handlePrintReceipt = () => {
    printElementDirect('printable-receipt');
  };

  return (
    <div className="space-y-6">
      {/* Header Info Banner */}
      <div className="bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 border border-blue-500/25 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Pemakaian Bahan untuk Produksi Sendiri</h2>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Otomatis Harga Beli (HPP)
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Catat setiap pemakaian tinta, powder lem, PET film, atau kertas sublime untuk pesanan sablon/cetak internal (SPK). Sistem secara otomatis membukukan pemakaian ini dengan <strong>Harga Beli (Modal/HPP)</strong> agar kalkulasi laporan laba atau rugi akurat.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 rounded-lg px-3 py-2 shrink-0">
            <UserIcon className="w-4 h-4 text-blue-400" />
            <div>
              <span className="text-[10px] text-slate-400 block leading-tight">Operator Bertugas</span>
              <span className="text-xs font-semibold text-white">{currentUser.name}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards with Payment & Billing Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Cost Value */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Pemakaian HPP</span>
            <span className="p-2 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 font-mono text-xl font-extrabold text-blue-300">
            {formatRupiah(totalProductionCost)}
          </div>
          <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span>{productionMovements.length} SPK Tercatat</span>
            </span>
            <span className="font-mono text-slate-300">{totalQuantityUsed} item</span>
          </div>
        </div>

        {/* Tagihan Divisi Terbayar (Lunas) */}
        <div className="bg-slate-900 border border-emerald-500/25 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-emerald-400">Tagihan Divisi Terbayar (Lunas)</span>
            <span className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Wallet className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 font-mono text-xl font-extrabold text-emerald-300">
            {formatRupiah(totalPaidDivisionBills)}
          </div>
          <p className="mt-1 text-[11px] text-emerald-400/80 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>Kas / transfer masuk dari divisi rekanan</span>
          </p>
        </div>

        {/* Piutang / Menunggu Pembayaran */}
        <div className="bg-slate-900 border border-amber-500/25 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-amber-400">Piutang / Menunggu Bayar</span>
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 font-mono text-xl font-extrabold text-amber-300">
            {formatRupiah(totalUnpaidDivisionBills)}
          </div>
          <p className="mt-1 text-[11px] text-amber-400/90 flex items-center gap-1 font-medium">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{unpaidCount} SPK divisi belum lunas</span>
          </p>
        </div>

        {/* Beban Internal Murni */}
        <div className="bg-slate-900 border border-slate-800/90 rounded-2xl p-4 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Beban Internal Murni</span>
            <span className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Layers className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-2 font-mono text-xl font-extrabold text-slate-200">
            {formatRupiah(pureInternalCost)}
          </div>
          <div className="mt-1 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
            <span>Bebas Tagihan (HPP):</span>
            <span className="text-slate-300 font-semibold">Operasional Pusat</span>
          </div>
        </div>
      </div>

      {successBanner && (
        <div className="p-4 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2.5 shadow-sm animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{successBanner}</span>
        </div>
      )}

      {/* Main Grid: Form Left, Recent Production Movements Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
        {/* Form Card */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-400" />
              <span>Formulir Pengeluaran Produksi</span>
            </h3>
            <span className="text-[10px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded font-mono">
              Modal Otomatis
            </span>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Product selection */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Pilih Bahan Baku yang Dipakai
              </label>
              <select
                id="select-production-product"
                value={selectedProductId}
                onChange={(e) => setSelectedProductId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500 font-medium"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    [{p.code}] {p.name} — Sisa: {p.currentStock} {p.unit}
                  </option>
                ))}
              </select>

              {currentSelectedProduct && (
                <div className="mt-2 p-2.5 rounded-lg bg-slate-950/70 border border-slate-800/80 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Sisa Stok Gudang:</span>
                    <div className="flex items-center gap-1.5 font-bold">
                      <span className={currentSelectedProduct.currentStock <= currentSelectedProduct.minStockAlert ? 'text-amber-400' : 'text-cyan-400'}>
                        {currentSelectedProduct.currentStock} {currentSelectedProduct.unit}
                      </span>
                      {currentSelectedProduct.currentStock <= currentSelectedProduct.minStockAlert && (
                        <span className="text-[10px] text-amber-300 bg-amber-500/20 px-1.5 py-0.5 rounded">Menipis</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-slate-400 border-t border-slate-850 pt-1">
                    <span>Harga Beli (Modal / HPP):</span>
                    <span className="font-mono text-emerald-400 font-semibold">
                      {formatRupiah(currentSelectedProduct.costPrice)} <span className="text-[10px] text-slate-500 font-normal">/ {currentSelectedProduct.unit}</span>
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Quantity */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-slate-300">Jumlah yang Dikeluarkan</label>
                <span className="text-[11px] text-slate-400">
                  Satuan: {currentSelectedProduct?.unit || 'Item'}
                </span>
              </div>
              <input
                id="input-production-quantity"
                type="number"
                min="0"
                step="any"
                max={currentSelectedProduct ? currentSelectedProduct.currentStock : 9999}
                required
                value={quantity}
                onChange={(e) => setQuantity(Math.max(0, parseFloat(e.target.value) || 0))}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-bold focus:outline-none focus:border-blue-500 font-mono"
              />
              {isStockInsufficient && (
                <p className="text-[11px] text-rose-400 flex items-center gap-1 mt-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  Stok tidak mencukupi! Sisa di gudang hanya {currentSelectedProduct?.currentStock} {currentSelectedProduct?.unit}.
                </p>
              )}
            </div>

            {/* Real-time Calculation Breakdown Box */}
            <div className="p-3 bg-blue-950/40 border border-blue-500/30 rounded-xl space-y-2 text-xs">
              <div className="flex items-center justify-between text-blue-200">
                <span className="font-medium flex items-center gap-1">
                  <DollarSign className="w-3.5 h-3.5 text-blue-400" />
                  Rincian Beban Biaya HPP:
                </span>
                <span className="text-[10px] text-blue-400 font-mono bg-blue-900/50 px-1.5 py-0.5 rounded">
                  Otomatis Harga Beli
                </span>
              </div>
              
              <div className="font-mono text-xs text-slate-300 flex items-center justify-between bg-slate-950/60 p-2 rounded-lg border border-slate-800">
                <span>{quantity} {currentSelectedProduct?.unit} × {formatRupiah(unitCostPrice)}</span>
                <span className="text-blue-300 font-extrabold text-sm">{formatRupiah(totalCostValue)}</span>
              </div>
              
              <p className="text-[11px] text-slate-400 leading-tight">
                Nominal <strong>{formatRupiah(totalCostValue)}</strong> ini akan langsung dibukukan sebagai Beban Pokok Produksi untuk menganalisis apakah produksi sablon menghasilkan profit atau rugi.
              </p>
            </div>

            {/* SPK / Job Order */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Nomor SPK / Surat Perintah Kerja
              </label>
              <input
                type="text"
                required
                value={spkNumber}
                onChange={(e) => setSpkNumber(e.target.value)}
                placeholder="misal: SPK-PRD-2026-095"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>

            {/* Division or Requester Name */}
            <div>
              <div className="flex items-center justify-between mb-1.5 flex-wrap gap-1">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Nama Pemesan / Divisi Pemohon</span>
                </label>
                <div className="flex items-center gap-2">
                  {onOpenMasterData && (
                    <button
                      type="button"
                      onClick={() => onOpenMasterData('division')}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 hover:underline font-semibold"
                    >
                      <Settings className="w-3 h-3" />
                      <span>Kelola Master Divisi</span>
                    </button>
                  )}
                  <span className="text-[10px] text-cyan-400 font-mono">Unit Kerja SPK</span>
                </div>
              </div>

              {/* Quick Select from Master Divisions */}
              <div className="space-y-1.5">
                <select
                  value={divisions.includes(divisionOrRequester) ? divisionOrRequester : ''}
                  onChange={(e) => {
                    if (e.target.value) {
                      setDivisionOrRequester(e.target.value);
                    }
                  }}
                  className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 hover:border-cyan-500/60 rounded-lg text-xs text-cyan-300 focus:outline-none focus:border-cyan-400 transition-colors font-medium"
                >
                  <option value="" className="text-slate-400 bg-slate-900">
                    -- Pilih Cepat dari Master Divisi ({divisions.length} divisi terdaftar) --
                  </option>
                  {divisions.map((d) => (
                    <option key={d} value={d} className="text-white bg-slate-900">
                      🏢 {d}
                    </option>
                  ))}
                </select>

                <div className="relative">
                  <input
                    type="text"
                    required
                    list="registered-divisions-list"
                    value={divisionOrRequester}
                    onChange={(e) => setDivisionOrRequester(e.target.value)}
                    placeholder="misal: Divisi Sablon DTF Kaos / Tim Printing Jersey"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-medium"
                  />
                  <datalist id="registered-divisions-list">
                    {divisions.map((d) => (
                      <option key={d} value={d} />
                    ))}
                  </datalist>
                </div>

                {/* Quick Selection Tags */}
                {divisions.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap pt-0.5">
                    <span className="text-[10px] text-slate-500">Pilih:</span>
                    {divisions.slice(0, 5).map((d) => (
                      <button
                        key={d}
                        type="button"
                        onClick={() => setDivisionOrRequester(d)}
                        className={`px-2 py-0.5 rounded text-[10px] transition-colors border ${
                          divisionOrRequester === d
                            ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Recipient / Courier Name */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <UserCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>Petugas Pengambil / Penerima Bahan</span>
                </label>
                <div className="flex items-center gap-2">
                  {currentUser?.name && (
                    <button
                      type="button"
                      onClick={() => setRecipientName(`${currentUser.name} (${currentUser.roleTitle || 'Petugas'})`)}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 transition-colors font-medium cursor-pointer"
                      title="Isi otomatis dengan akun yang sedang login"
                    >
                      + Akun Saya ({currentUser.name})
                    </button>
                  )}
                  <span className="text-[10px] text-amber-400 font-mono">PIC Lapangan</span>
                </div>
              </div>
              <input
                type="text"
                required
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="misal: Nama petugas pengambil / penerima bahan di lapangan..."
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-medium"
              />
            </div>

            {/* Notes / Description */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Keterangan Pekerjaan / Catatan SPK
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="misal: Sablon Kaos Komunitas 100 Pcs, Mesin XP600 shift pagi"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* BILLING & PAYMENT ACCORDION / TOGGLE */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-white flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={billingRequired}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setBillingRequired(checked);
                      if (checked && initialPaymentStatus === 'lunas') {
                        setPaidAmountInput(totalCostValue);
                      }
                    }}
                    className="w-4 h-4 rounded text-blue-600 bg-slate-900 border-slate-700 focus:ring-blue-500 cursor-pointer"
                  />
                  <div className="flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span>Divisi Wajib Bayar Tagihan Bahan</span>
                  </div>
                </label>
                <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-semibold ${
                  billingRequired ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
                }`}>
                  {billingRequired ? 'Wajib Tagihan' : 'Beban Internal'}
                </span>
              </div>

              {billingRequired ? (
                <div className="pt-2 border-t border-slate-800/80 space-y-3">
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Divisi pemohon (rekanan/cabang/komersial) wajib membayar beban pemakaian bahan ini.
                  </p>

                  {/* Status Pembayaran Awal */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-300 mb-1.5">
                      Status Pembayaran Awal:
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setInitialPaymentStatus('belum_lunas');
                          setPaidAmountInput(0);
                        }}
                        className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                          initialPaymentStatus === 'belum_lunas'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-300'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5" />
                        <span>Belum Lunas (Tempo)</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setInitialPaymentStatus('lunas');
                          setPaidAmountInput(totalCostValue);
                        }}
                        className={`p-2 rounded-lg border text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                          initialPaymentStatus === 'lunas'
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-300'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Langsung Lunas</span>
                      </button>
                    </div>
                  </div>

                  {/* Payment Method & Due Date */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className={`block text-[11px] font-medium ${
                          initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0 ? 'text-slate-500' : 'text-slate-400'
                        }`}>
                          Metode Pembayaran
                        </label>
                        {initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0 && (
                          <span className="text-[10px] text-amber-400 font-medium">
                            Tidak aktif (Belum bayar)
                          </span>
                        )}
                      </div>
                      <select
                        disabled={initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0}
                        value={initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0 ? 'Belum Ditentukan (Piutang)' : paymentMethod}
                        onChange={(e) => setPaymentMethod(e.target.value)}
                        className={`w-full px-2.5 py-1.5 border rounded-lg text-xs font-medium transition-all ${
                          initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0
                            ? 'bg-slate-900/60 border-slate-800 text-slate-500 cursor-not-allowed opacity-60 select-none'
                            : 'bg-slate-900 border-slate-800 text-white focus:outline-hidden focus:border-blue-500 cursor-pointer'
                        }`}
                      >
                        {initialPaymentStatus === 'belum_lunas' && paidAmountInput === 0 ? (
                          <option value="Belum Ditentukan (Piutang)">⛔ Belum Ditentukan (Piutang)</option>
                        ) : (
                          <>
                            <option value="Kas Internal / Tunai">Kas Internal / Tunai</option>
                            <option value="Transfer Bank">Transfer Bank</option>
                            <option value="Potong Alokasi Anggaran Divisi">Potong Alokasi Anggaran</option>
                            <option value="Giro / Nota Divisi">Giro / Nota Divisi</option>
                            <option value="QRIS / Dompet Digital">QRIS / E-Wallet</option>
                          </>
                        )}
                      </select>
                    </div>

                    <div className="sm:col-span-2 bg-slate-900/70 p-3 rounded-xl border border-slate-800">
                      <DueDateSelector
                        value={billingDueDate}
                        onChange={setBillingDueDate}
                        label={initialPaymentStatus === 'belum_lunas' ? 'Jatuh Tempo Pembayaran' : 'Tanggal Pelunasan'}
                        helperText="Pilih batas jatuh tempo tagihan: Tanpa batas (tidak terbatas), atau aksi cepat 2 minggu, 1 bulan, 2 bulan."
                        colorTheme="indigo"
                        compact={true}
                      />
                    </div>
                  </div>

                  {/* Nominal Terbayar if Belum Lunas (bisa DP) */}
                  {initialPaymentStatus === 'belum_lunas' ? (
                    <div className="p-2.5 bg-slate-900/90 rounded-lg border border-slate-800 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-medium text-slate-400">
                          Uang Muka (DP) / Dibayar Sebagian:
                        </label>
                        <span className="text-[10px] text-slate-500 font-mono">Boleh Rp 0</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="relative flex-1">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">Rp</span>
                          <input
                            type="number"
                            min="0"
                            step="any"
                            max={totalCostValue}
                            value={paidAmountInput}
                            onChange={(e) => setPaidAmountInput(Math.min(totalCostValue, Math.max(0, parseFloat(e.target.value) || 0)))}
                            className="w-full pl-8 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-mono font-bold focus:outline-none focus:border-blue-500"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setInitialPaymentStatus('lunas');
                            setPaidAmountInput(totalCostValue);
                          }}
                          className="px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg text-[11px] font-semibold whitespace-nowrap cursor-pointer transition-colors"
                        >
                          Lunasi Penuh
                        </button>
                      </div>
                      <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-850">
                        <span className="text-slate-400">Sisa Piutang Tertagih:</span>
                        <span className="font-mono font-bold text-amber-300">
                          {formatRupiah(Math.max(0, totalCostValue - (paidAmountInput || 0)))}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-2.5 bg-emerald-950/40 border border-emerald-500/30 rounded-lg flex items-center justify-between text-xs">
                      <span className="text-emerald-300 font-semibold flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                        Dibayar Lunas Penuh:
                      </span>
                      <span className="font-mono font-bold text-emerald-300">
                        {formatRupiah(totalCostValue)}
                      </span>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-[11px] text-slate-500 leading-tight">
                  Pemakaian akan dicatat murni sebagai beban pokok produksi internal (HPP), tanpa kewajiban bayar tagihan.
                </p>
              )}
            </div>

            {/* Submit button */}
            <button
              id="btn-submit-production"
              type="submit"
              disabled={isStockInsufficient || quantity <= 0}
              className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-all min-h-[44px] cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Simpan Pemakaian & Potong Stok ({formatRupiah(totalCostValue)})</span>
            </button>
          </form>
        </div>

        {/* History Table Right */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-blue-400" />
                <span>Rincian Riwayat Pemakaian Produksi Sendiri</span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Menampilkan <strong className="text-white">{filteredProductionMovements.length}</strong> catatan SPK • Total Beban: <strong className="text-blue-300">{formatRupiah(filteredTotalCost)}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowPdfPreview(true)}
                title="Cetak Laporan PDF Pemakaian Bahan (sesuai filter aktif)"
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs active:scale-95 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak PDF</span>
              </button>
              <button
                type="button"
                onClick={handleExportCSV}
                title="Ekspor CSV Rincian Pemakaian Produksi (sesuai filter aktif)"
                className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700/60 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Ekspor CSV</span>
              </button>
            </div>
          </div>

          {/* Filters Bar: Search + Divisi Filter + Status Bayar Filter + Periode Filter + Reset */}
          <div className="space-y-2">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
              {/* Search Box */}
              <div className="sm:col-span-4 relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="Cari SPK, bahan, petugas, catatan..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Divisi Filter Dropdown */}
              <div className="sm:col-span-3 relative">
                <Building2 className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 pointer-events-none" />
                <select
                  value={selectedDivisionFilter}
                  onChange={(e) => setSelectedDivisionFilter(e.target.value)}
                  className="w-full pl-8.5 pr-6 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 cursor-pointer font-medium truncate"
                >
                  <option value="all">Semua Divisi ({productionMovements.length} SPK)</option>
                  {availableDivisions.map((div) => {
                    const count = productionMovements.filter(
                      (m) => (m.divisionOrRequester || 'Divisi Produksi Internal') === div
                    ).length;
                    return (
                      <option key={div} value={div}>
                        {div} ({count} SPK)
                      </option>
                    );
                  })}
                </select>
              </div>

              {/* Payment Status Filter Dropdown */}
              <div className="sm:col-span-3 relative">
                <CreditCard className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400 pointer-events-none" />
                <select
                  value={paymentStatusFilter}
                  onChange={(e) => setPaymentStatusFilter(e.target.value as any)}
                  className="w-full pl-8.5 pr-6 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer font-medium truncate"
                >
                  <option value="all">Semua Status Bayar</option>
                  <option value="lunas">✅ Lunas</option>
                  <option value="belum_lunas">⏳ Belum Lunas (Tempo)</option>
                  <option value="beban_internal">🏢 Beban Internal Murni</option>
                </select>
              </div>

              {/* Periode Filter Dropdown */}
              <div className="sm:col-span-2 relative">
                <Calendar className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <select
                  value={dateRangeFilter}
                  onChange={(e) => setDateRangeFilter(e.target.value as any)}
                  className="w-full pl-8.5 pr-6 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-blue-500 cursor-pointer font-medium truncate"
                >
                  <option value="all">Semua Waktu</option>
                  <option value="today">Hari Ini</option>
                  <option value="7days">7 Hari</option>
                  <option value="30days">Bulan Ini</option>
                </select>
              </div>
            </div>

            {/* Active filter summary pill & Reset */}
            {(selectedDivisionFilter !== 'all' || dateRangeFilter !== 'all' || paymentStatusFilter !== 'all' || searchFilter.trim() !== '') && (
              <div className="flex flex-wrap items-center justify-between gap-2 p-2 rounded-lg bg-slate-950/90 border border-slate-800 text-[11px]">
                <div className="flex items-center gap-1.5 flex-wrap text-slate-400">
                  <Filter className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span>Filter Aktif:</span>
                  {selectedDivisionFilter !== 'all' && (
                    <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
                      Divisi: {selectedDivisionFilter}
                    </span>
                  )}
                  {paymentStatusFilter !== 'all' && (
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold border border-emerald-500/30">
                      Status: {paymentStatusFilter === 'lunas' ? 'Lunas' : paymentStatusFilter === 'belum_lunas' ? 'Belum Lunas' : 'Beban Internal'}
                    </span>
                  )}
                  {dateRangeFilter !== 'all' && (
                    <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-semibold border border-blue-500/30">
                      {dateRangeLabel}
                    </span>
                  )}
                  {searchFilter.trim() !== '' && (
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      "{searchFilter}"
                    </span>
                  )}
                  <span className="text-slate-500">•</span>
                  <span className="text-slate-300">
                    {filteredProductionMovements.length} SPK (Beban: <strong className="text-blue-300">{formatRupiah(filteredTotalCost)}</strong>)
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedDivisionFilter('all');
                    setDateRangeFilter('all');
                    setPaymentStatusFilter('all');
                    setSearchFilter('');
                  }}
                  className="text-rose-400 hover:text-rose-300 flex items-center gap-1 font-semibold cursor-pointer text-[10px]"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset Filter</span>
                </button>
              </div>
            )}
          </div>

          {/* Mobile Cards for Production Movements */}
          <div className="sm:hidden space-y-2.5 max-h-[520px] overflow-y-auto pr-0.5">
            {filteredProductionMovements.length === 0 ? (
              <div className="p-6 text-center text-slate-400 text-xs">
                Tidak ada data pemakaian produksi yang cocok.
              </div>
            ) : (
              filteredProductionMovements.map((m) => {
                const matchedProd = products.find((p) => p.id === m.productId);
                const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
                const totalCost = m.totalValue ?? (m.quantity * unitCost);
                const isBilled = m.billingRequired ?? false;
                const isLunas = m.paymentStatus === 'lunas';
                const isBelumLunas = m.paymentStatus === 'belum_lunas';
                const paid = isLunas ? totalCost : (m.paidAmount ?? 0);
                const remaining = isBelumLunas ? Math.max(0, totalCost - paid) : 0;

                return (
                  <div key={m.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2.5 text-xs">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="font-bold text-white block">{m.productName}</span>
                        <span className="text-[10px] text-cyan-400 font-mono">{m.productCode}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30 whitespace-nowrap">
                        -{m.quantity} {m.unit}
                      </span>
                    </div>

                    {/* Breakdown Cost Box */}
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800/80 flex items-center justify-between text-xs">
                      <div className="text-[11px] text-slate-400">
                        <span>HPP: </span>
                        <span className="font-mono text-slate-300">{formatRupiah(unitCost)}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">Total Beban:</span>
                        <span className="font-mono font-bold text-blue-300">{formatRupiah(totalCost)}</span>
                      </div>
                    </div>

                    {/* Billing / Payment Status Banner */}
                    <div className={`p-2 rounded-lg border text-[11px] flex items-center justify-between ${
                      !isBilled
                        ? 'bg-slate-900/80 text-slate-400 border-slate-800'
                        : isLunas
                        ? 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30'
                        : 'bg-amber-950/40 text-amber-300 border-amber-500/30'
                    }`}>
                      <div className="flex items-center gap-1.5">
                        {!isBilled ? (
                          <Layers className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                        ) : isLunas ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        )}
                        <span className="font-bold">
                          {!isBilled ? 'Beban Internal' : isLunas ? 'Tagihan LUNAS' : `BELUM LUNAS (Sisa ${formatRupiah(remaining)})`}
                        </span>
                      </div>
                      {isBilled && isBelumLunas && (
                        <button
                          type="button"
                          onClick={() => {
                            setPayingMovement(m);
                            setModalPaymentAmount(remaining);
                            setModalPaymentDueDate(m.billingDueDate || '');
                            setModalPaymentMethod(m.paymentMethod || 'Kas Internal / Tunai');
                          }}
                          className="px-2 py-0.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-[10px] cursor-pointer shadow-xs"
                        >
                          Bayar
                        </button>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-850">
                      <span className="font-mono text-indigo-300 font-semibold">{m.referenceNo}</span>
                      <span>{m.date}</span>
                    </div>

                    {/* Division & Recipient */}
                    <div className="space-y-1 text-[11px] bg-slate-900/60 p-2 rounded-lg border border-slate-850">
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <Building2 className="w-3 h-3 text-cyan-400 shrink-0" />
                        <span className="text-slate-400">Pemesan:</span>
                        <span className="text-cyan-300 font-medium truncate">
                          {m.divisionOrRequester || 'Divisi Produksi Internal'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-300">
                        <UserCheck className="w-3 h-3 text-amber-400 shrink-0" />
                        <span className="text-slate-400">Pengambil:</span>
                        <span className="text-amber-300 font-medium">
                          {m.recipientName || m.performedBy.userName}
                        </span>
                      </div>
                    </div>

                    {m.notes && <p className="text-[11px] text-slate-400 italic line-clamp-2">{m.notes}</p>}
                    
                    <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-850">
                      <span>Gudang: {m.performedBy.userName}</span>
                      <div className="flex items-center gap-2">
                        {isBilled && (
                          <button
                            onClick={() => setReceiptMovement(m)}
                            className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1 cursor-pointer"
                          >
                            <Receipt className="w-3 h-3" />
                            <span>Kuitansi</span>
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedDetailMovement(m)}
                          className="text-blue-400 hover:text-blue-300 font-medium underline flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Detail</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEdit(m)}
                          disabled={!canEditProductionUsage}
                          title={canEditProductionUsage ? "Edit Catatan Pemakaian SPK" : "Akses ditolak: Izin 'Edit Riwayat Pemakaian Produksi' tidak aktif"}
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 border ${
                            canEditProductionUsage
                              ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer active:scale-95'
                              : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeletingMovement(m)}
                          disabled={!canDeleteProductionUsage}
                          title={canDeleteProductionUsage ? "Hapus Catatan Pemakaian SPK & Revert Stok" : "Akses ditolak: Izin 'Hapus Riwayat Pemakaian Produksi' tidak aktif"}
                          className={`px-2 py-0.5 rounded text-[10px] font-semibold flex items-center gap-1 border ${
                            canDeleteProductionUsage
                              ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer active:scale-95'
                              : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Hapus</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Desktop Table for Production Movements */}
          <div className="hidden sm:block border border-slate-800/80 rounded-xl overflow-hidden">
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
              <table className="w-full min-w-[850px] text-left text-xs border-collapse">
                <thead className="bg-slate-950 sticky top-0 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider z-10">
                  <tr>
                    <th className="py-3 px-3 min-w-[95px]">Tanggal</th>
                    <th className="py-3 px-3 min-w-[150px]">Bahan Baku</th>
                    <th className="py-3 px-2 min-w-[80px]">Jumlah</th>
                    <th className="py-3 px-2 text-right min-w-[90px]">Harga (HPP)</th>
                    <th className="py-3 px-2 text-right min-w-[105px]">Total Beban</th>
                    <th className="py-3 px-3 min-w-[190px]">SPK & Pemesan/Pengambil</th>
                    <th className="py-3 px-3 min-w-[145px]">Status Tagihan</th>
                    <th className="py-3 px-2 text-center min-w-[90px]">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                {filteredProductionMovements.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-8 text-center text-slate-400">
                      Tidak ada pencatatan pemakaian produksi yang cocok.
                    </td>
                  </tr>
                ) : (
                  filteredProductionMovements.map((m) => {
                    const matchedProd = products.find((p) => p.id === m.productId);
                    const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
                    const totalCost = m.totalValue ?? (m.quantity * unitCost);
                    const isBilled = m.billingRequired ?? false;
                    const isLunas = m.paymentStatus === 'lunas';
                    const isBelumLunas = m.paymentStatus === 'belum_lunas';
                    const paid = isLunas ? totalCost : (m.paidAmount ?? 0);
                    const remaining = isBelumLunas ? Math.max(0, totalCost - paid) : 0;

                    return (
                      <tr key={m.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3 whitespace-nowrap text-slate-400 font-mono text-[11px]">
                          {m.date}
                        </td>
                        <td className="py-3 px-3">
                          <span className="font-semibold text-slate-100 block">{m.productName}</span>
                          <span className="text-[10px] text-cyan-400 font-mono">{m.productCode}</span>
                        </td>
                        <td className="py-3 px-2 whitespace-nowrap">
                          <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30">
                            -{m.quantity} {m.unit}
                          </span>
                          <span className="block text-[10px] text-slate-500 mt-0.5">
                            Sisa: {m.finalStock}
                          </span>
                        </td>
                        <td className="py-3 px-2 text-right font-mono text-slate-300 whitespace-nowrap">
                          {formatRupiah(unitCost)}
                        </td>
                        <td className="py-3 px-2 text-right font-mono font-bold text-blue-300 whitespace-nowrap">
                          {formatRupiah(totalCost)}
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-mono text-xs font-bold text-indigo-300 flex items-center gap-1">
                            <FileText className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                            <span>{m.referenceNo}</span>
                          </div>
                          <div className="text-[11px] font-semibold text-slate-200 mt-0.5 flex items-center gap-1.5">
                            <Building2 className="w-3 h-3 text-cyan-400 shrink-0" />
                            <span className="text-cyan-300 truncate">{m.divisionOrRequester || 'Divisi Produksi Internal'}</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                            <UserCheck className="w-3 h-3 text-amber-400 shrink-0" />
                            <span>Pengambil: <strong className="text-slate-300 font-medium">{m.recipientName || m.performedBy.userName}</strong></span>
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          {!isBilled ? (
                            <div>
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                                <Layers className="w-2.5 h-2.5" />
                                <span>Beban Internal</span>
                              </span>
                              <span className="block text-[10px] text-slate-500 mt-0.5">Non-tagihan</span>
                            </div>
                          ) : isLunas ? (
                            <div>
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>LUNAS</span>
                              </span>
                              <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                                {m.paymentMethod || 'Kas Internal'}
                              </div>
                            </div>
                          ) : (
                            <div>
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                                <Clock className="w-3 h-3" />
                                <span>BELUM LUNAS</span>
                              </span>
                              <div className="text-[10px] font-mono text-amber-300 font-semibold mt-0.5">
                                Sisa: {formatRupiah(remaining)}
                              </div>
                              {m.billingDueDate && (
                                <div className="text-[9px] text-slate-500">
                                  Tempo: {m.billingDueDate}
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-2 text-center whitespace-nowrap">
                          <div className="flex items-center justify-center gap-1">
                            {isBilled && isBelumLunas && (
                              <button
                                onClick={() => {
                                  setPayingMovement(m);
                                  setModalPaymentAmount(remaining);
                                  setModalPaymentDueDate(m.billingDueDate || '');
                                  setModalPaymentMethod(m.paymentMethod || 'Kas Internal / Tunai');
                                }}
                                title="Catat Pelunasan Tagihan Pemakaian Divisi"
                                className="p-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition-all shadow-xs flex items-center gap-1 text-[10px] font-bold cursor-pointer"
                              >
                                <CreditCard className="w-3 h-3" />
                                <span>Bayar</span>
                              </button>
                            )}
                            {isBilled && (
                              <button
                                onClick={() => setReceiptMovement(m)}
                                title="Lihat / Cetak Kuitansi Tagihan Pemakaian"
                                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700/60 transition-colors inline-flex items-center text-[10px] cursor-pointer"
                              >
                                <Receipt className="w-3 h-3 text-emerald-400" />
                              </button>
                            )}
                            <button
                              onClick={() => setSelectedDetailMovement(m)}
                              title="Buka Lembar Rincian Pemakaian SPK"
                              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700/60 transition-colors inline-flex items-center gap-0.5 text-[10px] cursor-pointer"
                            >
                              <Eye className="w-3 h-3 text-blue-400" />
                              <span>Detail</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleOpenEdit(m)}
                              disabled={!canEditProductionUsage}
                              title={canEditProductionUsage ? "Edit Catatan Pemakaian SPK" : "Akses ditolak: Izin 'Edit Riwayat Pemakaian Produksi' tidak aktif"}
                              className={`p-1.5 rounded-lg border transition-colors inline-flex items-center gap-0.5 text-[10px] font-semibold ${
                                canEditProductionUsage
                                  ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer active:scale-95'
                                  : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                              }`}
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>Edit</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeletingMovement(m)}
                              disabled={!canDeleteProductionUsage}
                              title={canDeleteProductionUsage ? "Hapus Catatan Pemakaian SPK & Revert Stok" : "Akses ditolak: Izin 'Hapus Riwayat Pemakaian Produksi' tidak aktif"}
                              className={`p-1.5 rounded-lg border transition-colors inline-flex items-center gap-0.5 text-[10px] font-semibold ${
                                canDeleteProductionUsage
                                  ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer active:scale-95'
                                  : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                              }`}
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Hapus</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

      {/* DETAIL MODAL: RINCIAN PEMAKAIAN SPK PRODUKSI */}
      {selectedDetailMovement && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">Lembar Rincian Pemakaian Produksi</h3>
                  <span className="font-mono text-xs text-indigo-300">{selectedDetailMovement.referenceNo}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedDetailMovement(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            {(() => {
              const m = selectedDetailMovement;
              const matchedProd = products.find((p) => p.id === m.productId);
              const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
              const totalCost = m.totalValue ?? (m.quantity * unitCost);

              return (
                <div className="p-5 space-y-4 text-xs">
                  {/* General Info */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-500 block">Tanggal & Waktu</span>
                      <span className="font-mono text-slate-200">{m.date}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">No. SPK / Perintah Kerja</span>
                      <span className="font-mono font-bold text-indigo-300">{m.referenceNo}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-850 sm:border-t-0">
                      <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-cyan-400" />
                        <span>Nama Pemesan / Divisi Kerja</span>
                      </span>
                      <span className="font-semibold text-cyan-300 text-xs mt-0.5 block">
                        {m.divisionOrRequester || 'Divisi Produksi Internal'}
                      </span>
                    </div>
                    <div className="pt-2 border-t border-slate-850 sm:border-t-0">
                      <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                        <UserCheck className="w-3 h-3 text-amber-400" />
                        <span>Petugas Pengambil / Penerima Bahan</span>
                      </span>
                      <span className="font-semibold text-amber-300 text-xs mt-0.5 block">
                        {m.recipientName || m.performedBy.userName}
                      </span>
                    </div>
                    <div className="col-span-1 sm:col-span-2 pt-2 border-t border-slate-850 flex items-center justify-between text-slate-400">
                      <span className="text-[10px] text-slate-500">Petugas Penyerah (Gudang):</span>
                      <span className="font-medium text-slate-200">{m.performedBy.userName}</span>
                    </div>
                    {m.notes && (
                      <div className="col-span-1 sm:col-span-2 pt-2 border-t border-slate-850">
                        <span className="text-[10px] text-slate-500 block">Keterangan Pekerjaan / Catatan SPK</span>
                        <span className="font-medium text-white text-xs mt-0.5 block">{m.notes}</span>
                      </div>
                    )}
                  </div>

                  {/* Material & Cost Breakdown */}
                  <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-3">
                    <span className="font-bold text-slate-300 block border-b border-slate-850 pb-2">
                      Rincian Bahan Baku & Valuasi HPP
                    </span>

                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-bold text-white text-sm block">{m.productName}</span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[11px] text-cyan-400">{m.productCode}</span>
                          <span className="text-slate-500">•</span>
                          <span className="text-slate-400 text-[11px]">Satuan: {m.unit}</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-300 font-extrabold border border-blue-500/30 text-sm">
                        -{m.quantity} {m.unit}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-slate-850 space-y-2">
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Harga Beli Satuan (HPP Modal):</span>
                        <span className="font-mono font-semibold text-slate-200">{formatRupiah(unitCost)}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Volume Pemakaian:</span>
                        <span className="font-semibold text-slate-200">{m.quantity} {m.unit}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Sisa Stok di Gudang:</span>
                        <span className="font-mono text-cyan-400 font-bold">{m.finalStock} {m.unit}</span>
                      </div>
                      <div className="flex items-center justify-between text-blue-300 text-sm font-bold pt-2 border-t border-slate-800">
                        <span>Total Beban Biaya Pokok (HPP):</span>
                        <span className="font-mono text-base text-blue-300">{formatRupiah(totalCost)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Tagihan & Pembayaran Divisi */}
                  <div className={`p-3.5 rounded-xl border space-y-2.5 ${
                    !m.billingRequired
                      ? 'bg-slate-950 border-slate-800'
                      : m.paymentStatus === 'lunas'
                      ? 'bg-emerald-950/30 border-emerald-500/40'
                      : 'bg-amber-950/30 border-amber-500/40'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200 text-xs flex items-center gap-1.5">
                        <CreditCard className={`w-4 h-4 ${
                          !m.billingRequired ? 'text-slate-400' : m.paymentStatus === 'lunas' ? 'text-emerald-400' : 'text-amber-400'
                        }`} />
                        <span>Status Pembebanan / Tagihan Divisi</span>
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        !m.billingRequired
                          ? 'bg-slate-800 text-slate-300'
                          : m.paymentStatus === 'lunas'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {!m.billingRequired ? 'Beban Internal Murni' : m.paymentStatus === 'lunas' ? 'LUNAS' : 'BELUM LUNAS'}
                      </span>
                    </div>

                    {m.billingRequired ? (
                      <div className="space-y-1.5 text-[11px] pt-1 border-t border-slate-800/80">
                        <div className="flex items-center justify-between text-slate-400">
                          <span>Total Tagihan Bahan:</span>
                          <span className="font-mono text-slate-200 font-bold">{formatRupiah(totalCost)}</span>
                        </div>
                        <div className="flex items-center justify-between text-slate-400">
                          <span>Nominal Terbayar:</span>
                          <span className="font-mono text-emerald-400 font-bold">
                            {formatRupiah(m.paymentStatus === 'lunas' ? totalCost : (m.paidAmount || 0))}
                          </span>
                        </div>
                        {m.paymentStatus === 'belum_lunas' && (
                          <div className="flex items-center justify-between text-amber-300 font-semibold">
                            <span>Sisa Piutang Tertagih:</span>
                            <span className="font-mono font-bold text-amber-300">
                              {formatRupiah(Math.max(0, totalCost - (m.paidAmount || 0)))}
                            </span>
                          </div>
                        )}
                        <div className="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-800/60">
                          <span>Metode Pembayaran:</span>
                          <span className="text-slate-300 font-medium">{m.paymentMethod || 'Kas Internal / Tunai'}</span>
                        </div>
                        {m.billingDueDate && m.paymentStatus === 'belum_lunas' && (
                          <div className="flex items-center justify-between text-slate-400">
                            <span>Jatuh Tempo:</span>
                            <span className="font-mono text-amber-300 font-bold">{m.billingDueDate}</span>
                          </div>
                        )}
                        {m.paidAt && (
                          <div className="flex items-center justify-between text-slate-400">
                            <span>Tanggal Pelunasan:</span>
                            <span className="font-mono text-emerald-300">{m.paidAt}</span>
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-400">
                        Pemakaian dicatat murni sebagai biaya modal produksi internal (HPP). Divisi pemesan tidak dibebankan kewajiban bayar tagihan.
                      </p>
                    )}
                  </div>

                  {/* Profit & Loss Context */}
                  <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/30 flex items-start gap-2 text-[11px] text-slate-300 leading-relaxed">
                    <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-blue-300 block mb-0.5">Alokasi ke Laporan Laba / Rugi:</span>
                      Biaya sebesar <strong>{formatRupiah(totalCost)}</strong> otomatis dicatat ke akun Biaya Bahan Baku Produksi Internal (HPP). Nilai ini dipakai untuk mengukur laba bersih terhadap omset hasil cetak sablon.
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 flex flex-wrap items-center justify-end gap-2">
                    {m.billingRequired && m.paymentStatus === 'belum_lunas' && (
                      <button
                        type="button"
                        onClick={() => {
                          const remaining = Math.max(0, totalCost - (m.paidAmount || 0));
                          setPayingMovement(m);
                          setModalPaymentAmount(remaining);
                          setModalPaymentDueDate(m.billingDueDate || '');
                          setModalPaymentMethod(m.paymentMethod || 'Kas Internal / Tunai');
                        }}
                        className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Catat Pembayaran</span>
                      </button>
                    )}
                    {m.billingRequired && (
                      <button
                        type="button"
                        onClick={() => setReceiptMovement(m)}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-emerald-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700/60 cursor-pointer"
                      >
                        <Receipt className="w-4 h-4 text-emerald-400" />
                        <span>Kuitansi Resmi</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => window.print()}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700/60 cursor-pointer"
                    >
                      <Printer className="w-4 h-4 text-cyan-400" />
                      <span>Cetak Bukti</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedDetailMovement(null)}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                    >
                      Tutup
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* MODAL CATAT PEMBAYARAN / PELUNASAN TAGIHAN DIVISI */}
      {payingMovement && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">Catat Pembayaran Tagihan</h3>
                  <span className="font-mono text-xs text-indigo-300">{payingMovement.referenceNo}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPayingMovement(null)}
                className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            {(() => {
              const matchedProd = products.find((p) => p.id === payingMovement.productId);
              const unitCost = payingMovement.unitPrice ?? matchedProd?.costPrice ?? 0;
              const totalCost = payingMovement.totalValue ?? (payingMovement.quantity * unitCost);
              const prevPaid = payingMovement.paidAmount ?? 0;
              const remainingToPay = Math.max(0, totalCost - prevPaid);

              return (
                <div className="p-5 space-y-4 text-xs">
                  {/* Info Box */}
                  <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Divisi Pemesan:</span>
                      <span className="font-bold text-cyan-300">{payingMovement.divisionOrRequester}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Bahan Baku:</span>
                      <span className="text-slate-200 font-medium">{payingMovement.productName} ({payingMovement.quantity} {payingMovement.unit})</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 pt-1.5 border-t border-slate-850">
                      <span>Total Beban Tagihan:</span>
                      <span className="font-mono font-bold text-slate-200">{formatRupiah(totalCost)}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Sudah Dibayar:</span>
                      <span className="font-mono text-emerald-400 font-semibold">{formatRupiah(prevPaid)}</span>
                    </div>
                    <div className="flex items-center justify-between text-amber-300 font-bold pt-1.5 border-t border-slate-850">
                      <span>Sisa Piutang Saat Ini:</span>
                      <span className="font-mono text-sm text-amber-300">{formatRupiah(remainingToPay)}</span>
                    </div>
                  </div>

                  {/* Payment Inputs */}
                  <div className="space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-[11px] font-semibold text-slate-300">
                          Nominal Pembayaran Sekarang
                        </label>
                        <button
                          type="button"
                          onClick={() => setModalPaymentAmount(remainingToPay)}
                          className="text-[10px] text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer underline"
                        >
                          Bayar Lunas Penuh ({formatRupiah(remainingToPay)})
                        </button>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-mono text-xs">Rp</span>
                        <input
                          type="number"
                          min="0"
                          step="any"
                          max={remainingToPay}
                          value={modalPaymentAmount}
                          onChange={(e) => setModalPaymentAmount(Math.min(remainingToPay, Math.max(0, parseFloat(e.target.value) || 0)))}
                          className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-sm text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-400 mb-1">
                        Metode Pembayaran
                      </label>
                      <select
                        value={modalPaymentMethod}
                        onChange={(e) => setModalPaymentMethod(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer font-medium"
                      >
                        <option value="Kas Internal / Tunai">Kas Internal / Tunai</option>
                        <option value="Transfer Bank">Transfer Bank</option>
                        <option value="Potong Alokasi Anggaran Divisi">Potong Alokasi Anggaran Divisi</option>
                        <option value="Giro / Nota Divisi">Giro / Nota Divisi</option>
                        <option value="QRIS / Dompet Digital">QRIS / E-Wallet</option>
                      </select>
                    </div>

                    {modalPaymentAmount < remainingToPay && (
                      <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800">
                        <DueDateSelector
                          value={modalPaymentDueDate}
                          onChange={setModalPaymentDueDate}
                          label={`Jatuh Tempo Pembayaran Sisa (${formatRupiah(remainingToPay - modalPaymentAmount)})`}
                          helperText="Pilih batas jatuh tempo untuk sisa tagihan divisi: Tanpa batas (tidak terbatas), atau aksi cepat 2 minggu, 1 bulan, 2 bulan."
                          colorTheme="emerald"
                          compact={true}
                        />
                      </div>
                    )}

                    {/* Result Preview */}
                    <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[11px] flex items-center justify-between">
                      <span className="text-slate-400">Status Setelah Disimpan:</span>
                      <span className={`font-bold px-2 py-0.5 rounded ${
                        modalPaymentAmount >= remainingToPay
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {modalPaymentAmount >= remainingToPay ? '✅ LUNAS' : `⏳ Sisa ${formatRupiah(remainingToPay - modalPaymentAmount)}`}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-2 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setPayingMovement(null)}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="button"
                      disabled={modalPaymentAmount <= 0}
                      onClick={handleConfirmPayment}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>Simpan Pembayaran</span>
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      )}

      {/* MODAL KUITANSI & BUKTI TAGIHAN RESMI */}
      {receiptMovement && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Header */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm sm:text-base font-bold text-white">Kuitansi / Bukti Pembayaran Tagihan</h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleSaveReceiptPdf(receiptMovement)}
                  disabled={isSavingReceiptPdf}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
                  title="Simpan kuitansi ke file PDF"
                >
                  {isSavingReceiptPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isSavingReceiptPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak</span>
                </button>
                <button
                  type="button"
                  onClick={() => setReceiptMovement(null)}
                  className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Document Body */}
            <div className="p-4 sm:p-6 overflow-y-auto bg-slate-950/50">
              {(() => {
                const m = receiptMovement;
                const matchedProd = products.find((p) => p.id === m.productId);
                const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
                const totalCost = m.totalValue ?? (m.quantity * unitCost);
                const isLunas = m.paymentStatus === 'lunas';
                const paid = isLunas ? totalCost : (m.paidAmount ?? 0);
                const remaining = isLunas ? 0 : Math.max(0, totalCost - paid);

                return (
                  <div
                    id="printable-receipt"
                    className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs space-y-5 border border-slate-200"
                  >
                    {/* Header */}
                    <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                          DEPARTEMEN LOGISTIK & PRODUKSI
                        </span>
                        <h2 className="text-lg sm:text-xl font-black text-slate-900">
                          GUDANG SABLON DTF & SUBLIME
                        </h2>
                        <p className="text-[11px] text-slate-600">
                          Bukti Pengeluaran & Penagihan Beban Pemakaian Bahan Baku
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="inline-block px-3 py-1 bg-slate-900 text-white font-extrabold text-xs tracking-wider uppercase rounded">
                          KUITANSI TAGIHAN
                        </span>
                        <p className="font-mono font-bold text-xs text-slate-800 mt-1.5">
                          NO: KWT-{m.referenceNo.replace(/[^a-zA-Z0-9]/g, '')}
                        </p>
                        <p className="text-[10px] text-slate-500">Tanggal: {m.date}</p>
                      </div>
                    </div>

                    {/* Metadata Grid */}
                    <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Telah Diterima Dari / Divisi Pemesan:</span>
                        <span className="font-bold text-slate-900 text-sm">{m.divisionOrRequester || 'Divisi Produksi'}</span>
                        <p className="text-[11px] text-slate-600 mt-0.5">PIC / Pengambil: <strong>{m.recipientName || m.performedBy.userName}</strong></p>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Nomor SPK & Penyerah Gudang:</span>
                        <span className="font-mono font-bold text-indigo-700">{m.referenceNo}</span>
                        <p className="text-[11px] text-slate-600 mt-0.5">Petugas Gudang: <strong>{m.performedBy.userName}</strong></p>
                      </div>
                    </div>

                    {/* Table of items */}
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-y border-slate-300 font-bold text-slate-700 text-[10px] uppercase">
                          <th className="py-2 px-2.5">Deskripsi Bahan Baku</th>
                          <th className="py-2 px-2 text-center">Volume</th>
                          <th className="py-2 px-2 text-right">Harga Satuan</th>
                          <th className="py-2 px-2.5 text-right">Subtotal Beban</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        <tr>
                          <td className="py-2.5 px-2.5">
                            <span className="font-bold text-slate-900 block">{m.productName}</span>
                            <span className="text-[10px] font-mono text-slate-500">Kode: {m.productCode}</span>
                            {m.notes && <p className="text-[10px] text-slate-600 italic mt-0.5">Catatan: {m.notes}</p>}
                          </td>
                          <td className="py-2.5 px-2 text-center font-bold text-slate-800">
                            {m.quantity} {m.unit}
                          </td>
                          <td className="py-2.5 px-2 text-right font-mono text-slate-600">
                            {formatRupiah(unitCost)}
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono font-bold text-slate-900">
                            {formatRupiah(totalCost)}
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr className="border-t-2 border-slate-300 font-bold">
                          <td colSpan={3} className="py-2 px-2.5 text-right text-slate-700">Total Beban Tagihan:</td>
                          <td className="py-2 px-2.5 text-right font-mono font-black text-slate-900">{formatRupiah(totalCost)}</td>
                        </tr>
                        <tr className="text-emerald-700 font-bold bg-emerald-50">
                          <td colSpan={3} className="py-1.5 px-2.5 text-right">Nominal Terbayar:</td>
                          <td className="py-1.5 px-2.5 text-right font-mono">{formatRupiah(paid)}</td>
                        </tr>
                        {!isLunas && (
                          <tr className="text-amber-800 font-bold bg-amber-50">
                            <td colSpan={3} className="py-1.5 px-2.5 text-right">Sisa Piutang (Tempo):</td>
                            <td className="py-1.5 px-2.5 text-right font-mono">{formatRupiah(remaining)}</td>
                          </tr>
                        )}
                      </tfoot>
                    </table>

                    {/* Status Badge & Payment Method */}
                    <div className="flex items-center justify-between p-3 rounded-lg border bg-slate-50">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase block font-semibold">Metode Pembayaran:</span>
                        <span className="font-semibold text-slate-800">{m.paymentMethod || 'Kas Internal / Tunai'}</span>
                        {m.billingDueDate && !isLunas && (
                          <span className="block text-[10px] text-amber-700 mt-0.5">Jatuh Tempo: <strong>{m.billingDueDate}</strong></span>
                        )}
                      </div>
                      <div className="text-center">
                        <span className={`inline-block px-4 py-1.5 rounded-lg border-2 font-black text-sm tracking-wider uppercase transform -rotate-3 ${
                          isLunas
                            ? 'border-emerald-600 text-emerald-700 bg-emerald-50'
                            : 'border-amber-600 text-amber-700 bg-amber-50'
                        }`}>
                          {isLunas ? 'LUNAS' : 'TEMPO / BELUM LUNAS'}
                        </span>
                      </div>
                    </div>

                    {/* Signatures */}
                    <div className="grid grid-cols-2 gap-8 pt-4 text-center text-xs text-slate-600 border-t border-slate-200">
                      <div>
                        <p className="font-semibold">Petugas Kasir / Gudang Penyerah,</p>
                        <div className="h-14"></div>
                        <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6">
                          ( {m.performedBy.userName} )
                        </p>
                      </div>
                      <div>
                        <p className="font-semibold">Yang Menyerahkan / PIC Divisi,</p>
                        <div className="h-14"></div>
                        <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6">
                          ( {m.recipientName || m.divisionOrRequester} )
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            {/* Bottom Footer */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setReceiptMovement(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Tutup
              </button>
              <button
                type="button"
                onClick={() => handleSaveReceiptPdf(receiptMovement)}
                disabled={isSavingReceiptPdf}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
              >
                {isSavingReceiptPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <FileDown className="w-4 h-4" />
                )}
                <span>{isSavingReceiptPdf ? 'Menyimpan PDF...' : 'Simpan PDF Kuitansi'}</span>
              </button>
              <button
                type="button"
                onClick={handlePrintReceipt}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Lembar Kuitansi</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PDF PRINT / PREVIEW MODAL: LAPORAN PEMAKAIAN BAHAN ANTAR DIVISI */}
      {showPdfPreview && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 flex-wrap">
                    <span>Pratinjau Cetak / PDF Laporan Pemakaian Bahan</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-300 border border-blue-500/30 font-mono">
                      {selectedDivisionFilter === 'all' ? 'Antar Seluruh Divisi' : selectedDivisionFilter}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Filter aktif: {filteredProductionMovements.length} SPK • Periode: {dateRangeLabel} • Total Beban: {formatRupiah(filteredTotalCost)}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveProductionPdf}
                  disabled={isSavingProductionPdf}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Unduh dan simpan dokumen sebagai file PDF ke perangkat Anda"
                >
                  {isSavingProductionPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4" />
                  )}
                  <span>{isSavingProductionPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintProduction}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Buka dialog cetak printer bawaan"
                >
                  <Printer className="w-4 h-4 text-blue-400" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPdfPreview(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup Pratinjau"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Notification Banner */}
            {savePdfSuccess && (
              <div className="px-4 py-2 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium shrink-0">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{savePdfSuccess}</span>
              </div>
            )}

            {/* Modal Content: Printable Document Sheet */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
              <div
                id="printable-production-report"
                className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-5xl xl:max-w-[1100px] mx-auto space-y-6"
              >
                {/* Official Letterhead Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-900">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      SISTEM INVENTARISASI & BEBAN HPP PRODUKSI
                    </span>
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
                      GUDANG SUPLAI SABLON DTF & SUBLIME
                    </h1>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Kawasan Industri Kreatif No. 88, Bandung • Kontak Internal Gudang: 0812-9988-7766
                    </p>
                  </div>
                  <div className="text-left sm:text-right shrink-0">
                    <span className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-extrabold text-xs tracking-wider uppercase">
                      LAPORAN PEMAKAIAN ANTAR DIVISI
                    </span>
                    <p className="font-mono font-bold text-xs text-slate-800 mt-2">
                      REF: LAP-PRD-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
                    </p>
                    <p className="text-[11px] text-slate-600">Dicetak: {formatTimestampWIB(new Date())}</p>
                    <p className="text-[11px] text-slate-600">Oleh: <strong>{currentUser.name}</strong> ({currentUser.role})</p>
                  </div>
                </div>

                {/* Executive Parameter & Financial Highlights Audit Box */}
                <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 space-y-3">
                  {/* Parameter Filter Bar */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-slate-200 pb-3">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Cakupan Divisi</span>
                      <span className="font-bold text-slate-900 text-xs block truncate mt-0.5">
                        {selectedDivisionFilter === 'all' ? 'Seluruh Divisi (Semua Unit Kerja)' : selectedDivisionFilter}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Periode Transaksi</span>
                      <span className="font-semibold text-slate-800 text-xs block mt-0.5">{dateRangeLabel}</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Status Pembayaran</span>
                      <span className="font-semibold text-slate-800 text-xs block capitalize mt-0.5">
                        {paymentStatusFilter === 'all'
                          ? 'Semua Status (Lunas, Belum Lunas, Internal)'
                          : paymentStatusFilter === 'lunas'
                          ? 'Hanya Tagihan Lunas'
                          : paymentStatusFilter === 'belum_lunas'
                          ? 'Hanya Piutang Tempo (Belum Lunas)'
                          : 'Hanya Beban Internal Murni'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Volume Transaksi</span>
                      <span className="font-bold text-slate-900 text-xs block mt-0.5">
                        {filteredProductionMovements.length} SPK ({filteredTotalQuantity} unit bahan)
                      </span>
                    </div>
                  </div>

                  {/* 4 Financial Highlight Audit Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Beban Pokok (HPP)</span>
                      <span className="font-mono font-black text-sm text-slate-900 block mt-0.5">
                        {formatRupiah(filteredTotalCost)}
                      </span>
                      <span className="text-[10px] text-slate-500">Akumulasi modal bahan</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-emerald-50/80 border border-emerald-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-emerald-700 uppercase block">Tagihan Divisi Lunas</span>
                      <span className="font-mono font-black text-sm text-emerald-800 block mt-0.5">
                        {formatRupiah(filteredPaidBills)}
                      </span>
                      <span className="text-[10px] text-emerald-600">Dana kas / bank masuk</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-amber-50/80 border border-amber-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-amber-800 uppercase block">Piutang Menunggu Bayar</span>
                      <span className="font-mono font-black text-sm text-amber-900 block mt-0.5">
                        {formatRupiah(filteredUnpaidBills)}
                      </span>
                      <span className="text-[10px] text-amber-700 font-medium">
                        {filteredUnpaidCount > 0 ? `${filteredUnpaidCount} SPK belum lunas (tempo)` : 'Nihil / Semua lunas'}
                      </span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-slate-100 border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-600 uppercase block">Beban Internal Murni</span>
                      <span className="font-mono font-black text-sm text-slate-800 block mt-0.5">
                        {formatRupiah(filteredPureInternalCost)}
                      </span>
                      <span className="text-[10px] text-slate-500">Non-tagihan operasional</span>
                    </div>
                  </div>
                </div>

                {/* RINCIAN LENGKAP TRANSAKSI PEMAKAIAN BAHAN & TAGIHAN PER SPK */}
                <div className="space-y-3 pt-1">
                  <div className="flex items-center justify-between border-b-2 border-slate-900 pb-2">
                    <div>
                      <h2 className="text-sm font-black uppercase tracking-wider text-slate-900">
                        Rincian Pengeluaran Bahan Baku & Status Tagihan per Lembar SPK
                      </h2>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Dokumen audit pencatatan pengeluaran gudang berdasarkan HPP modal dan status pembebanan biaya antar divisi
                      </p>
                    </div>
                    <span className="text-[11px] font-mono font-bold px-2.5 py-1 rounded bg-slate-100 text-slate-800 border border-slate-300">
                      {filteredProductionMovements.length} Transaksi SPK
                    </span>
                  </div>

                  <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-2xs bg-white">
                    <table className="w-full min-w-[960px] text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b-2 border-slate-300 font-extrabold text-slate-700 uppercase text-[10px] tracking-wider">
                          <th className="py-3 px-2 text-center w-10">No</th>
                          <th className="py-3 px-3 min-w-[155px]">No. SPK & Waktu</th>
                          <th className="py-3 px-3 min-w-[160px]">Divisi & Petugas PIC</th>
                          <th className="py-3 px-3 min-w-[190px]">Bahan Baku</th>
                          <th className="py-3 px-2 text-center min-w-[85px]">Jumlah</th>
                          <th className="py-3 px-3 text-right min-w-[105px]">HPP Satuan</th>
                          <th className="py-3 px-3 text-right min-w-[115px]">Total Beban</th>
                          <th className="py-3 px-3 text-center min-w-[140px]">Status & Tagihan</th>
                          <th className="py-3 px-3 min-w-[130px]">Catatan SPK</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {filteredProductionMovements.length === 0 ? (
                          <tr>
                            <td colSpan={9} className="py-8 text-center text-slate-500 italic">
                              Tidak ada rincian transaksi pemakaian bahan yang cocok dengan kriteria filter aktif.
                            </td>
                          </tr>
                        ) : (
                          filteredProductionMovements.map((m, idx) => {
                            const matchedProd = products.find((p) => p.id === m.productId);
                            const unitCost = m.unitPrice ?? matchedProd?.costPrice ?? 0;
                            const totalCost = m.totalValue ?? (m.quantity * unitCost);
                            const isBilled = m.billingRequired ?? false;
                            const isLunas = m.paymentStatus === 'lunas';
                            const paid = isLunas ? totalCost : (m.paidAmount ?? 0);
                            const remaining = isBilled && !isLunas ? Math.max(0, totalCost - paid) : 0;

                            return (
                              <tr key={m.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70 hover:bg-slate-50'}>
                                {/* No */}
                                <td className="py-3 px-2 font-mono text-center text-slate-500">{idx + 1}</td>

                                {/* No. SPK & Waktu */}
                                <td className="py-3 px-3 whitespace-nowrap">
                                  <div className="flex flex-col items-start gap-1">
                                    <span className="font-mono font-bold text-indigo-700 text-xs px-2.5 py-0.5 rounded-md bg-indigo-50 border border-indigo-200/90 whitespace-nowrap shadow-2xs">
                                      {m.referenceNo}
                                    </span>
                                    <span className="text-[10px] text-slate-500 font-mono whitespace-nowrap flex items-center gap-1">
                                      <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>
                                      {m.date}
                                    </span>
                                  </div>
                                </td>

                                {/* Divisi & PIC */}
                                <td className="py-3 px-3">
                                  <span className="font-bold text-slate-900 block text-xs leading-snug">
                                    {m.divisionOrRequester || 'Divisi Produksi'}
                                  </span>
                                  <span className="text-[10px] text-slate-600 block mt-0.5">
                                    PIC: <strong className="text-slate-800 font-semibold">{m.recipientName || m.performedBy.userName}</strong>
                                  </span>
                                </td>

                                {/* Bahan Baku */}
                                <td className="py-3 px-3">
                                  <span className="font-bold text-slate-900 block text-xs leading-snug">{m.productName}</span>
                                  <span className="inline-block mt-0.5 font-mono text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200 font-semibold">
                                    {m.productCode}
                                  </span>
                                </td>

                                {/* Jumlah */}
                                <td className="py-3 px-2 text-center">
                                  <span className="font-mono font-extrabold text-slate-900 text-xs block">{m.quantity}</span>
                                  <span className="text-[10px] text-slate-500 block">{m.unit}</span>
                                </td>

                                {/* HPP Satuan */}
                                <td className="py-3 px-3 text-right font-mono text-slate-700 whitespace-nowrap text-xs">
                                  {formatRupiah(unitCost)}
                                </td>

                                {/* Total Beban */}
                                <td className="py-3 px-3 text-right font-mono font-black text-slate-900 whitespace-nowrap text-xs">
                                  {formatRupiah(totalCost)}
                                </td>

                                {/* Status & Tagihan */}
                                <td className="py-3 px-3 text-center whitespace-nowrap">
                                  {!isBilled ? (
                                    <div className="flex flex-col items-center justify-center gap-0.5">
                                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-300">
                                        INTERNAL
                                      </span>
                                      <span className="text-[9px] text-slate-400 font-medium">Beban Pokok</span>
                                    </div>
                                  ) : isLunas ? (
                                    <div className="flex flex-col items-center justify-center gap-0.5">
                                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                                        LUNAS
                                      </span>
                                      <span className="text-[10px] font-mono text-emerald-700 font-bold whitespace-nowrap">
                                        {formatRupiah(paid)}
                                      </span>
                                    </div>
                                  ) : (
                                    <div className="flex flex-col items-center justify-center gap-1">
                                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 shadow-2xs">
                                        <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                                        TEMPO
                                      </span>
                                      <span className="text-[11px] font-mono text-amber-900 font-black whitespace-nowrap">
                                        Sisa: {formatRupiah(remaining)}
                                      </span>
                                      {m.billingDueDate && (
                                        <span className="text-[9px] font-mono text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200/90 whitespace-nowrap">
                                          Jth: {m.billingDueDate}
                                        </span>
                                      )}
                                    </div>
                                  )}
                                </td>

                                {/* Catatan SPK */}
                                <td className="py-3 px-3 text-slate-600 text-[11px] leading-relaxed">
                                  {m.notes ? m.notes : <span className="text-slate-400">-</span>}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-100 border-t-2 border-slate-900 font-bold text-xs">
                          <td colSpan={4} className="py-3 px-3 uppercase text-slate-900 font-black tracking-wide">
                            Total Akumulasi Terfilter ({filteredProductionMovements.length} SPK):
                          </td>
                          <td className="py-3 px-2 text-center text-slate-900 font-black whitespace-nowrap font-mono">
                            {filteredTotalQuantity} unit
                          </td>
                          <td className="py-3 px-3 text-right font-mono text-slate-400">-</td>
                          <td className="py-3 px-3 text-right font-mono font-black text-slate-900 whitespace-nowrap text-xs">
                            {formatRupiah(filteredTotalCost)}
                          </td>
                          <td className="py-3 px-3 text-center font-mono">
                            {filteredUnpaidBills > 0 ? (
                              <div className="inline-flex flex-col items-center">
                                <span className="text-[9px] uppercase tracking-wider font-bold text-amber-700">Total Piutang</span>
                                <span className="text-amber-900 font-black text-xs whitespace-nowrap">
                                  Sisa: {formatRupiah(filteredUnpaidBills)}
                                </span>
                              </div>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                ✓ Bebas Piutang
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-slate-400 text-center">-</td>
                        </tr>
                        <tr className="bg-slate-900 text-white text-xs">
                          <td colSpan={9} className="py-3 px-4">
                            <div className="flex flex-wrap items-center justify-between gap-3">
                              <div className="flex items-center gap-2">
                                <span className="inline-flex items-center justify-center w-5 h-5 rounded bg-blue-500/20 text-blue-300 font-bold text-[10px]">
                                  ✓
                                </span>
                                <span className="font-bold tracking-wide uppercase text-[11px] text-slate-200">
                                  Ringkasan Audit Finansial:
                                </span>
                              </div>
                              <div className="flex flex-wrap items-center gap-3 text-xs">
                                <div className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-emerald-950/70 border border-emerald-500/40 text-emerald-300 shadow-2xs">
                                  <span className="text-[10px] uppercase font-semibold text-emerald-400">Tagihan Terbayar Lunas:</span>
                                  <span className="font-mono font-bold text-white whitespace-nowrap">{formatRupiah(filteredPaidBills)}</span>
                                </div>
                                <div className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-950/70 border border-amber-500/40 text-amber-300 shadow-2xs">
                                  <span className="text-[10px] uppercase font-semibold text-amber-400">Piutang Menunggu Pelunasan:</span>
                                  <span className="font-mono font-bold text-white whitespace-nowrap">{formatRupiah(filteredUnpaidBills)}</span>
                                  {filteredUnpaidCount > 0 && (
                                    <span className="text-[10px] text-amber-300/80 font-normal">({filteredUnpaidCount} SPK Tempo)</span>
                                  )}
                                </div>
                                <div className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-800/90 border border-slate-700 text-slate-300 shadow-2xs">
                                  <span className="text-[10px] uppercase font-semibold text-slate-400">Beban Internal Murni:</span>
                                  <span className="font-mono font-bold text-white whitespace-nowrap">{formatRupiah(filteredPureInternalCost)}</span>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>

                {/* Accounting Policy Note */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed shadow-2xs">
                  <strong className="text-slate-900 font-bold">Catatan Kebijakan Akuntansi:</strong> Seluruh nominal pemakaian bahan baku dihitung berdasarkan Harga Beli Satuan (HPP Modal). Biaya ini dialokasikan secara proporsional ke divisi pemesan untuk mengukur beban pokok operasional dan menganalisis profitabilitas riil divisi tersebut.
                </div>

                {/* Official Signatures */}
                <div className="grid grid-cols-3 gap-4 pt-6 text-center text-xs text-slate-600 border-t border-slate-300">
                  <div>
                    <p className="font-semibold text-slate-700">Petugas Gudang (Penyerah),</p>
                    <div className="h-16"></div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6">
                      ( {currentUser.name} )
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-700">Koordinator / PIC Divisi,</p>
                    <div className="h-16"></div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6">
                      ( {selectedDivisionFilter === 'all' ? 'Perwakilan Divisi' : selectedDivisionFilter} )
                    </p>
                  </div>
                  <div>
                    <p className="font-semibold text-slate-700">Manajer Operasional / Finance,</p>
                    <div className="h-16"></div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6">
                      ( Manajemen Produksi )
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Bottom Footer Actions */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <span className="text-xs text-slate-400 text-center sm:text-left">
                💡 Dokumen diformat standar A4. Klik <strong>Simpan PDF</strong> untuk download langsung, atau <strong>Cetak</strong> untuk print fisik.
              </span>
              <div className="flex items-center gap-2 ml-auto w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setShowPdfPreview(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={handlePrintProduction}
                  className="flex items-center gap-1.5 px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer shadow-sm active:scale-95"
                >
                  <Printer className="w-4 h-4 text-blue-400" />
                  <span>Cetak (Print)</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveProductionPdf}
                  disabled={isSavingProductionPdf}
                  className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md transition-colors cursor-pointer active:scale-95"
                >
                  {isSavingProductionPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4" />
                  )}
                  <span>{isSavingProductionPdf ? 'Menyimpan PDF...' : 'Simpan PDF (Download)'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL EDIT RIWAYAT PEMAKAIAN PRODUKSI (SPK) */}
      {editingMovement && (() => {
        const prod = products.find((p) => p.id === editingMovement.productId);
        const currentStock = prod?.currentStock ?? 0;
        const oldQty = editingMovement.quantity;
        const newQty = Number(editFormData.quantity) || 0;
        const diff = newQty - oldQty;
        const estimatedNewStock = Math.max(0, currentStock - diff);
        const isExceedStock = diff > 0 && currentStock < diff;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg shadow-2xl text-slate-100 overflow-hidden my-auto animate-in fade-in duration-150">
              <div className="p-4 sm:p-5 bg-amber-950/40 border-b border-amber-500/20 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                    <Edit3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-white">
                      Edit Catatan Pemakaian SPK
                    </h3>
                    <p className="text-[11px] text-amber-300">
                      Bahan: <strong className="text-white">{editingMovement.productName}</strong>
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingMovement(null)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveEdit} className="p-4 sm:p-6 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                      Nomor SPK / Referensi
                    </label>
                    <input
                      type="text"
                      required
                      value={editFormData.referenceNo}
                      onChange={(e) => setEditFormData({ ...editFormData, referenceNo: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                      Tanggal Pemakaian
                    </label>
                    <input
                      type="text"
                      required
                      value={editFormData.date}
                      onChange={(e) => setEditFormData({ ...editFormData, date: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                      Divisi Pemesan
                    </label>
                    <input
                      type="text"
                      required
                      value={editFormData.divisionOrRequester}
                      onChange={(e) => setEditFormData({ ...editFormData, divisionOrRequester: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                      Nama Pengambil / PIC
                    </label>
                    <input
                      type="text"
                      value={editFormData.recipientName}
                      onChange={(e) => setEditFormData({ ...editFormData, recipientName: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                    Jumlah Pemakaian ({editingMovement.unit})
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={editFormData.quantity}
                    onChange={(e) => setEditFormData({ ...editFormData, quantity: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-amber-500"
                  />
                  <div className="mt-1.5 p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-[11px] space-y-0.5">
                    <div className="flex justify-between text-slate-400">
                      <span>Stok gudang saat ini:</span>
                      <span className="font-mono text-white">{currentStock} {editingMovement.unit}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Perubahan kuantiti SPK:</span>
                      <span className={`font-mono font-bold ${diff > 0 ? 'text-amber-400' : diff < 0 ? 'text-emerald-400' : 'text-slate-300'}`}>
                        {oldQty} → {newQty} ({diff >= 0 ? `+${diff}` : diff} {editingMovement.unit})
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Estimasi stok fisik setelah simpan:</span>
                      <span className="font-mono font-bold text-cyan-400">{estimatedNewStock} {editingMovement.unit}</span>
                    </div>
                  </div>
                  {isExceedStock && (
                    <p className="mt-1 text-[11px] text-rose-400 flex items-center gap-1 font-medium">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Stok fisik gudang ({currentStock}) tidak mencukupi untuk tambahan pemakaian ({diff}).</span>
                    </p>
                  )}
                </div>

                {/* Billing toggle */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2.5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editFormData.billingRequired}
                      onChange={(e) => setEditFormData({ ...editFormData, billingRequired: e.target.checked })}
                      className="rounded text-blue-600 focus:ring-0 w-4 h-4 cursor-pointer"
                    />
                    <span className="text-white font-semibold text-xs">Wajib Dibayar / Ditagih ke Divisi Pemesan</span>
                  </label>

                  {editFormData.billingRequired && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2 border-t border-slate-800">
                      <div>
                        <label className="block text-slate-400 text-[10px] mb-1 font-medium">Status Tagihan</label>
                        <select
                          value={editFormData.paymentStatus}
                          onChange={(e) => setEditFormData({ ...editFormData, paymentStatus: e.target.value as any })}
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                        >
                          <option value="belum_lunas">Belum Lunas (Tempo)</option>
                          <option value="lunas">Lunas</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-400 text-[10px] mb-1 font-medium">Metode Pembayaran</label>
                        <input
                          type="text"
                          value={editFormData.paymentMethod}
                          onChange={(e) => setEditFormData({ ...editFormData, paymentMethod: e.target.value })}
                          className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                        />
                      </div>

                      {editFormData.paymentStatus === 'belum_lunas' && (
                        <div className="sm:col-span-2">
                          <label className="block text-slate-400 text-[10px] mb-1 font-medium">Jatuh Tempo Pembayaran</label>
                          <input
                            type="date"
                            value={editFormData.billingDueDate}
                            onChange={(e) => setEditFormData({ ...editFormData, billingDueDate: e.target.value })}
                            className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
                          />
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-slate-400 text-[11px] mb-1 font-medium">
                    Catatan Pemakaian
                  </label>
                  <textarea
                    rows={2}
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-2.5 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setEditingMovement(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isExceedStock}
                    className="px-5 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Simpan Perubahan</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* MODAL KONFIRMASI HAPUS PEMAKAIAN PRODUKSI (REVERT STOK) */}
      {deletingMovement && (() => {
        const prod = products.find((p) => p.id === deletingMovement.productId);
        const currentStock = prod?.currentStock ?? 0;
        const returnQty = deletingMovement.quantity;
        const stockAfterDelete = currentStock + returnQty;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-xs overflow-y-auto">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg shadow-2xl text-slate-100 overflow-hidden my-auto animate-in fade-in duration-150">
              <div className="p-4 sm:p-5 bg-rose-950/40 border-b border-rose-500/20 flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Hapus Catatan Pemakaian Produksi
                  </h3>
                  <p className="text-[11px] text-rose-300">
                    Aksi ini akan menghapus catatan SPK dan mengembalikan stok bahan ke gudang.
                  </p>
                </div>
              </div>

              <div className="p-4 sm:p-6 space-y-4 text-xs">
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2.5">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Nomor SPK:</span>
                    <span className="font-mono font-bold text-indigo-300">{deletingMovement.referenceNo}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Tanggal Transaksi:</span>
                    <span className="font-mono text-slate-200">{deletingMovement.date}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Bahan Baku:</span>
                    <span className="font-bold text-white text-right">{deletingMovement.productName}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Divisi Pemesan:</span>
                    <span className="text-cyan-300 font-medium">{deletingMovement.divisionOrRequester || 'Internal'}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Kuantiti yang Dikembalikan:</span>
                    <span className="font-bold font-mono text-emerald-400">
                      +{returnQty} {deletingMovement.unit}
                    </span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-200">
                  <div className="flex items-center gap-2 font-bold text-xs mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Pengembalian (Revert) Stok Bahan ke Gudang</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Stok saat ini di gudang adalah <strong>{currentStock} {deletingMovement.unit}</strong>. Menghapus SPK ini akan mengembalikan stok sebesar <strong>{returnQty} {deletingMovement.unit}</strong> sehingga stok gudang bertambah menjadi <strong>{stockAfterDelete} {deletingMovement.unit}</strong>.
                  </p>
                </div>

                <div className="pt-2 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setDeletingMovement(null)}
                    disabled={isDeleting}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmDelete}
                    disabled={isDeleting}
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                  >
                    {isDeleting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    <span>Ya, Hapus SPK & Revert Stok</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Floating Action Notice Toast */}
      {actionNotice && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200 max-w-md">
          <div className={`p-4 rounded-2xl border shadow-2xl flex items-center gap-3 ${
            actionNotice.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/90 border-rose-500/40 text-rose-200'
          }`}>
            {actionNotice.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <p className="text-xs font-medium leading-relaxed">{actionNotice.message}</p>
          </div>
        </div>
      )}
    </div>
  );
};
