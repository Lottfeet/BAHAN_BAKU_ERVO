import React from 'react';
import { 
  Boxes, 
  ShoppingBag, 
  ClipboardCheck, 
  FileText, 
  Menu 
} from 'lucide-react';
import { User } from '../types';

interface MobileBottomNavProps {
  activeTab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname';
  setActiveTab: (tab: 'inventory' | 'purchases' | 'production' | 'sales' | 'analytics' | 'reports' | 'logs' | 'access' | 'opname') => void;
  currentUser: User;
  onOpenMobileMenu: () => void;
  lowStockCount?: number;
  unpaidInvoicesCount?: number;
  overdueInvoicesCount?: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  onOpenMobileMenu,
  lowStockCount = 0,
  unpaidInvoicesCount = 0,
  overdueInvoicesCount = 0,
}) => {
  const isSalesAllowed = currentUser.canCreateSalesInvoice || currentUser.canViewFinancials;
  const isOpnameAllowed = currentUser.canStockOpname ?? true;

  const items = [
    {
      id: 'inventory' as const,
      label: 'Stok Bahan',
      icon: Boxes,
      badge: lowStockCount > 0 ? (lowStockCount > 99 ? '99+' : lowStockCount) : null,
      badgeColor: 'bg-rose-500 text-white',
      allowed: true,
    },
    {
      id: 'purchases' as const,
      label: 'Pembelian',
      icon: ShoppingBag,
      allowed: true,
    },
    {
      id: 'opname' as const,
      label: 'Stok Opname',
      icon: ClipboardCheck,
      allowed: isOpnameAllowed,
    },
    {
      id: 'sales' as const,
      label: 'Penjualan',
      icon: FileText,
      allowed: isSalesAllowed,
    },
  ];

  return (
    <nav 
      aria-label="Navigasi Bawah Seluler"
      className="fixed bottom-0 inset-x-0 z-40 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800/90 md:hidden px-1 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))] shadow-2xl select-none"
    >
      <div className="grid grid-cols-5 items-center gap-0.5">
        {items.map((item) => {
          if (!item.allowed) return null;
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all cursor-pointer active:scale-95 ${
                isActive
                  ? 'text-cyan-400 font-bold bg-cyan-500/10'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                {item.badge && (
                  <span className={`absolute -top-1.5 -right-2.5 min-w-[15px] h-[15px] px-1 rounded-full text-[9px] font-extrabold flex items-center justify-center ring-2 ring-slate-900 shadow-xs ${item.badgeColor}`}>
                    {item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] mt-0.5 truncate max-w-full tracking-tight ${isActive ? 'text-cyan-300 font-semibold' : 'text-slate-400'}`}>
                {item.label}
              </span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-0.5 shadow-sm shadow-cyan-400/50" />
              )}
            </button>
          );
        })}

        {/* 5th Button: Open Mobile Drawer Menu for More Modules */}
        <button
          onClick={onOpenMobileMenu}
          className="relative flex flex-col items-center justify-center py-1 px-1 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800/50 transition-all cursor-pointer active:scale-95"
          title="Buka Menu Lainnya"
        >
          <Menu className="w-5 h-5 text-slate-300" />
          <span className="text-[10px] mt-0.5 truncate max-w-full tracking-tight text-slate-300 font-medium">
            Menu Lain
          </span>
        </button>
      </div>
    </nav>
  );
};
