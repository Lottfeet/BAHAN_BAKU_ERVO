import React, { useState, useMemo } from 'react';
import {
  ClipboardCheck,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Printer,
  Download,
  FileDown,
  Loader2,
  Plus,
  Minus,
  Save,
  Clock,
  Sparkles,
  Info,
  X,
  Boxes,
  MapPin,
  TrendingDown,
  TrendingUp,
  Tag,
  History,
  FileText
} from 'lucide-react';
import { Product, StockMovement, User, CategoryItem } from '../types';
import { formatRupiah, formatDateIndo } from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';

export interface OpnameDraftItem {
  productId: string;
  productCode: string;
  productName: string;
  category: string;
  unit: string;
  location: string;
  costPrice: number;
  systemStock: number;
  physicalStock: number | null;
  difference: number;
  totalVarianceValue: number;
  reasonCategory: 'Sesuai' | 'Rusak/Cacat' | 'Susut/Cutting' | 'Salah Catat' | 'Kadaluarsa' | 'Stok Terselip' | 'Lainnya';
  notes: string;
  isAudited: boolean;
}

interface StockOpnameViewProps {
  products: Product[];
  movements: StockMovement[];
  categories: CategoryItem[];
  currentUser: User;
  onApplyOpname: (adjustments: {
    productId: string;
    productName: string;
    productCode: string;
    category: string;
    unit: string;
    systemStock: number;
    physicalStock: number;
    difference: number;
    costPrice: number;
    reasonCategory: string;
    notes: string;
  }[], sessionNotes: string, auditorUser?: User) => void;
  onOpenMasterData?: () => void;
}

export const StockOpnameView: React.FC<StockOpnameViewProps> = ({
  products,
  movements,
  categories,
  currentUser,
  onApplyOpname,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'worksheet' | 'history'>('worksheet');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLocation, setSelectedLocation] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'unaudited' | 'discrepancy' | 'deficit' | 'surplus' | 'match' | 'audited'>('all');
  
  // Opname session reference
  const [sessionRefNo] = useState<string>(() => {
    const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    return `OPN-${today}-${rand}`;
  });

  // Working state for physical count per product - nilai hitung fisik aktual dikosongkan secara default
  const [opnameItems, setOpnameItems] = useState<Record<string, {
    physicalStock: number | null;
    reasonCategory: OpnameDraftItem['reasonCategory'];
    notes: string;
    isAudited: boolean;
  }>>({});

  // Confirm Modal state
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [sessionNotes, setSessionNotes] = useState<string>('Audit fisik periodik gudang DTF & Sublime');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // PDF Preview Modal
  const [showBeritaAcaraModal, setShowBeritaAcaraModal] = useState<boolean>(false);
  const [isSavingPdf, setIsSavingPdf] = useState<boolean>(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Extract unique locations from products
  const locationsList = useMemo(() => {
    const locs = Array.from(new Set(products.map((p) => p.location || 'Gudang Utama').filter(Boolean)));
    return locs.sort();
  }, [products]);

  // Transform products with active opname draft values - Fisik Aktual Kosong (null) sampai diisi pengguna
  const draftList: OpnameDraftItem[] = useMemo(() => {
    return products.map((prod) => {
      const state = opnameItems[prod.id];
      const hasEntered = state?.physicalStock !== undefined && state.physicalStock !== null;
      const physicalStock = hasEntered ? state.physicalStock : null;
      const difference = hasEntered ? (physicalStock! - prod.currentStock) : 0;
      const totalVarianceValue = hasEntered ? difference * prod.costPrice : 0;
      const reasonCategory = state?.reasonCategory || (difference === 0 ? 'Sesuai' : 'Susut/Cutting');
      const notes = state?.notes || '';
      const isAudited = hasEntered && (state?.isAudited ?? false);

      return {
        productId: prod.id,
        productCode: prod.code,
        productName: prod.name,
        category: prod.category,
        unit: prod.unit,
        location: prod.location || 'Gudang Utama',
        costPrice: prod.costPrice,
        systemStock: prod.currentStock,
        physicalStock,
        difference,
        totalVarianceValue,
        reasonCategory,
        notes,
        isAudited,
      };
    });
  }, [products, opnameItems]);

  // Filtered draft list
  const filteredDraftList = useMemo(() => {
    return draftList.filter((item) => {
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchCode = item.productCode.toLowerCase().includes(q);
        const matchName = item.productName.toLowerCase().includes(q);
        const matchLoc = item.location.toLowerCase().includes(q);
        if (!matchCode && !matchName && !matchLoc) return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }

      // Location filter
      if (selectedLocation !== 'all' && item.location !== selectedLocation) {
        return false;
      }

      // Status filter
      if (statusFilter === 'unaudited' && item.isAudited) return false;
      if (statusFilter === 'discrepancy' && (!item.isAudited || item.difference === 0)) return false;
      if (statusFilter === 'deficit' && (!item.isAudited || item.difference >= 0)) return false;
      if (statusFilter === 'surplus' && (!item.isAudited || item.difference <= 0)) return false;
      if (statusFilter === 'match' && (!item.isAudited || item.difference !== 0)) return false;
      if (statusFilter === 'audited' && !item.isAudited) return false;

      return true;
    });
  }, [draftList, searchQuery, selectedCategory, selectedLocation, statusFilter]);

  // Aggregate stats
  const stats = useMemo(() => {
    const totalItems = draftList.length;
    const auditedItems = draftList.filter((i) => i.isAudited && i.physicalStock !== null).length;
    const unauditedItems = totalItems - auditedItems;
    const itemsWithDiscrepancy = draftList.filter((i) => i.isAudited && i.physicalStock !== null && i.difference !== 0);
    const deficitItems = draftList.filter((i) => i.isAudited && i.physicalStock !== null && i.difference < 0);
    const surplusItems = draftList.filter((i) => i.isAudited && i.physicalStock !== null && i.difference > 0);
    const matchItems = draftList.filter((i) => i.isAudited && i.physicalStock !== null && i.difference === 0);

    const netVarianceRupiah = draftList.reduce((sum, i) => sum + i.totalVarianceValue, 0);
    const totalDeficitRupiah = deficitItems.reduce((sum, i) => sum + Math.abs(i.totalVarianceValue), 0);
    const totalSurplusRupiah = surplusItems.reduce((sum, i) => sum + i.totalVarianceValue, 0);

    const accuracyRate = auditedItems > 0 ? (matchItems.length / auditedItems) * 100 : 100;

    return {
      totalItems,
      auditedItems,
      unauditedItems,
      discrepancyCount: itemsWithDiscrepancy.length,
      deficitCount: deficitItems.length,
      surplusCount: surplusItems.length,
      matchCount: matchItems.length,
      netVarianceRupiah,
      totalDeficitRupiah,
      totalSurplusRupiah,
      accuracyRate,
    };
  }, [draftList]);

  // Filtered opname movements from history
  const opnameMovements = useMemo(() => {
    return movements.filter((m) => m.type === 'adjustment');
  }, [movements]);

  // Handlers for physical count updates
  const handleSetPhysical = (productId: string, val: number, defaultSystemStock: number) => {
    const safeVal = Math.max(0, val);
    setOpnameItems((prev) => {
      const current = prev[productId] || {
        physicalStock: safeVal,
        reasonCategory: 'Sesuai',
        notes: '',
        isAudited: true,
      };
      const diff = safeVal - defaultSystemStock;
      const defaultReason = diff === 0 ? 'Sesuai' : (current.reasonCategory === 'Sesuai' ? 'Susut/Cutting' : current.reasonCategory);

      return {
        ...prev,
        [productId]: {
          ...current,
          physicalStock: safeVal,
          reasonCategory: defaultReason,
          isAudited: true,
        },
      };
    });
  };

  const handleClearPhysical = (productId: string) => {
    setOpnameItems((prev) => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
  };

  const handleStepPhysical = (productId: string, step: number, defaultSystemStock: number) => {
    const state = opnameItems[productId];
    const currentVal = state?.physicalStock !== undefined && state.physicalStock !== null
      ? state.physicalStock
      : defaultSystemStock;
    handleSetPhysical(productId, currentVal + step, defaultSystemStock);
  };

  const handleSetReason = (productId: string, reason: OpnameDraftItem['reasonCategory']) => {
    setOpnameItems((prev) => {
      const current = prev[productId] || {
        physicalStock: null,
        reasonCategory: reason,
        notes: '',
        isAudited: true,
      };
      return {
        ...prev,
        [productId]: {
          ...current,
          reasonCategory: reason,
          isAudited: true,
        },
      };
    });
  };

  const handleSetNotes = (productId: string, notes: string) => {
    setOpnameItems((prev) => {
      const current = prev[productId] || {
        physicalStock: null,
        reasonCategory: 'Sesuai',
        notes,
        isAudited: true,
      };
      return {
        ...prev,
        [productId]: {
          ...current,
          notes,
          isAudited: true,
        },
      };
    });
  };

  const handleMatchAll = () => {
    if (window.confirm('Isi otomatis seluruh nilai hitung fisik sama dengan stok sistem?')) {
      const newItems: typeof opnameItems = {};
      products.forEach((p) => {
        newItems[p.id] = {
          physicalStock: p.currentStock,
          reasonCategory: 'Sesuai',
          notes: 'Sesuai stok sistem',
          isAudited: true,
        };
      });
      setOpnameItems(newItems);
    }
  };

  const handleResetWorksheet = () => {
    if (window.confirm('Kosongkan semua nilai hitung fisik aktual di lembar opname?')) {
      setOpnameItems({});
    }
  };

  // Submit adjustments
  const handleConfirmApply = () => {
    // Collect all items that have discrepancy and have been audited
    const discrepancyItems = draftList.filter((item) => item.isAudited && item.physicalStock !== null && item.difference !== 0);
    if (discrepancyItems.length === 0) {
      alert('Tidak ada bahan yang memiliki selisih stok fisik yang telah dihitung.');
      setShowConfirmModal(false);
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = discrepancyItems.map((item) => ({
        productId: item.productId,
        productName: item.productName,
        productCode: item.productCode,
        category: item.category,
        unit: item.unit,
        systemStock: item.systemStock,
        physicalStock: item.physicalStock!,
        difference: item.difference,
        costPrice: item.costPrice,
        reasonCategory: item.reasonCategory,
        notes: item.notes || `Stok Opname ${item.reasonCategory} (${item.difference > 0 ? `+${item.difference}` : item.difference} ${item.unit})`,
      }));

      onApplyOpname(payload, sessionNotes, currentUser);
      setShowConfirmModal(false);
      setOpnameItems({});
    } finally {
      setIsSubmitting(false);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'No. Ref Opname',
      'Kode Bahan',
      'Nama Bahan Baku',
      'Kategori',
      'Lokasi Rak',
      'Satuan',
      'Stok Sistem',
      'Stok Fisik Aktual',
      'Selisih (+/-)',
      'HPP Satuan (Rp)',
      'Total Selisih Rupiah (Rp)',
      'Kategori Alasan',
      'Status Audit',
      'Catatan Petugas',
    ];

    const rows = filteredDraftList.map((item) => [
      `"${sessionRefNo}"`,
      `"${item.productCode}"`,
      `"${item.productName.replace(/"/g, '""')}"`,
      `"${item.category}"`,
      `"${item.location}"`,
      `"${item.unit}"`,
      item.systemStock,
      item.physicalStock !== null ? item.physicalStock : '',
      item.physicalStock !== null ? item.difference : '',
      item.costPrice,
      item.physicalStock !== null ? item.totalVarianceValue : '',
      `"${item.reasonCategory}"`,
      item.isAudited ? 'SUDAH DIPERIKSA' : 'BELUM DIPERIKSA',
      `"${(item.notes || '-').replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Hasil_Stok_Opname_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Save Berita Acara PDF
  const handleSaveBeritaAcaraPdf = async () => {
    setIsSavingPdf(true);
    setSaveSuccessMsg(null);
    try {
      const filename = `Berita_Acara_Stok_Opname_${sessionRefNo}_${new Date().toISOString().slice(0, 10)}.pdf`;
      const success = await exportElementToPdf('printable-opname-report', filename);
      if (success) {
        setSaveSuccessMsg('Berita Acara Stok Opname berhasil disimpan & diunduh sebagai PDF!');
        setTimeout(() => setSaveSuccessMsg(null), 4500);
      }
    } finally {
      setIsSavingPdf(false);
    }
  };

  const handlePrintBeritaAcara = () => {
    printElementDirect('printable-opname-report');
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <ClipboardCheck className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base sm:text-lg font-bold text-white">Stok Opname & Audit Fisik</h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Audit Gudang
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">
              Ref: {sessionRefNo}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Verifikasi dan sinkronisasi berkala antara jumlah stok fisik aktual di rak gudang dengan data sistem komputer. Identifikasi selisih, barang rusak, serta susut pemotongan.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          {/* Sub tab toggle */}
          <div className="flex items-center bg-slate-800/90 p-0.5 rounded-xl border border-slate-700 text-xs">
            <button
              type="button"
              onClick={() => setActiveSubTab('worksheet')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all cursor-pointer ${
                activeSubTab === 'worksheet' ? 'bg-cyan-600 text-white font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Lembar Audit
            </button>
            <button
              type="button"
              onClick={() => setActiveSubTab('history')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1 cursor-pointer ${
                activeSubTab === 'history' ? 'bg-cyan-600 text-white font-bold shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Riwayat Mutasi ({opnameMovements.length})</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleExportCSV}
            title="Ekspor data hasil opname ke CSV"
            className="flex items-center justify-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            type="button"
            onClick={() => setShowBeritaAcaraModal(true)}
            title="Buka Berita Acara Opname Resmi"
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-colors shadow-xs active:scale-95 cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Berita Acara</span>
          </button>

          {activeSubTab === 'worksheet' && (
            <button
              type="button"
              onClick={() => setShowConfirmModal(true)}
              disabled={stats.discrepancyCount === 0}
              className={`flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm active:scale-95 cursor-pointer ${
                stats.discrepancyCount > 0
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-900/30'
                  : 'bg-slate-800 text-slate-500 border border-slate-700/60 cursor-not-allowed'
              }`}
            >
              <Save className="w-4 h-4" />
              <span>Terapkan Hasil Opname ({stats.discrepancyCount} Selisih)</span>
            </button>
          )}
        </div>
      </div>

      {/* KPI Metrics Dashboard Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        {/* Total Diperiksa */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Total Bahan Terdaftar</span>
            <div className="p-1.5 bg-blue-500/10 text-blue-400 rounded-lg">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-white">{stats.totalItems}</span>
            <span className="text-[11px] text-slate-400">Bahan</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-cyan-400" />
            <span>{stats.auditedItems} item telah diverifikasi</span>
          </div>
        </div>

        {/* Akurasi Stok */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Tingkat Akurasi Stok</span>
            <div className="p-1.5 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="text-xl sm:text-2xl font-black text-emerald-400">
              {stats.accuracyRate.toFixed(1)}%
            </span>
          </div>
          <div className="mt-1 text-[11px] text-emerald-500/90 font-medium">
            {stats.matchCount} dari {stats.totalItems} bahan cocok sempurna
          </div>
        </div>

        {/* Bahan Berselisih */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Item Ada Selisih</span>
            <div className="p-1.5 bg-amber-500/10 text-amber-400 rounded-lg">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className={`text-xl sm:text-2xl font-black ${stats.discrepancyCount > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
              {stats.discrepancyCount}
            </span>
            <span className="text-[11px] text-slate-400">Item</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 flex items-center gap-2">
            <span className="text-rose-400">Kurang: {stats.deficitCount}</span>
            <span>•</span>
            <span className="text-cyan-400">Lebih: {stats.surplusCount}</span>
          </div>
        </div>

        {/* Dampak Finansial (HPP) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Dampak Finansial Bersih</span>
            <div className={`p-1.5 rounded-lg ${stats.netVarianceRupiah < 0 ? 'bg-rose-500/10 text-rose-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
              {stats.netVarianceRupiah < 0 ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
            </div>
          </div>
          <div className="mt-1.5">
            <span className={`text-lg sm:text-xl font-black truncate block ${
              stats.netVarianceRupiah < 0 ? 'text-rose-400' : stats.netVarianceRupiah > 0 ? 'text-cyan-400' : 'text-slate-300'
            }`}>
              {currentUser.canViewFinancials ? (
                `${stats.netVarianceRupiah < 0 ? '-' : stats.netVarianceRupiah > 0 ? '+' : ''}${formatRupiah(Math.abs(stats.netVarianceRupiah))}`
              ) : (
                'Rp ••••••••'
              )}
            </span>
          </div>
          <div className="mt-1 text-[11px] text-slate-400 truncate">
            {currentUser.canViewFinancials ? (
              <span>Susut: {formatRupiah(stats.totalDeficitRupiah)} | Lebih: {formatRupiah(stats.totalSurplusRupiah)}</span>
            ) : (
              'Akses terbatas keuangan'
            )}
          </div>
        </div>
      </div>

      {activeSubTab === 'worksheet' ? (
        /* ================= WORKSHEET TAB ================= */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
          {/* Filter & Search Bar */}
          <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="flex flex-1 items-center gap-2">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Cari kode bahan, nama, atau lokasi rak..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-hidden focus:border-cyan-500 transition-colors"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Category Filter */}
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-hidden focus:border-cyan-500 cursor-pointer"
              >
                <option value="all">Semua Kategori</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>

              {/* Location / Rak Filter */}
              <select
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-hidden focus:border-cyan-500 cursor-pointer hidden sm:block"
              >
                <option value="all">Semua Lokasi Rak</option>
                {locationsList.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Status Filter Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-cyan-600 text-white font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-850'
              }`}
            >
              Semua Bahan ({draftList.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('unaudited')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'unaudited'
                  ? 'bg-slate-700 text-white font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-850'
              }`}
            >
              <Clock className="w-3 h-3 text-slate-400" />
              <span>Belum Diisi ({stats.unauditedItems})</span>
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('discrepancy')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer flex items-center gap-1.5 ${
                statusFilter === 'discrepancy'
                  ? 'bg-amber-600 text-white font-bold'
                  : 'bg-slate-950 text-amber-400/90 hover:text-amber-300 border border-slate-850'
              }`}
            >
              <AlertTriangle className="w-3 h-3 text-amber-400" />
              <span>Ada Selisih ({stats.discrepancyCount})</span>
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('deficit')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer ${
                statusFilter === 'deficit'
                  ? 'bg-rose-600 text-white font-bold'
                  : 'bg-slate-950 text-rose-400/90 hover:text-rose-300 border border-slate-850'
              }`}
            >
              Defisit / Kurang (-{stats.deficitCount})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('surplus')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer ${
                statusFilter === 'surplus'
                  ? 'bg-blue-600 text-white font-bold'
                  : 'bg-slate-950 text-blue-400/90 hover:text-blue-300 border border-slate-850'
              }`}
            >
              Surplus / Lebih (+{stats.surplusCount})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('match')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-colors shrink-0 cursor-pointer ${
                statusFilter === 'match'
                  ? 'bg-emerald-600 text-white font-bold'
                  : 'bg-slate-950 text-emerald-400/90 hover:text-emerald-300 border border-slate-850'
              }`}
            >
              Cocok / Sesuai ({stats.matchCount})
            </button>
          </div>

          {/* Audit Worksheet Table */}
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-3">Kode & Bahan Baku</th>
                  <th className="py-3 px-3">Lokasi Rak</th>
                  <th className="py-3 px-3 text-center">Stok Sistem</th>
                  <th className="py-3 px-3 text-center w-52">Hitung Fisik Aktual</th>
                  <th className="py-3 px-3 text-center">Selisih (+/-)</th>
                  {currentUser.canViewFinancials && <th className="py-3 px-3 text-right">Dampak Nilai (HPP)</th>}
                  <th className="py-3 px-3">Alasan & Catatan Selisih</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {filteredDraftList.length === 0 ? (
                  <tr>
                    <td colSpan={currentUser.canViewFinancials ? 7 : 6} className="py-12 text-center text-slate-500">
                      <div className="max-w-xs mx-auto space-y-2">
                        <CheckCircle2 className="w-8 h-8 mx-auto text-slate-600" />
                        <p className="font-semibold text-slate-400">Tidak ada bahan baku yang cocok dengan filter aktif.</p>
                        <p className="text-[11px] text-slate-600">Silakan ubah pencarian atau filter status untuk melihat bahan lainnya.</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredDraftList.map((item) => {
                    const isDiff = item.isAudited && item.difference !== 0;
                    const isNegative = item.isAudited && item.difference < 0;
                    const isPositive = item.isAudited && item.difference > 0;

                    return (
                      <tr
                        key={item.productId}
                        className={`hover:bg-slate-800/40 transition-colors ${
                          !item.isAudited
                            ? ''
                            : isNegative
                            ? 'bg-rose-950/10'
                            : isPositive
                            ? 'bg-blue-950/10'
                            : ''
                        }`}
                      >
                        {/* Name & Code */}
                        <td className="py-3 px-3">
                          <div className="font-bold text-white text-xs">{item.productName}</div>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-[10px] text-cyan-400">{item.productCode}</span>
                            <span className="text-[10px] text-slate-500">•</span>
                            <span className="text-[10px] text-slate-400 uppercase">{item.category}</span>
                          </div>
                        </td>

                        {/* Location */}
                        <td className="py-3 px-3">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-800/90 text-slate-300 font-mono text-[10px] border border-slate-700/80">
                            <MapPin className="w-2.5 h-2.5 text-cyan-400" />
                            <span>{item.location}</span>
                          </span>
                        </td>

                        {/* System Stock */}
                        <td className="py-3 px-3 text-center">
                          <span className="font-mono font-bold text-slate-300 text-xs">
                            {item.systemStock}
                          </span>
                          <span className="text-[10px] text-slate-500 block">{item.unit.split(' ')[0]}</span>
                        </td>

                        {/* Physical Stock Counter Input - Dikosongkan secara default */}
                        <td className="py-3 px-3">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleStepPhysical(item.productId, -1, item.systemStock)}
                              className="w-7 h-7 flex items-center justify-center bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                              title="Kurangi 1"
                            >
                              <Minus className="w-3 h-3" />
                            </button>

                            <input
                              type="number"
                              min="0"
                              step="any"
                              placeholder="- (isi fisik)"
                              value={item.physicalStock === null ? '' : item.physicalStock}
                              onChange={(e) => {
                                const raw = e.target.value;
                                if (raw === '') {
                                  handleClearPhysical(item.productId);
                                } else {
                                  handleSetPhysical(item.productId, parseFloat(raw) || 0, item.systemStock);
                                }
                              }}
                              className={`w-24 text-center font-mono font-bold text-xs py-1.5 rounded-lg border focus:outline-hidden transition-all ${
                                !item.isAudited
                                  ? 'bg-slate-950 text-slate-300 placeholder:text-slate-600 border-slate-800 focus:border-cyan-500'
                                  : isNegative
                                  ? 'bg-rose-950/40 text-rose-300 border-rose-500/50 focus:border-rose-400'
                                  : isPositive
                                  ? 'bg-blue-950/40 text-blue-300 border-blue-500/50 focus:border-blue-400'
                                  : 'bg-slate-950 text-emerald-300 border-emerald-500/40 focus:border-cyan-500'
                              }`}
                            />

                            <button
                              type="button"
                              onClick={() => handleStepPhysical(item.productId, 1, item.systemStock)}
                              className="w-7 h-7 flex items-center justify-center bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                              title="Tambah 1"
                            >
                              <Plus className="w-3 h-3" />
                            </button>

                            {/* Tombol Kosongkan jika sudah diisi */}
                            {item.isAudited && (
                              <button
                                type="button"
                                onClick={() => handleClearPhysical(item.productId)}
                                className="p-1.5 text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                                title="Kosongkan nilai hitung fisik"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Tombol samakan dengan sistem jika selisih */}
                            {isDiff && (
                              <button
                                type="button"
                                onClick={() => handleSetPhysical(item.productId, item.systemStock, item.systemStock)}
                                className="p-1.5 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                                title="Cocokkan dengan stok sistem"
                              >
                                <RotateCcw className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </td>

                        {/* Difference Badge */}
                        <td className="py-3 px-3 text-center">
                          {!item.isAudited ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-950 text-slate-500 font-mono text-[11px] border border-slate-800/80">
                              Belum diisi
                            </span>
                          ) : isDiff ? (
                            <span
                              className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-mono font-bold text-xs border ${
                                isNegative
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  : 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                              }`}
                            >
                              {isPositive ? `+${item.difference}` : item.difference} {item.unit.split(' ')[0]}
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-400 font-mono text-[11px] border border-emerald-500/30">
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Cocok (0)</span>
                            </span>
                          )}
                        </td>

                        {/* Financial Impact */}
                        {currentUser.canViewFinancials && (
                          <td className="py-3 px-3 text-right">
                            {!item.isAudited ? (
                              <span className="text-slate-600 font-mono text-xs">-</span>
                            ) : isDiff ? (
                              <div>
                                <span
                                  className={`font-mono font-bold text-xs ${
                                    isNegative ? 'text-rose-400' : 'text-cyan-400'
                                  }`}
                                >
                                  {isPositive ? '+' : '-'}{formatRupiah(Math.abs(item.totalVarianceValue))}
                                </span>
                                <span className="text-[10px] text-slate-500 block font-mono">
                                  HPP: {formatRupiah(item.costPrice)}
                                </span>
                              </div>
                            ) : (
                              <span className="text-slate-500 font-mono text-xs">Rp 0</span>
                            )}
                          </td>
                        )}

                        {/* Reason Dropdown & Notes */}
                        <td className="py-3 px-3">
                          {!item.isAudited ? (
                            <span className="text-slate-500 text-[11px] italic">Menunggu audit fisik</span>
                          ) : isDiff ? (
                            <div className="space-y-1.5 min-w-[200px]">
                              <select
                                value={item.reasonCategory}
                                onChange={(e) => handleSetReason(item.productId, e.target.value as any)}
                                className="w-full bg-slate-950 border border-slate-750 text-slate-200 rounded-lg px-2 py-1 text-[11px] focus:outline-hidden focus:border-cyan-500 cursor-pointer"
                              >
                                <option value="Susut/Cutting">Susut / Sisa Pemotongan Roll</option>
                                <option value="Rusak/Cacat">Barang Rusak / Cacat Pabrik</option>
                                <option value="Salah Catat">Salah Catat Masuk / Keluar</option>
                                <option value="Kadaluarsa">Kadaluarsa / Mengering</option>
                                <option value="Stok Terselip">Ditemukan Terselip / Bonus</option>
                                <option value="Lainnya">Lainnya / Catatan Khusus</option>
                              </select>
                              <input
                                type="text"
                                placeholder="Tuliskan keterangan detail..."
                                value={item.notes}
                                onChange={(e) => handleSetNotes(item.productId, e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 text-slate-300 placeholder:text-slate-600 rounded-lg px-2 py-0.5 text-[10px] focus:outline-hidden focus:border-cyan-500"
                              />
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[11px] italic">Stok fisik sesuai tercatat</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Quick Bottom Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 text-xs text-slate-400">
            <div>
              Menampilkan {filteredDraftList.length} dari {draftList.length} total bahan baku •{' '}
              <strong className="text-white">{stats.discrepancyCount} bahan</strong> memerlukan penyesuaian.
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowBeritaAcaraModal(true)}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Pratinjau Berita Acara A4
              </button>
              <button
                type="button"
                onClick={() => setShowConfirmModal(true)}
                disabled={stats.discrepancyCount === 0}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer ${
                  stats.discrepancyCount > 0
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                Terapkan Hasil Opname ({stats.discrepancyCount} Selisih)
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* ================= HISTORY TAB ================= */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-white text-sm">Riwayat Penyesuaian Stok Opname</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Daftar seluruh mutasi audit fisik (koreksi stok masuk/keluar) yang telah dieksekusi.
              </p>
            </div>
            <span className="px-2.5 py-1 rounded-lg text-xs font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Total {opnameMovements.length} Mutasi
            </span>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] tracking-wider font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-3">Tanggal & Ref</th>
                  <th className="py-3 px-3">Bahan Baku</th>
                  <th className="py-3 px-3 text-center">Koreksi Stok</th>
                  <th className="py-3 px-3 text-center">Sebelum &rarr; Sesudah</th>
                  {currentUser.canViewFinancials && <th className="py-3 px-3 text-right">Nilai Selisih (HPP)</th>}
                  <th className="py-3 px-3">Alasan & Catatan Audit</th>
                  <th className="py-3 px-3">Petugas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {opnameMovements.length === 0 ? (
                  <tr>
                    <td colSpan={currentUser.canViewFinancials ? 7 : 6} className="py-12 text-center text-slate-500">
                      <div className="max-w-xs mx-auto space-y-1.5">
                        <History className="w-8 h-8 mx-auto text-slate-600" />
                        <p className="font-semibold text-slate-400">Belum ada riwayat penyesuaian opname.</p>
                        <p className="text-[11px] text-slate-600">Lakukan stok opname pada tab Lembar Audit untuk mencatat penyesuaian fisik pertama.</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  opnameMovements.map((mov) => {
                    const diff = mov.finalStock - mov.previousStock;
                    const isPositive = diff > 0;

                    return (
                      <tr key={mov.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-3">
                          <span className="font-mono text-slate-200 block">{mov.date}</span>
                          <span className="font-mono text-[10px] text-cyan-400">{mov.referenceNo}</span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="font-bold text-white">{mov.productName}</div>
                          <span className="font-mono text-[10px] text-slate-400">{mov.productCode}</span>
                        </td>
                        <td className="py-3 px-3 text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-md font-mono font-bold text-xs border ${
                              isPositive
                                ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                                : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            }`}
                          >
                            {isPositive ? `+${diff}` : diff} {mov.unit.split(' ')[0]}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-center font-mono">
                          <span className="text-slate-400">{mov.previousStock}</span> &rarr;{' '}
                          <span className="text-white font-bold">{mov.finalStock}</span>
                        </td>
                        {currentUser.canViewFinancials && (
                          <td className="py-3 px-3 text-right font-mono font-semibold">
                            <span className={isPositive ? 'text-cyan-400' : 'text-rose-400'}>
                              {isPositive ? '+' : '-'}{formatRupiah(Math.abs(mov.totalValue || 0))}
                            </span>
                          </td>
                        )}
                        <td className="py-3 px-3 text-slate-300 max-w-xs">
                          <span className="text-xs">{mov.notes || '-'}</span>
                        </td>
                        <td className="py-3 px-3 text-slate-400 text-[11px]">
                          {mov.performedBy.userName}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= MODAL KONFIRMASI TERAPKAN OPNAME ================= */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full p-5 sm:p-6 shadow-2xl text-slate-100 my-auto space-y-4 animate-in fade-in duration-200">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Konfirmasi Terapkan Penyesuaian Stok Opname
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Aksi ini akan menyelaraskan stok sistem dengan hitungan fisik riil di gudang.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Summary Box */}
            <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Nomor Referensi Sesi:</span>
                <span className="font-mono font-bold text-cyan-300">{sessionRefNo}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Bahan yang Akan Disesuaikan:</span>
                <span className="font-bold text-amber-400">{stats.discrepancyCount} Bahan</span>
              </div>
              {currentUser.canViewFinancials && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-850">
                  <span className="text-slate-400">Estimasi Selisih Finansial Bersih:</span>
                  <span className={`font-mono font-bold ${stats.netVarianceRupiah < 0 ? 'text-rose-400' : 'text-cyan-400'}`}>
                    {stats.netVarianceRupiah < 0 ? '-' : '+'}{formatRupiah(Math.abs(stats.netVarianceRupiah))}
                  </span>
                </div>
              )}
            </div>

            {/* Items Discrepancy List preview */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 block mb-1.5">
                Rincian Selisih ({stats.discrepancyCount} Item):
              </span>
              <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1">
                {draftList
                  .filter((i) => i.isAudited && i.physicalStock !== null && i.difference !== 0)
                  .map((item) => (
                    <div
                      key={item.productId}
                      className="p-2 rounded-lg bg-slate-950/80 border border-slate-800/80 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-white block">{item.productName}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {item.location} • {item.reasonCategory}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className={`font-mono font-bold ${item.difference < 0 ? 'text-rose-400' : 'text-cyan-400'}`}>
                          {item.systemStock} &rarr; {item.physicalStock} ({item.difference > 0 ? `+${item.difference}` : item.difference} {item.unit.split(' ')[0]})
                        </span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>

            {/* Notes input */}
            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">
                Catatan Berita Acara / Keterangan Sesi Opname:
              </label>
              <textarea
                rows={2}
                value={sessionNotes}
                onChange={(e) => setSessionNotes(e.target.value)}
                placeholder="Contoh: Stok opname akhir bulan Maret, ditemukan selisih cutting roll..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-hidden focus:border-cyan-500"
              />
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmApply}
                disabled={isSubmitting}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm active:scale-95 cursor-pointer"
              >
                {isSubmitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                <span>{isSubmitting ? 'Memproses...' : 'Ya, Terapkan Sekarang'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL PRATINJAU BERITA ACARA STOK OPNAME (A4 / PDF) ================= */}
      {showBeritaAcaraModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Berita Acara Stok Opname Fisik Gudang</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                      {sessionRefNo}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Tanggal: {new Date().toISOString().slice(0, 10)} • Auditor: {currentUser.name} • Total Bahan: {draftList.length}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveBeritaAcaraPdf}
                  disabled={isSavingPdf}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Unduh Berita Acara sebagai file PDF resmi"
                >
                  {isSavingPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isSavingPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintBeritaAcara}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Cetak Berita Acara lewat printer bawaan"
                >
                  <Printer className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowBeritaAcaraModal(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup Pratinjau"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Notification Banner */}
            {saveSuccessMsg && (
              <div className="px-4 py-2 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium shrink-0">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{saveSuccessMsg}</span>
              </div>
            )}

            {/* Modal Body: Printable Document Sheet */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
              <div
                id="printable-opname-report"
                className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-4xl mx-auto space-y-6"
              >
                {/* Official Letterhead */}
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-900">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      DIVISI LOGISTIK & AUDIT FISIK PERGUDANGAN
                    </span>
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
                      GUDANG SABLON DTF & SUBLIME
                    </h1>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      Kawasan Industri Kreatif No. 88, Bandung • Telp: 0812-9988-7766 • Email: logistik@cetakprint.com
                    </p>
                  </div>
                  <div className="text-right sm:self-start bg-slate-50 p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] font-bold uppercase text-slate-500 block">Nomor Berita Acara:</span>
                    <span className="font-mono font-bold text-sm text-slate-900">{sessionRefNo}</span>
                    <div className="mt-1 text-[11px] text-slate-600">
                      <span>Tanggal Audit: <strong>{new Date().toISOString().slice(0, 10)}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Title & Purpose */}
                <div className="text-center py-2 border-b border-slate-200">
                  <h2 className="text-base font-extrabold text-slate-900 tracking-wide uppercase">
                    BERITA ACARA HASIL STOK OPNAME FISIK & REKONSILIASI
                  </h2>
                  <p className="text-[11px] text-slate-600 mt-1">
                    Keterangan: {sessionNotes || 'Verifikasi stok fisik aktual di rak penyimpanan gudang dan rekonsiliasi data inventaris.'}
                  </p>
                </div>

                {/* KPI Summary Grid */}
                <div className="grid grid-cols-4 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200 text-center text-xs">
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Item Diperiksa</span>
                    <span className="font-mono font-bold text-sm text-slate-900">{stats.totalItems} Bahan</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Stok Sesuai (Match)</span>
                    <span className="font-mono font-bold text-sm text-emerald-700">{stats.matchCount} Bahan ({stats.accuracyRate.toFixed(1)}%)</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Jumlah Item Selisih</span>
                    <span className="font-mono font-bold text-sm text-amber-700">{stats.discrepancyCount} Bahan</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Dampak Selisih HPP</span>
                    <span className="font-mono font-bold text-sm text-slate-900">
                      {currentUser.canViewFinancials ? (
                        `${stats.netVarianceRupiah < 0 ? '-' : stats.netVarianceRupiah > 0 ? '+' : ''}${formatRupiah(Math.abs(stats.netVarianceRupiah))}`
                      ) : (
                        '••••••••'
                      )}
                    </span>
                  </div>
                </div>

                {/* Detailed Table */}
                <div className="space-y-2">
                  <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                    Daftar Rekonsiliasi Rincian Bahan Baku:
                  </h3>
                  <table className="w-full border-collapse border border-slate-300 text-[11px]">
                    <thead className="bg-slate-100 font-bold text-slate-800 border-b border-slate-300">
                      <tr>
                        <th className="p-2 text-left border-r border-slate-300">No</th>
                        <th className="p-2 text-left border-r border-slate-300">Kode & Nama Bahan</th>
                        <th className="p-2 text-center border-r border-slate-300">Lokasi Rak</th>
                        <th className="p-2 text-center border-r border-slate-300">Stok Sistem</th>
                        <th className="p-2 text-center border-r border-slate-300">Stok Fisik</th>
                        <th className="p-2 text-center border-r border-slate-300">Selisih (+/-)</th>
                        {currentUser.canViewFinancials && <th className="p-2 text-right border-r border-slate-300">Harga HPP</th>}
                        {currentUser.canViewFinancials && <th className="p-2 text-right border-r border-slate-300">Total Selisih</th>}
                        <th className="p-2 text-left">Alasan / Catatan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {draftList.map((item, idx) => {
                        const isDiff = item.isAudited && item.difference !== 0;
                        const isNegative = item.isAudited && item.difference < 0;

                        return (
                          <tr key={item.productId} className={isDiff ? (isNegative ? 'bg-rose-50/50' : 'bg-blue-50/50') : ''}>
                            <td className="p-2 text-center font-mono border-r border-slate-300 text-slate-500">
                              {idx + 1}
                            </td>
                            <td className="p-2 font-semibold border-r border-slate-300 text-slate-900">
                              <div>{item.productName}</div>
                              <span className="font-mono text-[9px] text-slate-500">{item.productCode} • {(item.category || '').toUpperCase()}</span>
                            </td>
                            <td className="p-2 text-center font-mono border-r border-slate-300 text-slate-700">
                              {item.location}
                            </td>
                            <td className="p-2 text-center font-mono border-r border-slate-300 text-slate-700">
                              {item.systemStock} {item.unit.split(' ')[0]}
                            </td>
                            <td className="p-2 text-center font-mono font-bold border-r border-slate-300 text-slate-900">
                              {item.physicalStock !== null ? `${item.physicalStock} ${item.unit.split(' ')[0]}` : '- (Belum diisi)'}
                            </td>
                            <td className={`p-2 text-center font-mono font-bold border-r border-slate-300 ${
                              isDiff ? (isNegative ? 'text-rose-700' : 'text-blue-700') : 'text-slate-500'
                            }`}>
                              {!item.isAudited ? '-' : item.difference > 0 ? `+${item.difference} ${item.unit.split(' ')[0]}` : `${item.difference} ${item.unit.split(' ')[0]}`}
                            </td>
                            {currentUser.canViewFinancials && (
                              <td className="p-2 text-right font-mono border-r border-slate-300 text-slate-700">
                                {formatRupiah(item.costPrice)}
                              </td>
                            )}
                            {currentUser.canViewFinancials && (
                              <td className={`p-2 text-right font-mono font-bold border-r border-slate-300 ${
                                isDiff ? (isNegative ? 'text-rose-700' : 'text-blue-700') : 'text-slate-500'
                              }`}>
                                {isDiff ? `${item.difference > 0 ? '+' : '-'}${formatRupiah(Math.abs(item.totalVarianceValue))}` : 'Rp 0'}
                              </td>
                            )}
                            <td className="p-2 text-[10px] text-slate-600">
                              {!item.isAudited ? 'Belum dihitung' : isDiff ? `${item.reasonCategory}${item.notes ? ` — ${item.notes}` : ''}` : 'Sesuai fisik'}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-400">
                      <tr>
                        <td colSpan={currentUser.canViewFinancials ? 7 : 5} className="p-2 text-right uppercase text-[10px]">
                          Total Selisih Bersih Finansial:
                        </td>
                        {currentUser.canViewFinancials && (
                          <td className="p-2 text-right font-mono text-xs font-black">
                            {stats.netVarianceRupiah < 0 ? '-' : stats.netVarianceRupiah > 0 ? '+' : ''}{formatRupiah(Math.abs(stats.netVarianceRupiah))}
                          </td>
                        )}
                        <td className="p-2 text-slate-500 text-[10px]">
                          {stats.discrepancyCount} bahan berselisih
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Signatures */}
                <div className="pt-6 border-t-2 border-slate-900 space-y-2">
                  <p className="text-[11px] text-slate-600 text-center italic">
                    Demikian Berita Acara Stok Opname ini dibuat dengan sebenar-benarnya berdasarkan perhitungan fisik faktual di gudang penyimpanan.
                  </p>
                  <div className="grid grid-cols-3 gap-6 pt-6 text-center text-xs text-slate-700">
                    <div>
                      <p className="font-semibold text-slate-600">Petugas Hitung (Auditor),</p>
                      <p className="text-[10px] text-slate-500">Staf / Operator Gudang</p>
                      <div className="h-16 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                        ( {currentUser.name} )
                      </p>
                    </div>

                    <div>
                      <p className="font-semibold text-slate-600">Diverifikasi Oleh,</p>
                      <p className="text-[10px] text-slate-500">Supervisor Gudang & Logistik</p>
                      <div className="h-16 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                        ( Agus Setiawan, S.T. )
                      </p>
                    </div>

                    <div>
                      <p className="font-semibold text-slate-600">Disetujui Oleh,</p>
                      <p className="text-[10px] text-slate-500">Pemilik Usaha (Owner)</p>
                      <div className="h-16 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                        ( Budi Santoso )
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <span className="text-xs text-slate-400 text-center sm:text-left">
                💡 Berita Acara diformat standar A4. Simpan langsung sebagai file <strong>PDF</strong> atau cetak dokumen fisik.
              </span>
              <div className="flex items-center gap-2 ml-auto w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setShowBeritaAcaraModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={handlePrintBeritaAcara}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                >
                  <Printer className="w-4 h-4 text-cyan-400" />
                  <span>Cetak (Print)</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveBeritaAcaraPdf}
                  disabled={isSavingPdf}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                >
                  {isSavingPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4" />
                  )}
                  <span>{isSavingPdf ? 'Menyimpan PDF...' : 'Simpan PDF (Download)'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
