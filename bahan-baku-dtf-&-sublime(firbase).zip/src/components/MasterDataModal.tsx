import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  Trash2, 
  Tag, 
  Scale, 
  MapPin, 
  Truck,
  Users,
  Phone,
  AlertCircle, 
  Check, 
  Layers, 
  Info,
  Edit3,
  Building2
} from 'lucide-react';
import { CategoryItem, Product, SupplierItem, CustomerItem, StockMovement, Invoice } from '../types';

interface MasterDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'category' | 'unit' | 'location' | 'supplier' | 'customer' | 'division';
  categories: CategoryItem[];
  units: string[];
  locations: string[];
  suppliers: SupplierItem[];
  customers?: CustomerItem[];
  divisions?: string[];
  products: Product[];
  invoices?: Invoice[];
  movements?: StockMovement[];
  onAddCategory: (category: CategoryItem) => void;
  onDeleteCategory: (categoryId: string) => { success: boolean; message?: string };
  onUpdateCategory?: (oldCatId: string, updatedCategory: CategoryItem) => { success: boolean; message?: string };
  onAddUnit: (unit: string) => void;
  onDeleteUnit: (unit: string) => { success: boolean; message?: string };
  onUpdateUnit?: (oldUnit: string, newUnit: string) => { success: boolean; message?: string };
  onAddLocation: (location: string) => void;
  onDeleteLocation: (location: string) => { success: boolean; message?: string };
  onUpdateLocation?: (oldLocation: string, newLocation: string) => { success: boolean; message?: string };
  onAddDivision?: (division: string) => void;
  onDeleteDivision?: (division: string) => { success: boolean; message?: string };
  onUpdateDivision?: (oldDivision: string, newDivision: string) => { success: boolean; message?: string };
  onAddSupplier: (supplier: SupplierItem) => void;
  onDeleteSupplier: (supplierId: string) => { success: boolean; message?: string };
  onUpdateSupplier?: (updatedSupplier: SupplierItem) => { success: boolean; message?: string };
  onAddCustomer?: (customer: CustomerItem) => void;
  onDeleteCustomer?: (customerId: string) => { success: boolean; message?: string };
  onUpdateCustomer?: (updatedCustomer: CustomerItem) => { success: boolean; message?: string };
}

export const MasterDataModal: React.FC<MasterDataModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'category',
  categories,
  units,
  locations,
  suppliers,
  customers = [],
  divisions = [],
  products,
  invoices = [],
  movements = [],
  onAddCategory,
  onDeleteCategory,
  onUpdateCategory,
  onAddUnit,
  onDeleteUnit,
  onUpdateUnit,
  onAddLocation,
  onDeleteLocation,
  onUpdateLocation,
  onAddDivision,
  onDeleteDivision,
  onUpdateDivision,
  onAddSupplier,
  onDeleteSupplier,
  onUpdateSupplier,
  onAddCustomer,
  onDeleteCustomer,
  onUpdateCustomer,
}) => {
  const [activeTab, setActiveTab] = useState<'category' | 'unit' | 'location' | 'supplier' | 'customer' | 'division'>(initialTab);

  // Category Add Form State
  const [newCatName, setNewCatName] = useState('');
  const [newCatPrefix, setNewCatPrefix] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('📦');
  const [newCatDesc, setNewCatDesc] = useState('');

  // Category Edit State
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editCatName, setEditCatName] = useState('');
  const [editCatPrefix, setEditCatPrefix] = useState('');
  const [editCatIcon, setEditCatIcon] = useState('📦');
  const [editCatDesc, setEditCatDesc] = useState('');

  // Unit Add Form State
  const [newUnitName, setNewUnitName] = useState('');

  // Unit Edit State
  const [editingUnit, setEditingUnit] = useState<string | null>(null);
  const [editUnitName, setEditUnitName] = useState('');

  // Location Add Form State
  const [newLocationName, setNewLocationName] = useState('');

  // Location Edit State
  const [editingLocation, setEditingLocation] = useState<string | null>(null);
  const [editLocationName, setEditLocationName] = useState('');

  // Division Add Form State
  const [newDivName, setNewDivName] = useState('');

  // Division Edit State
  const [editingDivision, setEditingDivision] = useState<string | null>(null);
  const [editDivisionName, setEditDivisionName] = useState('');

  // Supplier Add Form State
  const [newSupName, setNewSupName] = useState('');
  const [newSupPhone, setNewSupPhone] = useState('');
  const [newSupAddress, setNewSupAddress] = useState('');
  const [newSupNotes, setNewSupNotes] = useState('');

  // Supplier Edit State
  const [editingSupId, setEditingSupId] = useState<string | null>(null);
  const [editSupName, setEditSupName] = useState('');
  const [editSupPhone, setEditSupPhone] = useState('');
  const [editSupAddress, setEditSupAddress] = useState('');
  const [editSupNotes, setEditSupNotes] = useState('');

  // Customer Add Form State
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');
  const [newCustNotes, setNewCustNotes] = useState('');

  // Customer Edit State
  const [editingCustId, setEditingCustId] = useState<string | null>(null);
  const [editCustName, setEditCustName] = useState('');
  const [editCustPhone, setEditCustPhone] = useState('');
  const [editCustAddress, setEditCustAddress] = useState('');
  const [editCustNotes, setEditCustNotes] = useState('');

  // Feedback message
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const showNotification = (msg: string, isError: boolean = false) => {
    if (isError) {
      setErrorMsg(msg);
      setTimeout(() => setErrorMsg(null), 4000);
    } else {
      setSuccessMsg(msg);
      setTimeout(() => setSuccessMsg(null), 3000);
    }
  };

  const cancelAllEdits = () => {
    setEditingCatId(null);
    setEditingUnit(null);
    setEditingLocation(null);
    setEditingDivision(null);
    setEditingSupId(null);
    setEditingCustId(null);
  };

  const handleTabChange = (tab: 'category' | 'unit' | 'location' | 'division' | 'supplier' | 'customer') => {
    cancelAllEdits();
    setActiveTab(tab);
  };

  // ==========================================
  // CATEGORY HANDLERS
  // ==========================================
  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newCatName.trim();
    let prefix = (newCatPrefix || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

    if (!name) {
      showNotification('Nama kategori tidak boleh kosong', true);
      return;
    }

    if (!prefix) {
      prefix = name.slice(0, 3).toUpperCase();
    }

    const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-');
    if (categories.some((c) => c.id === id || (c.prefix || '').toUpperCase() === prefix.toUpperCase())) {
      showNotification(`Kategori atau prefix "${prefix}" sudah terdaftar`, true);
      return;
    }

    const newCategory: CategoryItem = {
      id,
      name,
      prefix,
      icon: newCatIcon.trim() || '📦',
      description: newCatDesc.trim() || `Kategori bahan baku ${name}`,
    };

    onAddCategory(newCategory);
    setNewCatName('');
    setNewCatPrefix('');
    setNewCatDesc('');
    showNotification(`Kategori "${name}" (Kode: ${prefix}) berhasil ditambahkan!`);
  };

  const startEditingCategory = (cat: CategoryItem) => {
    cancelAllEdits();
    setEditingCatId(cat.id);
    setEditCatName(cat.name);
    setEditCatPrefix(cat.prefix);
    setEditCatIcon(cat.icon || '📦');
    setEditCatDesc(cat.description || '');
  };

  const handleSaveEditCategory = (e: React.FormEvent, cat: CategoryItem) => {
    e.preventDefault();
    const name = editCatName.trim();
    let prefix = (editCatPrefix || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

    if (!name) {
      showNotification('Nama kategori tidak boleh kosong', true);
      return;
    }
    if (!prefix) {
      prefix = name.slice(0, 3).toUpperCase();
    }

    if (categories.some((c) => c.id !== cat.id && (c.prefix || '').toUpperCase() === prefix.toUpperCase())) {
      showNotification(`Prefix "${prefix}" sudah digunakan oleh kategori lain`, true);
      return;
    }

    const updated: CategoryItem = {
      ...cat,
      name,
      prefix,
      icon: editCatIcon.trim() || '📦',
      description: editCatDesc.trim() || `Kategori bahan baku ${name}`,
    };

    if (onUpdateCategory) {
      const res = onUpdateCategory(cat.id, updated);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah kategori', true);
        return;
      }
    }
    setEditingCatId(null);
    showNotification(`Kategori "${name}" berhasil diperbarui!`);
  };

  const handleDeleteCategory = (catId: string, catName: string) => {
    const result = onDeleteCategory(catId);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus kategori', true);
    } else {
      if (editingCatId === catId) setEditingCatId(null);
      showNotification(`Kategori "${catName}" berhasil dihapus.`);
    }
  };

  // ==========================================
  // UNIT HANDLERS
  // ==========================================
  const handleCreateUnit = (e: React.FormEvent) => {
    e.preventDefault();
    const unit = newUnitName.trim();
    if (!unit) {
      showNotification('Nama satuan tidak boleh kosong', true);
      return;
    }

    if (units.some((u) => u.toLowerCase() === unit.toLowerCase())) {
      showNotification(`Satuan "${unit}" sudah terdaftar`, true);
      return;
    }

    onAddUnit(unit);
    setNewUnitName('');
    showNotification(`Satuan "${unit}" berhasil ditambahkan!`);
  };

  const startEditingUnit = (unit: string) => {
    cancelAllEdits();
    setEditingUnit(unit);
    setEditUnitName(unit);
  };

  const handleSaveEditUnit = (e: React.FormEvent, oldUnit: string) => {
    e.preventDefault();
    const unit = editUnitName.trim();
    if (!unit) {
      showNotification('Nama satuan tidak boleh kosong', true);
      return;
    }
    if (unit.toLowerCase() !== oldUnit.toLowerCase() && units.some((u) => u.toLowerCase() === unit.toLowerCase())) {
      showNotification(`Satuan "${unit}" sudah terdaftar`, true);
      return;
    }

    if (onUpdateUnit) {
      const res = onUpdateUnit(oldUnit, unit);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah satuan', true);
        return;
      }
    }
    setEditingUnit(null);
    showNotification(`Satuan "${oldUnit}" berhasil diubah menjadi "${unit}"!`);
  };

  const handleDeleteUnit = (unit: string) => {
    const result = onDeleteUnit(unit);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus satuan', true);
    } else {
      if (editingUnit === unit) setEditingUnit(null);
      showNotification(`Satuan "${unit}" berhasil dihapus.`);
    }
  };

  // ==========================================
  // LOCATION HANDLERS
  // ==========================================
  const handleCreateLocation = (e: React.FormEvent) => {
    e.preventDefault();
    const loc = newLocationName.trim();
    if (!loc) {
      showNotification('Nama lokasi penyimpanan tidak boleh kosong', true);
      return;
    }

    if (locations.some((l) => l.toLowerCase() === loc.toLowerCase())) {
      showNotification(`Lokasi "${loc}" sudah ada dalam daftar`, true);
      return;
    }

    onAddLocation(loc);
    setNewLocationName('');
    showNotification(`Lokasi "${loc}" berhasil ditambahkan!`);
  };

  const startEditingLocation = (loc: string) => {
    cancelAllEdits();
    setEditingLocation(loc);
    setEditLocationName(loc);
  };

  const handleSaveEditLocation = (e: React.FormEvent, oldLoc: string) => {
    e.preventDefault();
    const loc = editLocationName.trim();
    if (!loc) {
      showNotification('Nama lokasi penyimpanan tidak boleh kosong', true);
      return;
    }
    if (loc.toLowerCase() !== oldLoc.toLowerCase() && locations.some((l) => l.toLowerCase() === loc.toLowerCase())) {
      showNotification(`Lokasi "${loc}" sudah ada dalam daftar`, true);
      return;
    }

    if (onUpdateLocation) {
      const res = onUpdateLocation(oldLoc, loc);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah lokasi', true);
        return;
      }
    }
    setEditingLocation(null);
    showNotification(`Lokasi "${oldLoc}" berhasil diubah menjadi "${loc}"!`);
  };

  const handleDeleteLocation = (loc: string) => {
    const result = onDeleteLocation(loc);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus lokasi', true);
    } else {
      if (editingLocation === loc) setEditingLocation(null);
      showNotification(`Lokasi "${loc}" berhasil dihapus.`);
    }
  };

  // ==========================================
  // DIVISION HANDLERS
  // ==========================================
  const handleCreateDivision = (e: React.FormEvent) => {
    e.preventDefault();
    const div = newDivName.trim();
    if (!div) {
      showNotification('Nama divisi / unit pemohon tidak boleh kosong', true);
      return;
    }

    if (divisions.some((d) => d.toLowerCase() === div.toLowerCase())) {
      showNotification(`Divisi "${div}" sudah terdaftar`, true);
      return;
    }

    if (onAddDivision) {
      onAddDivision(div);
    }
    setNewDivName('');
    showNotification(`Divisi "${div}" berhasil ditambahkan!`);
  };

  const startEditingDivision = (div: string) => {
    cancelAllEdits();
    setEditingDivision(div);
    setEditDivisionName(div);
  };

  const handleSaveEditDivision = (e: React.FormEvent, oldDiv: string) => {
    e.preventDefault();
    const div = editDivisionName.trim();
    if (!div) {
      showNotification('Nama divisi tidak boleh kosong', true);
      return;
    }
    if (div.toLowerCase() !== oldDiv.toLowerCase() && divisions.some((d) => d.toLowerCase() === div.toLowerCase())) {
      showNotification(`Divisi "${div}" sudah terdaftar`, true);
      return;
    }

    if (onUpdateDivision) {
      const res = onUpdateDivision(oldDiv, div);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah divisi', true);
        return;
      }
    }
    setEditingDivision(null);
    showNotification(`Divisi "${oldDiv}" berhasil diubah menjadi "${div}"!`);
  };

  const handleDeleteDivision = (div: string) => {
    if (!onDeleteDivision) return;
    const result = onDeleteDivision(div);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus divisi', true);
    } else {
      if (editingDivision === div) setEditingDivision(null);
      showNotification(`Divisi "${div}" berhasil dihapus.`);
    }
  };

  // ==========================================
  // SUPPLIER HANDLERS
  // ==========================================
  const handleCreateSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newSupName.trim();
    if (!name) {
      showNotification('Nama suplier tidak boleh kosong', true);
      return;
    }

    if (suppliers.some((s) => s.name.toLowerCase() === name.toLowerCase())) {
      showNotification(`Suplier "${name}" sudah terdaftar`, true);
      return;
    }

    const newSupplier: SupplierItem = {
      id: `sup-${Date.now()}`,
      name,
      phone: newSupPhone.trim() || undefined,
      address: newSupAddress.trim() || undefined,
      notes: newSupNotes.trim() || undefined,
    };

    onAddSupplier(newSupplier);
    setNewSupName('');
    setNewSupPhone('');
    setNewSupAddress('');
    setNewSupNotes('');
    showNotification(`Suplier "${name}" berhasil ditambahkan!`);
  };

  const startEditingSupplier = (sup: SupplierItem) => {
    cancelAllEdits();
    setEditingSupId(sup.id);
    setEditSupName(sup.name);
    setEditSupPhone(sup.phone || '');
    setEditSupAddress(sup.address || '');
    setEditSupNotes(sup.notes || '');
  };

  const handleSaveEditSupplier = (e: React.FormEvent, sup: SupplierItem) => {
    e.preventDefault();
    const name = editSupName.trim();
    if (!name) {
      showNotification('Nama suplier tidak boleh kosong', true);
      return;
    }
    if (suppliers.some((s) => s.id !== sup.id && s.name.toLowerCase() === name.toLowerCase())) {
      showNotification(`Suplier "${name}" sudah terdaftar`, true);
      return;
    }

    const updated: SupplierItem = {
      ...sup,
      name,
      phone: editSupPhone.trim() || undefined,
      address: editSupAddress.trim() || undefined,
      notes: editSupNotes.trim() || undefined,
    };

    if (onUpdateSupplier) {
      const res = onUpdateSupplier(updated);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah suplier', true);
        return;
      }
    }
    setEditingSupId(null);
    showNotification(`Data suplier "${name}" berhasil diperbarui!`);
  };

  const handleDeleteSupplier = (supId: string) => {
    const result = onDeleteSupplier(supId);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus suplier', true);
    } else {
      if (editingSupId === supId) setEditingSupId(null);
      showNotification('Suplier berhasil dihapus.');
    }
  };

  // ==========================================
  // CUSTOMER HANDLERS
  // ==========================================
  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newCustName.trim();
    const phone = newCustPhone.trim();
    if (!name) {
      showNotification('Nama pelanggan tidak boleh kosong', true);
      return;
    }
    if (!phone) {
      showNotification('Nomor WhatsApp pelanggan tidak boleh kosong', true);
      return;
    }

    if (customers.some((c) => c.name.toLowerCase() === name.toLowerCase())) {
      showNotification(`Pelanggan "${name}" sudah terdaftar`, true);
      return;
    }

    const newCustomer: CustomerItem = {
      id: `cust-${Date.now()}`,
      name,
      phone,
      address: newCustAddress.trim() || undefined,
      notes: newCustNotes.trim() || undefined,
      createdAt: new Date().toISOString().slice(0, 10),
    };

    if (onAddCustomer) {
      onAddCustomer(newCustomer);
    }
    setNewCustName('');
    setNewCustPhone('');
    setNewCustAddress('');
    setNewCustNotes('');
    showNotification(`Pelanggan "${name}" berhasil ditambahkan!`);
  };

  const startEditingCustomer = (cust: CustomerItem) => {
    cancelAllEdits();
    setEditingCustId(cust.id);
    setEditCustName(cust.name);
    setEditCustPhone(cust.phone || '');
    setEditCustAddress(cust.address || '');
    setEditCustNotes(cust.notes || '');
  };

  const handleSaveEditCustomer = (e: React.FormEvent, cust: CustomerItem) => {
    e.preventDefault();
    const name = editCustName.trim();
    const phone = editCustPhone.trim();
    if (!name) {
      showNotification('Nama pelanggan tidak boleh kosong', true);
      return;
    }
    if (!phone) {
      showNotification('Nomor WhatsApp pelanggan tidak boleh kosong', true);
      return;
    }
    if (customers.some((c) => c.id !== cust.id && c.name.toLowerCase() === name.toLowerCase())) {
      showNotification(`Pelanggan "${name}" sudah terdaftar`, true);
      return;
    }

    const updated: CustomerItem = {
      ...cust,
      name,
      phone,
      address: editCustAddress.trim() || undefined,
      notes: editCustNotes.trim() || undefined,
    };

    if (onUpdateCustomer) {
      const res = onUpdateCustomer(updated);
      if (res && !res.success) {
        showNotification(res.message || 'Gagal mengubah pelanggan', true);
        return;
      }
    }
    setEditingCustId(null);
    showNotification(`Data pelanggan "${name}" berhasil diperbarui!`);
  };

  const handleDeleteCustomer = (custId: string) => {
    if (!onDeleteCustomer) return;
    const result = onDeleteCustomer(custId);
    if (!result.success) {
      showNotification(result.message || 'Gagal menghapus pelanggan', true);
    } else {
      if (editingCustId === custId) setEditingCustId(null);
      showNotification('Pelanggan berhasil dihapus.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-xl w-full p-4 sm:p-6 shadow-2xl text-slate-100 my-6 space-y-4">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="font-bold text-sm sm:text-base text-white">
                Kustomisasi Master Data Gudang
              </h3>
              <p className="text-[11px] text-slate-400">
                Kelola Kategori, Satuan Ukuran, Lokasi Rak, Divisi Pemohon SPK, Suplier, dan Pelanggan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => handleTabChange('category')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'category'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Kategori ({categories.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('unit')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'unit'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Scale className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Satuan ({units.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('location')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'location'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <MapPin className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Lokasi ({locations.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('division')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'division'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Divisi ({divisions.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('supplier')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'supplier'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Truck className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Suplier ({suppliers.length})</span>
          </button>

          <button
            onClick={() => handleTabChange('customer')}
            className={`py-2 px-1 rounded-lg font-bold flex items-center justify-center gap-1 transition-colors ${
              activeTab === 'customer'
                ? 'bg-cyan-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Pelanggan ({customers.length})</span>
          </button>
        </div>

        {/* Feedback alerts */}
        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}
        {successMsg && (
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* TAB 1: KATEGORI BAHAN */}
        {activeTab === 'category' && (
          <div className="space-y-4">
            {/* Add Category Form */}
            <form onSubmit={handleCreateCategory} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-3">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tambah Kategori Bahan Baku Baru</span>
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div className="sm:col-span-2">
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                    Nama Kategori
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="misal: Bahan Bordir Komputer"
                    value={newCatName}
                    onChange={(e) => {
                      setNewCatName(e.target.value);
                      if (!newCatPrefix) {
                        setNewCatPrefix(e.target.value.replace(/[^a-zA-Z]/g, '').slice(0, 3).toUpperCase());
                      }
                    }}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-semibold text-cyan-300 mb-1">
                    Prefix Kode (Otomatis)
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={5}
                    placeholder="e.g. BOR"
                    value={newCatPrefix}
                    onChange={(e) => setNewCatPrefix(e.target.value.toUpperCase())}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-cyan-500/40 rounded-lg text-xs font-mono font-bold text-cyan-300 placeholder-slate-500 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                    Ikon / Emoji
                  </label>
                  <input
                    type="text"
                    maxLength={3}
                    placeholder="🧵"
                    value={newCatIcon}
                    onChange={(e) => setNewCatIcon(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-center text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                    Keterangan Singkat
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="misal: Benang bordir, backing kain keras"
                      value={newCatDesc}
                      onChange={(e) => setNewCatDesc(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                    />
                    <button
                      type="submit"
                      className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold shrink-0 transition-colors flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Simpan</span>
                    </button>
                  </div>
                </div>
              </div>
            </form>

            {/* Category List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Kategori Aktif ({categories.length}):
              </span>
              {categories.map((cat) => {
                const count = products.filter((p) => p.category === cat.id).length;
                const isEditing = editingCatId === cat.id;

                if (isEditing) {
                  return (
                    <form
                      key={cat.id}
                      onSubmit={(e) => handleSaveEditCategory(e, cat)}
                      className="p-3.5 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-3 transition-all shadow-lg"
                    >
                      <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400">
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit Kategori: {cat.name}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setEditingCatId(null)}
                          className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" /> Batal
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                        <div className="sm:col-span-2">
                          <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                            Nama Kategori *
                          </label>
                          <input
                            type="text"
                            required
                            value={editCatName}
                            onChange={(e) => setEditCatName(e.target.value)}
                            className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] uppercase font-semibold text-cyan-300 mb-1">
                            Prefix Kode *
                          </label>
                          <input
                            type="text"
                            required
                            maxLength={5}
                            value={editCatPrefix}
                            onChange={(e) => setEditCatPrefix(e.target.value.toUpperCase())}
                            className="w-full px-3 py-1.5 bg-slate-950 border border-cyan-500/50 rounded-lg text-xs font-mono font-bold text-cyan-300 focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                        <div>
                          <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                            Ikon / Emoji
                          </label>
                          <input
                            type="text"
                            maxLength={3}
                            value={editCatIcon}
                            onChange={(e) => setEditCatIcon(e.target.value)}
                            className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-center text-white focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                        <div className="sm:col-span-3">
                          <label className="block text-[10px] uppercase font-semibold text-slate-400 mb-1">
                            Keterangan
                          </label>
                          <input
                            type="text"
                            value={editCatDesc}
                            onChange={(e) => setEditCatDesc(e.target.value)}
                            className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingCatId(null)}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Simpan Perubahan</span>
                        </button>
                      </div>
                    </form>
                  );
                }

                return (
                  <div
                    key={cat.id}
                    className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-base sm:text-lg shrink-0">{cat.icon || '📦'}</span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-white truncate">{cat.name}</span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                            {cat.prefix}-***
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {cat.description || 'Tidak ada deskripsi'} • {count} bahan baku
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 ml-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => startEditingCategory(cat)}
                        className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                        title="Edit Kategori"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteCategory(cat.id, cat.name)}
                        className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                        title={count > 0 ? `Masih digunakan oleh ${count} produk` : 'Hapus Kategori'}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: SATUAN UKURAN */}
        {activeTab === 'unit' && (
          <div className="space-y-4">
            {/* Add Unit Form */}
            <form onSubmit={handleCreateUnit} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tambah Satuan Ukuran Baru</span>
              </span>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  required
                  placeholder="misal: Lusin (12 pcs), Gram, Dus (24 Botol)"
                  value={newUnitName}
                  onChange={(e) => setNewUnitName(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold shrink-0 transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Satuan</span>
                </button>
              </div>
            </form>

            {/* Unit List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Satuan Tersedia ({units.length}):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {units.map((unit) => {
                  const count = products.filter((p) => p.unit === unit).length;
                  const isEditing = editingUnit === unit;

                  if (isEditing) {
                    return (
                      <form
                        key={unit}
                        onSubmit={(e) => handleSaveEditUnit(e, unit)}
                        className="p-3 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-2 transition-all shadow-lg col-span-1 sm:col-span-2"
                      >
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Satuan: {unit}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setEditingUnit(null)}
                            className="text-[11px] text-slate-400 hover:text-white"
                          >
                            Batal
                          </button>
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            required
                            value={editUnitName}
                            onChange={(e) => setEditUnitName(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            placeholder="Nama satuan ukuran"
                          />
                          <button
                            type="button"
                            onClick={() => setEditingUnit(null)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                          >
                            Batal
                          </button>
                          <button
                            type="submit"
                            className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Simpan</span>
                          </button>
                        </div>
                      </form>
                    );
                  }

                  return (
                    <div
                      key={unit}
                      className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                    >
                      <div className="min-w-0">
                        <span className="text-xs font-semibold text-slate-200 block truncate">
                          {unit}
                        </span>
                        <span className="text-[10px] text-slate-500">
                          Digunakan {count} bahan baku
                        </span>
                      </div>
                      <div className="flex items-center gap-1 ml-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEditingUnit(unit)}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                          title="Edit Satuan"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteUnit(unit)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                          title={count > 0 ? `Digunakan ${count} produk` : 'Hapus Satuan'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: LOKASI PENYIMPANAN */}
        {activeTab === 'location' && (
          <div className="space-y-4">
            {/* Add Location Form */}
            <form onSubmit={handleCreateLocation} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tambah Lokasi Rak / Penyimpanan Baru</span>
              </span>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  required
                  placeholder="misal: Gudang Utama - Rak D1, Ruang Finishing Meja 2"
                  value={newLocationName}
                  onChange={(e) => setNewLocationName(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold shrink-0 transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Lokasi</span>
                </button>
              </div>
            </form>

            {/* Location List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Lokasi Penyimpanan ({locations.length}):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {locations.map((loc) => {
                  const count = products.filter((p) => p.location === loc).length;
                  const isEditing = editingLocation === loc;

                  if (isEditing) {
                    return (
                      <form
                        key={loc}
                        onSubmit={(e) => handleSaveEditLocation(e, loc)}
                        className="p-3 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-2 transition-all shadow-lg col-span-1 sm:col-span-2"
                      >
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Lokasi Rak: {loc}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setEditingLocation(null)}
                            className="text-[11px] text-slate-400 hover:text-white"
                          >
                            Batal
                          </button>
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            required
                            value={editLocationName}
                            onChange={(e) => setEditLocationName(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            placeholder="Nama lokasi rak / gudang"
                          />
                          <button
                            type="button"
                            onClick={() => setEditingLocation(null)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                          >
                            Batal
                          </button>
                          <button
                            type="submit"
                            className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Simpan</span>
                          </button>
                        </div>
                      </form>
                    );
                  }

                  return (
                    <div
                      key={loc}
                      className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3 h-3 text-cyan-400 shrink-0" />
                          <span className="text-xs font-semibold text-slate-200 truncate">
                            {loc}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 block ml-4">
                          Menyimpan {count} bahan baku
                        </span>
                      </div>
                      <div className="flex items-center gap-1 ml-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEditingLocation(loc)}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                          title="Edit Lokasi"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteLocation(loc)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                          title="Hapus Lokasi"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: DIVISI / UNIT KERJA PEMOHON SPK */}
        {activeTab === 'division' && (
          <div className="space-y-4">
            {/* Add Division Form */}
            <form onSubmit={handleCreateDivision} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Tambah Divisi / Unit Pemohon SPK Baru</span>
              </span>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  required
                  placeholder="misal: Divisi Sablon DTF Kaos, Divisi Merchandise, Tim Sampling"
                  value={newDivName}
                  onChange={(e) => setNewDivName(e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="submit"
                  className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold shrink-0 transition-colors flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tambah Divisi</span>
                </button>
              </div>
            </form>

            {/* Division List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Divisi Pemohon Terdaftar ({divisions.length}):
              </span>
              <div className="space-y-2">
                {divisions.map((div) => {
                  const spkCount = movements.filter(
                    (m) => m.type === 'production' && m.divisionOrRequester?.trim().toLowerCase() === div.trim().toLowerCase()
                  ).length;
                  const isEditing = editingDivision === div;

                  if (isEditing) {
                    return (
                      <form
                        key={div}
                        onSubmit={(e) => handleSaveEditDivision(e, div)}
                        className="p-3 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-2 transition-all shadow-lg"
                      >
                        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                          <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Nama Divisi: {div}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setEditingDivision(null)}
                            className="text-[11px] text-slate-400 hover:text-white"
                          >
                            Batal
                          </button>
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            required
                            value={editDivisionName}
                            onChange={(e) => setEditDivisionName(e.target.value)}
                            className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-700 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            placeholder="Nama divisi / unit kerja"
                          />
                          <button
                            type="button"
                            onClick={() => setEditingDivision(null)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                          >
                            Batal
                          </button>
                          <button
                            type="submit"
                            className="px-3.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shrink-0"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Simpan</span>
                          </button>
                        </div>
                      </form>
                    );
                  }

                  return (
                    <div
                      key={div}
                      className="flex items-center justify-between p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                    >
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                          <span className="text-xs font-semibold text-slate-200 truncate">
                            {div}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-500 block ml-5">
                          {spkCount > 0 ? `${spkCount}x transaksi SPK pemakaian bahan` : 'Belum ada transaksi SPK'}
                        </span>
                      </div>
                      <div className="flex items-center gap-1 ml-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEditingDivision(div)}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                          title="Edit Divisi"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteDivision(div)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                          title={spkCount > 0 ? `Masih digunakan oleh ${spkCount} transaksi SPK` : 'Hapus Divisi'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: DAFTAR SUPLIER PEMASOK */}
        {activeTab === 'supplier' && (
          <div className="space-y-4">
            {/* Create Supplier Form */}
            <form
              onSubmit={handleCreateSupplier}
              className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs"
            >
              <div className="flex items-center gap-1.5 font-bold text-slate-200">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Daftarkan Suplier / Vendor Baru</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Nama Suplier / PT / Toko *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="misal: PT. Sinar Grafika Perkasa"
                    value={newSupName}
                    onChange={(e) => setNewSupName(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    No. Telepon / WhatsApp
                  </label>
                  <input
                    type="text"
                    placeholder="misal: 0812-3456-7890"
                    value={newSupPhone}
                    onChange={(e) => setNewSupPhone(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Kota / Alamat Kantor
                  </label>
                  <input
                    type="text"
                    placeholder="misal: Jakarta Barat"
                    value={newSupAddress}
                    onChange={(e) => setNewSupAddress(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Spesialisasi Bahan / Catatan
                  </label>
                  <input
                    type="text"
                    placeholder="misal: Tinta DTF, PET Film, Hotmelt"
                    value={newSupNotes}
                    onChange={(e) => setNewSupNotes(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Simpan Suplier Baru</span>
                </button>
              </div>
            </form>

            {/* Supplier List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Suplier Terdaftar ({suppliers.length}):
              </span>
              <div className="space-y-2">
                {suppliers.map((sup) => {
                  const restockCount = movements.filter(
                    (m) => m.type === 'restock' && m.supplierName === sup.name
                  ).length;
                  const isEditing = editingSupId === sup.id;

                  if (isEditing) {
                    return (
                      <form
                        key={sup.id}
                        onSubmit={(e) => handleSaveEditSupplier(e, sup)}
                        className="p-3.5 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-3 transition-all shadow-lg text-xs"
                      >
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                          <div className="flex items-center gap-1.5 font-bold text-cyan-400">
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Edit Data Suplier: {sup.name}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setEditingSupId(null)}
                            className="text-[11px] text-slate-400 hover:text-white"
                          >
                            Batal
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="block text-[11px] font-medium text-slate-300 mb-1">
                              Nama Suplier / PT / Toko *
                            </label>
                            <input
                              type="text"
                              required
                              value={editSupName}
                              onChange={(e) => setEditSupName(e.target.value)}
                              className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-medium text-slate-300 mb-1">
                              No. Telepon / WhatsApp
                            </label>
                            <input
                              type="text"
                              value={editSupPhone}
                              onChange={(e) => setEditSupPhone(e.target.value)}
                              className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="block text-[11px] font-medium text-slate-300 mb-1">
                              Kota / Alamat Kantor
                            </label>
                            <input
                              type="text"
                              value={editSupAddress}
                              onChange={(e) => setEditSupAddress(e.target.value)}
                              className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-medium text-slate-300 mb-1">
                              Spesialisasi Bahan / Catatan
                            </label>
                            <input
                              type="text"
                              value={editSupNotes}
                              onChange={(e) => setEditSupNotes(e.target.value)}
                              className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                            />
                          </div>
                        </div>

                        <div className="flex justify-end gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => setEditingSupId(null)}
                            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
                          >
                            Batal
                          </button>
                          <button
                            type="submit"
                            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>Simpan Perubahan</span>
                          </button>
                        </div>
                      </form>
                    );
                  }

                  return (
                    <div
                      key={sup.id}
                      className="flex items-start justify-between p-3 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                    >
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-white flex items-center gap-1.5">
                            <Truck className="w-3.5 h-3.5 text-emerald-400" />
                            {sup.name}
                          </span>
                          {sup.address && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                              {sup.address}
                            </span>
                          )}
                          {restockCount > 0 && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-medium">
                              {restockCount}x Order Masuk
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 flex-wrap">
                          {sup.phone && (
                            <span className="flex items-center gap-1 text-slate-300">
                              <Phone className="w-3 h-3 text-cyan-400" />
                              {sup.phone}
                            </span>
                          )}
                          {sup.notes && (
                            <span className="truncate text-slate-400 italic">
                              "{sup.notes}"
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1 ml-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => startEditingSupplier(sup)}
                          className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                          title="Edit Suplier"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteSupplier(sup.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                          title="Hapus Suplier"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: DAFTAR PELANGGAN / KONSUMEN */}
        {activeTab === 'customer' && (
          <div className="space-y-4">
            {/* Create Customer Form */}
            <form
              onSubmit={handleCreateCustomer}
              className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs"
            >
              <div className="flex items-center gap-1.5 font-bold text-slate-200">
                <Plus className="w-3.5 h-3.5 text-cyan-400" />
                <span>Daftarkan Data Pelanggan Baru</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Nama Pelanggan / Usaha Sablon *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="misal: Sablon Kilat Bandung"
                    value={newCustName}
                    onChange={(e) => setNewCustName(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    No. WhatsApp / Telepon *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="misal: 0812-3456-7890"
                    value={newCustPhone}
                    onChange={(e) => setNewCustPhone(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Alamat Pengiriman
                  </label>
                  <input
                    type="text"
                    placeholder="misal: Jl. Buah Batu No. 12, Bandung"
                    value={newCustAddress}
                    onChange={(e) => setNewCustAddress(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-300 mb-1">
                    Catatan Tambahan
                  </label>
                  <input
                    type="text"
                    placeholder="misal: Langganan DTF PET film 30cm"
                    value={newCustNotes}
                    onChange={(e) => setNewCustNotes(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Simpan Pelanggan</span>
                </button>
              </div>
            </form>

            {/* Customer List */}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block px-1">
                Daftar Pelanggan Terdaftar ({customers.length}):
              </span>

              {customers.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl">
                  Belum ada data pelanggan tersimpan. Pelanggan baru juga otomatis tersimpan saat membuat invoice!
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2">
                  {customers.map((cust) => {
                    const custInvoices = invoices.filter(
                      (inv) =>
                        inv.customerName.toLowerCase() === cust.name.toLowerCase() ||
                        inv.customerPhone === cust.phone
                    );
                    const totalTransactions = custInvoices.length;
                    const isEditing = editingCustId === cust.id;

                    if (isEditing) {
                      return (
                        <form
                          key={cust.id}
                          onSubmit={(e) => handleSaveEditCustomer(e, cust)}
                          className="p-3.5 bg-slate-900/95 rounded-xl border border-cyan-500/70 ring-1 ring-cyan-500/30 space-y-3 transition-all shadow-lg text-xs"
                        >
                          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                            <div className="flex items-center gap-1.5 font-bold text-cyan-400">
                              <Edit3 className="w-3.5 h-3.5" />
                              <span>Edit Data Pelanggan: {cust.name}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setEditingCustId(null)}
                              className="text-[11px] text-slate-400 hover:text-white"
                            >
                              Batal
                            </button>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                                Nama Pelanggan / Usaha Sablon *
                              </label>
                              <input
                                type="text"
                                required
                                value={editCustName}
                                onChange={(e) => setEditCustName(e.target.value)}
                                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                                No. WhatsApp / Telepon *
                              </label>
                              <input
                                type="text"
                                required
                                value={editCustPhone}
                                onChange={(e) => setEditCustPhone(e.target.value)}
                                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                                Alamat Pengiriman
                              </label>
                              <input
                                type="text"
                                value={editCustAddress}
                                onChange={(e) => setEditCustAddress(e.target.value)}
                                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                              />
                            </div>
                            <div>
                              <label className="block text-[11px] font-medium text-slate-300 mb-1">
                                Catatan Tambahan
                              </label>
                              <input
                                type="text"
                                value={editCustNotes}
                                onChange={(e) => setEditCustNotes(e.target.value)}
                                className="w-full px-3 py-1.5 bg-slate-950 border border-slate-750 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-400"
                              />
                            </div>
                          </div>

                          <div className="flex justify-end gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setEditingCustId(null)}
                              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
                            >
                              Batal
                            </button>
                            <button
                              type="submit"
                              className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5"
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Simpan Perubahan</span>
                            </button>
                          </div>
                        </form>
                      );
                    }

                    return (
                      <div
                        key={cust.id}
                        className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-750 transition-colors"
                      >
                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-xs font-bold text-white flex items-center gap-1.5">
                              <Users className="w-3.5 h-3.5 text-cyan-400" />
                              {cust.name}
                            </span>
                            {cust.address && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                                {cust.address}
                              </span>
                            )}
                            {totalTransactions > 0 && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-medium">
                                {totalTransactions}x Order
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-3 text-[11px] text-slate-400 flex-wrap">
                            {cust.phone && (
                              <a
                                href={`https://wa.me/${cust.phone.replace(/\D/g, '').startsWith('0') ? '62' + cust.phone.replace(/\D/g, '').slice(1) : cust.phone.replace(/\D/g, '')}`}
                                target="_blank"
                                rel="noreferrer"
                                className="flex items-center gap-1 text-emerald-400 hover:underline font-mono"
                              >
                                <Phone className="w-3 h-3 text-emerald-400" />
                                {cust.phone}
                              </a>
                            )}
                            {cust.notes && (
                              <span className="truncate text-slate-400 italic">
                                "{cust.notes}"
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1 ml-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => startEditingCustomer(cust)}
                            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-cyan-500/10 rounded-lg transition-colors"
                            title="Edit Pelanggan"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteCustomer(cust.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                            title="Hapus Pelanggan"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            <span>Perubahan dan editan tersimpan otomatis di seluruh sistem gudang & SPK produksi.</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-colors"
          >
            Selesai
          </button>
        </div>
      </div>
    </div>
  );
};
