import React, { useState, useRef, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Bell,
  Check,
  CheckCheck,
  Trash2,
  Clock,
  AlertTriangle,
  TrendingUp,
  Layers,
  PackagePlus,
  X,
  ExternalLink,
  Inbox,
  RotateCcw,
  Sparkles,
  ChevronRight,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { PushNotification } from '../types';
import {
  playPushNotificationSound,
  requestAndSendBrowserNotification,
  getBrowserNotificationPermission
} from '../utils/helpers';

interface NotificationPopupProps {
  notifications: PushNotification[];
  isOpen: boolean;
  onClose: () => void;
  onMarkAsRead: (id: string) => void;
  onToggleRead: (id: string) => void;
  onMarkAllAsRead: () => void;
  onDeleteNotification: (id: string) => void;
  onClearAllRead: () => void;
  onSelectNotification: (notif: PushNotification) => void;
  onViewAllLogs?: () => void;
  onReloadActiveAlerts?: () => void;
  onTriggerTestPush?: () => void;
  onOpenMobileSimulator?: () => void;
}

type FilterTab = 'all' | 'unread' | 'stock' | 'invoice';

export const NotificationPopup: React.FC<NotificationPopupProps> = ({
  notifications,
  isOpen,
  onClose,
  onMarkAsRead,
  onToggleRead,
  onMarkAllAsRead,
  onDeleteNotification,
  onClearAllRead,
  onSelectNotification,
  onViewAllLogs,
  onReloadActiveAlerts,
  onTriggerTestPush,
  onOpenMobileSimulator,
}) => {
  const [activeFilter, setActiveFilter] = useState<FilterTab>('all');
  const [browserPermission, setBrowserPermission] = useState<NotificationPermission | 'unsupported'>('default');
  const popupRef = useRef<HTMLDivElement>(null);

  // Check browser notification permission state
  useEffect(() => {
    if (isOpen) {
      setBrowserPermission(getBrowserNotificationPermission());
    }
  }, [isOpen]);

  // Close on outside click
  useEffect(() => {
    if (!isOpen) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  const unreadCount = notifications.filter((n) => !n.read).length;
  const readCount = notifications.length - unreadCount;

  // Filtered notifications
  const filteredNotifications = notifications.filter((n) => {
    if (activeFilter === 'unread') return !n.read;
    if (activeFilter === 'stock') return n.type === 'stock_warning';
    if (activeFilter === 'invoice') return n.type === 'invoice_due' || n.type === 'sale_alert';
    return true;
  });

  const formatRelativeTime = (timestampStr: string) => {
    try {
      const date = new Date(timestampStr.replace(' ', 'T'));
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMinutes = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);

      if (isNaN(diffMinutes) || diffMinutes < 1) return 'Baru saja';
      if (diffMinutes < 60) return `${diffMinutes} mnt lalu`;
      if (diffHours < 24) return `${diffHours} jam lalu`;
      if (diffDays === 1) return `Kemarin ${timestampStr.slice(11, 16)}`;
      if (diffDays < 7) return `${diffDays} hari lalu`;
      return timestampStr.slice(0, 16);
    } catch {
      return timestampStr;
    }
  };

  const handleTestNotification = async () => {
    playPushNotificationSound();
    const granted = await requestAndSendBrowserNotification(
      '🔔 Notifikasi Push DTF & Sublime',
      'Fitur Notifikasi Push Web & Audio Chime berhasil aktif dan berfungsi dengan baik!'
    );
    setBrowserPermission(getBrowserNotificationPermission());

    if (onTriggerTestPush) {
      onTriggerTestPush();
    }
  };

  const getTypeConfig = (type: PushNotification['type']) => {
    switch (type) {
      case 'stock_warning':
        return {
          icon: AlertTriangle,
          label: 'Peringatan Stok',
          borderLeftClass: 'border-l-4 border-l-rose-500',
          bgClass: 'bg-rose-950/20 hover:bg-rose-950/30 border-rose-500/30',
          iconColor: 'text-rose-400',
          iconBg: 'bg-rose-500/20 text-rose-300',
          badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
          actionText: 'Periksa Stok Bahan',
        };
      case 'invoice_due':
        return {
          icon: Clock,
          label: 'Jatuh Tempo Faktur',
          borderLeftClass: 'border-l-4 border-l-amber-500',
          bgClass: 'bg-amber-950/20 hover:bg-amber-950/30 border-amber-500/30',
          iconColor: 'text-amber-400',
          iconBg: 'bg-amber-500/20 text-amber-300',
          badgeClass: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
          actionText: 'Buka Tagihan Invoice',
        };
      case 'sale_alert':
        return {
          icon: TrendingUp,
          label: 'Penjualan Baru',
          borderLeftClass: 'border-l-4 border-l-emerald-500',
          bgClass: 'bg-emerald-950/20 hover:bg-emerald-950/30 border-emerald-500/30',
          iconColor: 'text-emerald-400',
          iconBg: 'bg-emerald-500/20 text-emerald-300',
          badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          actionText: 'Lihat Detail Faktur',
        };
      case 'production_alert':
        return {
          icon: Layers,
          label: 'Pakai Produksi',
          borderLeftClass: 'border-l-4 border-l-cyan-500',
          bgClass: 'bg-cyan-950/20 hover:bg-cyan-950/30 border-cyan-500/30',
          iconColor: 'text-cyan-400',
          iconBg: 'bg-cyan-500/20 text-cyan-300',
          badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
          actionText: 'Lihat Pemakaian Bahan',
        };
      case 'restock':
      default:
        return {
          icon: PackagePlus,
          label: 'Restok Masuk',
          borderLeftClass: 'border-l-4 border-l-indigo-500',
          bgClass: 'bg-indigo-950/20 hover:bg-indigo-950/30 border-indigo-500/30',
          iconColor: 'text-indigo-400',
          iconBg: 'bg-indigo-500/20 text-indigo-300',
          badgeClass: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
          actionText: 'Cek Riwayat Masuk',
        };
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop to close when clicking outside */}
          <motion.div 
            key="notification-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs" 
            onClick={onClose}
            aria-hidden="true"
          />

          {/* Slide-over Right Drawer: Mepet ke Kanan & ke Paling Atas */}
          <motion.div
            key="notification-drawer"
            ref={popupRef}
            id="notification-popup-drawer"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 280 }}
            className="fixed top-0 right-0 bottom-0 h-screen w-full sm:w-[450px] max-w-full bg-slate-900 border-l border-slate-700/80 shadow-2xl shadow-slate-950 z-50 text-slate-100 flex flex-col overflow-hidden"
          >
            {/* Top Header Bar */}
            <div className="p-3.5 sm:p-4 border-b border-slate-800 bg-slate-950/90 backdrop-blur-sm shrink-0">
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center shrink-0 shadow-xs">
                    <Bell className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-sm text-white truncate">Pusat Notifikasi Gudang</h3>
                      {unreadCount > 0 ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                          {unreadCount} Baru
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                          <Check className="w-2.5 h-2.5" />
                          Semua Terbaca
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 truncate">
                      Peringatan stok menipis, invoice tempo & mutasi bahan
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onClose}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors group border border-transparent hover:border-slate-700"
                  title="Tutup Panel Notifikasi (Esc)"
                >
                  <span className="text-[11px] font-medium hidden sm:inline text-slate-400 group-hover:text-slate-200">Tutup</span>
                  <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[9px] font-mono text-slate-400 bg-slate-800 rounded border border-slate-700">Esc</kbd>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>

          {/* Filter Tabs & Mark All Read */}
          <div className="flex items-center justify-between gap-2 pt-3">
            <div className="flex items-center gap-1 overflow-x-auto scrollbar-none py-0.5 max-w-full">
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFilter === 'all'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                Semua ({notifications.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('unread')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFilter === 'unread'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                Belum Dibaca {unreadCount > 0 && `(${unreadCount})`}
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('stock')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFilter === 'stock'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                Stok Kritis
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('invoice')}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  activeFilter === 'invoice'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                Faktur & Invoice
              </button>
            </div>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={onMarkAllAsRead}
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-bold text-cyan-300 bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-800/60 shrink-0 transition-all"
                title="Tandai semua notifikasi telah dibaca"
              >
                <CheckCheck className="w-3 h-3 text-cyan-400" />
                <span className="hidden sm:inline">Tandai Dibaca</span>
              </button>
            )}
          </div>
        </div>

        {/* Notifications List Body */}
        <div className="flex-1 overflow-y-auto p-3 space-y-2.5 scrollbar-thin scrollbar-thumb-slate-800">
          {filteredNotifications.length === 0 ? (
            <div className="py-8 px-4 text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-800/70 border border-slate-700 flex items-center justify-center mx-auto text-slate-400 shadow-inner">
                <Inbox className="w-7 h-7 text-cyan-400" />
              </div>

              <div>
                <h4 className="text-sm font-bold text-white">
                  {activeFilter === 'unread'
                    ? 'Semua Notifikasi Sudah Dibaca'
                    : 'Belum Ada Notifikasi di Kategori Ini'}
                </h4>
                <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1 leading-relaxed">
                  {activeFilter === 'unread'
                    ? 'Tidak ada peringatan baru yang terlewat. Semua bahan dan faktur dalam pengawasan.'
                    : 'Sistem memantau stok bahan dan jatuh tempo faktur secara otomatis.'}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
                {onReloadActiveAlerts && (
                  <button
                    type="button"
                    onClick={onReloadActiveAlerts}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Muat Peringatan Bahan & Invoice</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleTestNotification}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 transition-colors shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Kirim Notifikasi Tes</span>
                </button>
              </div>
            </div>
          ) : (
            filteredNotifications.map((notif) => {
              const config = getTypeConfig(notif.type);
              const Icon = config.icon;
              const isUnread = !notif.read;

              return (
                <div
                  key={notif.id}
                  onClick={() => onSelectNotification(notif)}
                  className={`group relative p-3 rounded-xl border transition-all cursor-pointer select-none ${config.borderLeftClass} ${
                    isUnread
                      ? `${config.bgClass} shadow-xs`
                      : 'bg-slate-950/70 hover:bg-slate-850 border-slate-800/80 text-slate-300 opacity-85 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {/* Category Icon Badge */}
                    <div
                      className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center mt-0.5 ${
                        isUnread ? config.iconBg : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>

                    {/* Notification Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1.5 mb-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-wider ${config.badgeClass}`}
                          >
                            {config.label}
                          </span>
                          {isUnread && (
                            <span className="w-2 h-2 rounded-full bg-cyan-400 ring-2 ring-slate-900 animate-pulse" />
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono shrink-0">
                          {formatRelativeTime(notif.timestamp)}
                        </span>
                      </div>

                      <h4
                        className={`text-xs font-bold leading-snug ${
                          isUnread ? 'text-white' : 'text-slate-300'
                        }`}
                      >
                        {notif.title}
                      </h4>

                      <p className="text-[11px] text-slate-300/90 leading-relaxed mt-1">
                        {notif.message}
                      </p>

                      {/* Metadata Highlights if available */}
                      {notif.meta && (notif.meta.unpaidAmount || notif.meta.currentStock !== undefined) && (
                        <div className="flex items-center gap-2.5 mt-2 pt-1.5 border-t border-slate-800/80 text-[10px]">
                          {notif.meta.currentStock !== undefined && (
                            <span className="font-semibold text-rose-300">
                              Sisa Stok: <strong className="font-mono text-white">{notif.meta.currentStock}</strong>
                            </span>
                          )}
                          {notif.meta.unpaidAmount && (
                            <span className="font-semibold text-amber-300">
                              Tagihan: <strong className="font-mono text-white">Rp {Number(notif.meta.unpaidAmount).toLocaleString('id-ID')}</strong>
                            </span>
                          )}
                          {notif.meta.dueDate && (
                            <span className="text-slate-400">
                              Tempo: <strong className="text-slate-200">{notif.meta.dueDate}</strong>
                            </span>
                          )}
                        </div>
                      )}

                      {/* Action Links & Buttons */}
                      <div className="flex items-center justify-between mt-2.5 pt-1 text-[11px]">
                        <span className="text-[10px] font-semibold text-cyan-400 flex items-center gap-1 group-hover:underline">
                          <span>{config.actionText}</span>
                          <ChevronRight className="w-3 h-3 transition-transform group-hover:translate-x-0.5" />
                        </span>

                        <div
                          className="flex items-center gap-1 shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() => onToggleRead(notif.id)}
                            className={`p-1 px-1.5 rounded-md text-[10px] flex items-center gap-1 transition-colors ${
                              isUnread
                                ? 'text-cyan-400 hover:text-cyan-200 hover:bg-cyan-500/20'
                                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                            }`}
                            title={isUnread ? 'Tandai sudah dibaca' : 'Tandai belum dibaca'}
                          >
                            <Check className="w-3 h-3" />
                            <span className="text-[9px]">
                              {isUnread ? 'Baca' : 'Batal'}
                            </span>
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteNotification(notif.id)}
                            className="p-1 rounded-md text-slate-500 hover:text-rose-400 hover:bg-rose-500/20 transition-colors"
                            title="Hapus notifikasi"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Bottom Footer Actions */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 flex items-center justify-between gap-2 shrink-0 text-xs">
          <div className="flex items-center gap-2">
            {readCount > 0 && (
              <button
                type="button"
                onClick={onClearAllRead}
                className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-rose-300 transition-colors"
                title="Hapus semua notifikasi yang telah dibaca"
              >
                <Trash2 className="w-3 h-3" />
                <span>Bersihkan Terbaca ({readCount})</span>
              </button>
            )}

            {onReloadActiveAlerts && (
              <button
                type="button"
                onClick={onReloadActiveAlerts}
                className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-cyan-300 transition-colors"
                title="Segarkan notifikasi dari stok dan invoice aktif"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Muat Ulang</span>
              </button>
            )}
          </div>

          {onViewAllLogs && (
            <button
              type="button"
              onClick={() => {
                onViewAllLogs();
                onClose();
              }}
              className="flex items-center gap-1 text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 hover:underline"
            >
              <span>Log Aktivitas Lengkap</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      </motion.div>
    </>
  )}
</AnimatePresence>
  );
};
