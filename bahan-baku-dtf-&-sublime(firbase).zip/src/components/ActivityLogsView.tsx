import React, { useState, useMemo } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  ShieldAlert, 
  User as UserIcon, 
  Download, 
  Clock, 
  Layers, 
  ShoppingCart, 
  PackagePlus, 
  RefreshCw,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  X,
  Lock,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { ActivityLog, User } from '../types';
import { exportToCSV, formatTimestampWIB } from '../utils/helpers';

interface ActivityLogsViewProps {
  logs: ActivityLog[];
  currentUser: User;
  onDeleteLog?: (logId: string) => { success: boolean; message?: string };
  onClearAllLogs?: () => { success: boolean; message?: string };
}

export const ActivityLogsView: React.FC<ActivityLogsViewProps> = ({ 
  logs, 
  currentUser,
  onDeleteLog,
  onClearAllLogs,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [actionFilter, setActionFilter] = useState<string>('all');
  const [userFilter, setUserFilter] = useState<string>('all');

  const uniqueUsersInLogs = useMemo(() => {
    const map = new Map<string, string>();
    logs.forEach((l) => {
      if (l.userId && l.userName) {
        map.set(l.userId, l.userName);
      }
    });
    return Array.from(map.entries()).map(([id, name]) => ({ id, name }));
  }, [logs]);
  
  // Delete states
  const [logToDelete, setLogToDelete] = useState<ActivityLog | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isClearAllModalOpen, setIsClearAllModalOpen] = useState(false);
  const [feedbackToast, setFeedbackToast] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Hak Akses Granular: Dikelola dari checklist Hak Akses & Pengguna (canDeleteLogs) atau Owner
  const canDeleteLogs = currentUser.role === 'owner' || Boolean(currentUser.canDeleteLogs);

  const showToast = (type: 'success' | 'error', message: string) => {
    setFeedbackToast({ type, message });
    setTimeout(() => {
      setFeedbackToast(null);
    }, 3500);
  };

  const formatRoleLabel = (role: string, title?: string) => {
    if (title) return title;
    if (role === 'owner') return 'Pemilik Usaha (Owner)';
    if (role === 'warehouse_admin') return 'Supervisor Gudang (SPV)';
    if (role === 'cashier_sales') return 'Kasir & Sales';
    if (role === 'production_staff') return 'Operator Produksi';
    return role;
  };

  const filteredLogs = logs.filter((log) => {
    const matchSearch =
      log.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.details.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.userName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchAction = actionFilter === 'all' || log.actionType === actionFilter;
    const matchUser = userFilter === 'all' || log.userId === userFilter || log.userName.toLowerCase() === userFilter.toLowerCase();
    return matchSearch && matchAction && matchUser;
  });

  const handleExportCSV = () => {
    const rows: (string | number)[][] = [
      ['AUDIT LOG AKTIVITAS PERUBAHAN STOK GUDANG DTF & SUBLIME'],
      ['Waktu (WIB)', 'User', 'Peran / Role', 'Tipe Aktivitas', 'Judul', 'Rincian Perubahan Stok'],
    ];

    logs.forEach((l) => {
      rows.push([
        formatTimestampWIB(l.timestamp),
        l.userName,
        l.userRoleTitle || l.userRole,
        l.actionType,
        l.title,
        l.details,
      ]);
    });

    exportToCSV(`Audit_Log_Aktivitas_${new Date().toISOString().slice(0, 10)}.csv`, rows);
  };

  const handleConfirmDeleteSingle = () => {
    if (!logToDelete || !onDeleteLog) return;
    if (!canDeleteLogs) {
      showToast('error', 'Aksi ditolak: Akun Anda tidak memiliki izin untuk menghapus log aktivitas.');
      return;
    }

    setIsDeleting(true);
    try {
      const res = onDeleteLog(logToDelete.id);
      if (res.success) {
        setLogToDelete(null);
        showToast('success', res.message || 'Catatan log aktivitas berhasil dihapus.');
      } else {
        showToast('error', res.message || 'Gagal menghapus log aktivitas.');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  const handleConfirmClearAll = () => {
    if (!onClearAllLogs) return;
    if (!canDeleteLogs) {
      showToast('error', 'Aksi ditolak: Akun Anda tidak memiliki izin untuk membersihkan seluruh log.');
      return;
    }

    setIsDeleting(true);
    try {
      const res = onClearAllLogs();
      if (res.success) {
        setIsClearAllModalOpen(false);
        showToast('success', res.message || 'Seluruh riwayat log aktivitas telah dibersihkan.');
      } else {
        showToast('error', res.message || 'Gagal membersihkan log aktivitas.');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h2 className="text-lg font-bold text-white">Sistem Log Aktivitas & Audit Perubahan Stok</h2>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold border flex items-center gap-1 ${
              canDeleteLogs
                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}>
              {canDeleteLogs ? (
                <>
                  <Trash2 className="w-3 h-3 text-rose-400" />
                  <span>Izin Hapus: Aktif</span>
                </>
              ) : (
                <>
                  <Lock className="w-3 h-3 text-slate-500" />
                  <span>Hapus Log: Terproteksi</span>
                </>
              )}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Mencatat setiap pergerakan barang (restock masuk, pemakaian produksi sendiri, dan invoice penjualan) secara transparan. Hak akses hapus log dikelola dari menu Pengaturan / Hak Akses.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap shrink-0">
          {/* Tombol Bersihkan Semua Log */}
          {canDeleteLogs && logs.length > 0 && onClearAllLogs && (
            <button
              type="button"
              id="btn-clear-all-logs"
              onClick={() => setIsClearAllModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-600/15 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/30 rounded-xl text-xs font-semibold transition-all active:scale-95 cursor-pointer shadow-xs"
              title="Bersihkan seluruh riwayat log audit"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Bersihkan Semua Log</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Ekspor Log (CSV)</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama pengguna, nomor SPK, invoice, atau nama bahan..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {uniqueUsersInLogs.length > 1 && (
            <select
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
              title="Filter aktivitas berdasarkan nama pengguna"
            >
              <option value="all">Semua Pengguna ({uniqueUsersInLogs.length})</option>
              {uniqueUsersInLogs.map((u) => (
                <option key={u.id} value={u.id}>
                  👤 {u.name}
                </option>
              ))}
            </select>
          )}

          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'Semua Aksi' },
              { id: 'PRODUCTION_USE', label: 'Pakai Produksi' },
              { id: 'SALES_INVOICE', label: 'Penjualan' },
              { id: 'RESTOCK_IN', label: 'Restock' },
              { id: 'STOCK_ADJUSTMENT', label: 'Opname' },
            ].map((flt) => (
              <button
                key={flt.id}
                onClick={() => setActionFilter(flt.id)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  actionFilter === flt.id
                    ? 'bg-cyan-600 text-white font-semibold'
                    : 'bg-slate-950 text-slate-400 hover:text-white'
                }`}
              >
                {flt.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Logs Timeline List */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/80">
          <span className="text-xs font-bold text-slate-300">
            Total Log: {filteredLogs.length} Aktivitas
          </span>
          {!canDeleteLogs && (
            <span className="text-[11px] text-slate-500 flex items-center gap-1">
              <Lock className="w-3 h-3 text-slate-400" />
              <span>Aksi Hapus Dikelola lewat Hak Akses</span>
            </span>
          )}
        </div>

        <div className="space-y-3">
          {filteredLogs.length === 0 ? (
            <p className="py-12 text-center text-xs text-slate-400">
              Tidak ada riwayat aktivitas yang sesuai.
            </p>
          ) : (
            filteredLogs.map((log) => {
              const isSale = log.actionType === 'SALES_INVOICE';
              const isProd = log.actionType === 'PRODUCTION_USE';
              const isRestock = log.actionType === 'RESTOCK_IN';

              return (
                <div
                  key={log.id}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 group"
                >
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div
                      className={`p-2 rounded-xl mt-0.5 shrink-0 ${
                        isSale
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : isProd
                          ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                          : isRestock
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {isSale ? (
                        <ShoppingCart className="w-4 h-4" />
                      ) : isProd ? (
                        <Layers className="w-4 h-4" />
                      ) : isRestock ? (
                        <PackagePlus className="w-4 h-4" />
                      ) : (
                        <RefreshCw className="w-4 h-4" />
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs sm:text-sm text-slate-100">{log.title}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                          {log.actionType}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-1 leading-relaxed break-words">{log.details}</p>
                    </div>
                  </div>

                  {/* Metadata and Delete Action */}
                  <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80">
                    <div className="text-left sm:text-right">
                      <div className="flex items-center sm:justify-end gap-1.5 text-xs text-slate-300 font-medium">
                        <UserIcon className="w-3.5 h-3.5 text-cyan-400" />
                        <span className="font-semibold text-white">{log.userName}</span>
                        <span className="text-[10px] text-cyan-300 bg-cyan-950/70 border border-cyan-800/40 px-2 py-0.5 rounded font-medium">
                          {formatRoleLabel(log.userRole, log.userRoleTitle)}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono flex items-center sm:justify-end gap-1 mt-0.5" title="Waktu Indonesia Barat (WIB)">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        <span>{formatTimestampWIB(log.timestamp)}</span>
                      </span>
                    </div>

                    {/* Tombol Hapus Satuan Log */}
                    <div className="shrink-0 pl-1">
                      {canDeleteLogs ? (
                        <button
                          type="button"
                          id={`btn-delete-log-${log.id}`}
                          onClick={() => setLogToDelete(log)}
                          className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/15 border border-transparent hover:border-rose-500/30 rounded-xl transition-all cursor-pointer active:scale-90"
                          title="Hapus Catatan Log Ini"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled
                          className="p-2 text-slate-700 cursor-not-allowed opacity-40 rounded-xl"
                          title="Aksi Hapus tidak diizinkan untuk akun ini (Dikelola di menu Hak Akses & Pengguna)"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* ================= MODAL KONFIRMASI HAPUS SATUAN LOG ================= */}
      {logToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-md p-5 shadow-2xl text-left">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Hapus Catatan Log</h3>
                <p className="text-xs text-rose-300">Aksi ini permanen dan menghapus catatan audit.</p>
              </div>
            </div>

            <div className="my-4 p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                <span className="text-slate-400">Judul Aktivitas:</span>
                <span className="font-bold text-white text-right">{logToDelete.title}</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                <span className="text-slate-400">Pengguna:</span>
                <span className="font-mono text-cyan-300">
                  {logToDelete.userName} ({formatRoleLabel(logToDelete.userRole, logToDelete.userRoleTitle)})
                </span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-slate-850">
                <span className="text-slate-400">Waktu (WIB):</span>
                <span className="font-mono text-cyan-300">{formatTimestampWIB(logToDelete.timestamp)}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5">Rincian:</span>
                <p className="text-slate-300 bg-slate-900/60 p-2 rounded-xl text-[11px] leading-relaxed border border-slate-800">
                  {logToDelete.details}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setLogToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-delete-log"
                onClick={handleConfirmDeleteSingle}
                disabled={isDeleting}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Hapus Log</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL KONFIRMASI BERSIHKAN SEMUA LOG ================= */}
      {isClearAllModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-rose-500/40 rounded-3xl w-full max-w-md p-5 shadow-2xl text-left">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Bersihkan Seluruh Riwayat Log?</h3>
                <p className="text-xs text-rose-300">Peringatan: Seluruh rekaman audit akan dikosongkan.</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 my-4 leading-relaxed">
              Anda akan menghapus <strong>{logs.length} catatan log aktivitas</strong> yang tersimpan di sistem. Tindakan ini tidak dapat dibatalkan, namun Anda dapat mencadangkan data terlebih dahulu lewat menu <em>Backup & Checkpoint</em>.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsClearAllModalOpen(false)}
                disabled={isDeleting}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-clear-all-logs"
                onClick={handleConfirmClearAll}
                disabled={isDeleting}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
              >
                <Trash2 className="w-4 h-4" />
                <span>Ya, Bersihkan Seluruh Log</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Feedback Toast */}
      {feedbackToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200 max-w-md">
          <div className={`p-4 rounded-2xl border shadow-2xl flex items-center gap-3 ${
            feedbackToast.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/90 border-rose-500/40 text-rose-200'
          }`}>
            {feedbackToast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <p className="text-xs font-semibold">{feedbackToast.message}</p>
          </div>
        </div>
      )}
    </div>
  );
};
