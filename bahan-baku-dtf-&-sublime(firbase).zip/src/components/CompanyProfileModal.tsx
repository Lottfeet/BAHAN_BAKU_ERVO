import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Building2, 
  Receipt, 
  FileSignature, 
  Smartphone, 
  Check, 
  RotateCcw, 
  Save, 
  Eye, 
  Sparkles,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Globe,
  Plus,
  Trash2,
  Star,
  Wallet,
  CheckCircle2,
  AlertCircle,
  Upload,
  Image as ImageIcon,
  Link as LinkIcon,
  RefreshCw
} from 'lucide-react';
import { CompanyProfile, User, BankAccountItem } from '../types';

interface CompanyProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  companyProfile: CompanyProfile;
  onSaveCompanyProfile: (updated: CompanyProfile) => void;
  onResetToDefault: () => void;
  currentUser: User;
}

const POPULAR_BANKS = ['BCA', 'Mandiri', 'BRI', 'BNI', 'BSI', 'CIMB Niaga', 'Permata', 'Bank Jago', 'SeaBank', 'QRIS'];

// Helper to compress and resize image for lightweight storage and fast rendering
const compressAndResizeImage = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    if (file.type === 'image/svg+xml') {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const MAX_DIM = 320;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(reader.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const format = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        const dataUrl = canvas.toDataURL(format, 0.9);
        resolve(dataUrl);
      };
      img.onerror = () => resolve(reader.result as string);
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const CompanyProfileModal: React.FC<CompanyProfileModalProps> = ({
  isOpen,
  onClose,
  companyProfile,
  onSaveCompanyProfile,
  onResetToDefault,
  currentUser,
}) => {
  const [activeTab, setActiveTab] = useState<'company' | 'invoice' | 'signers' | 'app'>('company');

  const initializeAccounts = (profile: CompanyProfile): BankAccountItem[] => {
    let accounts: BankAccountItem[] = profile.bankAccounts ? [...profile.bankAccounts] : [];
    if (accounts.length === 0) {
      if (profile.bankAccountNo) {
        accounts.push({
          id: 'bank-1',
          bankName: profile.bankName || 'BCA',
          accountNumber: profile.bankAccountNo,
          holderName: profile.bankAccountHolder || profile.companyName || 'CV DTF SUBLIME INDONESIA',
          isPrimary: true,
          notes: 'Rekening Utama Operasional & Transfer Nota',
        });
      } else {
        accounts = [
          {
            id: 'bank-1',
            bankName: 'BCA',
            accountNumber: '8820-192-381',
            holderName: profile.companyName || 'CV DTF SUBLIME INDONESIA',
            isPrimary: true,
            notes: 'Rekening Utama Operasional',
          },
          {
            id: 'bank-2',
            bankName: 'Mandiri',
            accountNumber: '131-00-9988123-4',
            holderName: profile.companyName || 'CV DTF SUBLIME INDONESIA',
            isPrimary: false,
            notes: 'Rekening Alternatif Transfer Konsumen',
          },
          {
            id: 'bank-3',
            bankName: 'BRI',
            accountNumber: '0341-01-002345-50-8',
            holderName: profile.companyName || 'CV DTF SUBLIME INDONESIA',
            isPrimary: false,
            notes: 'Rekening Pembayaran Unit Wilayah',
          },
        ];
      }
    }
    return accounts;
  };

  const [formData, setFormData] = useState<CompanyProfile>(() => {
    const accounts = initializeAccounts(companyProfile);
    return {
      ...companyProfile,
      bankAccounts: accounts,
    };
  });

  useEffect(() => {
    if (isOpen) {
      const accounts = initializeAccounts(companyProfile);
      setFormData({
        ...companyProfile,
        bankAccounts: accounts,
      });
    }
  }, [isOpen, companyProfile]);

  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoUploadError, setLogoUploadError] = useState<string | null>(null);
  const [isProcessingLogo, setIsProcessingLogo] = useState(false);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [customLogoUrl, setCustomLogoUrl] = useState('');

  const handleLogoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setLogoUploadError('File harus berupa gambar (PNG, JPG, SVG, WebP).');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setLogoUploadError('Ukuran file maksimal 8MB.');
      return;
    }

    setIsProcessingLogo(true);
    setLogoUploadError(null);

    try {
      const compressedDataUrl = await compressAndResizeImage(file);
      handleChange('logoUrl', compressedDataUrl);
    } catch {
      setLogoUploadError('Gagal memproses gambar logo. Silakan coba lagi.');
    } finally {
      setIsProcessingLogo(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleApplyLogoUrl = () => {
    if (!customLogoUrl.trim()) return;
    handleChange('logoUrl', customLogoUrl.trim());
    setCustomLogoUrl('');
    setShowUrlInput(false);
  };

  const handleRemoveLogo = () => {
    handleChange('logoUrl', '');
    setLogoUploadError(null);
  };

  const handleChange = (field: keyof CompanyProfile, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleAddBankAccount = (suggestedBank?: string) => {
    const defaultHolder = formData.bankAccounts?.[0]?.holderName || formData.companyName || 'CV DTF SUBLIME INDONESIA';
    const currentAccounts = formData.bankAccounts || [];
    const newAccount: BankAccountItem = {
      id: `bank-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      bankName: suggestedBank || 'BCA',
      accountNumber: '',
      holderName: defaultHolder,
      isPrimary: currentAccounts.length === 0,
      notes: suggestedBank === 'QRIS' ? 'QRIS Statis Kasir Toko' : '',
    };
    setFormData((prev) => ({
      ...prev,
      bankAccounts: [...(prev.bankAccounts || []), newAccount],
    }));
  };

  const handleUpdateBankAccount = (id: string, field: keyof BankAccountItem, value: any) => {
    setFormData((prev) => {
      const updatedAccounts = (prev.bankAccounts || []).map((acc) => {
        if (acc.id === id) {
          return { ...acc, [field]: value };
        }
        return acc;
      });

      const currentPrimary = updatedAccounts.find((a) => a.isPrimary) || updatedAccounts[0];

      return {
        ...prev,
        bankAccounts: updatedAccounts,
        bankName: currentPrimary?.bankName || prev.bankName,
        bankAccountNo: currentPrimary?.accountNumber || prev.bankAccountNo,
        bankAccountHolder: currentPrimary?.holderName || prev.bankAccountHolder,
      };
    });
  };

  const handleSetPrimaryBankAccount = (id: string) => {
    setFormData((prev) => {
      const updatedAccounts = (prev.bankAccounts || []).map((acc) => ({
        ...acc,
        isPrimary: acc.id === id,
      }));
      const primaryAcc = updatedAccounts.find((a) => a.id === id);
      return {
        ...prev,
        bankAccounts: updatedAccounts,
        bankName: primaryAcc ? primaryAcc.bankName : prev.bankName,
        bankAccountNo: primaryAcc ? primaryAcc.accountNumber : prev.bankAccountNo,
        bankAccountHolder: primaryAcc ? primaryAcc.holderName : prev.bankAccountHolder,
      };
    });
  };

  const handleRemoveBankAccount = (id: string) => {
    const accounts = formData.bankAccounts || [];
    if (accounts.length <= 1) {
      alert('Minimal harus ada 1 nomor rekening bank terdaftar untuk faktur dan nota penjualan.');
      return;
    }
    const filtered = accounts.filter((a) => a.id !== id);
    const wasPrimary = accounts.find((a) => a.id === id)?.isPrimary;
    if (wasPrimary && filtered.length > 0) {
      filtered[0].isPrimary = true;
    }
    const primaryAcc = filtered.find((a) => a.isPrimary) || filtered[0];

    setFormData((prev) => ({
      ...prev,
      bankAccounts: filtered,
      bankName: primaryAcc ? primaryAcc.bankName : prev.bankName,
      bankAccountNo: primaryAcc ? primaryAcc.accountNumber : prev.bankAccountNo,
      bankAccountHolder: primaryAcc ? primaryAcc.holderName : prev.bankAccountHolder,
    }));
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.companyName.trim()) {
      alert('Nama perusahaan tidak boleh kosong!');
      return;
    }

    const accounts = formData.bankAccounts || [];
    const primary = accounts.find((a) => a.isPrimary) || accounts[0];
    const dataToSave: CompanyProfile = {
      ...formData,
      bankAccounts: accounts,
      bankName: primary ? primary.bankName : formData.bankName,
      bankAccountNo: primary ? primary.accountNumber : formData.bankAccountNo,
      bankAccountHolder: primary ? primary.holderName : formData.bankAccountHolder,
    };

    onSaveCompanyProfile(dataToSave);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    onResetToDefault();
    setShowResetConfirm(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white shadow-md">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>Pengaturan Identitas Perusahaan & Aplikasi</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                  Sistem
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Kustomisasi nama usaha, kontak, kop nota invoice, pejabat tanda tangan, dan branding aplikasi
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Tutup Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/40 px-3 sm:px-5 gap-1.5 overflow-x-auto no-scrollbar shrink-0">
          {[
            { id: 'company', label: 'Profil Usaha & Kontak', icon: Building2 },
            { 
              id: 'invoice', 
              label: `Rekening Bank & Nota (${formData.bankAccounts?.length || 0})`, 
              icon: CreditCard 
            },
            { id: 'signers', label: 'Pejabat Pengesahan', icon: FileSignature },
            { id: 'app', label: 'Branding Aplikasi', icon: Smartphone },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-3.5 border-b-2 text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                  isActive
                    ? 'border-cyan-500 text-cyan-400 bg-cyan-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {saveSuccess && (
            <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Identitas perusahaan dan aplikasi berhasil diperbarui!</span>
            </div>
          )}

          {/* TAB 1: PROFIL USAHA & KONTAK */}
          {activeTab === 'company' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Nama Resmi Usaha / Toko / Gudang <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.companyName}
                    onChange={(e) => handleChange('companyName', e.target.value)}
                    placeholder="Contoh: GUDANG SUPLAI SABLON DTF & SUBLIME"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Dicetak pada kop faktur penjualan, kop laporan mutasi, bukti PO, dan kuitansi
                  </span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Nama Singkat / Inisial Logo
                  </label>
                  <input
                    type="text"
                    maxLength={10}
                    value={formData.shortName}
                    onChange={(e) => handleChange('shortName', e.target.value.toUpperCase())}
                    placeholder="DTF"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white font-mono font-bold focus:outline-hidden focus:border-cyan-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Digunakan pada ikon kotak kop dokumen
                  </span>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Slogan / Tagline Usaha
                </label>
                <input
                  type="text"
                  value={formData.tagline}
                  onChange={(e) => handleChange('tagline', e.target.value)}
                  placeholder="Contoh: Pusat Pengadaan Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Alamat Lengkap Usaha / Gudang
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => handleChange('address', e.target.value)}
                    placeholder="Kawasan Industri Kreatif No. 88"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Kota Operasional
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    placeholder="Bandung"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    No. Telp / WhatsApp
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={formData.phone}
                      onChange={(e) => handleChange('phone', e.target.value)}
                      placeholder="0812-9988-7766"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Email Resmi
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      placeholder="logistik@dtfsublime.id"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Website (Opsional)
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={formData.website || ''}
                      onChange={(e) => handleChange('website', e.target.value)}
                      placeholder="www.dtfsublime.id"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: KOP NOTA & PEMBAYARAN */}
          {activeTab === 'invoice' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              {/* Header & Daftar Rekening Bank */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                      <Wallet className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white uppercase tracking-wider">
                          Daftar Nomor Rekening Pembayaran Transfer
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold font-mono">
                          {(formData.bankAccounts || []).length} Rekening
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Daftarkan nomor rekening bank (BCA, Mandiri, BRI, BNI, QRIS, dll). Anda dapat menambahkan lebih dari 2 rekening.
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleAddBankAccount()}
                    className="flex items-center justify-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Tambah Rekening</span>
                  </button>
                </div>

                {/* Quick Add Pills */}
                <div className="flex items-center gap-1.5 flex-wrap text-xs">
                  <span className="text-[10.5px] text-slate-400 font-medium mr-1">
                    Tambah Cepat:
                  </span>
                  {POPULAR_BANKS.map((bank) => (
                    <button
                      key={bank}
                      type="button"
                      onClick={() => handleAddBankAccount(bank)}
                      className="px-2 py-0.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700/80 text-[10.5px] font-semibold transition-colors cursor-pointer flex items-center gap-1"
                    >
                      <span>+ {bank}</span>
                    </button>
                  ))}
                </div>

                {/* Bank Accounts List Cards */}
                <div className="space-y-3 pt-1">
                  {(formData.bankAccounts || []).map((account, index) => {
                    const isPrimary = !!account.isPrimary;
                    return (
                      <div
                        key={account.id}
                        className={`p-3.5 rounded-xl border transition-all ${
                          isPrimary
                            ? 'bg-slate-900/90 border-amber-500/50 shadow-md ring-1 ring-amber-500/20'
                            : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {/* Top card bar: index, primary status, delete button */}
                        <div className="flex items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-slate-800/80 flex-wrap">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 flex items-center justify-center text-[10px] font-bold font-mono">
                              #{index + 1}
                            </span>
                            <span className="text-xs font-bold text-white">
                              {account.bankName || 'Pilih / Masukkan Nama Bank'}
                            </span>
                            {account.accountNumber ? (
                              <span className="text-xs font-mono text-cyan-400 font-bold bg-cyan-950/40 px-2 py-0.5 rounded-md border border-cyan-800/40">
                                {account.accountNumber}
                              </span>
                            ) : (
                              <span className="text-[10px] text-rose-400 italic">
                                (Nomor rekening belum diisi)
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-2">
                            {isPrimary ? (
                              <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10.5px] font-bold flex items-center gap-1">
                                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                                <span>Rekening Utama (Default Nota)</span>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleSetPrimaryBankAccount(account.id)}
                                className="px-2.5 py-0.5 rounded-lg bg-slate-800 hover:bg-amber-950/40 text-slate-300 hover:text-amber-300 border border-slate-700 hover:border-amber-500/40 text-[10.5px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                                title="Jadikan rekening ini sebagai pilihan utama pada nota"
                              >
                                <Star className="w-3.5 h-3.5" />
                                <span>Set Jadi Rekening Utama</span>
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => handleRemoveBankAccount(account.id)}
                              disabled={(formData.bankAccounts || []).length <= 1}
                              title={(formData.bankAccounts || []).length <= 1 ? 'Minimal 1 nomor rekening wajib ada' : 'Hapus nomor rekening ini'}
                              className="p-1 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors disabled:opacity-20 disabled:cursor-not-allowed cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Account Form Fields */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {/* Nama Bank */}
                          <div>
                            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                              Nama Bank / Layanan
                            </label>
                            <input
                              type="text"
                              list="popular-banks-list"
                              value={account.bankName}
                              onChange={(e) => handleUpdateBankAccount(account.id, 'bankName', e.target.value)}
                              placeholder="BCA / Mandiri / BRI / QRIS"
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500 font-semibold"
                            />
                            <div className="flex gap-1 mt-1 flex-wrap">
                              {['BCA', 'Mandiri', 'BRI', 'BNI', 'QRIS'].map((b) => (
                                <button
                                  key={b}
                                  type="button"
                                  onClick={() => handleUpdateBankAccount(account.id, 'bankName', b)}
                                  className={`text-[9.5px] px-1.5 py-0.5 rounded border transition-colors cursor-pointer ${
                                    account.bankName === b
                                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-bold'
                                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                                  }`}
                                >
                                  {b}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Nomor Rekening */}
                          <div>
                            <label className="text-[11px] font-semibold text-slate-300 block mb-1">
                              Nomor Rekening
                            </label>
                            <input
                              type="text"
                              value={account.accountNumber}
                              onChange={(e) => handleUpdateBankAccount(account.id, 'accountNumber', e.target.value)}
                              placeholder="Contoh: 8820-192-381"
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500 font-mono font-bold"
                            />
                            <span className="text-[9.5px] text-slate-500 block mt-1">
                              Format bebas (boleh dengan tanda hubung '-')
                            </span>
                          </div>

                          {/* Atas Nama */}
                          <div>
                            <div className="flex items-center justify-between mb-1">
                              <label className="text-[11px] font-semibold text-slate-300 block">
                                Atas Nama (A/N)
                              </label>
                              <button
                                type="button"
                                onClick={() => handleUpdateBankAccount(account.id, 'holderName', formData.companyName || 'CV DTF SUBLIME INDONESIA')}
                                className="text-[9.5px] text-cyan-400 hover:underline cursor-pointer"
                                title="Salin nama usaha ke kolom atas nama rekening ini"
                              >
                                Pakai Nama Usaha
                              </button>
                            </div>
                            <input
                              type="text"
                              value={account.holderName}
                              onChange={(e) => handleUpdateBankAccount(account.id, 'holderName', e.target.value)}
                              placeholder="CV DTF SUBLIME INDONESIA"
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                            />
                            <span className="text-[9.5px] text-slate-500 block mt-1">
                              Nama pemilik sah buku tabungan
                            </span>
                          </div>
                        </div>

                        {/* Catatan / Keterangan Rekening */}
                        <div className="mt-2.5 pt-2 border-t border-slate-800/60">
                          <label className="text-[10.5px] font-medium text-slate-400 block mb-1">
                            Keterangan / Peruntukan Rekening (Opsional):
                          </label>
                          <input
                            type="text"
                            value={account.notes || ''}
                            onChange={(e) => handleUpdateBankAccount(account.id, 'notes', e.target.value)}
                            placeholder="Contoh: Rekening Utama Operasional / Transfer Konsumen / QRIS Kasir"
                            className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-xs text-slate-300 focus:outline-hidden focus:border-cyan-500"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Bottom Add Account Button */}
                <button
                  type="button"
                  onClick={() => handleAddBankAccount()}
                  className="w-full py-2.5 border-2 border-dashed border-slate-700 hover:border-cyan-500/60 bg-slate-900/50 hover:bg-cyan-950/20 text-slate-300 hover:text-cyan-300 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Tambah Nomor Rekening Baru (Bisa Tambah Lebih Dari 2 Rekening)</span>
                </button>

                {/* Datalist for popular banks */}
                <datalist id="popular-banks-list">
                  {POPULAR_BANKS.map((b) => (
                    <option key={b} value={b} />
                  ))}
                  <option value="Bank Danamon" />
                  <option value="Bank BTN" />
                  <option value="Bank Bukopin" />
                  <option value="Bank Mega" />
                  <option value="Bank OCBC NISP" />
                  <option value="Bank Panin" />
                  <option value="Bank BJB" />
                  <option value="Bank Jateng" />
                  <option value="Bank Jatim" />
                  <option value="Dana Bisnis" />
                  <option value="OVO Merchant" />
                  <option value="ShopeePay" />
                </datalist>

                {/* Info Callout */}
                <div className="p-3 bg-cyan-950/20 border border-cyan-800/30 rounded-xl flex items-start gap-2.5 text-xs text-slate-400">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-200">
                      Otomatis Tampil di Seluruh Nota & Faktur Penjualan:
                    </span>
                    <p className="mt-0.5 text-[11px] leading-relaxed">
                      Seluruh nomor rekening yang Anda tambahkan di atas akan tercantum di nota cetak kasir dan file PDF faktur penjualan, sehingga pelanggan dapat dengan leluasa memilih bank tujuan transfer yang paling nyaman.
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Catatan Kaki Standar Nota / Faktur Kasir
                </label>
                <textarea
                  rows={2}
                  value={formData.invoiceNotes}
                  onChange={(e) => handleChange('invoiceNotes', e.target.value)}
                  placeholder="Barang yang sudah dibeli telah dicek sesuai spesifikasi..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 leading-relaxed"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Syarat & ketentuan baku yang otomatis tertera di bagian bawah nota setiap transaksi
                </span>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                  Pesan Penutup / Ucapan Terima Kasih Nota
                </label>
                <input
                  type="text"
                  value={formData.invoiceFooterNotice}
                  onChange={(e) => handleChange('invoiceFooterNotice', e.target.value)}
                  placeholder="Terima kasih atas kepercayaan Anda bermitra dengan kami!"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                />
              </div>
            </div>
          )}

          {/* TAB 3: PEJABAT PENGESAHAN LAPORAN */}
          {activeTab === 'signers' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <p className="text-xs text-slate-400">
                Tentukan gelar jabatan penandatangan resmi pada lembar pengesahan Laporan Mutasi Stok dan dokumen audit lainnya:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Signer 1: Pembuat */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <span>1. Pihak Pembuat (Kiri)</span>
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Gelar Jabatan Utama
                    </label>
                    <input
                      type="text"
                      value={formData.signerTitle1}
                      onChange={(e) => handleChange('signerTitle1', e.target.value)}
                      placeholder="Petugas Logistik Gudang"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Sub-Gelar / Divisi
                    </label>
                    <input
                      type="text"
                      value={formData.signerSub1}
                      onChange={(e) => handleChange('signerSub1', e.target.value)}
                      placeholder="Staff Logistik & Kasir"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                </div>

                {/* Signer 2: Pemeriksa */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-blue-400 font-bold text-xs">
                    <span>2. Pihak Pemeriksa (Tengah)</span>
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Gelar Jabatan Utama
                    </label>
                    <input
                      type="text"
                      value={formData.signerTitle2}
                      onChange={(e) => handleChange('signerTitle2', e.target.value)}
                      placeholder="Supervisor Gudang (SPV)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Sub-Gelar / Divisi
                    </label>
                    <input
                      type="text"
                      value={formData.signerSub2}
                      onChange={(e) => handleChange('signerSub2', e.target.value)}
                      placeholder="Supervisor Operasional"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                </div>

                {/* Signer 3: Penyetuju */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <span>3. Pihak Penyetuju (Kanan)</span>
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Gelar Jabatan Utama
                    </label>
                    <input
                      type="text"
                      value={formData.signerTitle3}
                      onChange={(e) => handleChange('signerTitle3', e.target.value)}
                      placeholder="Pemilik Usaha (Owner)"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-semibold text-slate-400 block mb-1 uppercase">
                      Sub-Gelar / Divisi
                    </label>
                    <input
                      type="text"
                      value={formData.signerSub3}
                      onChange={(e) => handleChange('signerSub3', e.target.value)}
                      placeholder="Pimpinan Manajemen"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: BRANDING APLIKASI */}
          {activeTab === 'app' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              {/* Logo Kustom Perusahaan / Faktur */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3.5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <ImageIcon className="w-4 h-4 text-cyan-400" />
                        Logo Resmi Perusahaan & Faktur
                      </span>
                      {formData.logoUrl ? (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>Logo Gambar Aktif</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 text-[10px] font-semibold">
                          Inisial Monogram
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1">
                      Logo ini otomatis disematkan pada <strong>Kop Surat</strong>, <strong>Nota Kasir</strong>, dan <strong>Faktur Penjualan (Invoice)</strong> baik pada tampilan layar maupun saat dicetak/PDF.
                    </p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-4 p-3.5 bg-slate-900/60 rounded-xl border border-slate-800/80">
                  {/* Preview Box */}
                  <div className="flex flex-col items-center gap-1.5 shrink-0">
                    <div className="w-20 h-20 rounded-2xl bg-white border-2 border-slate-700/80 shadow-inner flex items-center justify-center p-2 relative overflow-hidden group">
                      {formData.logoUrl ? (
                        <img
                          src={formData.logoUrl}
                          alt="Logo Perusahaan"
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <div className="w-full h-full bg-slate-900 text-cyan-400 rounded-xl flex items-center justify-center font-black text-xl font-mono">
                          {formData.shortName || formData.appLogoBadge || 'DTF'}
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">
                      {formData.logoUrl ? 'Pratinjau Logo' : 'Inisial Standar'}
                    </span>
                  </div>

                  {/* Actions & Buttons */}
                  <div className="flex-1 w-full space-y-2.5">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleLogoFileUpload}
                      accept="image/png,image/jpeg,image/webp,image/svg+xml"
                      className="hidden"
                    />

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={isProcessingLogo}
                        className="px-3.5 py-2 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>{isProcessingLogo ? 'Memproses Gambar...' : formData.logoUrl ? 'Ganti Gambar Logo' : 'Unggah Gambar Logo'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShowUrlInput(!showUrlInput)}
                        className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer"
                      >
                        <LinkIcon className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Input URL Logo</span>
                      </button>

                      {formData.logoUrl && (
                        <button
                          type="button"
                          onClick={handleRemoveLogo}
                          className="px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 border border-rose-500/30 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer sm:ml-auto"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Hapus Logo</span>
                        </button>
                      )}
                    </div>

                    {/* URL Input collapse */}
                    {showUrlInput && (
                      <div className="flex items-center gap-2 pt-1 animate-in fade-in duration-150">
                        <input
                          type="url"
                          value={customLogoUrl}
                          onChange={(e) => setCustomLogoUrl(e.target.value)}
                          placeholder="https://example.com/logo-usaha.png"
                          className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                        />
                        <button
                          type="button"
                          onClick={handleApplyLogoUrl}
                          disabled={!customLogoUrl.trim()}
                          className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold disabled:opacity-40 cursor-pointer"
                        >
                          Terapkan
                        </button>
                      </div>
                    )}

                    {logoUploadError && (
                      <div className="flex items-center gap-1.5 text-[11px] text-rose-400 bg-rose-950/30 border border-rose-800/40 px-2.5 py-1 rounded-lg">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{logoUploadError}</span>
                      </div>
                    )}

                    <p className="text-[10.5px] text-slate-500 leading-normal">
                      Mendukung format PNG (latar transparan disarankan), JPG, SVG, WebP. Gambar otomatis dioptimasi agar tetap ringan dan tajam saat dicetak dalam format Faktur A4 / Nota Kasir.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Nama Aplikasi (Bilah Navigasi)
                  </label>
                  <input
                    type="text"
                    value={formData.appName}
                    onChange={(e) => handleChange('appName', e.target.value)}
                    placeholder="DTF & Sublime"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-bold"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Muncul pada header bilah navigasi dan judul sistem
                  </span>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Teks Badge Ikon Logo
                  </label>
                  <input
                    type="text"
                    maxLength={8}
                    value={formData.appLogoBadge}
                    onChange={(e) => handleChange('appLogoBadge', e.target.value.toUpperCase())}
                    placeholder="GUDANG"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Teks kecil di samping nama logo header
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Sub-Judul Aplikasi
                  </label>
                  <input
                    type="text"
                    value={formData.appSubtitle}
                    onChange={(e) => handleChange('appSubtitle', e.target.value)}
                    placeholder="Manajemen Stok, Produksi & Invoice Konsumen"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1.5">
                    Label Versi Aplikasi
                  </label>
                  <input
                    type="text"
                    value={formData.appVersion}
                    onChange={(e) => handleChange('appVersion', e.target.value)}
                    placeholder="v2.5 Pro"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-white focus:outline-hidden focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* LIVE PREVIEW OF OFFICIAL LETTERHEAD */}
          <div className="pt-4 border-t border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-cyan-400" />
                <span>Pratinjau Langsung Kop Surat & Dokumen Cetak</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Format A4 Live</span>
            </div>

            <div className="bg-white text-slate-900 p-4 sm:p-5 rounded-xl border border-slate-300 shadow-md">
              <div className="flex items-start justify-between gap-3 pb-3 border-b-2 border-slate-900">
                <div className="flex items-start gap-2.5">
                  {formData.logoUrl ? (
                    <div className="w-12 h-12 rounded-lg border border-slate-200 bg-white p-1 flex items-center justify-center shrink-0 shadow-xs overflow-hidden">
                      <img
                        src={formData.logoUrl}
                        alt={formData.companyName || 'Logo Perusahaan'}
                        className="w-full h-full object-contain"
                      />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-slate-900 text-cyan-400 flex items-center justify-center font-black text-sm shrink-0">
                      {formData.shortName || formData.appLogoBadge || 'DTF'}
                    </div>
                  )}
                  <div>
                    <h3 className="text-sm font-black text-slate-900 tracking-tight leading-tight uppercase">
                      {formData.companyName || 'NAMA PERUSAHAAN ANDA'}
                    </h3>
                    <p className="text-[10px] text-slate-600 font-medium line-clamp-1">
                      {formData.tagline || 'Slogan usaha Anda'}
                    </p>
                    <p className="text-[9.5px] text-slate-500 mt-0.5">
                      {formData.address || 'Alamat usaha'}, {formData.city || 'Kota'} • Telp: {formData.phone || '-'} • Email: {formData.email || '-'}
                    </p>
                  </div>
                </div>
                <div className="text-right shrink-0 max-w-[280px]">
                  <span className="inline-block px-2 py-0.5 rounded bg-slate-900 text-white font-black text-[9px] uppercase tracking-wider">
                    DOKUMEN RESMI
                  </span>
                  <div className="text-[9px] text-slate-600 font-mono mt-1 space-y-0.5 text-left bg-slate-50 p-1.5 rounded border border-slate-200">
                    <span className="font-bold text-slate-800 block text-[8px] uppercase font-sans">
                      Rekening Transfer Nota:
                    </span>
                    {(formData.bankAccounts && formData.bankAccounts.length > 0) ? (
                      formData.bankAccounts.slice(0, 4).map((acc, i) => (
                        <div key={acc.id || i} className="truncate text-[8.5px]">
                          • <strong className="text-slate-900">{acc.bankName}</strong> {acc.accountNumber || '-'}
                          {acc.isPrimary && <span className="text-emerald-600 font-semibold ml-1">(Utama)</span>}
                        </div>
                      ))
                    ) : (
                      <p className="text-[8.5px]">
                        Rek: {formData.bankName} {formData.bankAccountNo} a/n {formData.bankAccountHolder}
                      </p>
                    )}
                    {formData.bankAccounts && formData.bankAccounts.length > 4 && (
                      <span className="text-[8px] text-slate-400 italic block">
                        +{formData.bankAccounts.length - 4} rekening lainnya
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="pt-2 text-[9px] text-slate-500 flex justify-between font-mono">
                <span>Catatan Nota: "{formData.invoiceNotes}"</span>
                <span className="text-slate-400">{formData.city}, {new Date().toLocaleDateString('id-ID')}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
            <button
              type="button"
              onClick={() => setShowResetConfirm(true)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-rose-400 border border-slate-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              title="Kembalikan nama dan profil ke pengaturan awal bawaan"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Default</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-cyan-950/50 cursor-pointer active:scale-95 transition-all"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Perubahan Identitas</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Confirmation Dialog for Reset to Default */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-60 bg-black/85 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span>Reset ke Pengaturan Awal?</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Seluruh nama usaha, nomor rekening, pejabat penandatangan, dan branding aplikasi akan dikembalikan ke data default pabrik (Gudang Suplai Sablon DTF & Sublime).
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs font-semibold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleReset}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                Ya, Reset Default
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
