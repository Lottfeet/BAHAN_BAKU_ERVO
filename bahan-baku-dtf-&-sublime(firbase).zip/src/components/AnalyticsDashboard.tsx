import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Package, 
  PieChart as PieChartIcon, 
  AlertTriangle, 
  ArrowUpRight, 
  Layers, 
  ShoppingCart, 
  Calendar, 
  Sparkles, 
  BarChart3, 
  Clock, 
  CreditCard,
  Scale,
  TrendingDown,
  Info,
  CheckCircle2,
  FileSpreadsheet
} from 'lucide-react';
import { Product, Invoice, StockMovement } from '../types';
import { formatRupiah, getInvoiceDueInfo } from '../utils/helpers';
import { InvoiceDueReminders } from './InvoiceDueReminders';

interface AnalyticsDashboardProps {
  products: Product[];
  invoices: Invoice[];
  movements: StockMovement[];
  onOpenRestockModal: (product?: Product) => void;
  onNavigateToSales?: (statusFilter?: 'all' | 'lunas' | 'belum_lunas' | 'dp', invoiceId?: string) => void;
  onUpdateInvoiceStatus?: (invoiceId: string, status: 'lunas' | 'belum_lunas' | 'dp', paidAmount: number) => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  products,
  invoices,
  movements,
  onOpenRestockModal,
  onNavigateToSales,
  onUpdateInvoiceStatus,
}) => {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | 'all'>('7d');

  // Key figures
  const totalRevenue = invoices.reduce((acc, inv) => acc + inv.grandTotal, 0);

  // Unpaid invoices & receivables
  const unpaidInvoices = invoices.filter(
    (inv) => inv.paymentStatus === 'belum_lunas' || inv.paymentStatus === 'dp'
  );
  let totalReceivable = 0;
  let overdueCount = 0;
  unpaidInvoices.forEach((inv) => {
    const dueInfo = getInvoiceDueInfo(inv);
    totalReceivable += dueInfo.unpaidAmount;
    if (dueInfo.isOverdue) overdueCount++;
  });
  
  // Calculate total gross profit from invoices
  let totalCostSold = 0;
  invoices.forEach((inv) => {
    inv.items.forEach((item) => {
      totalCostSold += item.costPrice * item.quantity;
    });
  });
  const grossProfit = Math.max(0, totalRevenue - totalCostSold);
  const profitMarginPercent = totalRevenue > 0 ? Math.round((grossProfit / totalRevenue) * 100) : 0;

  // Comparison & Cost: Internal Production vs External Sales
  const productionMovements = movements.filter((m) => m.type === 'production');
  const salesMovements = movements.filter((m) => m.type === 'sale');

  // Total internal production cost calculated strictly from costPrice (Harga Beli/HPP)
  const totalProductionCost = productionMovements.reduce((acc, m) => {
    if (typeof m.totalValue === 'number' && m.totalValue > 0) return acc + m.totalValue;
    if (typeof m.unitPrice === 'number' && m.unitPrice > 0) return acc + (m.quantity * m.unitPrice);
    const matched = products.find((p) => p.id === m.productId);
    return acc + (m.quantity * (matched?.costPrice || 0));
  }, 0);

  // Net Profit / Loss contribution
  const netContribution = grossProfit - totalProductionCost;
  const isNetSurplus = netContribution >= 0;

  const totalQtyProduction = productionMovements.reduce((acc, m) => acc + m.quantity, 0);
  const totalQtySales = salesMovements.reduce((acc, m) => acc + m.quantity, 0);
  const totalCombinedQty = totalQtyProduction + totalQtySales || 1;
  const productionRatio = Math.round((totalQtyProduction / totalCombinedQty) * 100);
  const salesRatio = 100 - productionRatio;

  // Aggregate cost breakdown per product for internal production
  const productionCostByProduct = useMemo(() => {
    const map: Record<string, { name: string; code: string; unit: string; costPrice: number; qty: number; totalCost: number }> = {};
    productionMovements.forEach((m) => {
      const matched = products.find((p) => p.id === m.productId);
      const unitCost = m.unitPrice ?? matched?.costPrice ?? 0;
      const cost = m.totalValue ?? (m.quantity * unitCost);

      if (!map[m.productId]) {
        map[m.productId] = {
          name: m.productName,
          code: m.productCode,
          unit: m.unit,
          costPrice: unitCost,
          qty: 0,
          totalCost: 0,
        };
      }
      map[m.productId].qty += m.quantity;
      map[m.productId].totalCost += cost;
    });
    return Object.values(map).sort((a, b) => b.totalCost - a.totalCost);
  }, [productionMovements, products]);

  // Top consumed products
  const productConsumptionMap: Record<string, { name: string; category: string; count: number; unit: string }> = {};
  movements.forEach((m) => {
    if (!productConsumptionMap[m.productId]) {
      productConsumptionMap[m.productId] = {
        name: m.productName,
        category: m.category,
        count: 0,
        unit: m.unit,
      };
    }
    productConsumptionMap[m.productId].count += m.quantity;
  });

  const topConsumed = Object.values(productConsumptionMap)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Critical stock items
  const criticalProducts = products.filter((p) => p.currentStock <= p.minStockAlert);

  // Daily sales mockup for chart
  const days = [
    { label: 'Senin', sales: 450000, production: 3 },
    { label: 'Selasa', sales: 850000, production: 5 },
    { label: 'Rabu', sales: 1200000, production: 4 },
    { label: 'Kamis', sales: 685000, production: 6 },
    { label: 'Jumat', sales: 1350000, production: 7 },
    { label: 'Sabtu', sales: 1950000, production: 8 },
    { label: 'Hari Ini', sales: totalRevenue > 0 ? totalRevenue : 1450000, production: 5 },
  ];
  const maxSale = Math.max(...days.map((d) => d.sales));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <div>
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base sm:text-lg font-bold text-white">Dasbor Analitik Performa & Stok</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Pantau omset penjualan bahan baku ke konsumen luar vs intensitas pemakaian produksi sablon internal.
          </p>
        </div>

        <div className="w-full sm:w-auto flex items-center justify-between sm:justify-start gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setTimeRange('7d')}
            className={`flex-1 sm:flex-none text-center px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              timeRange === '7d' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            7 Hari
          </button>
          <button
            onClick={() => setTimeRange('30d')}
            className={`flex-1 sm:flex-none text-center px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              timeRange === '30d' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Bulan Ini
          </button>
          <button
            onClick={() => setTimeRange('all')}
            className={`flex-1 sm:flex-none text-center px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              timeRange === 'all' ? 'bg-cyan-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Semua
          </button>
        </div>
      </div>

      {/* 5 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Total Omset</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-emerald-400 mt-1.5 truncate">{formatRupiah(totalRevenue)}</p>
          <div className="flex items-center gap-1 mt-1 text-[10px] sm:text-[11px] text-emerald-400 font-medium">
            <ArrowUpRight className="w-3 h-3" />
            <span className="truncate">{invoices.length} invoice</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-rose-300">Piutang Tertunda</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-rose-500/20 text-rose-400">
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-rose-400 mt-1.5 truncate">{formatRupiah(totalReceivable)}</p>
          <span className="text-[10px] sm:text-[11px] text-rose-400/80 mt-1 block truncate font-medium">
            {unpaidInvoices.length} invoice ({overdueCount} lewat tempo)
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Estimasi Laba</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-indigo-300 mt-1.5 truncate">{formatRupiah(grossProfit)}</p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-1 block truncate">
            Margin: <strong className="text-indigo-400">{profitMarginPercent}%</strong>
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Rasio Bahan</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-blue-500/20 text-blue-400">
              <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-1.5 mt-1.5">
            <span className="text-base sm:text-xl font-bold text-blue-400">{productionRatio}%</span>
            <span className="text-[10px] text-slate-400">Prod</span>
            <span className="text-slate-600">/</span>
            <span className="text-base sm:text-xl font-bold text-emerald-400">{salesRatio}%</span>
            <span className="text-[10px] text-slate-400">Jual</span>
          </div>
          <div className="w-full bg-slate-800 h-1.5 sm:h-2 rounded-full mt-2 flex overflow-hidden">
            <div className="bg-blue-500 h-full" style={{ width: `${productionRatio}%` }} />
            <div className="bg-emerald-500 h-full" style={{ width: `${salesRatio}%` }} />
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-amber-300">Perlu Reorder</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-amber-500/20 text-amber-400">
              <AlertTriangle className="w-3.5 h-3.5 sm:w-4 sm:h-4 animate-bounce" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-amber-300 mt-1.5">{criticalProducts.length} Item</p>
          <span className="text-[10px] sm:text-[11px] text-amber-400/80 mt-1 block truncate">
            Stok &le; batas minimum
          </span>
        </div>
      </div>

      {/* PENGINGAT JATUH TEMPO INVOICE (BELUM LUNAS & DP) */}
      <InvoiceDueReminders
        invoices={invoices}
        onUpdateInvoiceStatus={onUpdateInvoiceStatus || (() => {})}
        onNavigateToSales={onNavigateToSales}
      />

      {/* LAPORAN LABA / RUGI & BEBAN PEMAKAIAN PRODUKSI SENDIRI */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white">Analisis Laba / Rugi Bahan Baku & Alokasi Produksi</h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide border ${
                  isNetSurplus 
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30' 
                    : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                }`}>
                  {isNetSurplus ? 'Status: Surplus / Profit' : 'Status: Alokasi Biaya Cetak'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Kalkulasi keuntungan penjualan ke konsumen luar disandingkan dengan beban pemakaian bahan produksi sablon sendiri (dihitung otomatis dari Harga Beli/HPP).
              </p>
            </div>
          </div>
        </div>

        {/* 4-Step P&L Equation Flow */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Step 1: Penjualan Luar */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-semibold uppercase text-slate-400 flex items-center justify-between">
              <span>1. Omset Penjualan Luar</span>
              <span className="text-emerald-400 font-mono">(+)</span>
            </span>
            <div className="text-base sm:text-lg font-bold text-emerald-400 font-mono">
              {formatRupiah(totalRevenue)}
            </div>
            <p className="text-[11px] text-slate-500 leading-tight">
              Dari {invoices.length} invoice penjualan bahan ke konsumen
            </p>
          </div>

          {/* Step 2: HPP Terjual */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-semibold uppercase text-slate-400 flex items-center justify-between">
              <span>2. Modal Bahan Terjual</span>
              <span className="text-rose-400 font-mono">(-)</span>
            </span>
            <div className="text-base sm:text-lg font-bold text-slate-300 font-mono">
              {formatRupiah(totalCostSold)}
            </div>
            <p className="text-[11px] text-slate-500 leading-tight">
              HPP modal bahan yang dikirim ke konsumen
            </p>
          </div>

          {/* Step 3: Beban Produksi Sendiri */}
          <div className="p-3.5 rounded-xl bg-slate-950 border border-blue-500/30 space-y-1">
            <span className="text-[10px] font-semibold uppercase text-blue-300 flex items-center justify-between">
              <span>3. Beban Pakai Sendiri (HPP)</span>
              <span className="text-blue-400 font-mono">(-)</span>
            </span>
            <div className="text-base sm:text-lg font-bold text-blue-300 font-mono">
              {formatRupiah(totalProductionCost)}
            </div>
            <p className="text-[11px] text-blue-400/80 leading-tight">
              Otomatis dari harga beli ({productionMovements.length} SPK sablon)
            </p>
          </div>

          {/* Step 4: Net Result */}
          <div className={`p-3.5 rounded-xl border space-y-1 ${
            isNetSurplus 
              ? 'bg-emerald-950/20 border-emerald-500/40' 
              : 'bg-amber-950/20 border-amber-500/40'
          }`}>
            <span className="text-[10px] font-semibold uppercase flex items-center justify-between">
              <span className={isNetSurplus ? 'text-emerald-300' : 'text-amber-300'}>
                4. Posisi Bersih Bahan
              </span>
              <span className="font-mono text-xs font-bold">(=)</span>
            </span>
            <div className={`text-base sm:text-lg font-extrabold font-mono ${
              isNetSurplus ? 'text-emerald-400' : 'text-amber-300'
            }`}>
              {isNetSurplus ? `+${formatRupiah(netContribution)}` : `-${formatRupiah(Math.abs(netContribution))}`}
            </div>
            <p className={`text-[11px] leading-tight ${isNetSurplus ? 'text-emerald-400/80' : 'text-amber-400/80'}`}>
              {isNetSurplus 
                ? 'Profit bersih bahan setelah menutupi seluruh pemakaian internal.' 
                : 'Beban dialokasikan ke laba pendapatan jasa sablon.'}
            </p>
          </div>
        </div>

        {/* Detailed Material Cost Breakdown for Internal Production */}
        {productionCostByProduct.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>Rincian Beban Bahan yang Dipakai Produksi Sendiri (Dihitung dari Harga Beli Satuan)</span>
              </h4>
              <span className="text-[11px] text-blue-400 font-mono">
                Total: {formatRupiah(totalProductionCost)}
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-800 rounded-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-950/90 text-slate-400 font-semibold uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Bahan Baku</th>
                    <th className="py-2.5 px-2 text-center">Volume Pemakaian</th>
                    <th className="py-2.5 px-3 text-right">Harga Beli Satuan (HPP Otomatis)</th>
                    <th className="py-2.5 px-3 text-right">Total Beban Pokok</th>
                    <th className="py-2.5 px-3 text-right">Porsi Beban</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/80">
                  {productionCostByProduct.map((p) => {
                    const percent = totalProductionCost > 0 ? Math.round((p.totalCost / totalProductionCost) * 100) : 0;
                    return (
                      <tr key={p.code} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-3">
                          <span className="font-semibold text-white block">{p.name}</span>
                          <span className="text-[10px] font-mono text-cyan-400">{p.code}</span>
                        </td>
                        <td className="py-2.5 px-2 text-center font-semibold text-blue-300 whitespace-nowrap">
                          {p.qty} {p.unit}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono text-slate-300 whitespace-nowrap">
                          {formatRupiah(p.costPrice)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-blue-300 whitespace-nowrap">
                          {formatRupiah(p.totalCost)}
                        </td>
                        <td className="py-2.5 px-3 text-right whitespace-nowrap">
                          <span className="text-xs font-mono font-semibold text-slate-400">{percent}%</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Chart & Top Consumed Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6">
        {/* Left 7 cols: SVG Trend Chart */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 gap-2">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Tren Penjualan Bahan Baku 7 Hari</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Grafik volume omset harian</p>
            </div>
            <span className="text-[10px] sm:text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-2 py-1 rounded border border-emerald-800/40 shrink-0">
              Puncak: {formatRupiah(maxSale)}
            </span>
          </div>

          {/* SVG Bar Chart with Tooltips */}
          <div className="pt-2 sm:pt-4">
            <div className="flex items-end justify-between gap-1.5 sm:gap-2 h-48 sm:h-56 pt-6 px-1 sm:px-2">
              {days.map((d, idx) => {
                const heightPercent = Math.max(12, Math.round((d.sales / maxSale) * 100));
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                    {/* Hover Value Tooltip */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-slate-950 text-white text-[9px] sm:text-[10px] font-mono px-1.5 py-0.5 rounded shadow-lg border border-slate-700 whitespace-nowrap mb-1">
                      {formatRupiah(d.sales)}
                    </div>
                    {/* Bar */}
                    <div className="w-full max-w-[36px] bg-slate-800 rounded-t-lg overflow-hidden flex flex-col justify-end h-full">
                      <div
                        className="w-full bg-gradient-to-t from-emerald-600 to-cyan-400 rounded-t-lg transition-all duration-500 group-hover:brightness-125"
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                    {/* Label */}
                    <span className="text-[9px] sm:text-xs text-slate-400 group-hover:text-cyan-300 transition-colors">
                      {d.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right 5 cols: Top Consumed Materials */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>5 Bahan Baku Paling Cepat Keluar</span>
          </h3>

          <div className="space-y-3">
            {topConsumed.map((item, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-semibold text-slate-100 line-clamp-1">{item.name}</span>
                  <span className="font-mono font-bold text-cyan-300 shrink-0 ml-2">
                    {item.count} {item.unit.split(' ')[0]}
                  </span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, item.count * 15)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/20 text-xs text-cyan-300 leading-relaxed">
            💡 <strong>Rekomendasi Operasional:</strong> Tinta DTF White & PET Film 30cm memiliki perputaran tercepat. Pastikan stok cadangan (safety stock) selalu tersedia minimal 2 pekan ke depan.
          </div>
        </div>
      </div>

      {/* Critical Stock List with Quick Reorder */}
      {criticalProducts.length > 0 && (
        <div className="bg-slate-900 border border-amber-500/30 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2 text-amber-300">
              <AlertTriangle className="w-5 h-5 animate-pulse" />
              <h3 className="font-bold text-sm sm:text-base">
                Daftar Bahan Menipis yang Membutuhkan Reorder Segera
              </h3>
            </div>
            <span className="text-xs text-amber-400/80 font-medium">
              {criticalProducts.length} bahan di bawah ambang batas minimum
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {criticalProducts.map((p) => (
              <div key={p.id} className="p-3.5 rounded-xl bg-slate-950 border border-amber-500/20 flex items-center justify-between gap-3">
                <div>
                  <span className="font-semibold text-xs text-slate-100 block">{p.name}</span>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs font-bold text-amber-400">
                      Sisa: {p.currentStock} {p.unit}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      (Min: {p.minStockAlert})
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => onOpenRestockModal(p)}
                  className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-lg text-xs font-bold shrink-0 transition-colors"
                >
                  + Restock
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
