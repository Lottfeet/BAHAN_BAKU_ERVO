import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  AlertTriangle, 
  AlertCircle,
  CheckCircle2, 
  PackageMinus, 
  PackagePlus, 
  ShoppingCart, 
  ShoppingBag,
  Edit3, 
  Trash2,
  Layers, 
  ArrowUpDown,
  X,
  Boxes,
  SlidersHorizontal,
  Info,
  Settings2,
  Sparkles,
  RotateCcw,
  RotateCw,
  Tag,
  Scale,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Pin,
  ClipboardCheck
} from 'lucide-react';
import { Product, ProductCategory, User, ProductUnit, CategoryItem, SupplierItem, CustomerItem, Invoice, StockMovement } from '../types';
import { formatRupiah, getWIBNow } from '../utils/helpers';
import { generateAutoProductCode } from '../data/masterData';
import { MasterDataModal } from './MasterDataModal';

interface StockListProps {
  products: Product[];
  currentUser: User;
  categories: CategoryItem[];
  units: string[];
  locations: string[];
  suppliers?: SupplierItem[];
  customers?: CustomerItem[];
  invoices?: Invoice[];
  movements?: StockMovement[];
  onAddCategory: (category: CategoryItem) => void;
  onDeleteCategory: (categoryId: string) => { success: boolean; message?: string };
  onAddUnit: (unit: string) => void;
  onDeleteUnit: (unit: string) => { success: boolean; message?: string };
  onAddLocation: (location: string) => void;
  onDeleteLocation: (location: string) => { success: boolean; message?: string };
  onAddSupplier?: (supplier: SupplierItem) => void;
  onDeleteSupplier?: (supplierId: string) => { success: boolean; message?: string };
  onAddCustomer?: (customer: CustomerItem) => void;
  onDeleteCustomer?: (customerId: string) => { success: boolean; message?: string };
  onUpdateCategory?: (oldCatId: string, updatedCategory: CategoryItem) => { success: boolean; message?: string };
  onUpdateUnit?: (oldUnit: string, newUnit: string) => { success: boolean; message?: string };
  onUpdateLocation?: (oldLocation: string, newLocation: string) => { success: boolean; message?: string };
  onUpdateSupplier?: (updatedSupplier: SupplierItem) => { success: boolean; message?: string };
  onUpdateCustomer?: (updatedCustomer: CustomerItem) => { success: boolean; message?: string };
  divisions?: string[];
  onAddDivision?: (division: string) => void;
  onDeleteDivision?: (division: string) => { success: boolean; message?: string };
  onUpdateDivision?: (oldDivision: string, newDivision: string) => { success: boolean; message?: string };
  onOpenProductionModal: (product?: Product) => void;
  onOpenRestockModal: (product?: Product) => void;
  onOpenSaleModal: (product?: Product) => void;
  onSaveProduct: (product: Product, operatorUser?: User) => void;
  onDeleteProduct?: (productId: string, operatorUser?: User) => { success: boolean; message?: string };
  onNavigateToPurchases?: () => void;
  onNavigateToOpname?: () => void;
  initialFilterCritical?: boolean;
}

export const StockList: React.FC<StockListProps> = ({
  products,
  currentUser,
  categories,
  units,
  locations,
  suppliers = [],
  customers = [],
  invoices = [],
  movements = [],
  onAddCategory,
  onDeleteCategory,
  onAddUnit,
  onDeleteUnit,
  onAddLocation,
  onDeleteLocation,
  onAddSupplier = () => {},
  onDeleteSupplier = () => ({ success: true }),
  onAddCustomer,
  onDeleteCustomer,
  onUpdateCategory,
  onUpdateUnit,
  onUpdateLocation,
  onUpdateSupplier,
  onUpdateCustomer,
  divisions = [],
  onAddDivision,
  onDeleteDivision,
  onUpdateDivision,
  onOpenProductionModal,
  onOpenRestockModal,
  onOpenSaleModal,
  onSaveProduct,
  onDeleteProduct,
  onNavigateToPurchases,
  onNavigateToOpname,
  initialFilterCritical = false,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'critical' | 'safe' | 'empty'>(
    initialFilterCritical ? 'critical' : 'all'
  );

  useEffect(() => {
    if (initialFilterCritical) {
      setStatusFilter('critical');
    }
  }, [initialFilterCritical]);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Aksi Hapus Bahan Baku HANYA diizinkan untuk SPV (Supervisor Gudang) dan Owner (Pemilik)
  const canDeleteProduct = currentUser.role === 'owner' || currentUser.role === 'warehouse_admin';
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeletingProduct, setIsDeletingProduct] = useState(false);
  const [deleteProductError, setDeleteProductError] = useState<string | null>(null);
  const [deleteSuccessToast, setDeleteSuccessToast] = useState<string | null>(null);

  const handleConfirmDelete = () => {
    if (!productToDelete || !onDeleteProduct) return;
    setIsDeletingProduct(true);
    setDeleteProductError(null);
    const res = onDeleteProduct(productToDelete.id, currentUser);
    if (res.success) {
      setDeleteSuccessToast(res.message || `Bahan ${productToDelete.name} berhasil dihapus.`);
      setTimeout(() => setDeleteSuccessToast(null), 4000);
      if (editingProduct?.id === productToDelete.id) {
        setIsProductModalOpen(false);
        setEditingProduct(null);
      }
      setProductToDelete(null);
      setIsDeletingProduct(false);
    } else {
      setDeleteProductError(res.message || 'Gagal menghapus bahan.');
      setIsDeletingProduct(false);
    }
  };

  // Master Data modal state
  const [isMasterDataModalOpen, setIsMasterDataModalOpen] = useState(false);
  const [masterDataInitialTab, setMasterDataInitialTab] = useState<'category' | 'unit' | 'location' | 'supplier'>('category');

  // Form states for Add/Edit product
  const [formCode, setFormCode] = useState('');
  const [isAutoCode, setIsAutoCode] = useState(true);
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<string>('dtf');
  const [formUnit, setFormUnit] = useState<string>('Botol (1 Liter)');
  const [formStock, setFormStock] = useState<number>(10);
  const [formMinStock, setFormMinStock] = useState<number>(4);
  const [formCostPrice, setFormCostPrice] = useState<number>(150000);
  const [formSellingPrice, setFormSellingPrice] = useState<number>(200000);
  const [formLocation, setFormLocation] = useState('Gudang Utama - Rak A1');
  const [formDescription, setFormDescription] = useState('');

  const openNewProductModal = () => {
    setEditingProduct(null);
    const initialCat = categories[0]?.id || 'dtf';
    const autoCode = generateAutoProductCode(initialCat, products, categories);
    setFormCode(autoCode);
    setIsAutoCode(true);
    setFormName('');
    setFormCategory(initialCat);
    setFormUnit(units[0] || 'Botol (1 Liter)');
    setFormStock(10);
    setFormMinStock(5);
    setFormCostPrice(150000);
    setFormSellingPrice(210000);
    setFormLocation(locations[0] || 'Gudang Utama - Rak A1');
    setFormDescription('');
    setIsProductModalOpen(true);
  };

  const openEditProductModal = (prod: Product) => {
    setEditingProduct(prod);
    setFormCode(prod.code);
    setIsAutoCode(false); // In edit mode, retain existing code
    setFormName(prod.name);
    setFormCategory(prod.category);
    setFormUnit(prod.unit);
    setFormStock(prod.currentStock);
    setFormMinStock(prod.minStockAlert);
    setFormCostPrice(prod.costPrice);
    setFormSellingPrice(prod.sellingPrice);
    setFormLocation(prod.location || locations[0] || 'Gudang Utama');
    setFormDescription(prod.description);
    setIsProductModalOpen(true);
  };

  const handleCategoryChange = (newCatId: string) => {
    setFormCategory(newCatId);
    // Auto-generate code when category is changed if in auto mode or creating new item
    if (!editingProduct || isAutoCode) {
      const nextCode = generateAutoProductCode(newCatId, products, categories);
      setFormCode(nextCode);
      setIsAutoCode(true);
    }
  };

  const handleRegenerateCode = () => {
    const nextCode = generateAutoProductCode(formCategory, products, categories);
    setFormCode(nextCode);
    setIsAutoCode(true);
  };

  const isSpv = Boolean(
    currentUser?.id === 'user-2' ||
    currentUser?.roleTitle?.toLowerCase().includes('spv') ||
    currentUser?.roleTitle?.toLowerCase().includes('supervisor') ||
    currentUser?.name?.toLowerCase().includes('spv') ||
    currentUser?.name?.toLowerCase().includes('supervisor')
  );

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const trimmedLoc = formLocation.trim() || 'Gudang Utama';
    if (!locations.includes(trimmedLoc)) {
      onAddLocation(trimmedLoc);
    }

    const effectiveStock = (editingProduct && !isSpv)
      ? editingProduct.currentStock
      : Number(formStock);

    const newProd: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      code: formCode.trim() || generateAutoProductCode(formCategory, products, categories),
      name: formName.trim(),
      category: formCategory,
      unit: formUnit,
      currentStock: effectiveStock,
      minStockAlert: Number(formMinStock),
      costPrice: Number(formCostPrice),
      sellingPrice: Number(formSellingPrice),
      description: formDescription.trim(),
      location: trimmedLoc,
      lastUpdated: getWIBNow(false),
    };

    onSaveProduct(newProd, currentUser);
    setIsProductModalOpen(false);
  };

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.location.toLowerCase().includes(searchQuery.toLowerCase());

      const matchCategory = selectedCategory === 'all' || p.category === selectedCategory;

      let matchStatus = true;
      if (statusFilter === 'critical' || (statusFilter as string) === 'low') {
        matchStatus = p.currentStock <= p.minStockAlert;
      } else if (statusFilter === 'safe') {
        matchStatus = p.currentStock > p.minStockAlert;
      } else if (statusFilter === 'empty') {
        matchStatus = p.currentStock <= 0;
      }

      return matchSearch && matchCategory && matchStatus;
    });
  }, [products, searchQuery, selectedCategory, statusFilter]);

  // Horizontal scroll tracking for desktop table
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    const el = tableContainerRef.current;
    if (!el) return;
    setCanScrollLeft(el.scrollLeft > 4);
    setCanScrollRight(el.scrollLeft + el.clientWidth < el.scrollWidth - 4);
  };

  useEffect(() => {
    const el = tableContainerRef.current;
    if (!el) return;
    checkScroll();
    el.addEventListener('scroll', checkScroll, { passive: true });
    window.addEventListener('resize', checkScroll);
    return () => {
      el.removeEventListener('scroll', checkScroll);
      window.removeEventListener('resize', checkScroll);
    };
  }, [filteredProducts]);

  const handleScrollLeft = () => {
    tableContainerRef.current?.scrollBy({ left: -240, behavior: 'smooth' });
  };

  const handleScrollRight = () => {
    tableContainerRef.current?.scrollBy({ left: 240, behavior: 'smooth' });
  };

  // Statistics calculation
  const totalItems = products.length;
  const criticalItems = products.filter((p) => p.currentStock <= p.minStockAlert).length;
  const totalCostValue = products.reduce((acc, p) => acc + p.currentStock * p.costPrice, 0);
  const totalSalesValue = products.reduce((acc, p) => acc + p.currentStock * p.sellingPrice, 0);

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Top summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] sm:text-xs text-slate-400 font-medium">Total Bahan</span>
            <Boxes className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-400" />
          </div>
          <p className="text-lg sm:text-2xl font-bold text-white mt-0.5 sm:mt-1">{totalItems}</p>
          <span className="text-[9px] sm:text-[11px] text-slate-400 truncate block">DTF, Sublime & Kimia</span>
        </div>

        <div 
          onClick={() => setStatusFilter((prev) => (prev === 'critical' ? 'all' : 'critical'))}
          className={`border rounded-xl p-2.5 sm:p-4 shadow-sm cursor-pointer transition-all hover:scale-[1.01] active:scale-95 ${
            statusFilter === 'critical' 
              ? 'bg-amber-500/20 border-amber-500 ring-2 ring-amber-500/40' 
              : criticalItems > 0 
                ? 'bg-amber-500/10 border-amber-500/30' 
                : 'bg-slate-900 border-slate-800'
          }`}
          title="Klik untuk filter bahan baku yang menipis"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] sm:text-xs font-medium text-amber-300">Stok Kritis</span>
            <AlertTriangle className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-400 animate-bounce" />
          </div>
          <p className="text-lg sm:text-2xl font-bold text-amber-300 mt-0.5 sm:mt-1">{criticalItems}</p>
          <span className="text-[9px] sm:text-[11px] text-amber-400/80 truncate block">Perlu restock supplier</span>
        </div>

        {currentUser.canViewFinancials ? (
          <>
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 sm:p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-[10px] sm:text-xs text-slate-400 font-medium">Modal (HPP)</span>
                <span className="text-emerald-400 text-[9px] sm:text-xs font-bold">Gudang</span>
              </div>
              <p className="text-sm sm:text-xl font-bold text-emerald-400 mt-0.5 sm:mt-1 truncate">{formatRupiah(totalCostValue)}</p>
              <span className="text-[9px] sm:text-[11px] text-slate-400 truncate block">Aset bahan baku</span>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 sm:p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-[10px] sm:text-xs text-slate-400 font-medium">Estimasi Jual</span>
                <span className="text-indigo-400 text-[9px] sm:text-xs font-bold">Omset</span>
              </div>
              <p className="text-sm sm:text-xl font-bold text-indigo-300 mt-0.5 sm:mt-1 truncate">{formatRupiah(totalSalesValue)}</p>
              <span className="text-[9px] sm:text-[11px] text-slate-400 truncate block">Jika habis terjual</span>
            </div>
          </>
        ) : (
          <div className="col-span-2 bg-slate-900/60 border border-slate-800 rounded-xl p-2.5 sm:p-4 flex items-center gap-2 sm:gap-3">
            <Info className="w-4 h-4 sm:w-5 sm:h-5 text-slate-500 shrink-0" />
            <p className="text-[10px] sm:text-xs text-slate-400 leading-relaxed">
              Nilai finansial aset gudang hanya dapat diakses oleh akun <strong>Pemilik Usaha</strong>.
            </p>
          </div>
        )}
      </div>

      {/* Control bar: Search, filters, Add Button */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 sm:gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="input-search-stock"
              type="text"
              placeholder="Cari bahan DTF/Sublime, kode, atau rak..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-12 py-2.5 sm:py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs px-1"
              >
                Clear
              </button>
            )}
          </div>

          {/* Action buttons (Symmetrical 2x2 grid on mobile, flex on desktop) */}
          <div className="grid grid-cols-2 sm:flex sm:items-center gap-2 shrink-0">
            {currentUser.canManageProducts && (
              <button
                id="btn-add-product"
                onClick={openNewProductModal}
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-xl shadow-sm active:scale-95 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>+ Bahan Baru</span>
              </button>
            )}

            {currentUser.canRestock && (
              <button
                id="btn-quick-restock-all"
                onClick={() => onOpenRestockModal()}
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 bg-slate-800 hover:bg-slate-750 text-emerald-400 border border-emerald-500/30 text-xs font-semibold rounded-xl active:scale-95 transition-all cursor-pointer"
              >
                <PackagePlus className="w-4 h-4 text-emerald-400" />
                <span>Restock Masuk</span>
              </button>
            )}

            {onNavigateToPurchases && (
              <button
                id="btn-goto-purchases"
                onClick={onNavigateToPurchases}
                className="hidden sm:inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                title="Lihat Mutasi Pembelian Bahan Baku"
              >
                <ShoppingBag className="w-4 h-4 text-cyan-400" />
                <span>Mutasi Beli</span>
              </button>
            )}

            {onNavigateToOpname && (
              <button
                id="btn-goto-opname"
                onClick={onNavigateToOpname}
                className="flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 text-xs font-semibold rounded-xl active:scale-95 transition-all cursor-pointer"
                title="Audit Fisik & Stok Opname Gudang"
              >
                <ClipboardCheck className="w-4 h-4 text-cyan-400" />
                <span>Stok Opname</span>
              </button>
            )}

            <button
              id="btn-open-master-data"
              onClick={() => {
                setMasterDataInitialTab('category');
                setIsMasterDataModalOpen(true);
              }}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 sm:py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 text-xs font-semibold rounded-xl active:scale-95 transition-all cursor-pointer"
              title="Kelola Master Kategori, Satuan Ukuran & Lokasi Rak"
            >
              <Settings2 className="w-4 h-4 text-cyan-400" />
              <span>Master Data</span>
            </button>
          </div>
        </div>

        {/* Category & Status Filter Chips (Horizontally Scrollable on Mobile Portrait) */}
        <div className="space-y-2 pt-2 border-t border-slate-800/80">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider shrink-0 mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3" /> Bahan:
            </span>
            <button
              onClick={() => setSelectedCategory('all')}
              className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                selectedCategory === 'all'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-xs'
                  : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
              }`}
            >
              Semua
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-colors flex items-center gap-1 cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-xs'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                }`}
              >
                <span>{cat.icon || '📦'}</span>
                <span>{cat.prefix}</span>
                <span className="hidden sm:inline">({cat.name.split(' ')[0]})</span>
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider shrink-0 mr-1">
              Status:
            </span>
            {[
              { id: 'all', label: 'Semua Status' },
              { id: 'critical', label: `⚠️ Menipis ${criticalItems > 0 ? `(${criticalItems})` : ''}`.trim() },
              { id: 'safe', label: `✅ Stok Aman (${totalItems - criticalItems})` },
            ].map((st) => (
              <button
                key={st.id}
                onClick={() => setStatusFilter(st.id as typeof statusFilter)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs font-medium transition-colors cursor-pointer ${
                  statusFilter === st.id
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-xs'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                }`}
              >
                {st.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* MOBILE PORTRAIT CARD VIEW (Optimized specifically for phone screens) */}
      <div className="md:hidden space-y-3">
        {filteredProducts.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
            {products.length === 0 ? (
              <div className="space-y-2">
                <p className="text-slate-300 font-semibold text-sm">Gudang Bahan Masih Kosong</p>
                <p className="text-slate-500">Klik tombol &quot;+ Tambah Bahan Baku Baru&quot; di atas untuk mulai mencatat stok bahan fisik Anda.</p>
              </div>
            ) : (
              'Tidak ada bahan baku yang cocok dengan pencarian Anda.'
            )}
          </div>
        ) : (
          filteredProducts.map((p) => {
            const isCritical = p.currentStock <= p.minStockAlert;
            const isEmpty = p.currentStock <= 0;
            const targetMax = Math.max(1, (p.minStockAlert || 0) * 2.5);
            const stockRatio = Math.min(100, Math.max(0, Math.round(((p.currentStock || 0) / targetMax) * 100)));

            return (
              <div
                key={p.id}
                className={`bg-slate-900 border rounded-2xl p-4 space-y-3 transition-colors ${
                  isCritical ? 'border-amber-500/40 bg-amber-500/5' : 'border-slate-800'
                }`}
              >
                {/* Header: Badges & Status */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-mono text-[10px] font-bold text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800/40">
                      {p.code}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-cyan-300 border border-slate-700 flex items-center gap-1">
                      {(() => {
                        const cat = categories.find((c) => c.id === p.category);
                        return cat ? (
                          <>
                            <span>{cat.icon || '📦'}</span>
                            <span>{cat.prefix}</span>
                          </>
                        ) : (
                          <span>{(p.category || 'ITEM').toUpperCase()}</span>
                        );
                      })()}
                    </span>
                  </div>

                  <div>
                    {isEmpty ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
                        Habis (0)
                      </span>
                    ) : isCritical ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                        <AlertTriangle className="w-3 h-3" /> Menipis
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" /> Aman
                      </span>
                    )}
                  </div>
                </div>

                {/* Name & Location */}
                <div>
                  <h4 className="text-sm font-bold text-white leading-snug">
                    {p.name}
                  </h4>
                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                    <span>📍 {p.location || 'Gudang'}</span>
                    <span>•</span>
                    <span className="text-slate-300 font-medium">Satuan: {p.unit}</span>
                  </div>
                </div>

                {/* Stock Level Progress */}
                <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Sisa Stok:</span>
                    <div className="flex items-baseline gap-1 font-mono">
                      <strong className={`text-base font-extrabold ${isCritical ? 'text-amber-400' : 'text-cyan-300'}`}>
                        {p.currentStock}
                      </strong>
                      <span className="text-[11px] text-slate-400">/ min {p.minStockAlert} {p.unit}</span>
                    </div>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isEmpty ? 'bg-rose-500' : isCritical ? 'bg-amber-400' : 'bg-emerald-400'
                      }`}
                      style={{ width: `${Math.max(5, stockRatio)}%` }}
                    />
                  </div>
                </div>

                {/* Price info */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Harga Jual Konsumen</span>
                    <span className="font-mono font-bold text-cyan-300 text-sm">
                      {formatRupiah(p.sellingPrice)}
                    </span>
                  </div>
                  {currentUser.canViewFinancials && (
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Modal (HPP)</span>
                      <span className="font-mono text-slate-300 text-xs">
                        {formatRupiah(p.costPrice)}
                      </span>
                    </div>
                  )}
                </div>

                {/* Action Buttons (Ergonomic Touch Targets for Mobile) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800/80">
                  {currentUser.canUseForProduction && (
                    <button
                      onClick={() => onOpenProductionModal(p)}
                      className="py-2.5 px-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all min-h-[42px]"
                    >
                      <Layers className="w-4 h-4 text-blue-400" />
                      <span>Produksi</span>
                    </button>
                  )}

                  {currentUser.canCreateSalesInvoice && (
                    <button
                      onClick={() => onOpenSaleModal(p)}
                      className="py-2.5 px-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all min-h-[42px]"
                    >
                      <ShoppingCart className="w-4 h-4 text-emerald-400" />
                      <span>Jual</span>
                    </button>
                  )}

                  {currentUser.canRestock && (
                    <button
                      onClick={() => onOpenRestockModal(p)}
                      className="py-2.5 px-2 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all min-h-[42px]"
                    >
                      <PackagePlus className="w-4 h-4 text-amber-400" />
                      <span>+Masuk</span>
                    </button>
                  )}

                  {currentUser.canManageProducts && (
                    <button
                      onClick={() => openEditProductModal(p)}
                      className="py-2.5 px-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-all min-h-[42px]"
                    >
                      <Edit3 className="w-4 h-4 text-slate-400" />
                      <span>Edit</span>
                    </button>
                  )}

                  {/* Delete Action: Active when canDeleteProducts is permitted */}
                  {canDeleteProduct ? (
                    <button
                      id={`btn-delete-mobile-${p.id}`}
                      onClick={() => {
                        setProductToDelete(p);
                        setDeleteProductError(null);
                      }}
                      title="Hapus Bahan Baku (Izin Hapus Aktif)"
                      className="py-2.5 px-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 transition-all min-h-[42px]"
                    >
                      <Trash2 className="w-4 h-4 text-rose-400" />
                      <span>Hapus</span>
                    </button>
                  ) : (
                    <button
                      disabled
                      title="Aksi hapus tidak diizinkan untuk akun ini (Hubungi Admin / Atur di Manajemen Hak Akses)"
                      className="py-2.5 px-2 bg-slate-900 border border-slate-800/80 text-slate-600 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 cursor-not-allowed opacity-40 min-h-[42px] select-none"
                    >
                      <Trash2 className="w-4 h-4 text-slate-600" />
                      <span>Hapus</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* DESKTOP / TABLET WIDE TABLE (Hidden on Mobile) */}
      <div className="hidden md:block bg-slate-900 border border-slate-800 rounded-2xl shadow-sm overflow-hidden">
        {/* Table Top Utility & Horizontal Navigation Bar */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/70 border-b border-slate-800/80 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="font-medium text-slate-300">
              Menampilkan {filteredProducts.length} {statusFilter === 'critical' ? 'bahan baku menipis' : statusFilter === 'safe' ? 'bahan baku aman' : 'bahan baku'}
            </span>
            {(statusFilter !== 'all' || selectedCategory !== 'all' || searchQuery) && (
              <>
                <span className="text-slate-600">•</span>
                <button
                  onClick={() => {
                    setStatusFilter('all');
                    setSelectedCategory('all');
                    setSearchQuery('');
                  }}
                  className="text-[11px] text-cyan-400 hover:text-cyan-300 underline font-medium cursor-pointer"
                >
                  Reset Filter
                </button>
              </>
            )}
            <span className="text-slate-600">•</span>
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Pin className="w-3 h-3 text-cyan-400" />
              Kolom Aksi terkunci di sisi kanan
            </span>
          </div>

          {/* Quick Horizontal Scroll Controls */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-400 hidden lg:inline mr-1">Geser tabel:</span>
            <button
              onClick={handleScrollLeft}
              disabled={!canScrollLeft}
              title="Geser tabel ke kiri"
              className="px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors border border-slate-700/60 shadow-2xs cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5 text-cyan-400" />
              <span>Kiri</span>
            </button>
            <button
              onClick={handleScrollRight}
              disabled={!canScrollRight}
              title="Geser tabel ke kanan"
              className="px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1 transition-colors border border-slate-700/60 shadow-2xs cursor-pointer"
            >
              <span>Kanan</span>
              <ChevronRight className="w-3.5 h-3.5 text-cyan-400" />
            </button>
          </div>
        </div>

        {/* Scrollable Container with Max Height & Visible Scrollbar */}
        <div 
          ref={tableContainerRef}
          className="overflow-auto max-h-[calc(100vh-270px)] min-h-[380px] scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900"
        >
          <table className="w-full min-w-[860px] text-left text-xs sm:text-sm border-collapse">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] sm:text-[11px] tracking-wider sticky top-0 z-20">
              <tr>
                <th className="py-3 px-3.5 min-w-[170px]">Kode & Nama Bahan</th>
                <th className="py-3 px-2 min-w-[85px]">Kategori</th>
                <th className="py-3 px-2 min-w-[90px]">Status Stok</th>
                <th className="py-3 px-2 min-w-[95px]">Sisa / Min</th>
                {currentUser.canViewFinancials && (
                  <th className="py-3 px-2 text-right min-w-[105px]">Harga Modal</th>
                )}
                <th className="py-3 px-2 text-right min-w-[105px]">Harga Jual</th>
                <th className="py-3 px-2 min-w-[115px]">Lokasi Gudang</th>
                <th className="py-3 px-3 text-right min-w-[155px] sticky right-0 z-20 bg-slate-950 border-b border-slate-800 shadow-[-10px_0_15px_-3px_rgba(0,0,0,0.6)]">
                  Aksi Cepat
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={currentUser.canViewFinancials ? 8 : 7} className="py-16 text-center text-slate-400 text-sm">
                    {products.length === 0 ? (
                      <div className="max-w-md mx-auto space-y-2">
                        <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 border border-slate-700 flex items-center justify-center text-xl text-slate-300">
                          📦
                        </div>
                        <p className="text-slate-200 font-semibold text-base">Gudang Bahan Masih Kosong</p>
                        <p className="text-slate-400 text-xs">
                          Seluruh data dummy telah dihapus. Klik tombol <span className="text-cyan-400 font-medium">+ Tambah Bahan Baku Baru</span> di atas untuk mulai memasukkan stok gudang nyata Anda.
                        </p>
                      </div>
                    ) : (
                      'Tidak ada bahan baku yang cocok dengan pencarian atau filter Anda.'
                    )}
                  </td>
                </tr>
              ) : (
                filteredProducts.map((p) => {
                  const isCritical = p.currentStock <= p.minStockAlert;
                  const isEmpty = p.currentStock <= 0;
                  const targetMax = Math.max(1, (p.minStockAlert || 0) * 2.5);
                  const stockRatio = Math.min(100, Math.max(0, Math.round(((p.currentStock || 0) / targetMax) * 100)));
                  const cat = categories.find((c) => c.id === p.category);

                  return (
                    <tr 
                      key={p.id}
                      className={`group hover:bg-slate-800/40 transition-colors ${
                        isCritical ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      {/* Name & Code */}
                      <td className="py-3 px-3.5">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-semibold text-slate-100 text-xs sm:text-sm leading-snug">
                            {p.name}
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-mono text-[10px] font-bold text-cyan-400 bg-cyan-950/70 border border-cyan-800/40 px-1.5 py-0.5 rounded tracking-wide whitespace-nowrap shadow-2xs">
                              {p.code}
                            </span>
                            <span className="text-[10px] text-slate-400 whitespace-nowrap">
                              • {p.unit}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Category */}
                      <td className="py-3 px-2 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-800/90 text-cyan-300 border border-slate-700/80 whitespace-nowrap shadow-2xs">
                          <span>{cat ? cat.icon : '📦'}</span>
                          <span>{cat ? cat.prefix || cat.name.split(' ')[0] : p.category}</span>
                        </span>
                      </td>

                      {/* Status badge */}
                      <td className="py-3 px-2 whitespace-nowrap">
                        {isEmpty ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/15 text-rose-400 border border-rose-500/30 shadow-2xs animate-pulse">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-400 shrink-0" />
                            Habis (0)
                          </span>
                        ) : isCritical ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-2xs">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            Menipis
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 shadow-2xs">
                            <CheckCircle2 className="w-3 h-3 shrink-0" />
                            Aman
                          </span>
                        )}
                      </td>

                      {/* Stock Qty & Progress */}
                      <td className="py-3 px-2 whitespace-nowrap">
                        <div className="flex items-baseline gap-1">
                          <span className={`text-xs sm:text-sm font-extrabold tabular-nums ${isEmpty ? 'text-rose-400' : isCritical ? 'text-amber-300' : 'text-slate-100'}`}>
                            {p.currentStock}
                          </span>
                          <span className="text-[10px] text-slate-400 tabular-nums">/ min {p.minStockAlert}</span>
                        </div>
                        <div className="w-16 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-300 ${
                              isEmpty ? 'bg-rose-500' : isCritical ? 'bg-amber-400' : 'bg-emerald-400'
                            }`}
                            style={{ width: `${Math.max(6, stockRatio)}%` }}
                          />
                        </div>
                      </td>

                      {/* Cost price (modal) */}
                      {currentUser.canViewFinancials && (
                        <td className="py-3 px-2 text-right font-mono tabular-nums text-slate-300 text-xs font-medium whitespace-nowrap">
                          {formatRupiah(p.costPrice)}
                        </td>
                      )}

                      {/* Selling price */}
                      <td className="py-3 px-2 text-right font-mono tabular-nums text-cyan-300 text-xs font-bold whitespace-nowrap">
                        {formatRupiah(p.sellingPrice)}
                      </td>

                      {/* Location */}
                      <td className="py-3 px-2 whitespace-nowrap">
                        <div className="flex items-center gap-1 text-slate-300 text-xs">
                          <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
                          <span className="truncate max-w-[125px]">{p.location || 'Gudang Utama'}</span>
                        </div>
                      </td>

                      {/* Quick Action buttons - Sticky on the Right */}
                      <td className="py-3 px-3 text-right whitespace-nowrap sticky right-0 z-10 bg-slate-900/95 group-hover:bg-slate-850/95 backdrop-blur-xs transition-colors shadow-[-10px_0_15px_-3px_rgba(0,0,0,0.6)]">
                        <div className="inline-flex items-center justify-end gap-1">
                          {/* Pakai Produksi */}
                          {currentUser.canUseForProduction && (
                            <button
                              id={`btn-use-prod-${p.id}`}
                              onClick={() => onOpenProductionModal(p)}
                              title="Catat Pemakaian untuk Produksi Sablon Sendiri"
                              className="px-2 py-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs cursor-pointer"
                            >
                              <Layers className="w-3 h-3 text-blue-400" />
                              <span>Produksi</span>
                            </button>
                          )}

                          {/* Jual Konsumen */}
                          {currentUser.canCreateSalesInvoice && (
                            <button
                              id={`btn-sell-${p.id}`}
                              onClick={() => onOpenSaleModal(p)}
                              title="Jual Bahan ke Konsumen & Terbitkan Invoice"
                              className="px-2 py-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs cursor-pointer"
                            >
                              <ShoppingCart className="w-3 h-3 text-emerald-400" />
                              <span>Jual</span>
                            </button>
                          )}

                          {/* Restock */}
                          {currentUser.canRestock && (
                            <button
                              id={`btn-restock-${p.id}`}
                              onClick={() => onOpenRestockModal(p)}
                              title="Tambah Stok Masuk Supplier"
                              className="px-2 py-1 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1 active:scale-95 transition-all shadow-2xs cursor-pointer"
                            >
                              <PackagePlus className="w-3 h-3 text-amber-400" />
                              <span>Restok</span>
                            </button>
                          )}

                          {/* Edit Product */}
                          {currentUser.canManageProducts && (
                            <button
                              id={`btn-edit-prod-${p.id}`}
                              onClick={() => openEditProductModal(p)}
                              title="Edit Data Bahan & Batas Stok Minimum"
                              className="p-1 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg border border-transparent hover:border-slate-700 transition-colors cursor-pointer"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Delete Product (Active when canDeleteProducts is permitted) */}
                          {canDeleteProduct ? (
                            <button
                              id={`btn-delete-prod-${p.id}`}
                              onClick={() => {
                                setProductToDelete(p);
                                setDeleteProductError(null);
                              }}
                              title="Hapus Bahan Baku (Izin Hapus Aktif)"
                              className="p-1 text-rose-400 hover:text-white hover:bg-rose-600 rounded-lg border border-rose-500/30 hover:border-rose-600 transition-colors cursor-pointer shadow-2xs"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              disabled
                              title="Aksi Hapus tidak diizinkan untuk akun ini (Atur di Manajemen Hak Akses)"
                              className="p-1 text-slate-700 rounded-lg border border-transparent cursor-not-allowed opacity-30 select-none"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Add / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl text-slate-100 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Boxes className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-base text-white">
                  {editingProduct ? 'Edit Bahan Baku DTF / Sublime' : 'Tambah Bahan Baku Baru'}
                </h3>
              </div>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">Kode Bahan</label>
                    {isAutoCode ? (
                      <span className="text-[10px] text-cyan-400 bg-cyan-950/80 px-1.5 py-0.5 rounded border border-cyan-800/40 flex items-center gap-1 font-mono">
                        <Sparkles className="w-2.5 h-2.5" /> Otomatis
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={handleRegenerateCode}
                        className="text-[10px] text-cyan-400 hover:text-cyan-300 underline flex items-center gap-1"
                      >
                        <RotateCcw className="w-2.5 h-2.5" /> Auto
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={formCode}
                      onChange={(e) => {
                        setFormCode(e.target.value);
                        setIsAutoCode(false);
                      }}
                      placeholder="misal: DTF-016"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono font-bold text-white focus:outline-none focus:border-cyan-500 pr-8"
                    />
                    <button
                      type="button"
                      onClick={handleRegenerateCode}
                      title="Generate ulang kode sesuai prefix kategori"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-400 p-1"
                    >
                      <RotateCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">Kategori</label>
                    <button
                      type="button"
                      onClick={() => {
                        setMasterDataInitialTab('category');
                        setIsMasterDataModalOpen(true);
                      }}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                    >
                      <Settings2 className="w-2.5 h-2.5" />
                      <span>+ Kelola</span>
                    </button>
                  </div>
                  <select
                    value={formCategory}
                    onChange={(e) => handleCategoryChange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon || '📦'} {c.name} ({c.prefix})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Nama Bahan Baku</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="misal: Tinta DTF Premium White (1 Liter)"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-slate-300">Satuan</label>
                    <button
                      type="button"
                      onClick={() => {
                        setMasterDataInitialTab('unit');
                        setIsMasterDataModalOpen(true);
                      }}
                      className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                    >
                      <Settings2 className="w-2.5 h-2.5" />
                      <span>+ Kelola</span>
                    </button>
                  </div>
                  <select
                    value={formUnit}
                    onChange={(e) => setFormUnit(e.target.value)}
                    className="w-full px-2.5 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                  >
                    {units.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Stok Sekarang</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    readOnly={Boolean(editingProduct && !isSpv)}
                    tabIndex={editingProduct && !isSpv ? -1 : 0}
                    value={formStock}
                    onChange={(e) => {
                      if (!editingProduct || isSpv) {
                        setFormStock(Number(e.target.value));
                      }
                    }}
                    onKeyDown={(e) => {
                      if (editingProduct && !isSpv && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
                        e.preventDefault();
                      }
                    }}
                    className={`w-full px-3 py-2 rounded-lg text-xs font-semibold focus:outline-none transition-colors ${
                      editingProduct && !isSpv
                        ? 'bg-slate-950/70 border border-slate-800 text-slate-400 cursor-not-allowed select-none'
                        : 'bg-slate-950 border border-slate-800 text-white focus:border-cyan-500'
                    }`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-amber-300 mb-1">Batas Minimum</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formMinStock}
                    onChange={(e) => setFormMinStock(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-amber-500/40 rounded-lg text-xs text-amber-300 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Harga Beli / Modal (HPP)</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formCostPrice}
                    onChange={(e) => setFormCostPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-cyan-300 mb-1">Harga Jual ke Konsumen</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={formSellingPrice}
                    onChange={(e) => setFormSellingPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-cyan-300 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-medium text-slate-300">Lokasi Rak / Penyimpanan</label>
                  <button
                    type="button"
                    onClick={() => {
                      setMasterDataInitialTab('location');
                      setIsMasterDataModalOpen(true);
                    }}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300 flex items-center gap-0.5"
                  >
                    <Settings2 className="w-2.5 h-2.5" />
                    <span>+ Kelola Lokasi</span>
                  </button>
                </div>
                <div className="relative">
                  <input
                    type="text"
                    list="locations-datalist"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    placeholder="Pilih atau ketik lokasi (misal: Gudang Utama - Rak A1)"
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                  <datalist id="locations-datalist">
                    {locations.map((loc) => (
                      <option key={loc} value={loc} />
                    ))}
                  </datalist>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  Pilih dari {locations.length} lokasi master atau ketik lokasi baru.
                </p>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Deskripsi & Catatan Spesifikasi</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="misal: Tinta putih anti endap, cocok untuk head Epson XP600 / i3200"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                {editingProduct && canDeleteProduct ? (
                  <button
                    type="button"
                    onClick={() => {
                      setProductToDelete(editingProduct);
                      setDeleteProductError(null);
                    }}
                    className="px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/40 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95"
                    title="Hapus Bahan Ini dari Master Inventaris Gudang"
                  >
                    <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                    <span>Hapus Bahan</span>
                  </button>
                ) : (
                  <div />
                )}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsProductModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold transition-colors"
                  >
                    Batal
                  </button>
                  <button
                    id="btn-submit-save-product"
                    type="submit"
                    className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-colors"
                  >
                    {editingProduct ? 'Simpan Perubahan' : 'Tambah ke Gudang'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL KONFIRMASI HAPUS BAHAN BAKU (KHUSUS SPV & OWNER) */}
      {productToDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs overflow-y-auto">
          <div className="bg-slate-900 border border-rose-500/40 rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl text-slate-100 my-8 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-white">Hapus Bahan Baku</h3>
                <p className="text-xs text-rose-300">
                  Otorisasi Izin Hapus: <span className="font-semibold text-white">{currentUser.name}</span> ({currentUser.roleTitle})
                </p>
              </div>
            </div>

            <div className="my-4 space-y-3">
              {deleteProductError && (
                <div className="p-3 bg-rose-500/20 border border-rose-500/50 rounded-xl text-xs text-rose-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{deleteProductError}</span>
                </div>
              )}

              <p className="text-xs text-slate-300 leading-relaxed">
                Apakah Anda yakin ingin menghapus data bahan baku berikut dari master gudang?
              </p>

              <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5 text-xs">
                <div className="flex justify-between items-start">
                  <span className="text-slate-400">Nama Bahan:</span>
                  <span className="font-bold text-white text-right max-w-[220px]">{productToDelete.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Kode Bahan:</span>
                  <span className="font-mono font-bold text-cyan-300">{productToDelete.code}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Kategori / Satuan:</span>
                  <span className="text-slate-200 capitalize">{productToDelete.category} • {productToDelete.unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Lokasi Rak:</span>
                  <span className="text-slate-300">{productToDelete.location}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-800 font-bold">
                  <span className="text-slate-300">Sisa Stok Fisik:</span>
                  <span className={`font-mono ${productToDelete.currentStock > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {productToDelete.currentStock} {productToDelete.unit}
                  </span>
                </div>
              </div>

              {productToDelete.currentStock > 0 && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-2 text-[11px] text-amber-300">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    Perhatian: Bahan ini masih memiliki stok tercatat sebanyak <strong>{productToDelete.currentStock} {productToDelete.unit}</strong>. Menghapusnya akan membuang catatan stok aktif ini.
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                disabled={isDeletingProduct}
                onClick={() => {
                  setProductToDelete(null);
                  setDeleteProductError(null);
                }}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={isDeletingProduct}
                onClick={handleConfirmDelete}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-rose-900/30 transition-all active:scale-95 disabled:opacity-50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{isDeletingProduct ? 'Menghapus...' : 'Ya, Hapus Bahan'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Success Toast */}
      {deleteSuccessToast && (
        <div className="fixed top-4 right-4 z-70 bg-emerald-950 border border-emerald-500/50 text-emerald-200 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 text-xs animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{deleteSuccessToast}</span>
          <button
            type="button"
            onClick={() => setDeleteSuccessToast(null)}
            className="ml-2 text-emerald-400 hover:text-white p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Master Data Customization Modal */}
      {isMasterDataModalOpen && (
        <MasterDataModal
          isOpen={isMasterDataModalOpen}
          onClose={() => setIsMasterDataModalOpen(false)}
          categories={categories}
          units={units}
          locations={locations}
          suppliers={suppliers}
          customers={customers}
          products={products}
          invoices={invoices}
          movements={movements}
          onAddCategory={onAddCategory}
          onDeleteCategory={onDeleteCategory}
          onAddUnit={onAddUnit}
          onDeleteUnit={onDeleteUnit}
          onAddLocation={onAddLocation}
          onDeleteLocation={onDeleteLocation}
          onAddSupplier={onAddSupplier}
          onDeleteSupplier={onDeleteSupplier}
          onAddCustomer={onAddCustomer}
          onDeleteCustomer={onDeleteCustomer}
          onUpdateCategory={onUpdateCategory}
          onUpdateUnit={onUpdateUnit}
          onUpdateLocation={onUpdateLocation}
          onUpdateSupplier={onUpdateSupplier}
          onUpdateCustomer={onUpdateCustomer}
          divisions={divisions}
          onAddDivision={onAddDivision}
          onDeleteDivision={onDeleteDivision}
          onUpdateDivision={onUpdateDivision}
          initialTab={masterDataInitialTab}
        />
      )}
    </div>
  );
};
