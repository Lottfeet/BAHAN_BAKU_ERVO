import React, { useState, useMemo } from 'react';
import { 
  ShoppingBag, 
  Search, 
  Download, 
  Printer, 
  PackagePlus, 
  Building2, 
  Calendar, 
  FileText, 
  Eye, 
  X, 
  Boxes, 
  Coins, 
  Truck, 
  CheckCircle2,
  Filter,
  Settings2,
  FileDown,
  Loader2,
  Edit3,
  Trash2,
  AlertTriangle,
  AlertCircle,
  ShieldAlert
} from 'lucide-react';
import { Product, StockMovement, User, CategoryItem, SupplierItem } from '../types';
import { formatRupiah } from '../utils/helpers';
import { exportElementToPdf, printElementDirect } from '../utils/pdfExport';

interface PurchasesViewProps {
  movements: StockMovement[];
  products: Product[];
  currentUser: User;
  categories?: CategoryItem[];
  suppliers?: SupplierItem[];
  onOpenMasterData?: (tab?: 'category' | 'unit' | 'location' | 'supplier') => void;
  onOpenRestockModal: () => void;
  onEditPurchase?: (
    movementId: string,
    updatedData: {
      quantity: number;
      unitPrice: number;
      supplierName: string;
      referenceNo: string;
      date: string;
      notes: string;
    },
    operatorUser?: User
  ) => { success: boolean; message?: string };
  onDeletePurchase?: (
    movementId: string,
    operatorUser?: User
  ) => { success: boolean; message?: string };
}

export const PurchasesView: React.FC<PurchasesViewProps> = ({
  movements,
  products,
  currentUser,
  categories,
  suppliers = [],
  onOpenMasterData,
  onOpenRestockModal,
  onEditPurchase,
  onDeletePurchase,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [timeFilter, setTimeFilter] = useState<'7d' | '30d' | 'all'>('all');
  const [selectedSupplier, setSelectedSupplier] = useState<string>('all');
  const [selectedReceipt, setSelectedReceipt] = useState<StockMovement | null>(null);
  const [showRecapPreview, setShowRecapPreview] = useState(false);
  const [isSavingRecapPdf, setIsSavingRecapPdf] = useState(false);
  const [isSavingReceiptPdf, setIsSavingReceiptPdf] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [receiptViewMode, setReceiptViewMode] = useState<'card' | 'official'>('official');

  // Hak Akses Granular (dikelola dari Pengaturan / AccessControl)
  const canEditPurchases = currentUser.canEditPurchases !== undefined
    ? Boolean(currentUser.canEditPurchases)
    : (currentUser.role === 'owner' || currentUser.role === 'warehouse_admin');

  // Hak Akses: Aksi Hapus Mutasi Pembelian HANYA untuk SPV (Supervisor Gudang) dan Owner (Pemilik)
  const canDeletePurchases = currentUser.role === 'owner' || currentUser.role === 'warehouse_admin';

  // Edit Purchase State & Form
  const [editingMovement, setEditingMovement] = useState<StockMovement | null>(null);
  const [editFormData, setEditFormData] = useState<{
    referenceNo: string;
    date: string;
    supplierName: string;
    quantity: number;
    unitPrice: number;
    notes: string;
  }>({
    referenceNo: '',
    date: '',
    supplierName: '',
    quantity: 0,
    unitPrice: 0,
    notes: '',
  });
  const [editError, setEditError] = useState<string | null>(null);
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Delete Purchase Confirmation State
  const [deletingMovement, setDeletingMovement] = useState<StockMovement | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Notification Toast Feedback
  const [feedbackToast, setFeedbackToast] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const showToast = (type: 'success' | 'error', message: string) => {
    setFeedbackToast({ type, message });
    setTimeout(() => {
      setFeedbackToast(null);
    }, 4500);
  };

  const handleOpenEdit = (m: StockMovement) => {
    if (!canEditPurchases) {
      showToast('error', 'Aksi ditolak: Akun Anda tidak memiliki izin untuk mengedit mutasi pembelian.');
      return;
    }
    const supName = m.supplierName || (m.notes.includes('—') ? m.notes.split('—')[0].replace('Restock dari ', '').trim() : '');
    const cleanNotes = m.notes.includes('—') ? m.notes.split('—').slice(1).join('—').trim() : m.notes;

    setEditingMovement(m);
    setEditFormData({
      referenceNo: m.referenceNo,
      date: m.date,
      supplierName: supName || 'Supplier Umum',
      quantity: m.quantity,
      unitPrice: m.unitPrice || 0,
      notes: cleanNotes || '',
    });
    setEditError(null);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMovement || !onEditPurchase) return;

    if (!editFormData.referenceNo.trim()) {
      setEditError('Nomor referensi / PO tidak boleh kosong.');
      return;
    }
    if (editFormData.quantity <= 0) {
      setEditError('Kuantiti pembelian harus lebih besar dari 0.');
      return;
    }
    if (editFormData.unitPrice < 0) {
      setEditError('Harga satuan (HPP) tidak boleh negatif.');
      return;
    }

    setIsSavingEdit(true);
    try {
      const res = onEditPurchase(editingMovement.id, {
        referenceNo: editFormData.referenceNo.trim(),
        date: editFormData.date,
        supplierName: editFormData.supplierName.trim() || 'Supplier Umum',
        quantity: Number(editFormData.quantity),
        unitPrice: Number(editFormData.unitPrice),
        notes: editFormData.notes.trim() ? `Restock dari ${editFormData.supplierName.trim() || 'Supplier Umum'} — ${editFormData.notes.trim()}` : `Restock dari ${editFormData.supplierName.trim() || 'Supplier Umum'}`,
      }, currentUser);

      if (res.success) {
        setEditingMovement(null);
        showToast('success', res.message || 'Mutasi pembelian berhasil diperbarui.');
      } else {
        setEditError(res.message || 'Gagal memperbarui mutasi pembelian.');
      }
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleOpenDelete = (m: StockMovement) => {
    if (!canDeletePurchases) {
      showToast('error', 'Aksi ditolak: Akun Anda tidak memiliki izin untuk menghapus mutasi pembelian.');
      return;
    }
    setDeletingMovement(m);
    setDeleteError(null);
  };

  const handleConfirmDelete = () => {
    if (!deletingMovement || !onDeletePurchase) return;

    setIsDeleting(true);
    try {
      const res = onDeletePurchase(deletingMovement.id, currentUser);
      if (res.success) {
        setDeletingMovement(null);
        showToast('success', res.message || 'Mutasi pembelian berhasil dihapus dan stok telah dikembalikan.');
      } else {
        setDeleteError(res.message || 'Gagal menghapus mutasi pembelian.');
      }
    } finally {
      setIsDeleting(false);
    }
  };

  // Human readable label for active time filter
  const dateRangeLabel = useMemo(() => {
    if (timeFilter === '7d') return '7 Hari Terakhir';
    if (timeFilter === '30d') return '30 Hari Terakhir (Bulan Ini)';
    return 'Seluruh Riwayat Pengadaan';
  }, [timeFilter]);

  // Filter only restock movements (purchases)
  const purchaseMovements = useMemo(() => {
    return movements.filter((m) => m.type === 'restock');
  }, [movements]);

  // Unique list of suppliers
  const supplierList = useMemo(() => {
    const set = new Set<string>();
    // Add registered suppliers from master data
    suppliers.forEach((s) => set.add(s.name));
    // Also include any suppliers recorded in movements
    purchaseMovements.forEach((m) => {
      if (m.supplierName) {
        set.add(m.supplierName);
      } else if (m.notes.includes('Supplier') || m.notes.includes('dari ')) {
        const parts = m.notes.split('—')[0].replace('Restock dari ', '').trim();
        if (parts) set.add(parts);
      }
    });
    return Array.from(set);
  }, [suppliers, purchaseMovements]);

  // Filtered purchases
  const filteredPurchases = useMemo(() => {
    return purchaseMovements.filter((p) => {
      // Search
      const q = searchQuery.toLowerCase();
      const matchSearch =
        !q ||
        p.productName.toLowerCase().includes(q) ||
        p.productCode.toLowerCase().includes(q) ||
        p.referenceNo.toLowerCase().includes(q) ||
        (p.supplierName && p.supplierName.toLowerCase().includes(q)) ||
        p.notes.toLowerCase().includes(q);

      // Category
      const matchCategory = selectedCategory === 'all' || p.category === selectedCategory;

      // Supplier
      const supplierName = p.supplierName || (p.notes.split('—')[0].replace('Restock dari ', '').trim());
      const matchSupplier = selectedSupplier === 'all' || supplierName === selectedSupplier;

      // Time Filter
      let matchTime = true;
      if (timeFilter !== 'all') {
        const now = new Date();
        const itemDate = new Date(p.date.replace(' ', 'T'));
        const diffDays = (now.getTime() - itemDate.getTime()) / (1000 * 3600 * 24);
        if (timeFilter === '7d') matchTime = diffDays <= 7;
        if (timeFilter === '30d') matchTime = diffDays <= 30;
      }

      return matchSearch && matchCategory && matchSupplier && matchTime;
    });
  }, [purchaseMovements, searchQuery, selectedCategory, selectedSupplier, timeFilter]);

  // Aggregate Metrics
  const totalPurchaseValue = useMemo(() => {
    return filteredPurchases.reduce((acc, p) => {
      if (p.totalValue) return acc + p.totalValue;
      const prod = products.find((pr) => pr.id === p.productId);
      const hpp = prod?.costPrice || 0;
      return acc + hpp * p.quantity;
    }, 0);
  }, [filteredPurchases, products]);

  const totalQuantityReceived = useMemo(() => {
    return filteredPurchases.reduce((acc, p) => acc + p.quantity, 0);
  }, [filteredPurchases]);

  const uniqueSuppliersCount = useMemo(() => {
    const set = new Set<string>();
    filteredPurchases.forEach((p) => {
      const s = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim();
      if (s) set.add(s);
    });
    return set.size;
  }, [filteredPurchases]);

  // Aggregated data per supplier for recap summary
  const supplierSummary = useMemo(() => {
    const map = new Map<string, { count: number; qty: number; total: number }>();
    filteredPurchases.forEach((p) => {
      const s = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim() || 'Supplier Umum';
      const prod = products.find((pr) => pr.id === p.productId);
      const hpp = p.unitPrice || prod?.costPrice || 0;
      const total = p.totalValue || hpp * p.quantity;
      const cur = map.get(s) || { count: 0, qty: 0, total: 0 };
      map.set(s, {
        count: cur.count + 1,
        qty: cur.qty + p.quantity,
        total: cur.total + total,
      });
    });
    return Array.from(map.entries()).map(([name, data]) => ({ name, ...data }));
  }, [filteredPurchases, products]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'No',
      'Tanggal & Jam',
      'No. Dokumen PO',
      'Nama Supplier',
      'Kode Bahan',
      'Nama Bahan',
      'Kategori',
      'Jumlah Masuk',
      'Satuan',
      'Harga Beli Satuan (HPP)',
      'Total Nilai Pembelian',
      'Stok Awal',
      'Stok Akhir',
      'Penerima Gudang',
      'Catatan',
    ];

    const rows = filteredPurchases.map((p, idx) => {
      const prod = products.find((pr) => pr.id === p.productId);
      const hpp = p.unitPrice || prod?.costPrice || 0;
      const total = p.totalValue || hpp * p.quantity;
      const supplier = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim();

      return [
        idx + 1,
        `"${p.date}"`,
        `"${p.referenceNo}"`,
        `"${supplier}"`,
        `"${p.productCode}"`,
        `"${p.productName}"`,
        `"${(p.category || '').toUpperCase()}"`,
        p.quantity,
        `"${p.unit}"`,
        hpp,
        total,
        p.previousStock,
        p.finalStock,
        `"${p.performedBy.userName}"`,
        `"${p.notes.replace(/"/g, '""')}"`,
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `mutasi_pembelian_bahan_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleSaveRecapPdf = async () => {
    setIsSavingRecapPdf(true);
    setSaveSuccessMsg(null);
    try {
      const supplierSuffix = selectedSupplier === 'all' ? 'Semua_Supplier' : selectedSupplier.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Rekap_Pembelian_Bahan_${supplierSuffix}_${new Date().toISOString().slice(0, 10)}.pdf`;
      const success = await exportElementToPdf('printable-purchases-recap', filename);
      if (success) {
        setSaveSuccessMsg('File PDF Rekapitulasi Pembelian Bahan berhasil disimpan & diunduh!');
        setTimeout(() => setSaveSuccessMsg(null), 4500);
      }
    } finally {
      setIsSavingRecapPdf(false);
    }
  };

  const handlePrintRecap = () => {
    printElementDirect('printable-purchases-recap');
  };

  const handleSaveReceiptPdf = async () => {
    if (!selectedReceipt) return;
    setIsSavingReceiptPdf(true);
    setSaveSuccessMsg(null);
    try {
      const refSuffix = selectedReceipt.referenceNo.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Bukti_Masuk_PO_${refSuffix}_${selectedReceipt.date}.pdf`;
      const success = await exportElementToPdf('printable-purchase-receipt', filename);
      if (success) {
        setSaveSuccessMsg('File PDF Bukti Masuk PO berhasil disimpan & diunduh!');
        setTimeout(() => setSaveSuccessMsg(null), 4500);
      }
    } finally {
      setIsSavingReceiptPdf(false);
    }
  };

  const handlePrintReceipt = () => {
    printElementDirect('printable-purchase-receipt');
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base sm:text-lg font-bold text-white">Mutasi Pembelian Bahan Baku</h2>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Restok Masuk
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Pencatatan riwayat pengadaan bahan baku DTF & Sublimasi dari supplier, nomor purchase order (PO), kalkulasi harga modal (HPP), serta mutasi stok masuk gudang secara real-time.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
          {currentUser.canRestock && (
            <button
              id="btn-add-purchase-restock"
              onClick={onOpenRestockModal}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors shadow-sm"
            >
              <PackagePlus className="w-4 h-4" />
              <span>+ Catat Pembelian Bahan</span>
            </button>
          )}

          {onOpenMasterData && (
            <button
              id="btn-manage-suppliers-purchase"
              onClick={() => onOpenMasterData('supplier')}
              className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-cyan-300 border border-cyan-500/30 rounded-xl text-xs font-semibold transition-colors"
              title="Kelola Master Data Suplier"
            >
              <Truck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Kelola Suplier</span>
            </button>
          )}

          <button
            onClick={handleExportCSV}
            title="Download CSV"
            className="flex items-center justify-center gap-1 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 rounded-xl text-xs font-semibold transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            id="btn-print-purchases-recap"
            onClick={() => setShowRecapPreview(true)}
            title="Cetak & Simpan PDF Rekapitulasi Pembelian Bahan Baku"
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-colors shadow-xs active:scale-95 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-cyan-400" />
            <span>Cetak / PDF Rekap</span>
          </button>
        </div>
      </div>

      {/* KPI Metrics Cards (2x2 on Mobile Portrait) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Total Belanja Bahan</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Coins className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-emerald-400 mt-1.5 truncate">
            {currentUser.canViewFinancials ? formatRupiah(totalPurchaseValue) : 'Rp ••••••••'}
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-1 block truncate">
            Dari {filteredPurchases.length} kali pengadaan
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Total Unit Masuk</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-cyan-500/20 text-cyan-400">
              <Boxes className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-cyan-300 mt-1.5 truncate">
            {totalQuantityReceived} <span className="text-xs sm:text-sm font-normal text-slate-400">Item</span>
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-1 block truncate">
            Penambahan fisik stok gudang
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Pemasok Aktif</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-indigo-500/20 text-indigo-400">
              <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-indigo-300 mt-1.5">
            {uniqueSuppliersCount} <span className="text-xs sm:text-sm font-normal text-slate-400">Vendor</span>
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-1 block truncate">
            Mitra suplai digital printing
          </span>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] sm:text-xs font-medium text-slate-400">Rata-rata per PO</span>
            <div className="p-1.5 sm:p-2 rounded-lg bg-blue-500/20 text-blue-400">
              <Truck className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
          </div>
          <p className="text-lg sm:text-2xl font-bold text-blue-300 mt-1.5 truncate">
            {currentUser.canViewFinancials
              ? formatRupiah(filteredPurchases.length > 0 ? Math.round(totalPurchaseValue / filteredPurchases.length) : 0)
              : 'Rp ••••••••'}
          </p>
          <span className="text-[10px] sm:text-[11px] text-slate-400 mt-1 block truncate">
            Nilai rata-rata nota pembelian
          </span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari nomor PO, nama bahan baku, supplier, atau kode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Supplier Dropdown */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 shrink-0 hidden sm:inline">Pemasok:</span>
            <select
              value={selectedSupplier}
              onChange={(e) => setSelectedSupplier(e.target.value)}
              className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
            >
              <option value="all">Semua Supplier</option>
              {supplierList.map((sup) => (
                <option key={sup} value={sup}>
                  {sup}
                </option>
              ))}
            </select>

            {/* Time Filter */}
            <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setTimeFilter('7d')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  timeFilter === '7d' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                7 Hari
              </button>
              <button
                onClick={() => setTimeFilter('30d')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  timeFilter === '30d' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Bulan Ini
              </button>
              <button
                onClick={() => setTimeFilter('all')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  timeFilter === 'all' ? 'bg-cyan-600 text-white font-semibold' : 'text-slate-400 hover:text-white'
                }`}
              >
                Semua
              </button>
            </div>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1 border-t border-slate-850">
          <span className="text-[11px] text-slate-400 mr-1 shrink-0 flex items-center gap-1">
            <Filter className="w-3 h-3" />
            <span>Kategori:</span>
          </span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-lg text-xs whitespace-nowrap font-medium transition-colors ${
              selectedCategory === 'all'
                ? 'bg-slate-700 text-cyan-300 font-semibold border border-cyan-500/40'
                : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-850'
            }`}
          >
            Semua Bahan
          </button>
          {categories && categories.length > 0 ? (
            categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-lg text-xs whitespace-nowrap font-medium transition-colors flex items-center gap-1 ${
                  selectedCategory === cat.id
                    ? 'bg-slate-700 text-cyan-300 font-semibold border border-cyan-500/40'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-850'
                }`}
              >
                <span>{cat.icon || '📦'}</span>
                <span>{cat.name}</span>
              </button>
            ))
          ) : (
            [
              { id: 'dtf', label: 'DTF Printing' },
              { id: 'sublime', label: 'Sublimasi' },
              { id: 'cleaning', label: 'Cleaner' },
              { id: 'consumable', label: 'Consumables' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1 rounded-lg text-xs whitespace-nowrap font-medium transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-slate-700 text-cyan-300 font-semibold border border-cyan-500/40'
                    : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-850'
                }`}
              >
                {cat.label}
              </button>
            ))
          )}
        </div>
      </div>

      {/* MOBILE PORTRAIT CARDS VIEW (Phone screens) */}
      <div className="md:hidden space-y-3">
        {filteredPurchases.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
            Tidak ada mutasi pembelian bahan baku yang cocok dengan filter.
          </div>
        ) : (
          filteredPurchases.map((p) => {
            const prod = products.find((pr) => pr.id === p.productId);
            const hpp = p.unitPrice || prod?.costPrice || 0;
            const total = p.totalValue || hpp * p.quantity;
            const supplier = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim();

            return (
              <div
                key={p.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3 shadow-xs"
              >
                {/* Top: PO & Badge */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="font-mono font-bold text-cyan-300 text-sm block">
                      {p.referenceNo}
                    </span>
                    <span className="text-[11px] text-slate-400 font-mono">{p.date}</span>
                  </div>
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                    +{p.quantity} {p.unit.split(' ')[0]}
                  </span>
                </div>

                {/* Material Info Box */}
                <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800/80 space-y-1.5">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-xs font-bold text-white block">{p.productName}</span>
                      <span className="text-[10px] text-cyan-400 font-mono">{p.productCode}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-300">
                    <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{supplier || 'Supplier Umum'}</span>
                  </div>
                  {p.notes && (
                    <p className="text-[10px] text-slate-400 italic line-clamp-1">
                      {p.notes}
                    </p>
                  )}
                </div>

                {/* Stock Transition & Total Value */}
                <div className="flex items-center justify-between pt-1">
                  <div>
                    <span className="text-[10px] text-slate-400 block">
                      Stok: {p.previousStock} &rarr; <strong className="text-cyan-300 font-mono">{p.finalStock}</strong> {p.unit.split(' ')[0]}
                    </span>
                    {currentUser.canViewFinancials ? (
                      <span className="font-mono font-extrabold text-emerald-400 text-base">
                        {formatRupiah(total)}
                      </span>
                    ) : (
                      <span className="font-mono text-slate-400 text-xs">Rp ••••••••</span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap justify-end">
                    <button
                      type="button"
                      onClick={() => setSelectedReceipt(p)}
                      title="Lihat Bukti PO"
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5 text-cyan-400" />
                      <span className="text-[11px]">Bukti</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleOpenEdit(p)}
                      disabled={!canEditPurchases}
                      title={canEditPurchases ? "Edit Mutasi Pembelian" : "Akses ditolak: Izin 'Edit Mutasi Pembelian' tidak aktif"}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors border ${
                        canEditPurchases
                          ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer active:scale-95'
                          : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                      }`}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span className="text-[11px]">Edit</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleOpenDelete(p)}
                      disabled={!canDeletePurchases}
                      title={canDeletePurchases ? "Hapus Mutasi Pembelian (Revert Stok)" : "Akses ditolak: Izin 'Hapus Mutasi Pembelian' tidak aktif"}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors border ${
                        canDeletePurchases
                          ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer active:scale-95'
                          : 'bg-slate-900 text-slate-600 border-slate-800 opacity-50 cursor-not-allowed'
                      }`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span className="text-[11px]">Hapus</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* DESKTOP / TABLET PURCHASES TABLE */}
      <div className="hidden md:block bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
          <table className="w-full min-w-[1050px] text-left text-xs sm:text-sm border-collapse">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] sm:text-[11px] tracking-wider sticky top-0 z-10">
              <tr>
                <th className="py-3.5 px-4 min-w-[150px]">Tanggal & PO</th>
                <th className="py-3.5 px-3 min-w-[160px]">Pemasok / Supplier</th>
                <th className="py-3.5 px-4 min-w-[210px]">Bahan Baku</th>
                <th className="py-3.5 px-3 text-center min-w-[120px]">Jumlah Masuk</th>
                {currentUser.canViewFinancials && (
                  <th className="py-3.5 px-3 text-right min-w-[130px]">Harga Modal (HPP)</th>
                )}
                {currentUser.canViewFinancials && (
                  <th className="py-3.5 px-4 text-right min-w-[140px]">Total Pembelian</th>
                )}
                <th className="py-3.5 px-3 text-center min-w-[120px]">Mutasi Stok</th>
                <th className="py-3.5 px-3 min-w-[130px]">Penerima Gudang</th>
                <th className="py-3.5 px-4 text-right min-w-[180px]">Aksi & Kontrol</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredPurchases.length === 0 ? (
                <tr>
                  <td colSpan={currentUser.canViewFinancials ? 9 : 7} className="py-12 text-center text-slate-400 text-xs">
                    Tidak ada catatan mutasi pembelian bahan baku yang ditemukan.
                  </td>
                </tr>
              ) : (
                filteredPurchases.map((p) => {
                  const prod = products.find((pr) => pr.id === p.productId);
                  const hpp = p.unitPrice || prod?.costPrice || 0;
                  const total = p.totalValue || hpp * p.quantity;
                  const supplier = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim();

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="font-mono font-bold text-cyan-300 text-xs block">
                          {p.referenceNo}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">{p.date}</span>
                      </td>

                      <td className="py-3.5 px-3">
                        <span className="font-semibold text-slate-200 block text-xs">
                          {supplier || 'Supplier Umum'}
                        </span>
                        <span className="text-[10px] text-slate-500 truncate max-w-[160px] block">
                          {p.notes}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-slate-100 block">{p.productName}</span>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-cyan-400 font-mono">{p.productCode}</span>
                          <span className="text-[10px] text-slate-400 uppercase">• {p.category}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 text-xs">
                          +{p.quantity} {p.unit.split(' ')[0]}
                        </span>
                      </td>

                      {currentUser.canViewFinancials && (
                        <td className="py-3.5 px-3 text-right font-mono text-slate-300 text-xs">
                          {formatRupiah(hpp)}
                        </td>
                      )}

                      {currentUser.canViewFinancials && (
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400 text-xs">
                          {formatRupiah(total)}
                        </td>
                      )}

                      <td className="py-3.5 px-3 text-center whitespace-nowrap">
                        <div className="text-xs font-mono">
                          <span className="text-slate-400">{p.previousStock}</span>
                          <span className="text-slate-600 mx-1">&rarr;</span>
                          <span className="text-cyan-300 font-bold">{p.finalStock}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 block">{p.unit}</span>
                      </td>

                      <td className="py-3.5 px-3 whitespace-nowrap">
                        <span className="text-xs text-slate-200 font-medium block">
                          {p.performedBy.userName}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          {p.performedBy.userRole === 'owner' ? 'Pemilik Usaha' : 'Admin Gudang'}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedReceipt(p)}
                            title="Lihat Bukti Penerimaan Barang (PO)"
                            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <Eye className="w-3.5 h-3.5 text-cyan-400" />
                            <span className="hidden xl:inline">Bukti</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleOpenEdit(p)}
                            disabled={!canEditPurchases}
                            title={
                              canEditPurchases
                                ? "Edit Mutasi Pembelian (Ubah Jumlah, HPP, Pemasok, dll)"
                                : "Akses ditolak: Izin 'Edit Mutasi Pembelian' tidak aktif pada akun Anda"
                            }
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition-colors border ${
                              canEditPurchases
                                ? 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border-amber-500/30 cursor-pointer active:scale-95'
                                : 'bg-slate-900/60 text-slate-600 border-slate-800/80 cursor-not-allowed opacity-50'
                            }`}
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span className="hidden lg:inline">Edit</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleOpenDelete(p)}
                            disabled={!canDeletePurchases}
                            title={
                              canDeletePurchases
                                ? "Hapus Catatan Mutasi Pembelian & Revert Stok Gudang"
                                : "Akses ditolak: Izin 'Hapus Mutasi Pembelian' tidak aktif pada akun Anda"
                            }
                            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 transition-colors border ${
                              canDeletePurchases
                                ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border-rose-500/30 cursor-pointer active:scale-95'
                                : 'bg-slate-900/60 text-slate-600 border-slate-800/80 cursor-not-allowed opacity-50'
                            }`}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span className="hidden lg:inline">Hapus</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL BUKTI PENERIMAAN BARANG / PURCHASE RECEIPT SLIP */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
          <div className={`bg-slate-900 border border-slate-700 rounded-2xl w-full ${receiptViewMode === 'official' ? 'max-w-3xl max-h-[92vh]' : 'max-w-lg'} flex flex-col shadow-2xl text-slate-100 my-auto overflow-hidden animate-in fade-in duration-200`}>
            {/* Modal Header */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white flex items-center gap-2">
                    <span>Bukti Penerimaan Barang Masuk (PO)</span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                      {selectedReceipt.referenceNo}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Tanggal: {selectedReceipt.date} • Oleh: {selectedReceipt.performedBy.userName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap sm:flex-nowrap">
                {/* View Mode Toggle */}
                <div className="flex items-center bg-slate-800/80 p-0.5 rounded-lg border border-slate-700/80 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setReceiptViewMode('card')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                      receiptViewMode === 'card' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Ringkasan
                  </button>
                  <button
                    type="button"
                    onClick={() => setReceiptViewMode('official')}
                    className={`px-2.5 py-1 rounded-md font-medium transition-colors cursor-pointer ${
                      receiptViewMode === 'official' ? 'bg-cyan-600 text-white font-bold' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Format Cetak A4
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleSaveReceiptPdf}
                  disabled={isSavingReceiptPdf}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Simpan file PDF bukti masuk PO"
                >
                  {isSavingReceiptPdf ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5" />
                  )}
                  <span>{isSavingReceiptPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>

                <button
                  type="button"
                  onClick={handlePrintReceipt}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Cetak lembar slip PO"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak</span>
                </button>

                <button
                  type="button"
                  onClick={() => setSelectedReceipt(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup Modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Notification Banner */}
            {saveSuccessMsg && (
              <div className="px-4 py-2 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium shrink-0">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{saveSuccessMsg}</span>
              </div>
            )}

            {/* Modal Body: Switch between Compact Card & Official Document Sheet */}
            {receiptViewMode === 'card' ? (
              <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
                {/* Document Body */}
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-4 text-xs font-sans">
                  {/* Slip Header */}
                  <div className="flex items-start justify-between border-b border-slate-850 pb-3">
                    <div>
                      <span className="font-extrabold text-sm text-cyan-300 block">
                        GUDANG DTF & SUBLIME PRINTING
                      </span>
                      <span className="text-[11px] text-slate-400">Slip Verifikasi Masuk Bahan Baku</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-white block">{selectedReceipt.referenceNo}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{selectedReceipt.date}</span>
                    </div>
                  </div>

                  {/* Vendor & Receiver Info */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-medium">Pemasok / Supplier:</span>
                      <span className="font-bold text-slate-100 block mt-0.5">
                        {selectedReceipt.supplierName || selectedReceipt.notes.split('—')[0].replace('Restock dari ', '').trim() || 'Supplier Rekanan'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block uppercase font-medium">Petugas Penerima:</span>
                      <span className="font-bold text-slate-100 block mt-0.5">
                        {selectedReceipt.performedBy.userName}
                      </span>
                      <span className="text-[10px] text-slate-400">Gudang Bahan Baku</span>
                    </div>
                  </div>

                  {/* Material Detail Box */}
                  <div className="bg-slate-900/90 p-3.5 rounded-xl border border-slate-800 space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="font-bold text-white text-sm block">{selectedReceipt.productName}</span>
                        <span className="text-[11px] text-cyan-400 font-mono">{selectedReceipt.productCode}</span>
                      </div>
                      <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 text-xs">
                        +{selectedReceipt.quantity} {selectedReceipt.unit}
                      </span>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                      <span className="text-slate-400">Mutasi Stok Gudang:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {selectedReceipt.previousStock} {selectedReceipt.unit.split(' ')[0]} &rarr;{' '}
                        <span className="text-cyan-300">{selectedReceipt.finalStock} {selectedReceipt.unit.split(' ')[0]}</span>
                      </span>
                    </div>

                    {currentUser.canViewFinancials && (
                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                        <span className="text-slate-400">Harga Beli Modal (HPP):</span>
                        <span className="font-mono text-slate-200 font-semibold">
                          {formatRupiah(selectedReceipt.unitPrice || 0)} / {selectedReceipt.unit.split(' ')[0]}
                        </span>
                      </div>
                    )}

                    {currentUser.canViewFinancials && (
                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-200">Total Biaya Pembelian:</span>
                        <span className="font-mono font-extrabold text-emerald-400 text-sm">
                          {formatRupiah(selectedReceipt.totalValue || 0)}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Notes */}
                  <div>
                    <span className="text-[10px] text-slate-400 block uppercase font-medium">Catatan Kondisi Barang:</span>
                    <p className="text-xs text-slate-300 mt-0.5 bg-slate-900 p-2.5 rounded-lg border border-slate-850">
                      {selectedReceipt.notes || 'Barang diterima dalam kondisi baik dan tersegel.'}
                    </p>
                  </div>
                </div>

                {/* Modal Actions */}
                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setSelectedReceipt(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                  >
                    Tutup
                  </button>
                  <button
                    type="button"
                    onClick={handlePrintReceipt}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                  >
                    <Printer className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Cetak Slip</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveReceiptPdf}
                    disabled={isSavingReceiptPdf}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                  >
                    {isSavingReceiptPdf ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                    ) : (
                      <FileDown className="w-3.5 h-3.5" />
                    )}
                    <span>{isSavingReceiptPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
                {/* Official Paper Sheet in View Mode */}
                <div
                  id="printable-purchase-receipt"
                  className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-2xl mx-auto space-y-5"
                >
                  {/* Official Header */}
                  <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                        GUDANG LOGISTIK SABLON DTF & SUBLIME
                      </span>
                      <h2 className="text-lg font-black text-slate-900 tracking-tight">
                        BUKTI PENERIMAAN BARANG MASUK (PO)
                      </h2>
                      <p className="text-[11px] text-slate-600">
                        Kawasan Industri Kreatif No. 88, Bandung • Telp: 0812-9988-7766
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="inline-block px-2.5 py-1 rounded bg-slate-900 text-white font-mono font-bold text-xs">
                        {selectedReceipt.referenceNo}
                      </span>
                      <p className="text-[11px] text-slate-600 font-mono mt-1">Tanggal: {selectedReceipt.date}</p>
                    </div>
                  </div>

                  {/* Vendor & Receiver Info */}
                  <div className="grid grid-cols-2 gap-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Pemasok / Supplier:</span>
                      <span className="font-bold text-slate-900 block mt-0.5 text-sm">
                        {selectedReceipt.supplierName || selectedReceipt.notes.split('—')[0].replace('Restock dari ', '').trim() || 'Supplier Rekanan'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Petugas Penerima Gudang:</span>
                      <span className="font-bold text-slate-900 block mt-0.5 text-sm">
                        {selectedReceipt.performedBy.userName}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {selectedReceipt.performedBy.userRole === 'owner' ? 'Pemilik Usaha' : 'Admin / Staff Gudang'}
                      </span>
                    </div>
                  </div>

                  {/* Material Detail Table */}
                  <table className="w-full border-collapse border border-slate-300 text-xs">
                    <thead className="bg-slate-100 font-bold text-slate-800 border-b border-slate-300">
                      <tr>
                        <th className="p-2.5 text-left">Kode & Nama Bahan</th>
                        <th className="p-2.5 text-center">Kategori</th>
                        <th className="p-2.5 text-center">Jumlah Masuk</th>
                        {currentUser.canViewFinancials && <th className="p-2.5 text-right">Harga Modal (HPP)</th>}
                        {currentUser.canViewFinancials && <th className="p-2.5 text-right">Total Biaya</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-2.5 font-semibold text-slate-900">
                          <div>{selectedReceipt.productName}</div>
                          <div className="text-[10px] font-mono text-slate-500">{selectedReceipt.productCode}</div>
                        </td>
                        <td className="p-2.5 text-center uppercase text-[10px] text-slate-600">
                          {selectedReceipt.category}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-emerald-800">
                          +{selectedReceipt.quantity} {selectedReceipt.unit}
                        </td>
                        {currentUser.canViewFinancials && (
                          <td className="p-2.5 text-right font-mono text-slate-700">
                            {formatRupiah(selectedReceipt.unitPrice || 0)}
                          </td>
                        )}
                        {currentUser.canViewFinancials && (
                          <td className="p-2.5 text-right font-mono font-bold text-emerald-800">
                            {formatRupiah(selectedReceipt.totalValue || 0)}
                          </td>
                        )}
                      </tr>
                    </tbody>
                  </table>

                  {/* Stock Mutation Audit */}
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Rekam Mutasi Stok Fisik Gudang:</span>
                    <span className="font-mono text-slate-800">
                      Stok Awal: <strong>{selectedReceipt.previousStock}</strong> &rarr; Stok Akhir:{' '}
                      <strong className="text-emerald-700">{selectedReceipt.finalStock} {selectedReceipt.unit.split(' ')[0]}</strong>
                    </span>
                  </div>

                  {/* Notes */}
                  <div className="text-xs">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Catatan Pemeriksaan Fisik:</span>
                    <p className="mt-0.5 text-slate-700 italic border-l-2 border-slate-400 pl-2">
                      {selectedReceipt.notes || 'Barang diterima dalam kondisi tersegel, baik, dan sesuai dengan surat jalan vendor.'}
                    </p>
                  </div>

                  {/* Signatures */}
                  <div className="grid grid-cols-2 gap-8 pt-6 text-center text-xs text-slate-700 border-t border-slate-300">
                    <div>
                      <p className="font-semibold text-slate-600">Petugas Penerima Gudang,</p>
                      <div className="h-14 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6 pt-1 mt-1">
                        ( {selectedReceipt.performedBy.userName} )
                      </p>
                    </div>
                    <div>
                      <p className="font-semibold text-slate-600">Kurir / Petugas Pengantar,</p>
                      <div className="h-14 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6 pt-1 mt-1">
                        ( .............................................. )
                      </p>
                    </div>
                  </div>
                </div>

                {/* Footer for Official View */}
                <div className="flex items-center justify-between gap-2 pt-4 max-w-2xl mx-auto">
                  <span className="text-xs text-slate-400">
                    💡 Lembar A4 resmi siap dicetak atau disimpan sebagai PDF.
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedReceipt(null)}
                      className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                    >
                      Tutup
                    </button>
                    <button
                      type="button"
                      onClick={handlePrintReceipt}
                      className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                    >
                      <Printer className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Cetak Slip</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveReceiptPdf}
                      disabled={isSavingReceiptPdf}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                    >
                      {isSavingReceiptPdf ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
                      ) : (
                        <FileDown className="w-3.5 h-3.5" />
                      )}
                      <span>{isSavingReceiptPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Hidden copy for HTML2Canvas capture if user is in card mode */}
            {receiptViewMode === 'card' && (
              <div 
                style={{
                  position: 'fixed',
                  left: '-9999px',
                  top: '0',
                  width: '794px',
                  pointerEvents: 'none'
                }}
              >
                <div
                  id="printable-purchase-receipt"
                  className="bg-white text-slate-900 p-8 rounded-xl font-sans text-xs space-y-5"
                >
                  <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                        GUDANG LOGISTIK SABLON DTF & SUBLIME
                      </span>
                      <h2 className="text-lg font-black text-slate-900 tracking-tight">
                        BUKTI PENERIMAAN BARANG MASUK (PO)
                      </h2>
                      <p className="text-[11px] text-slate-600">
                        Kawasan Industri Kreatif No. 88, Bandung • Telp: 0812-9988-7766
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="inline-block px-2.5 py-1 rounded bg-slate-900 text-white font-mono font-bold text-xs">
                        {selectedReceipt.referenceNo}
                      </span>
                      <p className="text-[11px] text-slate-600 font-mono mt-1">Tanggal: {selectedReceipt.date}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Pemasok / Supplier:</span>
                      <span className="font-bold text-slate-900 block mt-0.5 text-sm">
                        {selectedReceipt.supplierName || selectedReceipt.notes.split('—')[0].replace('Restock dari ', '').trim() || 'Supplier Rekanan'}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Petugas Penerima Gudang:</span>
                      <span className="font-bold text-slate-900 block mt-0.5 text-sm">
                        {selectedReceipt.performedBy.userName}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {selectedReceipt.performedBy.userRole === 'owner' ? 'Pemilik Usaha' : 'Admin / Staff Gudang'}
                      </span>
                    </div>
                  </div>

                  <table className="w-full border-collapse border border-slate-300 text-xs">
                    <thead className="bg-slate-100 font-bold text-slate-800 border-b border-slate-300">
                      <tr>
                        <th className="p-2.5 text-left">Kode & Nama Bahan</th>
                        <th className="p-2.5 text-center">Kategori</th>
                        <th className="p-2.5 text-center">Jumlah Masuk</th>
                        {currentUser.canViewFinancials && <th className="p-2.5 text-right">Harga Modal (HPP)</th>}
                        {currentUser.canViewFinancials && <th className="p-2.5 text-right">Total Biaya</th>}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-2.5 font-semibold text-slate-900">
                          <div>{selectedReceipt.productName}</div>
                          <div className="text-[10px] font-mono text-slate-500">{selectedReceipt.productCode}</div>
                        </td>
                        <td className="p-2.5 text-center uppercase text-[10px] text-slate-600">
                          {selectedReceipt.category}
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold text-emerald-800">
                          +{selectedReceipt.quantity} {selectedReceipt.unit}
                        </td>
                        {currentUser.canViewFinancials && (
                          <td className="p-2.5 text-right font-mono text-slate-700">
                            {formatRupiah(selectedReceipt.unitPrice || 0)}
                          </td>
                        )}
                        {currentUser.canViewFinancials && (
                          <td className="p-2.5 text-right font-mono font-bold text-emerald-800">
                            {formatRupiah(selectedReceipt.totalValue || 0)}
                          </td>
                        )}
                      </tr>
                    </tbody>
                  </table>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
                    <span className="text-slate-600 font-medium">Rekam Mutasi Stok Fisik Gudang:</span>
                    <span className="font-mono text-slate-800">
                      Stok Awal: <strong>{selectedReceipt.previousStock}</strong> &rarr; Stok Akhir:{' '}
                      <strong className="text-emerald-700">{selectedReceipt.finalStock} {selectedReceipt.unit.split(' ')[0]}</strong>
                    </span>
                  </div>

                  <div className="text-xs">
                    <span className="text-[10px] font-bold text-slate-500 uppercase block">Catatan Pemeriksaan Fisik:</span>
                    <p className="mt-0.5 text-slate-700 italic border-l-2 border-slate-400 pl-2">
                      {selectedReceipt.notes || 'Barang diterima dalam kondisi tersegel, baik, dan sesuai dengan surat jalan vendor.'}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-8 pt-6 text-center text-xs text-slate-700 border-t border-slate-300">
                    <div>
                      <p className="font-semibold text-slate-600">Petugas Penerima Gudang,</p>
                      <div className="h-14 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6 pt-1 mt-1">
                        ( {selectedReceipt.performedBy.userName} )
                      </p>
                    </div>
                    <div>
                      <p className="font-semibold text-slate-600">Kurir / Petugas Pengantar,</p>
                      <div className="h-14 flex items-end justify-center">
                        <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                      </div>
                      <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-6 pt-1 mt-1">
                        ( .............................................. )
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL PRATINJAU CETAK / PDF REKAPITULASI PEMBELIAN BAHAN BAKU */}
      {showRecapPreview && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in duration-200">
            {/* Modal Header */}
            <div className="p-4 bg-slate-950/90 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 flex-wrap">
                    <span>Pratinjau Cetak / PDF Rekap Pembelian Bahan</span>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-mono">
                      {selectedSupplier === 'all' ? 'Semua Supplier' : selectedSupplier}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Filter aktif: {filteredPurchases.length} Dokumen PO • Periode: {dateRangeLabel} • Total: {currentUser.canViewFinancials ? formatRupiah(totalPurchaseValue) : 'Rp ••••••••'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleSaveRecapPdf}
                  disabled={isSavingRecapPdf}
                  className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Unduh dan simpan dokumen sebagai file PDF ke perangkat Anda"
                >
                  {isSavingRecapPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4" />
                  )}
                  <span>{isSavingRecapPdf ? 'Menyimpan...' : 'Simpan PDF'}</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintRecap}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
                  title="Buka dialog cetak printer bawaan"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowRecapPreview(false)}
                  className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Tutup Pratinjau"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Notification Banner */}
            {saveSuccessMsg && (
              <div className="px-4 py-2 bg-emerald-500/20 border-b border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium shrink-0">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{saveSuccessMsg}</span>
              </div>
            )}

            {/* Modal Content: Printable Document Sheet */}
            <div className="p-3 sm:p-6 overflow-y-auto bg-slate-950/60">
              <div
                id="printable-purchases-recap"
                className="bg-white text-slate-900 p-6 sm:p-8 rounded-xl shadow-lg font-sans text-xs max-w-4xl mx-auto space-y-6"
              >
                {/* Official Letterhead Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-900">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                      SISTEM LOGISTIK & PENGADAAN BAHAN BAKU
                    </span>
                    <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
                      GUDANG SUPLAI SABLON DTF & SUBLIME
                    </h1>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Pusat Distribusi Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Kawasan Industri Kreatif No. 88, Bandung • Telp/WA: 0812-9988-7766 • Email: logistik@dtfsublime.id
                    </p>
                  </div>
                  <div className="text-left sm:text-right shrink-0">
                    <span className="inline-block px-3 py-1 rounded bg-slate-900 text-white font-extrabold text-xs tracking-wider uppercase">
                      REKAPITULASI PEMBELIAN BAHAN BAKU
                    </span>
                    <p className="font-mono font-bold text-xs text-slate-800 mt-2">
                      REF: REKAP-PO-{new Date().getFullYear()}{String(new Date().getMonth() + 1).padStart(2, '0')}-{String(new Date().getDate()).padStart(2, '0')}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      Dicetak: {new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </p>
                    <p className="text-[11px] text-slate-600">
                      Oleh: <strong>{currentUser.name}</strong> ({currentUser.roleTitle || (currentUser.role === 'owner' ? 'Pemilik Usaha' : 'Admin Gudang')})
                    </p>
                  </div>
                </div>

                {/* Executive Parameter & Audit Filter Box */}
                <div className="bg-slate-50 rounded-xl border border-slate-300 p-4 space-y-3">
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs border-b border-slate-200 pb-3">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Cakupan Pemasok</span>
                      <span className="font-bold text-slate-900 text-xs block truncate mt-0.5">
                        {selectedSupplier === 'all' ? 'Seluruh Supplier Rekanan' : selectedSupplier}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Kategori Bahan</span>
                      <span className="font-semibold text-slate-800 text-xs block mt-0.5">
                        {selectedCategory === 'all' || !selectedCategory ? 'Semua Kategori Bahan' : selectedCategory.toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Periode Waktu</span>
                      <span className="font-semibold text-slate-800 text-xs block mt-0.5">{dateRangeLabel}</span>
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block tracking-wider">Volume Transaksi</span>
                      <span className="font-bold text-slate-900 text-xs block mt-0.5">
                        {filteredPurchases.length} PO ({totalQuantityReceived} Unit Masuk)
                      </span>
                    </div>
                  </div>

                  {/* 4 Financial Highlight Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Belanja Bahan</span>
                      <span className="font-mono font-black text-sm text-emerald-700 block mt-0.5">
                        {currentUser.canViewFinancials ? formatRupiah(totalPurchaseValue) : 'Rp ••••••••'}
                      </span>
                      <span className="text-[10px] text-slate-500">Akumulasi biaya pengadaan</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Total Fisik Masuk</span>
                      <span className="font-mono font-black text-sm text-cyan-700 block mt-0.5">
                        {totalQuantityReceived} Item
                      </span>
                      <span className="text-[10px] text-slate-500">Penambahan stok riil gudang</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Pemasok Terlibat</span>
                      <span className="font-mono font-black text-sm text-indigo-700 block mt-0.5">
                        {uniqueSuppliersCount} Vendor
                      </span>
                      <span className="text-[10px] text-slate-500">Mitra suplai aktif</span>
                    </div>
                    <div className="p-2.5 rounded-lg bg-white border border-slate-200 shadow-2xs">
                      <span className="text-[10px] font-bold text-slate-500 uppercase block">Rata-rata per PO</span>
                      <span className="font-mono font-black text-sm text-blue-700 block mt-0.5">
                        {currentUser.canViewFinancials
                          ? formatRupiah(filteredPurchases.length > 0 ? Math.round(totalPurchaseValue / filteredPurchases.length) : 0)
                          : 'Rp ••••••••'}
                      </span>
                      <span className="text-[10px] text-slate-500">Nilai rata-rata per transaksi</span>
                    </div>
                  </div>
                </div>

                {/* Ringkasan per Pemasok (jika ada lebih dari 1 supplier) */}
                {supplierSummary.length > 1 && (
                  <div className="border border-slate-200 rounded-xl overflow-hidden">
                    <div className="bg-slate-100 px-3.5 py-2 border-b border-slate-200 font-bold text-[11px] text-slate-700 flex items-center justify-between">
                      <span>Ringkasan Pengadaan per Pemasok / Rekanan</span>
                      <span className="font-normal text-slate-500 text-[10px]">{supplierSummary.length} Supplier Terdaftar</span>
                    </div>
                    <table className="w-full text-left text-[11px]">
                      <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                        <tr>
                          <th className="py-2 px-3">Nama Pemasok / Vendor</th>
                          <th className="py-2 px-3 text-center">Frekuensi PO</th>
                          <th className="py-2 px-3 text-center">Total Unit Masuk</th>
                          {currentUser.canViewFinancials && (
                            <th className="py-2 px-3 text-right">Akumulasi Nilai Belanja</th>
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {supplierSummary.map((s) => (
                          <tr key={s.name}>
                            <td className="py-1.5 px-3 font-medium text-slate-800">{s.name}</td>
                            <td className="py-1.5 px-3 text-center text-slate-600">{s.count} kali PO</td>
                            <td className="py-1.5 px-3 text-center font-mono font-semibold text-slate-700">+{s.qty}</td>
                            {currentUser.canViewFinancials && (
                              <td className="py-1.5 px-3 text-right font-mono font-bold text-emerald-700">
                                {formatRupiah(s.total)}
                              </td>
                            )}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Main Purchase Log Table */}
                <div className="border border-slate-300 rounded-xl overflow-hidden">
                  <div className="bg-slate-100 px-3.5 py-2.5 border-b border-slate-300 font-bold text-xs text-slate-800 flex items-center justify-between">
                    <span>Tabel Rincian Riwayat Pengadaan & Mutasi Masuk Bahan Baku</span>
                    <span className="text-[10px] font-mono text-slate-600 font-normal">
                      Menampilkan {filteredPurchases.length} baris data
                    </span>
                  </div>

                  <table className="w-full text-left text-[10px] border-collapse">
                    <thead className="bg-slate-50 border-b border-slate-300 text-slate-700 font-bold uppercase tracking-wider">
                      <tr>
                        <th className="py-2 px-2 text-center w-8">No</th>
                        <th className="py-2 px-2.5">Tanggal & PO</th>
                        <th className="py-2 px-2.5">Pemasok / Supplier</th>
                        <th className="py-2 px-2.5">Bahan Baku</th>
                        <th className="py-2 px-2 text-center">Masuk</th>
                        {currentUser.canViewFinancials && (
                          <th className="py-2 px-2.5 text-right">HPP Modal</th>
                        )}
                        {currentUser.canViewFinancials && (
                          <th className="py-2 px-2.5 text-right">Total Belanja</th>
                        )}
                        <th className="py-2 px-2 text-center">Stok</th>
                        <th className="py-2 px-2.5">Penerima Gudang</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredPurchases.length === 0 ? (
                        <tr>
                          <td colSpan={currentUser.canViewFinancials ? 9 : 7} className="py-8 text-center text-slate-500 italic">
                            Tidak ada data pembelian yang sesuai dengan filter yang dipilih.
                          </td>
                        </tr>
                      ) : (
                        filteredPurchases.map((p, idx) => {
                          const prod = products.find((pr) => pr.id === p.productId);
                          const hpp = p.unitPrice || prod?.costPrice || 0;
                          const total = p.totalValue || hpp * p.quantity;
                          const supplier = p.supplierName || p.notes.split('—')[0].replace('Restock dari ', '').trim() || 'Supplier Umum';

                          return (
                            <tr key={p.id} className={idx % 2 === 1 ? 'bg-slate-50/50' : 'bg-white'}>
                              <td className="py-2 px-2 text-center font-mono text-slate-500">{idx + 1}</td>
                              <td className="py-2 px-2.5">
                                <span className="font-mono font-bold text-slate-900 block">{p.referenceNo}</span>
                                <span className="text-[9px] text-slate-500 font-mono block">{p.date}</span>
                              </td>
                              <td className="py-2 px-2.5">
                                <span className="font-bold text-slate-800 block">{supplier}</span>
                                {p.notes && (
                                  <span className="text-[9px] text-slate-500 italic block line-clamp-1">
                                    {p.notes}
                                  </span>
                                )}
                              </td>
                              <td className="py-2 px-2.5">
                                <span className="font-semibold text-slate-900 block">{p.productName}</span>
                                <span className="text-[9px] font-mono text-slate-500 block">
                                  {p.productCode} • {(p.category || '').toUpperCase()}
                                </span>
                              </td>
                              <td className="py-2 px-2 text-center">
                                <span className="font-mono font-bold text-emerald-800">
                                  +{p.quantity}
                                </span>
                                <span className="text-[9px] text-slate-500 block">{p.unit.split(' ')[0]}</span>
                              </td>
                              {currentUser.canViewFinancials && (
                                <td className="py-2 px-2.5 text-right font-mono text-slate-700">
                                  {formatRupiah(hpp)}
                                </td>
                              )}
                              {currentUser.canViewFinancials && (
                                <td className="py-2 px-2.5 text-right font-mono font-bold text-emerald-800">
                                  {formatRupiah(total)}
                                </td>
                              )}
                              <td className="py-2 px-2 text-center font-mono text-[9px] text-slate-600">
                                {p.previousStock} &rarr; <strong className="text-slate-900">{p.finalStock}</strong>
                              </td>
                              <td className="py-2 px-2.5 text-slate-800">
                                <span className="font-medium block">{p.performedBy.userName}</span>
                                <span className="text-[9px] text-slate-500">
                                  {p.performedBy.userRole === 'owner' ? 'Owner' : 'Staff Gudang'}
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                    {filteredPurchases.length > 0 && (
                      <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300 text-slate-900">
                        <tr>
                          <td colSpan={4} className="py-2.5 px-3 text-right uppercase text-[10px]">
                            Grand Total Rekapitulasi:
                          </td>
                          <td className="py-2.5 px-2 text-center font-mono text-emerald-900 text-xs">
                            +{totalQuantityReceived} Unit
                          </td>
                          {currentUser.canViewFinancials && <td className="py-2.5 px-2.5"></td>}
                          {currentUser.canViewFinancials && (
                            <td className="py-2.5 px-2.5 text-right font-mono text-emerald-800 text-xs font-black">
                              {formatRupiah(totalPurchaseValue)}
                            </td>
                          )}
                          <td colSpan={2} className="py-2.5 px-3 text-slate-500 text-[9px] text-right font-normal">
                            {filteredPurchases.length} Transaksi PO Terverifikasi
                          </td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>

                {/* Audit & Legal Notes */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-[10px] text-slate-600 leading-relaxed">
                  <p>
                    <strong>Keterangan & Catatan Audit Gudang:</strong> Laporan rekapitulasi pembelian ini disusun secara otomatis berdasarkan transaksi barang masuk yang telah terverifikasi oleh petugas penerima. Seluruh stok telah ditambahkan ke kartu stok fisik secara real-time dan nilai HPP telah disesuaikan dengan faktur/PO supplier yang sah.
                  </p>
                </div>

                {/* Official Signatures Block (3 columns) */}
                <div className="grid grid-cols-3 gap-6 pt-6 text-center text-xs text-slate-700 border-t border-slate-300">
                  <div>
                    <p className="font-semibold text-slate-600">Dibuat / Diterima Oleh,</p>
                    <p className="text-[10px] text-slate-500">Petugas Gudang Bahan Baku</p>
                    <div className="h-16 flex items-end justify-center">
                      <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                    </div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                      {currentUser.name}
                    </p>
                  </div>

                  <div>
                    <p className="font-semibold text-slate-600">Diverifikasi Oleh,</p>
                    <p className="text-[10px] text-slate-500">Supervisor Gudang & Logistik</p>
                    <div className="h-16 flex items-end justify-center">
                      <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                    </div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                      ( .............................................. )
                    </p>
                  </div>

                  <div>
                    <p className="font-semibold text-slate-600">Disetujui Oleh,</p>
                    <p className="text-[10px] text-slate-500">Pemilik Usaha (Owner)</p>
                    <div className="h-16 flex items-end justify-center">
                      <span className="text-[10px] text-slate-400 italic">( Tanda Tangan )</span>
                    </div>
                    <p className="font-bold text-slate-900 border-t border-slate-400 inline-block px-4 pt-1 mt-1">
                      ( .............................................. )
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
              <span className="text-xs text-slate-400 text-center sm:text-left">
                💡 Dokumen diformat standar A4. Klik <strong>Simpan PDF</strong> untuk download file langsung, atau <strong>Cetak</strong> untuk print dokumen fisik.
              </span>
              <div className="flex items-center gap-2 ml-auto w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => setShowRecapPreview(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={handlePrintRecap}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>Cetak (Print)</span>
                </button>
                <button
                  type="button"
                  onClick={handleSaveRecapPdf}
                  disabled={isSavingRecapPdf}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
                >
                  {isSavingRecapPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4" />
                  )}
                  <span>{isSavingRecapPdf ? 'Menyimpan PDF...' : 'Simpan PDF (Download)'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL EDIT MUTASI PEMBELIAN */}
      {editingMovement && (() => {
        const prod = products.find((p) => p.id === editingMovement.productId);
        const oldQty = editingMovement.quantity;
        const newQty = Number(editFormData.quantity) || 0;
        const qtyDiff = newQty - oldQty;
        const currentStock = prod?.currentStock ?? 0;
        const estimatedStock = currentStock + qtyDiff;
        const unitPrice = Number(editFormData.unitPrice) || 0;
        const totalValue = newQty * unitPrice;
        const isNegativeStock = estimatedStock < 0;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-y-auto">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-xl shadow-2xl text-slate-100 overflow-hidden my-auto animate-in fade-in duration-150">
              {/* Modal Header */}
              <div className="p-4 sm:p-5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <Edit3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-white">
                      Edit Catatan Mutasi Pembelian Bahan
                    </h3>
                    <p className="text-[11px] text-slate-400">
                      PO: <span className="font-mono text-cyan-300">{editingMovement.referenceNo}</span> • {editingMovement.productName}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setEditingMovement(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Form Body */}
              <form onSubmit={handleSaveEdit} className="p-4 sm:p-6 space-y-4">
                {editError && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                    <span>{editError}</span>
                  </div>
                )}

                {/* Material Info Box */}
                <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl flex items-center justify-between gap-3">
                  <div>
                    <span className="text-xs font-bold text-white block">
                      {editingMovement.productName}
                    </span>
                    <span className="text-[10px] text-cyan-400 font-mono">
                      {editingMovement.productCode} • {(editingMovement.category || '').toUpperCase()}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Stok Fisik Gudang Sekarang</span>
                    <span className="text-xs font-mono font-bold text-slate-200">
                      {currentStock} {editingMovement.unit}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Reference No */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Nomor PO / Bukti Masuk
                    </label>
                    <input
                      type="text"
                      value={editFormData.referenceNo}
                      onChange={(e) => setEditFormData({ ...editFormData, referenceNo: e.target.value })}
                      placeholder="Contoh: PO-MSK-001..."
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                      required
                    />
                  </div>

                  {/* Date */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Tanggal & Waktu Transaksi
                    </label>
                    <input
                      type="text"
                      value={editFormData.date}
                      onChange={(e) => setEditFormData({ ...editFormData, date: e.target.value })}
                      placeholder="YYYY-MM-DD HH:mm"
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Supplier */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Nama Pemasok / Supplier
                    </label>
                    <input
                      type="text"
                      list="supplier-suggestions"
                      value={editFormData.supplierName}
                      onChange={(e) => setEditFormData({ ...editFormData, supplierName: e.target.value })}
                      placeholder="Pilih atau ketik supplier..."
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                      required
                    />
                    <datalist id="supplier-suggestions">
                      {supplierList.map((s) => (
                        <option key={s} value={s} />
                      ))}
                    </datalist>
                  </div>

                  {/* Quantity */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                      <span>Jumlah Masuk ({editingMovement.unit.split(' ')[0]})</span>
                      <span className="text-[10px] text-slate-400">Sebelumnya: {oldQty}</span>
                    </label>
                    <input
                      type="number"
                      step="any"
                      min="0"
                      value={editFormData.quantity}
                      onChange={(e) => setEditFormData({ ...editFormData, quantity: parseFloat(e.target.value) || 0 })}
                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {/* Cost Price */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Harga Beli Satuan (HPP / Unit)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 font-mono">Rp</span>
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={editFormData.unitPrice}
                        onChange={(e) => setEditFormData({ ...editFormData, unitPrice: parseFloat(e.target.value) || 0 })}
                        className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                        required
                      />
                    </div>
                  </div>

                  {/* Total Value Preview */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Total Nilai Pengadaan
                    </label>
                    <div className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono font-bold text-emerald-400">
                      {formatRupiah(totalValue)}
                    </div>
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Catatan / Keterangan
                  </label>
                  <textarea
                    rows={2}
                    value={editFormData.notes}
                    onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                    placeholder="Keterangan pengadaan, no resi kirim, kualitas bahan..."
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Dynamic Stock Impact Calculation Card */}
                <div className={`p-3.5 rounded-2xl border ${
                  isNegativeStock
                    ? 'bg-rose-950/25 border-rose-500/40 text-rose-200'
                    : 'bg-cyan-950/20 border-cyan-500/30 text-cyan-200'
                }`}>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold flex items-center gap-1.5">
                      {isNegativeStock ? <AlertTriangle className="w-4 h-4 text-rose-400" /> : <Boxes className="w-4 h-4 text-cyan-400" />}
                      <span>Dampak Penyesuaian Stok Gudang:</span>
                    </span>
                    <span className="font-mono text-[11px]">
                      Selisih: <strong className={qtyDiff >= 0 ? 'text-emerald-400' : 'text-amber-400'}>{qtyDiff >= 0 ? `+${qtyDiff}` : qtyDiff} {editingMovement.unit.split(' ')[0]}</strong>
                    </span>
                  </div>
                  <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      Stok Fisik Gudang Sekarang: <strong className="text-slate-200 font-mono">{currentStock}</strong>
                    </span>
                    <span className="text-slate-400">
                      &rarr; Estimasi Akhir: <strong className={`font-mono font-bold ${isNegativeStock ? 'text-rose-400 text-sm' : 'text-cyan-300'}`}>{estimatedStock} {editingMovement.unit.split(' ')[0]}</strong>
                    </span>
                  </div>
                  {isNegativeStock && (
                    <p className="text-[11px] text-rose-300 mt-2 font-medium">
                      ⚠️ Peringatan: Mengurangi kuantiti menjadi {newQty} akan menyebabkan stok fisik di gudang bernilai minus ({estimatedStock}). Periksa kembali apakah bahan telah terpakai di pesanan.
                    </p>
                  )}
                </div>

                {/* Modal Footer */}
                <div className="pt-2 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setEditingMovement(null)}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingEdit || isNegativeStock}
                    className="px-5 py-2 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                  >
                    {isSavingEdit ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    <span>Simpan Perubahan</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* MODAL KONFIRMASI HAPUS MUTASI PEMBELIAN (REVERT STOK) */}
      {deletingMovement && (() => {
        const prod = products.find((p) => p.id === deletingMovement.productId);
        const currentStock = prod?.currentStock ?? 0;
        const revertQty = deletingMovement.quantity;
        const stockAfterDelete = currentStock - revertQty;
        const isNegativeStock = stockAfterDelete < 0;

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-xs overflow-y-auto">
            <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg shadow-2xl text-slate-100 overflow-hidden my-auto animate-in fade-in duration-150">
              {/* Header */}
              <div className="p-4 sm:p-5 bg-rose-950/40 border-b border-rose-500/20 flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-white">
                    Hapus Catatan Mutasi Pembelian
                  </h3>
                  <p className="text-[11px] text-rose-300">
                    Aksi ini akan menghapus catatan PO dan membatalkan (mengurangi) stok masuk gudang.
                  </p>
                </div>
              </div>

              {/* Body */}
              <div className="p-4 sm:p-6 space-y-4">
                {deleteError && (
                  <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                    <span>{deleteError}</span>
                  </div>
                )}

                {/* Details Card */}
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2.5 text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Nomor Bukti PO:</span>
                    <span className="font-mono font-bold text-cyan-300">{deletingMovement.referenceNo}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Tanggal Transaksi:</span>
                    <span className="font-mono text-slate-200">{deletingMovement.date}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Bahan Baku:</span>
                    <span className="font-bold text-white text-right">{deletingMovement.productName}</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-800">
                    <span className="text-slate-400">Jumlah Pembelian yang Dihapus:</span>
                    <span className="font-bold font-mono text-rose-400">
                      -{revertQty} {deletingMovement.unit}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Pemasok / Supplier:</span>
                    <span className="text-slate-200">{deletingMovement.supplierName || 'Supplier Umum'}</span>
                  </div>
                </div>

                {/* Stock Reversion Box */}
                <div className={`p-4 rounded-2xl border ${
                  isNegativeStock
                    ? 'bg-rose-950/30 border-rose-500/50 text-rose-200'
                    : 'bg-amber-950/20 border-amber-500/30 text-amber-200'
                }`}>
                  <div className="flex items-center gap-2 font-bold text-xs mb-1">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Pengembalian (Revert) Stok Fisik Gudang</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    Stok saat ini di gudang adalah <strong>{currentStock} {deletingMovement.unit}</strong>. Menghapus mutasi ini akan mengurangi stok sebesar <strong>{revertQty} {deletingMovement.unit}</strong> sehingga estimasi stok menjadi <strong>{stockAfterDelete} {deletingMovement.unit}</strong>.
                  </p>
                  {isNegativeStock && (
                    <div className="mt-2.5 p-2.5 rounded-xl bg-rose-950/60 border border-rose-500/40 text-[11px] text-rose-200 font-semibold leading-relaxed">
                      ⚠️ PERINGATAN: Stok saat ini ({currentStock} {deletingMovement.unit}) lebih kecil dari kuantiti PO yang dihapus ({revertQty} {deletingMovement.unit}). Dengan melanjutkan, mutasi PO akan dihapus dan stok fisik gudang akan disesuaikan menjadi <strong>{Math.max(0, stockAfterDelete)} {deletingMovement.unit}</strong>.
                    </div>
                  )}
                </div>

                {/* Modal Footer */}
                <div className="pt-2 flex items-center justify-end gap-2.5">
                  <button
                    type="button"
                    onClick={() => setDeletingMovement(null)}
                    disabled={isDeleting}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    id="btn-confirm-delete-purchase"
                    onClick={handleConfirmDelete}
                    disabled={isDeleting}
                    className="px-5 py-2 bg-rose-600 hover:bg-rose-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-sm active:scale-95 transition-all"
                  >
                    {isDeleting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    <span>Ya, Hapus Mutasi & Revert Stok</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Floating Feedback Toast */}
      {feedbackToast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 duration-200 max-w-md">
          <div className={`p-4 rounded-2xl border shadow-2xl flex items-center gap-3 ${
            feedbackToast.type === 'success'
              ? 'bg-emerald-950/90 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-950/90 border-rose-500/40 text-rose-200'
          }`}>
            {feedbackToast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            )}
            <span className="text-xs font-medium leading-snug">{feedbackToast.message}</span>
            <button
              type="button"
              onClick={() => setFeedbackToast(null)}
              className="ml-auto text-slate-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
