import React, { useState } from 'react';
import { 
  Smartphone, 
  X, 
  Bell, 
  Volume2, 
  Wifi, 
  BatteryMedium, 
  Clock, 
  Sparkles, 
  Layers, 
  ShoppingCart, 
  AlertTriangle, 
  PackagePlus,
  Send
} from 'lucide-react';
import { PushNotification } from '../types';
import { playPushNotificationSound, requestAndSendBrowserNotification } from '../utils/helpers';

interface MobilePushSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: PushNotification[];
  onTriggerTestPush: (type: 'sale' | 'production' | 'critical' | 'invoice_due') => void;
}

export const MobilePushSimulator: React.FC<MobilePushSimulatorProps> = ({
  isOpen,
  onClose,
  notifications,
  onTriggerTestPush,
}) => {
  const [browserPushEnabled, setBrowserPushEnabled] = useState(false);

  if (!isOpen) return null;

  const handleEnableBrowserPush = async () => {
    const success = await requestAndSendBrowserNotification(
      '🔔 Notifikasi Gudang DTF & Sublime Aktif',
      'Pemilik usaha akan menerima pemberitahuan setiap ada penjualan atau stok menipis!'
    );
    if (success) {
      setBrowserPushEnabled(true);
      playPushNotificationSound();
    }
  };

  const currentTime = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-4xl w-full p-5 sm:p-6 shadow-2xl text-slate-100 my-4 sm:my-8">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <span>Simulator Notifikasi Push Mobile (Pemilik Usaha)</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">
                  REAL-TIME
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Memungkinkan pemilik usaha memantau setiap transaksi dan mutasi bahan baku dari jarak jauh lewat smartphone.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Layout: Controls Left, Phone Mockup Right */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6 items-start">
          {/* Controls Left */}
          <div className="md:col-span-6 space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Bell className="w-4 h-4 text-cyan-400" />
                <span>Pengaturan Push Notifikasi</span>
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Setiap kali staf mencatat pemakaian produksi atau kasir mencetak invoice penjualan bahan baku, notifikasi push instan akan terkirim ke perangkat HP pemilik usaha.
              </p>

              {/* Native Browser Push Trigger */}
              <button
                onClick={handleEnableBrowserPush}
                className={`w-full py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all ${
                  browserPushEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : 'bg-indigo-600 hover:bg-indigo-500 text-white border-transparent'
                }`}
              >
                <Volume2 className="w-4 h-4" />
                <span>
                  {browserPushEnabled ? '✅ Notifikasi Browser Aktif' : 'Aktifkan Notifikasi Asli Browser (OS)'}
                </span>
              </button>
            </div>

            {/* Test push trigger buttons */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Uji Coba Kirim Notifikasi Cepat</span>
              </h4>
              <div className="grid grid-cols-1 gap-2">
                <button
                  onClick={() => {
                    onTriggerTestPush('sale');
                    playPushNotificationSound();
                  }}
                  className="px-3 py-2 bg-slate-900 hover:bg-emerald-950/50 text-emerald-300 border border-slate-800 hover:border-emerald-500/40 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <ShoppingCart className="w-4 h-4 text-emerald-400" />
                    <span>Simulasi Penjualan Bahan (Invoice)</span>
                  </span>
                  <Send className="w-3.5 h-3.5 opacity-60" />
                </button>

                <button
                  onClick={() => {
                    onTriggerTestPush('critical');
                    playPushNotificationSound();
                  }}
                  className="px-3 py-2 bg-slate-900 hover:bg-amber-950/50 text-amber-300 border border-slate-800 hover:border-amber-500/40 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Simulasi Peringatan Stok Kritis (Reorder)</span>
                  </span>
                  <Send className="w-3.5 h-3.5 opacity-60" />
                </button>

                <button
                  onClick={() => {
                    onTriggerTestPush('production');
                    playPushNotificationSound();
                  }}
                  className="px-3 py-2 bg-slate-900 hover:bg-blue-950/50 text-blue-300 border border-slate-800 hover:border-blue-500/40 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-blue-400" />
                    <span>Simulasi Pemakaian Bahan Produksi</span>
                  </span>
                  <Send className="w-3.5 h-3.5 opacity-60" />
                </button>

                <button
                  onClick={() => {
                    onTriggerTestPush('invoice_due');
                    playPushNotificationSound();
                  }}
                  className="px-3 py-2 bg-slate-900 hover:bg-rose-950/50 text-rose-300 border border-slate-800 hover:border-rose-500/40 rounded-xl text-xs font-semibold flex items-center justify-between transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-rose-400" />
                    <span>Simulasi Pengingat Jatuh Tempo (Invoice DP / Tempo)</span>
                  </span>
                  <Send className="w-3.5 h-3.5 opacity-60" />
                </button>
              </div>
            </div>
          </div>

          {/* Smartphone Mockup Right */}
          <div className="md:col-span-6 flex justify-center">
            <div className="w-[300px] sm:w-[320px] bg-slate-950 border-4 border-slate-700 rounded-[38px] p-3 shadow-2xl relative overflow-hidden ring-4 ring-slate-800/60">
              {/* Phone Speaker Notch */}
              <div className="w-28 h-4 bg-slate-800 rounded-full mx-auto mb-2 flex items-center justify-center">
                <div className="w-3 h-3 rounded-full bg-slate-950 border border-slate-700 ml-auto mr-3" />
              </div>

              {/* Status Bar */}
              <div className="flex items-center justify-between px-3 text-[10px] text-slate-400 font-mono mb-3">
                <span>{currentTime}</span>
                <div className="flex items-center gap-1.5">
                  <Wifi className="w-3 h-3" />
                  <BatteryMedium className="w-3 h-3" />
                </div>
              </div>

              {/* Smartphone Screen Inner */}
              <div className="bg-slate-900/90 rounded-[28px] p-3 min-h-[380px] max-h-[440px] overflow-y-auto space-y-2.5 border border-slate-800/80">
                <div className="text-center pt-2 pb-1">
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold block">
                    Pusat Notifikasi DTF & Sublime
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">Layar Terkunci (Lockscreen)</span>
                </div>

                {/* Notification banners */}
                {notifications.length === 0 ? (
                  <div className="py-16 text-center text-xs text-slate-500">
                    Tidak ada notifikasi aktif.
                  </div>
                ) : (
                  notifications.map((n, idx) => {
                    const isWarn = n.type === 'stock_warning';
                    const isSale = n.type === 'sale_alert';
                    const isDue = n.type === 'invoice_due';

                    return (
                      <div
                        key={`${n.id}-${idx}`}
                        className={`p-3 rounded-2xl border backdrop-blur-md shadow-lg transition-all animate-fade-in ${
                          isDue
                            ? 'bg-rose-950/50 border-rose-500/50 text-rose-200'
                            : isWarn
                            ? 'bg-amber-950/40 border-amber-500/40 text-amber-200'
                            : isSale
                            ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                            : 'bg-slate-800/80 border-slate-700 text-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                          <span className="font-bold flex items-center gap-1 text-slate-300">
                            {isDue ? '⏰ Tagihan Tempo' : isWarn ? '⚠️ Alert Stok' : isSale ? '🛍️ Penjualan' : '📦 Gudang'}
                          </span>
                          <span className="font-mono text-[9px]">{n.timestamp.split(' ')[1] || n.timestamp}</span>
                        </div>
                        <p className="text-xs font-bold text-white leading-tight">{n.title}</p>
                        <p className="text-[11px] text-slate-300 mt-1 leading-snug">{n.message}</p>
                        {n.meta?.unpaidAmount && (
                          <div className="mt-1.5 pt-1.5 border-t border-rose-500/30 flex items-center justify-between text-[10px]">
                            <span className="text-rose-300 font-medium">Sisa Piutang:</span>
                            <span className="font-mono font-bold text-rose-300">
                              Rp {n.meta.unpaidAmount.toLocaleString('id-ID')}
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>

              {/* Bottom Home Indicator Bar */}
              <div className="w-28 h-1 bg-slate-700 rounded-full mx-auto mt-3" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
