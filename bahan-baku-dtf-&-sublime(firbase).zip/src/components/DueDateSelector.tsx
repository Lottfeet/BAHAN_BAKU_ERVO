import React from 'react';
import { Clock, Infinity as InfinityIcon, Calendar, Check, Zap } from 'lucide-react';
import { calculateQuickDueDate, formatDateIndo, formatDueDateIndo } from '../utils/helpers';

export interface DueDateSelectorProps {
  value: string;
  onChange: (newValue: string) => void;
  label?: string;
  helperText?: string;
  colorTheme?: 'rose' | 'amber' | 'cyan' | 'emerald' | 'indigo';
  compact?: boolean;
  baseDate?: string | Date;
}

export const DueDateSelector: React.FC<DueDateSelectorProps> = ({
  value,
  onChange,
  label = 'Batas Tanggal Jatuh Tempo Pelunasan',
  helperText = 'Pengingat jatuh tempo otomatis akan aktif di dasbor & notifikasi untuk menagih sisa pembayaran.',
  colorTheme = 'rose',
  compact = false,
  baseDate,
}) => {
  const isUnlimited =
    !value ||
    value === 'tidak_terbatas' ||
    value === 'unlimited' ||
    value === '9999-12-31' ||
    value === '-' ||
    value.toLowerCase().includes('tidak terbatas');

  // Calculate preset dates for comparison
  const twoWeeksDate = calculateQuickDueDate('2_weeks', baseDate);
  const oneMonthDate = calculateQuickDueDate('1_month', baseDate);
  const twoMonthsDate = calculateQuickDueDate('2_months', baseDate);

  const is2Weeks = !isUnlimited && value === twoWeeksDate;
  const is1Month = !isUnlimited && value === oneMonthDate;
  const is2Months = !isUnlimited && value === twoMonthsDate;

  // Compute remaining days if specific date
  let daysDiff: number | null = null;
  if (!isUnlimited && value) {
    try {
      const parts = value.split('-');
      if (parts.length === 3) {
        const target = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
        const today = new Date();
        const ref = new Date(today.getFullYear(), today.getMonth(), today.getDate());
        daysDiff = Math.round((target.getTime() - ref.getTime()) / (1000 * 3600 * 24));
      }
    } catch {
      // ignore
    }
  }

  // Color classes map
  const themeStyles = {
    rose: {
      activeButton: 'bg-rose-500/25 border-rose-500 text-rose-200 ring-1 ring-rose-500/30',
      labelColor: 'text-rose-300',
      inputBorder: 'border-rose-500/40 focus:border-rose-400 text-rose-200',
      badge: 'bg-rose-950/60 border-rose-500/30 text-rose-300',
    },
    cyan: {
      activeButton: 'bg-cyan-500/25 border-cyan-500 text-cyan-200 ring-1 ring-cyan-500/30',
      labelColor: 'text-cyan-300',
      inputBorder: 'border-cyan-500/40 focus:border-cyan-400 text-cyan-200',
      badge: 'bg-cyan-950/60 border-cyan-500/30 text-cyan-300',
    },
    amber: {
      activeButton: 'bg-amber-500/25 border-amber-500 text-amber-200 ring-1 ring-amber-500/30',
      labelColor: 'text-amber-300',
      inputBorder: 'border-amber-500/40 focus:border-amber-400 text-amber-200',
      badge: 'bg-amber-950/60 border-amber-500/30 text-amber-300',
    },
    emerald: {
      activeButton: 'bg-emerald-500/25 border-emerald-500 text-emerald-200 ring-1 ring-emerald-500/30',
      labelColor: 'text-emerald-300',
      inputBorder: 'border-emerald-500/40 focus:border-emerald-400 text-emerald-200',
      badge: 'bg-emerald-950/60 border-emerald-500/30 text-emerald-300',
    },
    indigo: {
      activeButton: 'bg-indigo-500/25 border-indigo-500 text-indigo-200 ring-1 ring-indigo-500/30',
      labelColor: 'text-indigo-300',
      inputBorder: 'border-indigo-500/40 focus:border-indigo-400 text-indigo-200',
      badge: 'bg-indigo-950/60 border-indigo-500/30 text-indigo-300',
    },
  };

  const style = themeStyles[colorTheme] || themeStyles.rose;

  return (
    <div className="space-y-2">
      {/* Header & Label */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <label className={`block text-xs font-semibold ${style.labelColor} flex items-center gap-1.5`}>
          <Clock className="w-3.5 h-3.5 shrink-0" />
          <span>{label}</span>
        </label>
        {isUnlimited ? (
          <span className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-cyan-950/80 border border-cyan-500/40 text-cyan-300 font-bold flex items-center gap-1 shadow-xs">
            <InfinityIcon className="w-3 h-3 text-cyan-400" />
            Tidak Terbatas
          </span>
        ) : (
          <span className={`text-[11px] font-mono px-2 py-0.5 rounded-md border font-semibold ${style.badge}`}>
            {daysDiff !== null
              ? daysDiff < 0
                ? `Lewat ${Math.abs(daysDiff)} hari`
                : daysDiff === 0
                ? 'Hari Ini'
                : `${daysDiff} hari lagi`
              : value}
          </span>
        )}
      </div>

      {/* Quick Action Presets (2 Minggu, 1 Bulan, 2 Bulan, Tidak Terbatas) */}
      <div>
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Preset: Tidak Terbatas */}
          <button
            type="button"
            onClick={() => onChange('tidak_terbatas')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-all cursor-pointer ${
              isUnlimited
                ? 'bg-cyan-500/30 border-cyan-400 text-cyan-200 shadow-md ring-1 ring-cyan-400/40'
                : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title="Bebas jatuh tempo (Tanpa batas waktu pelunasan)"
          >
            <InfinityIcon className={`w-3.5 h-3.5 ${isUnlimited ? 'text-cyan-300' : 'text-slate-400'}`} />
            <span>Tidak Terbatas</span>
            {isUnlimited && <Check className="w-3 h-3 text-cyan-300 ml-0.5" />}
          </button>

          {/* Preset: 2 Minggu */}
          <button
            type="button"
            onClick={() => onChange(twoWeeksDate)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 border transition-all cursor-pointer ${
              is2Weeks
                ? style.activeButton
                : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title={`Jatuh tempo 2 minggu ke depan (${twoWeeksDate})`}
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>2 Minggu</span>
            {is2Weeks && <Check className="w-3 h-3 ml-0.5" />}
          </button>

          {/* Preset: 1 Bulan */}
          <button
            type="button"
            onClick={() => onChange(oneMonthDate)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 border transition-all cursor-pointer ${
              is1Month
                ? style.activeButton
                : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title={`Jatuh tempo 1 bulan ke depan (${oneMonthDate})`}
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>1 Bulan</span>
            {is1Month && <Check className="w-3 h-3 ml-0.5" />}
          </button>

          {/* Preset: 2 Bulan */}
          <button
            type="button"
            onClick={() => onChange(twoMonthsDate)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 border transition-all cursor-pointer ${
              is2Months
                ? style.activeButton
                : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            title={`Jatuh tempo 2 bulan ke depan (${twoMonthsDate})`}
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>2 Bulan</span>
            {is2Months && <Check className="w-3 h-3 ml-0.5" />}
          </button>
        </div>
      </div>

      {/* Input or Banner based on unlimited / custom date */}
      {isUnlimited ? (
        <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-cyan-300">
            <InfinityIcon className="w-4 h-4 text-cyan-400 shrink-0" />
            <div>
              <p className="font-semibold text-white">Batas Jatuh Tempo Tidak Terbatas</p>
              <p className="text-[11px] text-cyan-300/80">
                Faktur tidak akan memicu peringatan jatuh tempo atau denda keterlambatan di dasbor.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onChange(twoWeeksDate)}
            className="shrink-0 px-2.5 py-1 text-[11px] font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 rounded-lg transition-all"
          >
            Atur Tanggal
          </button>
        </div>
      ) : (
        <div className="space-y-1.5">
          <div className="relative">
            <input
              type="date"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={`w-full px-3 py-2 bg-slate-950 border rounded-lg text-xs font-mono focus:outline-none transition-all ${style.inputBorder}`}
            />
          </div>
          <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
            <span>
              Terhitung: <strong className="text-slate-300">{formatDateIndo(value)}</strong>
            </span>
            <button
              type="button"
              onClick={() => onChange('tidak_terbatas')}
              className="text-cyan-400 hover:text-cyan-300 underline font-medium"
            >
              Ubah ke Tidak Terbatas
            </button>
          </div>
        </div>
      )}

      {helperText && !compact && !isUnlimited && (
        <p className="text-[10px] text-slate-500">
          {helperText}
        </p>
      )}
    </div>
  );
};
