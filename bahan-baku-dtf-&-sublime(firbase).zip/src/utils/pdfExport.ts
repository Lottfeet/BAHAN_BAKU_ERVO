import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';

export interface PdfExportOptions {
  orientation?: 'portrait' | 'landscape';
  format?: 'a4';
  marginMm?: number;
  scale?: number;
  quality?: number;
  includePageNumbers?: boolean;
  documentTitle?: string;
  customWidthPx?: number;
  footerText?: string;
}

/**
 * Helper to convert any modern CSS color (oklch, oklab, color(), etc.)
 * into standard sRGB (rgb/rgba/hex) using the browser canvas context.
 */
function sanitizeColorToSrgb(colorValue: string, ctx: CanvasRenderingContext2D | null): string {
  if (!colorValue || (!colorValue.includes('oklch') && !colorValue.includes('oklab') && !colorValue.includes('color('))) {
    return colorValue;
  }
  if (!ctx) return colorValue;

  try {
    ctx.fillStyle = '#000000'; // reset
    ctx.fillStyle = colorValue;
    const srgb = ctx.fillStyle;
    return srgb || colorValue;
  } catch {
    return colorValue;
  }
}

/**
 * Traverses a DOM tree and sanitizes any computed or inline colors containing modern color models
 * into standard sRGB values to guarantee 100% compatibility with html2canvas and PDF rendering.
 */
function sanitizeDomColors(rootElement: HTMLElement) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const colorProperties = [
    'color',
    'backgroundColor',
    'borderColor',
    'borderTopColor',
    'borderRightColor',
    'borderBottomColor',
    'borderLeftColor',
    'outlineColor',
    'boxShadow',
    'fill',
    'stroke',
  ];

  const elements = [rootElement, ...Array.from(rootElement.querySelectorAll<HTMLElement | SVGElement>('*'))];

  elements.forEach((node) => {
    if (!(node instanceof HTMLElement || node instanceof SVGElement)) return;

    try {
      const computed = window.getComputedStyle(node);
      for (const prop of colorProperties) {
        const cssProp = prop.replace(/([A-Z])/g, '-$1').toLowerCase();
        const value = computed.getPropertyValue(cssProp);

        if (value && (value.includes('oklch') || value.includes('oklab') || value.includes('color('))) {
          const converted = value.replace(/(oklch|oklab|color)\([^)]+\)/g, (match) => {
            return sanitizeColorToSrgb(match, ctx);
          });
          (node as HTMLElement).style?.setProperty(cssProp, converted, 'important');
        }
      }
    } catch {
      // Ignore access or security errors on specific nodes
    }
  });
}

/**
 * Exports an HTML element to a high-quality A4 PDF document and triggers download.
 * Features:
 * - ZERO live-DOM flicker or resizing: modifies only the cloned DOM inside html2canvas
 * - Clean portrait or landscape orientation
 * - High-DPI retina rendering (scale 2x)
 * - Intelligent single-page autofit (avoids accidental blank second page)
 * - True page-by-page slice generation for long documents (avoids overlapping/bleeding)
 * - Automatic page numbering (Halaman X dari Y)
 * - Color sanitization for modern CSS colors
 */
export async function exportElementToPdf(
  elementId: string, 
  filename: string,
  options: PdfExportOptions = {}
): Promise<boolean> {
  const element = document.getElementById(elementId);
  if (!element) {
    console.error(`[pdfExport] Element #${elementId} not found in DOM.`);
    return false;
  }

  const orientation = options.orientation || 'portrait';
  const marginMm = options.marginMm ?? 8;
  const scale = options.scale ?? 2;
  const quality = options.quality ?? 0.98;
  const includePageNumbers = options.includePageNumbers !== false;
  const footerNote = options.footerText || 'Sistem Gudang & Logistik Sablon DTF & Sublime';

  // Standard A4 dimensions in mm
  const isLandscape = orientation === 'landscape';
  const pdfPageWidth = isLandscape ? 297 : 210;
  const pdfPageHeight = isLandscape ? 210 : 297;
  
  // Standard pixel width for capturing at 96 DPI
  const targetWidthPx = options.customWidthPx || (isLandscape ? 1120 : 794);

  try {
    // IMPORTANT: DO NOT modify the live visible element in the DOM!
    // Instead, modify the cloned element inside the onclone callback.
    // This completely eliminates any visible resizing, shrinking, or "kembang-kempis" in the UI.

    const canvas = await html2canvas(element, {
      scale,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: Math.max(1280, targetWidthPx + 100),
      scrollY: 0,
      scrollX: 0,
      onclone: (_clonedDoc, clonedElement) => {
        if (clonedElement instanceof HTMLElement) {
          // Unconstrain and reset any offscreen/hidden parent in cloned DOM
          let parent = clonedElement.parentElement;
          if (parent) {
            parent.style.width = 'auto';
            parent.style.maxWidth = 'none';
            parent.style.overflow = 'visible';
            parent.style.padding = '0';
            parent.style.position = 'static';
            parent.style.left = '0';
            parent.style.top = '0';
            parent.style.opacity = '1';
            parent.style.visibility = 'visible';
            parent.style.pointerEvents = 'auto';
            parent.style.transform = 'none';
          }

          // Apply clean target dimensions to cloned element
          clonedElement.style.position = 'static';
          clonedElement.style.left = '0';
          clonedElement.style.top = '0';
          clonedElement.style.opacity = '1';
          clonedElement.style.visibility = 'visible';
          clonedElement.style.display = 'block';
          clonedElement.style.width = `${targetWidthPx}px`;
          clonedElement.style.minWidth = `${targetWidthPx}px`;
          clonedElement.style.maxWidth = `${targetWidthPx}px`;
          clonedElement.style.height = 'auto';
          clonedElement.style.minHeight = 'fit-content';
          clonedElement.style.maxHeight = 'none';
          clonedElement.style.overflow = 'visible';
          clonedElement.style.boxShadow = 'none';
          clonedElement.style.background = '#ffffff';
          clonedElement.style.transition = 'none';
          clonedElement.style.transform = 'none';
          clonedElement.style.animation = 'none';

          // Disable transitions on all children inside the clone
          const allDescendants = clonedElement.querySelectorAll('*');
          allDescendants.forEach((node) => {
            if (node instanceof HTMLElement) {
              node.style.transition = 'none';
              node.style.animation = 'none';
            }
          });

          sanitizeDomColors(clonedElement);
        }
      },
    });

    const contentWidthMm = pdfPageWidth - (marginMm * 2);
    // Reserve bottom 6mm for running footer if page numbers are enabled
    const footerSpaceMm = includePageNumbers ? 6 : 0;
    const pageAvailableHeightMm = pdfPageHeight - (marginMm * 2) - footerSpaceMm;

    // Pixels per mm on the rendered canvas
    const pxPerMm = canvas.width / contentWidthMm;
    const pageHeightPx = Math.floor(pageAvailableHeightMm * pxPerMm);

    // If within 5% tolerance of single page, fit onto 1 single page
    const singlePageTolerancePx = Math.floor(pageHeightPx * 0.05);
    const isSinglePageFit = canvas.height <= (pageHeightPx + singlePageTolerancePx);

    const pdf = new jsPDF({
      orientation,
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    if (isSinglePageFit) {
      // Single page document: render cleanly
      const contentHeightMm = (canvas.height / canvas.width) * contentWidthMm;
      // If content slightly exceeds available height, scale proportionally to fit page cleanly
      const finalHeightMm = Math.min(pageAvailableHeightMm, contentHeightMm);
      const finalWidthMm = (finalHeightMm / contentHeightMm) * contentWidthMm;
      const offsetX = marginMm + (contentWidthMm - finalWidthMm) / 2;

      const imgData = canvas.toDataURL('image/jpeg', quality);
      pdf.addImage(imgData, 'JPEG', offsetX, marginMm, finalWidthMm, finalHeightMm);

      if (includePageNumbers) {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(8);
        pdf.setTextColor(100, 116, 139);
        pdf.text(`${footerNote} • Halaman 1 dari 1`, marginMm, pdfPageHeight - 3.5);
        const printTime = new Date().toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
        pdf.text(`Waktu Cetak: ${printTime}`, pdfPageWidth - marginMm, pdfPageHeight - 3.5, { align: 'right' });
      }
    } else {
      // Multi-page document: slice page-by-page cleanly
      const totalPages = Math.ceil(canvas.height / pageHeightPx);

      for (let pageIndex = 0; pageIndex < totalPages; pageIndex++) {
        const sourceY = Math.floor(pageIndex * pageHeightPx);
        const currentSliceHeightPx = Math.min(pageHeightPx, canvas.height - sourceY);
        if (currentSliceHeightPx <= 0) break;

        const sliceCanvas = document.createElement('canvas');
        sliceCanvas.width = canvas.width;
        sliceCanvas.height = currentSliceHeightPx;
        const sliceCtx = sliceCanvas.getContext('2d');

        if (sliceCtx) {
          sliceCtx.fillStyle = '#ffffff';
          sliceCtx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
          sliceCtx.drawImage(
            canvas,
            0, sourceY, canvas.width, currentSliceHeightPx,
            0, 0, canvas.width, currentSliceHeightPx
          );
        }

        const sliceImgData = sliceCanvas.toDataURL('image/jpeg', quality);
        const sliceHeightMm = (currentSliceHeightPx / canvas.width) * contentWidthMm;

        if (pageIndex > 0) {
          pdf.addPage([pdfPageWidth, pdfPageHeight], orientation);
        }

        pdf.addImage(sliceImgData, 'JPEG', marginMm, marginMm, contentWidthMm, sliceHeightMm);

        if (includePageNumbers) {
          pdf.setFont('helvetica', 'normal');
          pdf.setFontSize(8);
          pdf.setTextColor(100, 116, 139);
          pdf.text(`${footerNote} • Halaman ${pageIndex + 1} dari ${totalPages}`, marginMm, pdfPageHeight - 3.5);
          const printTime = new Date().toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
          pdf.text(`Waktu Cetak: ${printTime}`, pdfPageWidth - marginMm, pdfPageHeight - 3.5, { align: 'right' });
        }
      }
    }

    const cleanFilename = filename.toLowerCase().endsWith('.pdf') ? filename : `${filename}.pdf`;
    pdf.save(cleanFilename);
    return true;
  } catch (error) {
    console.error('[pdfExport] Failed to generate PDF:', error);
    return false;
  }
}

/**
 * Triggers standard browser window.print() with specific document active class
 * and dynamic @page orientation support.
 */
export function printElementDirect(
  elementId: string, 
  orientation: 'portrait' | 'landscape' = 'portrait'
): void {
  const className = `printing-${elementId}`;
  const orientationClass = orientation === 'landscape' ? 'print-landscape' : 'print-portrait';
  document.body.classList.add(className, orientationClass);

  // Inject temporary @page size override for browser printer dialog
  const styleEl = document.createElement('style');
  styleEl.id = 'dynamic-print-orientation-style';
  styleEl.innerHTML = `@page { size: A4 ${orientation}; margin: 8mm; }`;
  document.head.appendChild(styleEl);
  
  const cleanup = () => {
    document.body.classList.remove(className, orientationClass);
    const existing = document.getElementById('dynamic-print-orientation-style');
    if (existing) existing.remove();
    window.removeEventListener('afterprint', cleanup);
  };
  
  window.addEventListener('afterprint', cleanup);

  try {
    window.print();
  } catch (e) {
    console.error('[pdfExport] window.print failed:', e);
  }

  // Fallback cleanup in case afterprint does not fire
  setTimeout(cleanup, 2500);
}
