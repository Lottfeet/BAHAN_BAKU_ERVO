// Helpers for formatting, Web Audio chime, and local storage

export function formatRupiah(amount: number): string {
  const safe = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(safe);
}

export function formatDateIndo(dateStr: string): string {
  try {
    let d: Date;
    const matchSimple = typeof dateStr === 'string' && dateStr.trim().match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::(\d{2}))?$/);
    if (matchSimple) {
      d = new Date(`${matchSimple[1]}T${matchSimple[2]}:${matchSimple[3] || '00'}Z`);
    } else {
      d = new Date(dateStr);
    }
    if (isNaN(d.getTime())) return dateStr;
    return new Intl.DateTimeFormat('id-ID', {
      timeZone: 'Asia/Jakarta',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(d);
  } catch {
    return dateStr;
  }
}

/**
 * Format any timestamp string or Date object to Western Indonesian Time (WIB, UTC+7).
 * Accurately parses:
 * - UTC strings created without timezone (e.g., "2026-10-08 14:40:50" or "2026-10-08 14:40")
 * - ISO strings (e.g., "2026-10-08T14:40:50.000Z")
 * - Formatted strings that already have "WIB"
 *
 * Example output: "2026-10-08 21:40:50 WIB" or "2026-10-08 21:40 WIB"
 */
export function formatTimestampWIB(raw?: string | Date | number | null, withSuffix: boolean = true): string {
  if (!raw) return '-';
  if (typeof raw === 'string' && raw.includes('WIB')) {
    return withSuffix ? raw : raw.replace(' WIB', '');
  }

  let d: Date;
  let hasSeconds = true;

  if (raw instanceof Date) {
    d = raw;
  } else if (typeof raw === 'number') {
    d = new Date(raw);
  } else if (typeof raw === 'string') {
    const trimmed = raw.trim();
    // Check if format is 'YYYY-MM-DD HH:mm:ss' or 'YYYY-MM-DD HH:mm'
    const matchSimple = trimmed.match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::(\d{2}))?$/);
    if (matchSimple) {
      hasSeconds = Boolean(matchSimple[3]);
      // Generated without offset via toISOString().replace('T', ' '), meaning it is UTC!
      d = new Date(`${matchSimple[1]}T${matchSimple[2]}:${matchSimple[3] || '00'}Z`);
    } else {
      d = new Date(trimmed);
      hasSeconds = trimmed.length > 16;
    }
  } else {
    return String(raw);
  }

  if (isNaN(d.getTime())) return String(raw);

  try {
    const formatted = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: hasSeconds ? '2-digit' : undefined,
      hour12: false,
    }).format(d);

    return withSuffix ? `${formatted} WIB` : formatted;
  } catch {
    return String(raw);
  }
}

/**
 * Returns current timestamp in Western Indonesian Time (WIB, UTC+7).
 * Example: "2026-10-08 21:40:50" or with suffix "2026-10-08 21:40:50 WIB"
 */
export function getWIBNow(includeSeconds: boolean = true, withSuffix: boolean = false): string {
  const d = new Date();
  try {
    const formatted = new Intl.DateTimeFormat('sv-SE', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: includeSeconds ? '2-digit' : undefined,
      hour12: false,
    }).format(d);
    return withSuffix ? `${formatted} WIB` : formatted;
  } catch {
    const utc = d.getTime() + d.getTimezoneOffset() * 60000;
    const wib = new Date(utc + 7 * 3600000);
    const iso = wib.toISOString().replace('T', ' ');
    const res = includeSeconds ? iso.slice(0, 19) : iso.slice(0, 16);
    return withSuffix ? `${res} WIB` : res;
  }
}

/**
 * Returns current date string in WIB (e.g. "2026-10-08")
 */
export function getWIBDateOnly(): string {
  return getWIBNow(false).slice(0, 10);
}

export function playPushNotificationSound() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }
    
    // Play a friendly dual-tone mobile push chime
    const now = ctx.currentTime;
    
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5
    
    gain1.gain.setValueAtTime(0.2, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
    
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    
    osc1.start(now);
    osc1.stop(now + 0.35);

    // Second harmonic ping
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1046.5, now + 0.1); // C6
    gain2.gain.setValueAtTime(0.15, now + 0.1);
    gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
    
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    
    osc2.start(now + 0.1);
    osc2.stop(now + 0.45);
  } catch (e) {
    console.debug('Audio play not allowed or unsupported:', e);
  }
}

export function isBrowserNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export function getBrowserNotificationPermission(): NotificationPermission | 'unsupported' {
  if (!isBrowserNotificationSupported()) {
    return 'unsupported';
  }
  return Notification.permission;
}

export async function requestAndSendBrowserNotification(title: string, body: string) {
  if (!('Notification' in window)) {
    return false;
  }

  try {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
      });
      return true;
    } else if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
        return true;
      }
    }
  } catch (e) {
    console.debug('Browser push notification error:', e);
  }
  return false;
}

export function exportToCSV(filename: string, rows: (string | number)[][]) {
  const processRow = (row: (string | number)[]) => {
    let finalVal = '';
    for (let j = 0; j < row.length; j++) {
      let innerValue = row[j] === null || row[j] === undefined ? '' : row[j].toString();
      let result = innerValue.replace(/"/g, '""');
      if (result.search(/("|,|\n)/g) >= 0) result = '"' + result + '"';
      if (j > 0) finalVal += ',';
      finalVal += result;
    }
    return finalVal + '\n';
  };

  let csvFile = '\uFEFF'; // UTF-8 BOM
  for (let i = 0; i < rows.length; i++) {
    csvFile += processRow(rows[i]);
  }

  const blob = new Blob([csvFile], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
}

export interface InvoiceDueInfo {
  unpaidAmount: number;
  isPaid: boolean;
  diffDays: number;
  isOverdue: boolean;
  isDueToday: boolean;
  isUpcoming: boolean; // within 3 days
  statusLabel: string;
  badgeClass: string;
}

export function formatDueDateIndo(dueDateStr?: string): string {
  if (
    !dueDateStr ||
    dueDateStr === 'unlimited' ||
    dueDateStr === 'tidak_terbatas' ||
    dueDateStr === '9999-12-31' ||
    dueDateStr === '-' ||
    dueDateStr.toLowerCase().includes('tidak terbatas')
  ) {
    return 'Tidak Terbatas';
  }
  return dueDateStr;
}

export function calculateQuickDueDate(
  type: 'unlimited' | '2_weeks' | '1_month' | '2_months',
  baseDate?: Date | string
): string {
  if (type === 'unlimited') {
    return 'tidak_terbatas';
  }
  const d = baseDate ? (typeof baseDate === 'string' ? new Date(baseDate) : new Date(baseDate)) : new Date();
  if (isNaN(d.getTime())) {
    d.setTime(Date.now());
  }

  if (type === '2_weeks') {
    d.setDate(d.getDate() + 14);
  } else if (type === '1_month') {
    d.setMonth(d.getMonth() + 1);
  } else if (type === '2_months') {
    d.setMonth(d.getMonth() + 2);
  }

  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getInvoiceDueInfo(
  invoice: { grandTotal: number; paidAmount: number; paymentStatus: 'lunas' | 'belum_lunas' | 'dp'; dueDate: string },
  referenceDateStr?: string
): InvoiceDueInfo {
  const unpaidAmount = Math.max(0, invoice.grandTotal - invoice.paidAmount);
  const isPaid = invoice.paymentStatus === 'lunas' || unpaidAmount <= 0;

  if (isPaid) {
    return {
      unpaidAmount: 0,
      isPaid: true,
      diffDays: 999,
      isOverdue: false,
      isDueToday: false,
      isUpcoming: false,
      statusLabel: 'Lunas',
      badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    };
  }

  // Handle unlimited / unrestricted due date
  if (
    !invoice.dueDate ||
    invoice.dueDate === 'unlimited' ||
    invoice.dueDate === 'tidak_terbatas' ||
    invoice.dueDate === '9999-12-31' ||
    invoice.dueDate === '-' ||
    invoice.dueDate.toLowerCase().includes('tidak terbatas')
  ) {
    return {
      unpaidAmount,
      isPaid: false,
      diffDays: 9999,
      isOverdue: false,
      isDueToday: false,
      isUpcoming: false,
      statusLabel: 'Tidak Terbatas',
      badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    };
  }

  // Parse reference date (default to today at 00:00:00)
  const now = referenceDateStr ? new Date(referenceDateStr) : new Date();
  const refDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  // Parse due date
  const dueParts = invoice.dueDate.split('-');
  let dueDateObj: Date;
  if (dueParts.length === 3) {
    dueDateObj = new Date(Number(dueParts[0]), Number(dueParts[1]) - 1, Number(dueParts[2]));
  } else {
    dueDateObj = new Date(invoice.dueDate);
  }

  if (isNaN(dueDateObj.getTime())) {
    return {
      unpaidAmount,
      isPaid: false,
      diffDays: 9999,
      isOverdue: false,
      isDueToday: false,
      isUpcoming: false,
      statusLabel: 'Tidak Terbatas',
      badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
    };
  }

  const diffTime = dueDateObj.getTime() - refDate.getTime();
  const diffDays = Math.round(diffTime / (1000 * 3600 * 24));

  const isOverdue = diffDays < 0;
  const isDueToday = diffDays === 0;
  const isUpcoming = diffDays > 0 && diffDays <= 3;

  let statusLabel = '';
  let badgeClass = '';

  if (isOverdue) {
    const daysLate = Math.abs(diffDays);
    statusLabel = `Lewat ${daysLate} Hari`;
    badgeClass = 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse';
  } else if (isDueToday) {
    statusLabel = 'Jatuh Tempo Hari Ini';
    badgeClass = 'bg-amber-500/20 text-amber-300 border-amber-500/40';
  } else if (isUpcoming) {
    statusLabel = `Sisa ${diffDays} Hari`;
    badgeClass = 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40';
  } else {
    statusLabel = `${diffDays} Hari Lagi`;
    badgeClass = 'bg-slate-800 text-slate-300 border-slate-700';
  }

  return {
    unpaidAmount,
    isPaid: false,
    diffDays,
    isOverdue,
    isDueToday,
    isUpcoming,
    statusLabel,
    badgeClass,
  };
}

export function generateInvoiceWaReminder(invoice: {
  invoiceNumber: string;
  customerName: string;
  grandTotal: number;
  paidAmount: number;
  dueDate: string;
}): string {
  const unpaid = Math.max(0, invoice.grandTotal - invoice.paidAmount);
  const dueFormatted = formatDueDateIndo(invoice.dueDate);
  return `Halo Kak ${invoice.customerName}, kami dari Gudang Sablon DTF & Sublimasi ingin mengingatkan perihal tagihan pesanan bahan baku:

• No. Invoice: *${invoice.invoiceNumber}*
• Total Tagihan: *${formatRupiah(invoice.grandTotal)}*
${invoice.paidAmount > 0 ? `• Sudah Dibayar (DP): ${formatRupiah(invoice.paidAmount)}\n` : ''}• Sisa Pelunasan: *${formatRupiah(unpaid)}*
• Jatuh Tempo: *${dueFormatted === 'Tidak Terbatas' ? 'Tidak Terbatas (Fleksibel)' : dueFormatted}*

Mohon bantuan untuk melakukan pelunasan ke rekening operasional gudang. Apabila sudah melakukan transfer, mohon kirimkan konfirmasi bukti transfer ya Kak. Terima kasih banyak atas kerjasamanya! 🙏`;
}

export function formatWaPhone(phone: string): string {
  let clean = phone.replace(/\D/g, '');
  if (clean.startsWith('0')) {
    clean = '62' + clean.slice(1);
  } else if (!clean.startsWith('62')) {
    clean = '62' + clean;
  }
  return clean;
}

export function generatePaymentHistoryWaMessage(invoice: {
  invoiceNumber: string;
  customerName: string;
  grandTotal: number;
  paidAmount: number;
  paymentStatus: string;
  paymentHistory?: { date: string; amount: number; paymentMethod: string; referenceNumber?: string; notes?: string }[];
}): string {
  const unpaid = Math.max(0, invoice.grandTotal - invoice.paidAmount);
  const statusStr = invoice.paidAmount >= invoice.grandTotal ? 'LUNAS' : invoice.paidAmount > 0 ? 'SEBAGIAN / CICILAN' : 'BELUM DIBAYAR';
  
  let historyText = '';
  if (invoice.paymentHistory && invoice.paymentHistory.length > 0) {
    historyText = '\n*Rincian Riwayat Pembayaran:*\n' + invoice.paymentHistory.map((p, idx) => 
      `${idx + 1}. ${p.date.slice(0, 16)} • ${p.paymentMethod}: *${formatRupiah(p.amount)}*${p.referenceNumber ? ` [Ref: ${p.referenceNumber}]` : ''}${p.notes ? ` (${p.notes})` : ''}`
    ).join('\n') + '\n';
  }

  return `Halo Kak ${invoice.customerName}, berikut kami kirimkan rincian bukti & histori pembayaran untuk pesanan bahan baku:

📋 *No. Invoice:* ${invoice.invoiceNumber}
💰 *Total Tagihan:* ${formatRupiah(invoice.grandTotal)}
✅ *Total Terbayar:* ${formatRupiah(invoice.paidAmount)}
${unpaid > 0 ? `⚠️ *Sisa Tagihan:* *${formatRupiah(unpaid)}*\n` : ''}📌 *Status:* *${statusStr}*
${historyText}
Terima kasih banyak atas kepercayaannya berbelanja di Gudang DTF & Sublime Pro! 🙏`;
}

export function generateCustomerConsolidatedWaReminder(
  customerName: string,
  invoices: {
    invoiceNumber: string;
    date: string;
    dueDate: string;
    grandTotal: number;
    paidAmount: number;
  }[],
  companyName = 'Gudang DTF & Sublime'
): string {
  const totalBill = invoices.reduce((acc, inv) => acc + inv.grandTotal, 0);
  const totalPaid = invoices.reduce((acc, inv) => acc + inv.paidAmount, 0);
  const totalUnpaid = Math.max(0, totalBill - totalPaid);

  const invoiceLines = invoices
    .map((inv, idx) => {
      const sisa = Math.max(0, inv.grandTotal - inv.paidAmount);
      return `${idx + 1}. *${inv.invoiceNumber}* (Tgl: ${inv.date} • Tempo: ${inv.dueDate})\n   - Total: ${formatRupiah(inv.grandTotal)} | Terbayar: ${formatRupiah(inv.paidAmount)}\n   - *Sisa: ${formatRupiah(sisa)}*`;
    })
    .join('\n\n');

  return `Halo Kak ${customerName}, kami dari *${companyName}* ingin menyampaikan ringkasan rekapitulasi tagihan/piutang berjalan Anda:

📋 *Daftar Faktur Belum Lunas (${invoices.length} Faktur):*
${invoiceLines}

━━━━━━━━━━━━━━━━━━━━━
💰 *Total Tagihan:* ${formatRupiah(totalBill)}
✅ *Total Terbayar (DP/Cicilan):* ${formatRupiah(totalPaid)}
🚨 *TOTAL SISA PIUTANG:* *${formatRupiah(totalUnpaid)}*
━━━━━━━━━━━━━━━━━━━━━

Mohon bantuannya untuk melakukan pelunasan ke rekening operasional gudang kami. Apabila sudah transfer, mohon lampirkan bukti pembayarannya ya Kak. Terima kasih banyak atas kerjasamanya! 🙏`;
}


