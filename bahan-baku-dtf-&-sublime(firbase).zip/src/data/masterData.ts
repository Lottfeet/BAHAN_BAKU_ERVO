import { CategoryItem, Product, SupplierItem, CustomerItem } from '../types';

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  {
    id: 'dtf',
    name: 'Bahan DTF (Film, Tinta, Powder)',
    prefix: 'DTF',
    icon: '🔥',
    description: 'Film PET Roll/Sheet, Tinta DTF CMYK & White, Hotmelt Adhesive Powder',
  },
  {
    id: 'sublime',
    name: 'Bahan Sublimasi (Tinta & Kertas)',
    prefix: 'SUB',
    icon: '🖨️',
    description: 'Tinta Dye Sublimation, Kertas Sublim Roll 100gsm/Lembar A3/A4',
  },
  {
    id: 'cleaning',
    name: 'Head Cleaner & Perawatan',
    prefix: 'CLN',
    icon: '🧪',
    description: 'Cairan pembersih printhead, wiper blade, swab busa lint-free, capping',
  },
  {
    id: 'consumable',
    name: 'Perlengkapan & Consumable',
    prefix: 'CNS',
    icon: '🛠️',
    description: 'Lakban anti panas, lembaran teflon sheet, sarung tangan anti panas',
  },
];

export const DEFAULT_UNITS: string[] = [
  'Botol (1 Liter)',
  'Botol (500 ml)',
  'Kg',
  'Roll (100 Meter)',
  'Roll (50 Meter)',
  'Pack (100 Lembar)',
  'Pcs',
  'Meter',
  'Lembar',
  'Set',
  'Dus / Karton',
];

export const DEFAULT_LOCATIONS: string[] = [
  'Gudang Utama - Rak A1',
  'Gudang Utama - Rak A2',
  'Gudang Utama - Rak B1',
  'Gudang Utama - Rak B2',
  'Gudang Utama - Rak C1',
  'Gudang Utama - Rak C2',
  'Lemari Kimia Clean',
  'Lantai Palet 1',
  'Ruang Mesin Press',
];

export const DEFAULT_SUPPLIERS: SupplierItem[] = [];

export const DEFAULT_CUSTOMERS: CustomerItem[] = [];

export const DEFAULT_DIVISIONS: string[] = [
  'Divisi Sablon DTF Kaos',
  'Divisi Printing & Finishing Jersey',
  'Divisi Merchandise & Souvenir',
  'Divisi Bordir & Finishing',
  'Divisi Konveksi & Pola Kaos',
  'Divisi Quality Control & Packing',
  'Workshop Sampling & Percobaan',
];

/**
 * Generate automatic sequential material code based on category and current products
 */
export function generateAutoProductCode(
  categoryId: string,
  products: Product[],
  categories: CategoryItem[]
): string {
  const safeCatId = categoryId || '';
  const category = (categories || []).find((c) => c.id === safeCatId);
  let prefix = category?.prefix?.toUpperCase().trim();
  if (!prefix) {
    prefix = safeCatId.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 3);
  }
  prefix = prefix.replace(/[^A-Z0-9]/g, '') || 'ITM';

  const existingCodes = (products || []).map((p) => (p.code || '').toUpperCase());

  let maxNum = 0;
  (products || []).forEach((p) => {
    const code = (p.code || '').toUpperCase();
    if (code.startsWith(prefix) || p.category === safeCatId) {
      const match = code.match(/(\d+)/g);
      if (match) {
        const lastNum = parseInt(match[match.length - 1], 10);
        if (!isNaN(lastNum) && lastNum > maxNum) {
          maxNum = lastNum;
        }
      }
    }
  });

  const categoryItemCount = (products || []).filter(
    (p) => p.category === safeCatId || (p.code || '').toUpperCase().startsWith(prefix)
  ).length;

  let candidateNum = Math.max(maxNum + 1, categoryItemCount + 1, 1);
  let candidateCode = `${prefix}-${String(candidateNum).padStart(3, '0')}`;

  // Ensure uniqueness
  while (existingCodes.includes(candidateCode)) {
    candidateNum++;
    candidateCode = `${prefix}-${String(candidateNum).padStart(3, '0')}`;
  }

  return candidateCode;
}
