<?php
/**
 * ====================================================================
 * KONFIGURASI KONEKSI DATABASE MYSQL & CPANEL
 * Aplikasi: Gudang Stok DTF & Sublime Pro
 * ====================================================================
 * Petunjuk pengaturan di cPanel:
 * 1. Buka cPanel > "MySQL® Databases"
 * 2. Buat database baru (misal: usernamecpanel_dtfgudang)
 * 3. Buat user MySQL baru & password (misal: usernamecpanel_dbuser)
 * 4. Tambahkan user ke database dengan hak akses "ALL PRIVILEGES"
 * 5. Buka phpMyAdmin > pilih database tersebut > klik tab "Import" > pilih file database.sql
 * 6. Ubah variabel di bawah ini sesuai nama database, user, dan password Anda:
 */

// Header CORS agar frontend dapat berkomunikasi lancar
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Tangani Preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// --------------------------------------------------------------------
// SILAKAN SESUAIKAN KREDENSIAL DATABASE CPANEL ANDA DI SINI:
// --------------------------------------------------------------------
$db_host = 'localhost';          // Host database cPanel (umumnya 'localhost')
$db_name = 'u1234567_dtfgudang'; // Ganti dengan Nama Database cPanel Anda
$db_user = 'u1234567_dbuser';    // Ganti dengan Username Database cPanel Anda
$db_pass = 'PasswordDBAnda123';  // Ganti dengan Password Database cPanel Anda

try {
    $pdo = new PDO("mysql:host={$db_host};dbname={$db_name};charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error_type' => 'DB_CONNECTION_FAILED',
        'message' => 'Gagal terhubung ke MySQL: ' . $e->getMessage(),
        'hint' => 'Silakan buka file api/config.php di cPanel File Manager dan sesuaikan $db_name, $db_user, serta $db_pass sesuai database phpMyAdmin Anda.'
    ]);
    exit();
}
