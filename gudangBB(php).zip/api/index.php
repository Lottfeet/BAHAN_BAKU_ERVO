<?php
/**
 * ====================================================================
 * REST API ROUTER & CONTROLLER UNTUK CPANEL & MYSQL (PHPMYADMIN)
 * Aplikasi: Gudang Stok DTF & Sublime Pro
 * ====================================================================
 */

require_once __DIR__ . '/config.php';

// Auto-Migration Self-Healing: Pastikan kolom email pada tabel users nullable dan tidak memiliki batasan UNIQUE yang merusak
try {
    if (isset($pdo)) {
        $colStmt = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'email'")->fetch();
        if ($colStmt && strtoupper($colStmt['Null'] ?? '') !== 'YES') {
            $pdo->exec("ALTER TABLE `users` MODIFY `email` VARCHAR(150) DEFAULT NULL");
        }
        $idxStmt = $pdo->query("SHOW INDEX FROM `users` WHERE Column_name = 'email' AND Non_unique = 0")->fetchAll();
        foreach ($idxStmt as $idx) {
            $keyName = $idx['Key_name'] ?? '';
            if ($keyName && $keyName !== 'PRIMARY') {
                $pdo->exec("ALTER TABLE `users` DROP INDEX `{$keyName}`");
                $pdo->exec("ALTER TABLE `users` ADD INDEX `idx_users_email` (`email`)");
            }
        }
    }
} catch (Exception $e) {
    // Abaikan jika tabel belum ada
}

$action = isset($_GET['action']) ? trim($_GET['action']) : '';
$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true);

// Helper untuk respons JSON konsisten
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

// ====================================================================
// REUSABLE ROW INSERTER HELPERS
// ====================================================================

function upsertProduct($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO products (id, code, name, category, unit, current_stock, min_stock_alert, cost_price, selling_price, description, location, last_updated)
        VALUES (:id, :code, :name, :category, :unit, :current_stock, :min_stock_alert, :cost_price, :selling_price, :description, :location, :last_updated)
        ON DUPLICATE KEY UPDATE 
        code=VALUES(code), name=VALUES(name), category=VALUES(category), unit=VALUES(unit),
        current_stock=VALUES(current_stock), min_stock_alert=VALUES(min_stock_alert),
        cost_price=VALUES(cost_price), selling_price=VALUES(selling_price),
        description=VALUES(description), location=VALUES(location), last_updated=VALUES(last_updated)");
    $stmt->execute([
        ':id' => $item['id'],
        ':code' => $item['code'] ?? '',
        ':name' => $item['name'] ?? '',
        ':category' => $item['category'] ?? '',
        ':unit' => $item['unit'] ?? 'Roll',
        ':current_stock' => $item['currentStock'] ?? 0,
        ':min_stock_alert' => $item['minStockAlert'] ?? 0,
        ':cost_price' => $item['costPrice'] ?? 0,
        ':selling_price' => $item['sellingPrice'] ?? 0,
        ':description' => $item['description'] ?? '',
        ':location' => $item['location'] ?? 'Gudang Utama',
        ':last_updated' => $item['lastUpdated'] ?? date('Y-m-d H:i:s')
    ]);
}

function upsertMovement($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO movements (id, date, product_id, product_name, product_code, category, type, quantity, unit, previous_stock, final_stock, reference_no, notes, total_value, supplier_name, unit_price, recipient_name, division_or_requester, billing_required, payment_status, payment_method, paid_amount, billing_due_date, paid_at, performed_by)
        VALUES (:id, :date, :product_id, :product_name, :product_code, :category, :type, :quantity, :unit, :previous_stock, :final_stock, :reference_no, :notes, :total_value, :supplier_name, :unit_price, :recipient_name, :division_or_requester, :billing_required, :payment_status, :payment_method, :paid_amount, :billing_due_date, :paid_at, :performed_by)
        ON DUPLICATE KEY UPDATE 
        date=VALUES(date), product_name=VALUES(product_name), quantity=VALUES(quantity), final_stock=VALUES(final_stock), total_value=VALUES(total_value), payment_status=VALUES(payment_status), paid_amount=VALUES(paid_amount), paid_at=VALUES(paid_at), notes=VALUES(notes)");
    $stmt->execute([
        ':id' => $item['id'],
        ':date' => $item['date'] ?? date('Y-m-d H:i:s'),
        ':product_id' => $item['productId'] ?? '',
        ':product_name' => $item['productName'] ?? '',
        ':product_code' => $item['productCode'] ?? '',
        ':category' => $item['category'] ?? '',
        ':type' => $item['type'] ?? 'production',
        ':quantity' => $item['quantity'] ?? 0,
        ':unit' => $item['unit'] ?? 'Pcs',
        ':previous_stock' => $item['previousStock'] ?? 0,
        ':final_stock' => $item['finalStock'] ?? 0,
        ':reference_no' => $item['referenceNo'] ?? '',
        ':notes' => $item['notes'] ?? '',
        ':total_value' => $item['totalValue'] ?? 0,
        ':supplier_name' => $item['supplierName'] ?? null,
        ':unit_price' => $item['unitPrice'] ?? 0,
        ':recipient_name' => $item['recipientName'] ?? null,
        ':division_or_requester' => $item['divisionOrRequester'] ?? null,
        ':billing_required' => !empty($item['billingRequired']) ? 1 : 0,
        ':payment_status' => $item['paymentStatus'] ?? 'beban_internal',
        ':payment_method' => $item['paymentMethod'] ?? null,
        ':paid_amount' => $item['paidAmount'] ?? 0,
        ':billing_due_date' => $item['billingDueDate'] ?? null,
        ':paid_at' => $item['paidAt'] ?? null,
        ':performed_by' => !empty($item['performedBy']) ? (is_string($item['performedBy']) ? $item['performedBy'] : json_encode($item['performedBy'], JSON_UNESCAPED_UNICODE)) : null,
    ]);
}

function upsertInvoice($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO invoices (id, invoice_number, date, due_date, customer_name, customer_phone, customer_address, items, subtotal, tax_percent, tax_amount, grand_total, payment_status, paid_amount, payment_method, payment_history, notes, created_by)
        VALUES (:id, :invoice_number, :date, :due_date, :customer_name, :customer_phone, :customer_address, :items, :subtotal, :tax_percent, :tax_amount, :grand_total, :payment_status, :paid_amount, :payment_method, :payment_history, :notes, :created_by)
        ON DUPLICATE KEY UPDATE 
        customer_name=VALUES(customer_name), customer_phone=VALUES(customer_phone), customer_address=VALUES(customer_address),
        items=VALUES(items), subtotal=VALUES(subtotal), tax_percent=VALUES(tax_percent), tax_amount=VALUES(tax_amount),
        grand_total=VALUES(grand_total), payment_status=VALUES(payment_status), paid_amount=VALUES(paid_amount),
        payment_method=VALUES(payment_method), payment_history=VALUES(payment_history), due_date=VALUES(due_date), notes=VALUES(notes)");
    $stmt->execute([
        ':id' => $item['id'],
        ':invoice_number' => $item['invoiceNumber'] ?? '',
        ':date' => $item['date'] ?? date('Y-m-d H:i:s'),
        ':due_date' => $item['dueDate'] ?? date('Y-m-d'),
        ':customer_name' => $item['customerName'] ?? '',
        ':customer_phone' => $item['customerPhone'] ?? null,
        ':customer_address' => $item['customerAddress'] ?? null,
        ':items' => is_string($item['items'] ?? null) ? $item['items'] : json_encode($item['items'] ?? [], JSON_UNESCAPED_UNICODE),
        ':subtotal' => $item['subtotal'] ?? 0,
        ':tax_percent' => $item['taxPercent'] ?? 0,
        ':tax_amount' => $item['taxAmount'] ?? 0,
        ':grand_total' => $item['grandTotal'] ?? 0,
        ':payment_status' => $item['paymentStatus'] ?? 'belum_lunas',
        ':paid_amount' => $item['paidAmount'] ?? 0,
        ':payment_method' => $item['paymentMethod'] ?? 'Tunai',
        ':payment_history' => is_string($item['paymentHistory'] ?? null) ? $item['paymentHistory'] : json_encode($item['paymentHistory'] ?? [], JSON_UNESCAPED_UNICODE),
        ':notes' => $item['notes'] ?? '',
        ':created_by' => !empty($item['createdBy']) ? (is_string($item['createdBy']) ? $item['createdBy'] : json_encode($item['createdBy'], JSON_UNESCAPED_UNICODE)) : null,
    ]);
}

function upsertCategory($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO categories (id, name, prefix, icon, description)
        VALUES (:id, :name, :prefix, :icon, :description)
        ON DUPLICATE KEY UPDATE name=VALUES(name), prefix=VALUES(prefix), icon=VALUES(icon), description=VALUES(description)");
    $stmt->execute([
        ':id' => $item['id'],
        ':name' => $item['name'] ?? '',
        ':prefix' => $item['prefix'] ?? '',
        ':icon' => $item['icon'] ?? null,
        ':description' => $item['description'] ?? null
    ]);
}

function upsertSupplier($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO suppliers (id, name, phone, address, notes)
        VALUES (:id, :name, :phone, :address, :notes)
        ON DUPLICATE KEY UPDATE name=VALUES(name), phone=VALUES(phone), address=VALUES(address), notes=VALUES(notes)");
    $stmt->execute([
        ':id' => $item['id'],
        ':name' => $item['name'] ?? '',
        ':phone' => $item['phone'] ?? null,
        ':address' => $item['address'] ?? null,
        ':notes' => $item['notes'] ?? null
    ]);
}

function upsertCustomer($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO customers (id, name, phone, address, notes, created_at)
        VALUES (:id, :name, :phone, :address, :notes, :created_at)
        ON DUPLICATE KEY UPDATE name=VALUES(name), phone=VALUES(phone), address=VALUES(address), notes=VALUES(notes)");
    $stmt->execute([
        ':id' => $item['id'],
        ':name' => $item['name'] ?? '',
        ':phone' => $item['phone'] ?? '',
        ':address' => $item['address'] ?? null,
        ':notes' => $item['notes'] ?? null,
        ':created_at' => $item['createdAt'] ?? date('Y-m-d')
    ]);
}

function upsertUser($pdo, $item) {
    $permissions = [];
    foreach ($item as $k => $v) {
        if (str_starts_with($k, 'can')) {
            $permissions[$k] = (bool)$v;
        }
    }
    if (!empty($item['permissions'])) {
        if (is_array($item['permissions'])) {
            $permissions = array_merge($permissions, $item['permissions']);
        } elseif (is_string($item['permissions'])) {
            $decoded = json_decode($item['permissions'], true);
            if (is_array($decoded)) {
                $permissions = array_merge($permissions, $decoded);
            }
        }
    }

    $email = !empty($item['email']) && trim($item['email']) !== '' ? trim($item['email']) : null;
    $role = $item['role'] ?? 'warehouse_admin';
    $roleTitle = $item['roleTitle'] ?? ($role === 'owner' ? 'Pemilik Usaha (Owner)' : 'Staff');
    $name = !empty($item['name']) ? trim($item['name']) : 'User';
    $password = !empty($item['password']) ? $item['password'] : '123456';
    $avatarColor = $item['avatarColor'] ?? 'bg-indigo-600';

    $stmt = $pdo->prepare("INSERT INTO users (id, name, role, role_title, email, password, avatar_color, permissions)
        VALUES (:id, :name, :role, :role_title, :email, :password, :avatar_color, :permissions)
        ON DUPLICATE KEY UPDATE 
            name=VALUES(name), 
            role=VALUES(role), 
            role_title=VALUES(role_title), 
            email=VALUES(email), 
            password=VALUES(password), 
            avatar_color=VALUES(avatar_color), 
            permissions=VALUES(permissions)");
    $stmt->execute([
        ':id' => $item['id'],
        ':name' => $name,
        ':role' => $role,
        ':role_title' => $roleTitle,
        ':email' => $email,
        ':password' => $password,
        ':avatar_color' => $avatarColor,
        ':permissions' => json_encode($permissions, JSON_UNESCAPED_UNICODE)
    ]);
}

function upsertLog($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO activity_logs (id, timestamp, user_id, user_name, user_role, user_role_title, action_type, title, details, severity)
        VALUES (:id, :timestamp, :user_id, :user_name, :user_role, :user_role_title, :action_type, :title, :details, :severity)
        ON DUPLICATE KEY UPDATE details=VALUES(details)");
    $stmt->execute([
        ':id' => $item['id'],
        ':timestamp' => $item['timestamp'] ?? date('Y-m-d H:i:s'),
        ':user_id' => $item['userId'] ?? 'user-1',
        ':user_name' => $item['userName'] ?? 'User',
        ':user_role' => $item['userRole'] ?? 'warehouse_admin',
        ':user_role_title' => $item['userRoleTitle'] ?? null,
        ':action_type' => $item['actionType'] ?? 'SYSTEM',
        ':title' => $item['title'] ?? '',
        ':details' => $item['details'] ?? '',
        ':severity' => $item['severity'] ?? 'info'
    ]);
}

function upsertNotification($pdo, $item) {
    $stmt = $pdo->prepare("INSERT INTO notifications (id, timestamp, title, message, type, read_status, meta)
        VALUES (:id, :timestamp, :title, :message, :type, :read_status, :meta)
        ON DUPLICATE KEY UPDATE read_status=VALUES(read_status)");
    $stmt->execute([
        ':id' => $item['id'],
        ':timestamp' => $item['timestamp'] ?? date('Y-m-d H:i:s'),
        ':title' => $item['title'] ?? '',
        ':message' => $item['message'] ?? '',
        ':type' => $item['type'] ?? 'system',
        ':read_status' => !empty($item['read']) ? 1 : 0,
        ':meta' => !empty($item['meta']) ? (is_string($item['meta']) ? $item['meta'] : json_encode($item['meta'], JSON_UNESCAPED_UNICODE)) : null
    ]);
}

function saveItemGeneric($pdo, $table, $item) {
    if ($table === 'products') upsertProduct($pdo, $item);
    elseif ($table === 'movements') upsertMovement($pdo, $item);
    elseif ($table === 'invoices') upsertInvoice($pdo, $item);
    elseif ($table === 'categories') upsertCategory($pdo, $item);
    elseif ($table === 'suppliers') upsertSupplier($pdo, $item);
    elseif ($table === 'customers') upsertCustomer($pdo, $item);
    elseif ($table === 'users') upsertUser($pdo, $item);
    elseif ($table === 'activity_logs') upsertLog($pdo, $item);
    elseif ($table === 'notifications') upsertNotification($pdo, $item);
}

// --------------------------------------------------------------------
// 1. ACTION: status (Cek Koneksi Database MySQL)
// --------------------------------------------------------------------
if ($action === 'status') {
    try {
        $stmt = $pdo->query("SELECT 
            (SELECT COUNT(*) FROM products) as products_count,
            (SELECT COUNT(*) FROM movements) as movements_count,
            (SELECT COUNT(*) FROM invoices) as invoices_count,
            (SELECT COUNT(*) FROM users) as users_count");
        $counts = $stmt->fetch();

        jsonResponse([
            'success' => true,
            'message' => 'Terhubung ke database MySQL cPanel (phpMyAdmin) dengan sukses!',
            'version' => 'v2.5-cpanel',
            'server_time' => date('Y-m-d H:i:s'),
            'database' => $db_name,
            'stats' => $counts
        ]);
    } catch (Exception $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Tabel belum siap atau terjadi galat: ' . $e->getMessage(),
            'hint' => 'Pastikan Anda telah mengimpor database.sql ke phpMyAdmin.'
        ], 500);
    }
}

// --------------------------------------------------------------------
// 2. ACTION: fetch_all (Ambil Seluruh Data Sistem Sekaligus)
// --------------------------------------------------------------------
if ($action === 'fetch_all') {
    try {
        // Products
        $stmt = $pdo->query("SELECT id, code, name, category, unit, current_stock as currentStock, min_stock_alert as minStockAlert, cost_price as costPrice, selling_price as sellingPrice, description, location, last_updated as lastUpdated FROM products");
        $products = $stmt->fetchAll();
        foreach ($products as &$p) {
            $p['currentStock'] = (float)$p['currentStock'];
            $p['minStockAlert'] = (float)$p['minStockAlert'];
            $p['costPrice'] = (float)$p['costPrice'];
            $p['sellingPrice'] = (float)$p['sellingPrice'];
        }

        // Movements
        $stmt = $pdo->query("SELECT id, date, product_id as productId, product_name as productName, product_code as productCode, category, type, quantity, unit, previous_stock as previousStock, final_stock as finalStock, reference_no as referenceNo, notes, total_value as totalValue, supplier_name as supplierName, unit_price as unitPrice, recipient_name as recipientName, division_or_requester as divisionOrRequester, billing_required as billingRequired, payment_status as paymentStatus, payment_method as paymentMethod, paid_amount as paidAmount, billing_due_date as billingDueDate, paid_at as paidAt, performed_by as performedBy FROM movements ORDER BY date DESC");
        $movements = $stmt->fetchAll();
        foreach ($movements as &$m) {
            $m['quantity'] = (float)$m['quantity'];
            $m['previousStock'] = (float)$m['previousStock'];
            $m['finalStock'] = (float)$m['finalStock'];
            $m['totalValue'] = (float)$m['totalValue'];
            $m['unitPrice'] = (float)$m['unitPrice'];
            $m['paidAmount'] = (float)$m['paidAmount'];
            $m['billingRequired'] = (bool)$m['billingRequired'];
            if (!empty($m['performedBy'])) {
                $m['performedBy'] = json_decode($m['performedBy'], true);
            }
        }

        // Invoices
        $stmt = $pdo->query("SELECT id, invoice_number as invoiceNumber, date, due_date as dueDate, customer_name as customerName, customer_phone as customerPhone, customer_address as customerAddress, items, subtotal, tax_percent as taxPercent, tax_amount as taxAmount, grand_total as grandTotal, payment_status as paymentStatus, paid_amount as paidAmount, payment_method as paymentMethod, payment_history as paymentHistory, notes, created_by as createdBy FROM invoices ORDER BY date DESC");
        $invoices = $stmt->fetchAll();
        foreach ($invoices as &$inv) {
            $inv['items'] = !empty($inv['items']) ? json_decode($inv['items'], true) : [];
            $inv['paymentHistory'] = !empty($inv['paymentHistory']) ? json_decode($inv['paymentHistory'], true) : [];
            $inv['createdBy'] = !empty($inv['createdBy']) ? json_decode($inv['createdBy'], true) : null;
            $inv['subtotal'] = (float)$inv['subtotal'];
            $inv['taxPercent'] = (float)$inv['taxPercent'];
            $inv['taxAmount'] = (float)$inv['taxAmount'];
            $inv['grandTotal'] = (float)$inv['grandTotal'];
            $inv['paidAmount'] = (float)$inv['paidAmount'];
        }

        // Categories, Suppliers, Customers, Users, Logs, Notifications
        $categories = $pdo->query("SELECT id, name, prefix, icon, description FROM categories")->fetchAll();
        $suppliers = $pdo->query("SELECT id, name, phone, address, notes FROM suppliers")->fetchAll();
        $customers = $pdo->query("SELECT id, name, phone, address, notes, created_at as createdAt FROM customers")->fetchAll();
        
        $usersStmt = $pdo->query("SELECT id, name, role, role_title as roleTitle, email, password, avatar_color as avatarColor, permissions FROM users");
        $users = $usersStmt->fetchAll();
        foreach ($users as &$u) {
            $perms = !empty($u['permissions']) ? json_decode($u['permissions'], true) : [];
            if (is_array($perms)) {
                $u = array_merge($u, $perms);
            }
        }

        $logsStmt = $pdo->query("SELECT id, timestamp, user_id as userId, user_name as userName, user_role as userRole, user_role_title as userRoleTitle, action_type as actionType, title, details, severity FROM activity_logs ORDER BY timestamp DESC LIMIT 200");
        $logs = $logsStmt->fetchAll();

        $notifsStmt = $pdo->query("SELECT id, timestamp, title, message, type, read_status as `read`, meta FROM notifications ORDER BY timestamp DESC LIMIT 100");
        $notifications = $notifsStmt->fetchAll();
        foreach ($notifications as &$n) {
            $n['read'] = (bool)$n['read'];
            if (!empty($n['meta'])) {
                $n['meta'] = json_decode($n['meta'], true);
            }
        }

        // Settings
        $settingsStmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
        $settingsRows = $settingsStmt->fetchAll();
        $settings = [];
        foreach ($settingsRows as $row) {
            $settings[$row['setting_key']] = json_decode($row['setting_value'], true);
        }

        jsonResponse([
            'success' => true,
            'products' => $products,
            'movements' => $movements,
            'invoices' => $invoices,
            'categories' => $categories,
            'suppliers' => $suppliers,
            'customers' => $customers,
            'users' => $users,
            'logs' => $logs,
            'notifications' => $notifications,
            'settings' => $settings
        ]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 3. ACTION: fetch_table (Ambil 1 Tabel Tertentu)
// --------------------------------------------------------------------
if ($action === 'fetch_table') {
    $table = isset($_GET['table']) ? trim($_GET['table']) : '';
    $allowed = ['products', 'movements', 'invoices', 'categories', 'suppliers', 'customers', 'users', 'activity_logs', 'notifications'];
    if (!in_array($table, $allowed)) {
        jsonResponse(['success' => false, 'message' => 'Tabel tidak valid'], 400);
    }

    try {
        if ($table === 'products') {
            $stmt = $pdo->query("SELECT id, code, name, category, unit, current_stock as currentStock, min_stock_alert as minStockAlert, cost_price as costPrice, selling_price as sellingPrice, description, location, last_updated as lastUpdated FROM products");
            $items = $stmt->fetchAll();
            foreach ($items as &$p) {
                $p['currentStock'] = (float)$p['currentStock'];
                $p['minStockAlert'] = (float)$p['minStockAlert'];
                $p['costPrice'] = (float)$p['costPrice'];
                $p['sellingPrice'] = (float)$p['sellingPrice'];
            }
            jsonResponse(['success' => true, 'items' => $items]);
        } elseif ($table === 'movements') {
            $stmt = $pdo->query("SELECT id, date, product_id as productId, product_name as productName, product_code as productCode, category, type, quantity, unit, previous_stock as previousStock, final_stock as finalStock, reference_no as referenceNo, notes, total_value as totalValue, supplier_name as supplierName, unit_price as unitPrice, recipient_name as recipientName, division_or_requester as divisionOrRequester, billing_required as billingRequired, payment_status as paymentStatus, payment_method as paymentMethod, paid_amount as paidAmount, billing_due_date as billingDueDate, paid_at as paidAt, performed_by as performedBy FROM movements ORDER BY date DESC");
            $items = $stmt->fetchAll();
            foreach ($items as &$m) {
                $m['quantity'] = (float)$m['quantity'];
                $m['previousStock'] = (float)$m['previousStock'];
                $m['finalStock'] = (float)$m['finalStock'];
                $m['totalValue'] = (float)$m['totalValue'];
                $m['unitPrice'] = (float)$m['unitPrice'];
                $m['paidAmount'] = (float)$m['paidAmount'];
                $m['billingRequired'] = (bool)$m['billingRequired'];
                if (!empty($m['performedBy'])) {
                    $m['performedBy'] = json_decode($m['performedBy'], true);
                }
            }
            jsonResponse(['success' => true, 'items' => $items]);
        } elseif ($table === 'invoices') {
            $stmt = $pdo->query("SELECT id, invoice_number as invoiceNumber, date, due_date as dueDate, customer_name as customerName, customer_phone as customerPhone, customer_address as customerAddress, items, subtotal, tax_percent as taxPercent, tax_amount as taxAmount, grand_total as grandTotal, payment_status as paymentStatus, paid_amount as paidAmount, payment_method as paymentMethod, payment_history as paymentHistory, notes, created_by as createdBy FROM invoices ORDER BY date DESC");
            $items = $stmt->fetchAll();
            foreach ($items as &$inv) {
                $inv['items'] = !empty($inv['items']) ? json_decode($inv['items'], true) : [];
                $inv['paymentHistory'] = !empty($inv['paymentHistory']) ? json_decode($inv['paymentHistory'], true) : [];
                $inv['createdBy'] = !empty($inv['createdBy']) ? json_decode($inv['createdBy'], true) : null;
                $inv['subtotal'] = (float)$inv['subtotal'];
                $inv['taxPercent'] = (float)$inv['taxPercent'];
                $inv['taxAmount'] = (float)$inv['taxAmount'];
                $inv['grandTotal'] = (float)$inv['grandTotal'];
                $inv['paidAmount'] = (float)$inv['paidAmount'];
            }
            jsonResponse(['success' => true, 'items' => $items]);
        } elseif ($table === 'users') {
            $stmt = $pdo->query("SELECT id, name, role, role_title as roleTitle, email, password, avatar_color as avatarColor, permissions FROM users");
            $items = $stmt->fetchAll();
            foreach ($items as &$u) {
                $perms = !empty($u['permissions']) ? json_decode($u['permissions'], true) : [];
                if (is_array($perms)) {
                    $u = array_merge($u, $perms);
                }
            }
            jsonResponse(['success' => true, 'items' => $items]);
        } elseif ($table === 'notifications') {
            $stmt = $pdo->query("SELECT id, timestamp, title, message, type, read_status as `read`, meta FROM notifications ORDER BY timestamp DESC");
            $items = $stmt->fetchAll();
            foreach ($items as &$n) {
                $n['read'] = (bool)$n['read'];
                if (!empty($n['meta'])) {
                    $n['meta'] = json_decode($n['meta'], true);
                }
            }
            jsonResponse(['success' => true, 'items' => $items]);
        } else {
            $stmt = $pdo->query("SELECT * FROM `{$table}`");
            $items = $stmt->fetchAll();
            jsonResponse(['success' => true, 'items' => $items]);
        }
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 4. ACTION: save_item (Insert or Update 1 Dokumen)
// --------------------------------------------------------------------
if ($action === 'save_item') {
    $table = isset($body['table']) ? trim($body['table']) : '';
    $item = isset($body['item']) ? $body['item'] : null;

    if (!$table || !$item || empty($item['id'])) {
        jsonResponse(['success' => false, 'message' => 'Parameter tidak lengkap'], 400);
    }

    try {
        saveItemGeneric($pdo, $table, $item);
        jsonResponse(['success' => true, 'id' => $item['id']]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 5. ACTION: batch_save (Simpan Banyak Item Dalam 1 Transaksi)
// --------------------------------------------------------------------
if ($action === 'batch_save') {
    $table = isset($body['table']) ? trim($body['table']) : '';
    $items = isset($body['items']) && is_array($body['items']) ? $body['items'] : [];
    $allowed = ['products', 'movements', 'invoices', 'categories', 'suppliers', 'customers', 'users', 'activity_logs', 'notifications'];
    if (!in_array($table, $allowed) || empty($items)) {
        jsonResponse(['success' => false, 'message' => 'Parameter tidak valid'], 400);
    }

    try {
        $pdo->beginTransaction();
        foreach ($items as $item) {
            if (!empty($item['id'])) {
                saveItemGeneric($pdo, $table, $item);
            }
        }
        $pdo->commit();
        jsonResponse(['success' => true, 'table' => $table, 'saved_count' => count($items)]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 6. ACTION: replace_table (Ganti Seluruh Isi 1 Tabel dengan Data Baru)
// --------------------------------------------------------------------
if ($action === 'replace_table') {
    $table = isset($body['table']) ? trim($body['table']) : '';
    $items = isset($body['items']) && is_array($body['items']) ? $body['items'] : [];
    $allowed = ['products', 'movements', 'invoices', 'categories', 'suppliers', 'customers', 'users', 'activity_logs', 'notifications'];
    if (!in_array($table, $allowed)) {
        jsonResponse(['success' => false, 'message' => 'Tabel tidak valid'], 400);
    }

    try {
        $pdo->beginTransaction();
        $pdo->exec("DELETE FROM `{$table}`");
        foreach ($items as $item) {
            if (!empty($item['id'])) {
                saveItemGeneric($pdo, $table, $item);
            }
        }
        $pdo->commit();
        jsonResponse(['success' => true, 'table' => $table, 'replaced_count' => count($items)]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 7. ACTION: restore_all & seed_all (PEMULIHAN LENGKAP & SEED DARI FILE .JSON CADANGAN)
// --------------------------------------------------------------------
if ($action === 'restore_all' || $action === 'seed_all') {
    $data = isset($body['data']) && is_array($body['data']) ? $body['data'] : (isset($body['products']) ? $body : null);
    if (!$data) {
        jsonResponse(['success' => false, 'message' => 'Data restore atau seed kosong atau tidak valid'], 400);
    }

    try {
        $pdo->beginTransaction();
        $counts = [];

        // 1. Products
        if (isset($data['products']) && is_array($data['products'])) {
            $pdo->exec("DELETE FROM products");
            foreach ($data['products'] as $p) {
                if (!empty($p['id'])) upsertProduct($pdo, $p);
            }
            $counts['products'] = count($data['products']);
        }

        // 2. Movements
        if (isset($data['movements']) && is_array($data['movements'])) {
            $pdo->exec("DELETE FROM movements");
            foreach ($data['movements'] as $m) {
                if (!empty($m['id'])) upsertMovement($pdo, $m);
            }
            $counts['movements'] = count($data['movements']);
        }

        // 3. Invoices
        if (isset($data['invoices']) && is_array($data['invoices'])) {
            $pdo->exec("DELETE FROM invoices");
            foreach ($data['invoices'] as $inv) {
                if (!empty($inv['id'])) upsertInvoice($pdo, $inv);
            }
            $counts['invoices'] = count($data['invoices']);
        }

        // 4. Categories
        if (isset($data['categories']) && is_array($data['categories'])) {
            $pdo->exec("DELETE FROM categories");
            foreach ($data['categories'] as $c) {
                if (!empty($c['id'])) upsertCategory($pdo, $c);
            }
            $counts['categories'] = count($data['categories']);
        }

        // 5. Suppliers
        if (isset($data['suppliers']) && is_array($data['suppliers'])) {
            $pdo->exec("DELETE FROM suppliers");
            foreach ($data['suppliers'] as $s) {
                if (!empty($s['id'])) upsertSupplier($pdo, $s);
            }
            $counts['suppliers'] = count($data['suppliers']);
        }

        // 6. Customers
        if (isset($data['customers']) && is_array($data['customers'])) {
            $pdo->exec("DELETE FROM customers");
            foreach ($data['customers'] as $cust) {
                if (!empty($cust['id'])) upsertCustomer($pdo, $cust);
            }
            $counts['customers'] = count($data['customers']);
        }

        // 7. Users
        if (isset($data['users']) && is_array($data['users']) && count($data['users']) > 0) {
            $pdo->exec("DELETE FROM users");
            foreach ($data['users'] as $u) {
                if (!empty($u['id'])) upsertUser($pdo, $u);
            }
            $counts['users'] = count($data['users']);
        }

        // 8. Logs
        if (isset($data['logs']) && is_array($data['logs'])) {
            $pdo->exec("DELETE FROM activity_logs");
            foreach ($data['logs'] as $l) {
                if (!empty($l['id'])) upsertLog($pdo, $l);
            }
            $counts['logs'] = count($data['logs']);
        }

        // 9. Settings: Company Profile
        if (!empty($data['companyProfile'])) {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('company_profile', :v) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
            $stmt->execute([':v' => json_encode($data['companyProfile'], JSON_UNESCAPED_UNICODE)]);
            $counts['companyProfile'] = 1;
        }

        // 10. Settings: Master Lists (Units, Locations, Divisions)
        if (!empty($data['units']) || !empty($data['locations']) || !empty($data['divisions'])) {
            $masterLists = [
                'units' => $data['units'] ?? [],
                'locations' => $data['locations'] ?? [],
                'divisions' => $data['divisions'] ?? [],
            ];
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES ('master_lists', :v) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
            $stmt->execute([':v' => json_encode($masterLists, JSON_UNESCAPED_UNICODE)]);
            $counts['masterLists'] = 1;
        }

        $pdo->commit();
        jsonResponse([
            'success' => true,
            'message' => 'Seluruh data dari file cadangan .json berhasil dipulihkan ke database MySQL cPanel!',
            'counts' => $counts
        ]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        jsonResponse(['success' => false, 'message' => 'Gagal memulihkan ke database MySQL: ' . $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 8. ACTION: remove_item (Delete 1 Record by ID)
// --------------------------------------------------------------------
if ($action === 'remove_item') {
    $table = isset($body['table']) ? trim($body['table']) : '';
    $id = isset($body['id']) ? trim($body['id']) : '';

    $allowed = ['products', 'movements', 'invoices', 'categories', 'suppliers', 'customers', 'users', 'activity_logs', 'notifications'];
    if (!in_array($table, $allowed) || !$id) {
        jsonResponse(['success' => false, 'message' => 'Parameter tidak valid'], 400);
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE id = :id");
        $stmt->execute([':id' => $id]);
        jsonResponse(['success' => true]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 9. ACTION: batch_remove (Delete Multiple by IDs)
// --------------------------------------------------------------------
if ($action === 'batch_remove') {
    $table = isset($body['table']) ? trim($body['table']) : '';
    $ids = isset($body['ids']) && is_array($body['ids']) ? $body['ids'] : [];

    $allowed = ['products', 'movements', 'invoices', 'categories', 'suppliers', 'customers', 'users', 'activity_logs', 'notifications'];
    if (!in_array($table, $allowed) || empty($ids)) {
        jsonResponse(['success' => false, 'message' => 'Parameter tidak valid'], 400);
    }

    try {
        $inQuery = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE id IN ({$inQuery})");
        $stmt->execute($ids);
        jsonResponse(['success' => true, 'deleted_count' => $stmt->rowCount()]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 10. ACTION: clear_operational (Kosongkan Products, Movements, Invoices)
// --------------------------------------------------------------------
if ($action === 'clear_operational') {
    try {
        $pdo->beginTransaction();
        $pdo->exec("TRUNCATE TABLE movements");
        $pdo->exec("TRUNCATE TABLE invoices");
        $pdo->exec("TRUNCATE TABLE products");
        $pdo->commit();
        jsonResponse(['success' => true, 'message' => 'Data operasional (produk, mutasi, invoice) berhasil dikosongkan.']);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --------------------------------------------------------------------
// 11. ACTION: save_setting & get_setting
// --------------------------------------------------------------------
if ($action === 'save_setting') {
    $key = isset($body['key']) ? trim($body['key']) : '';
    $val = isset($body['value']) ? $body['value'] : null;

    if (!$key) {
        jsonResponse(['success' => false, 'message' => 'Key tidak boleh kosong'], 400);
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (:k, :v) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
        $stmt->execute([
            ':k' => $key,
            ':v' => json_encode($val, JSON_UNESCAPED_UNICODE)
        ]);
        jsonResponse(['success' => true]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

if ($action === 'get_setting') {
    $key = isset($_GET['key']) ? trim($_GET['key']) : '';
    if (!$key) jsonResponse(['success' => false], 400);

    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = :k");
        $stmt->execute([':k' => $key]);
        $row = $stmt->fetch();
        if ($row) {
            jsonResponse(['success' => true, 'value' => json_decode($row['setting_value'], true)]);
        } else {
            jsonResponse(['success' => false, 'value' => null]);
        }
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

jsonResponse(['success' => false, 'message' => 'Action tidak dikenali'], 404);
