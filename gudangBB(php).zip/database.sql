-- ====================================================================
-- SKEMA BASIS DATA MYSQL & PHPMYADMIN
-- Aplikasi: Gudang Stok DTF & Sublime Pro
-- Host cPanel: phpMyAdmin / MariaDB / MySQL 5.7+ / 8.0+
-- Collation: utf8mb4_unicode_ci
-- ====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+07:00";

-- --------------------------------------------------------
-- 1. TABEL: users (Pengguna & Hak Akses Granular)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `role` VARCHAR(50) NOT NULL DEFAULT 'warehouse_admin',
  `role_title` VARCHAR(150) NOT NULL DEFAULT 'Staff Logistik',
  `email` VARCHAR(150) DEFAULT NULL,
  `password` VARCHAR(255) NOT NULL DEFAULT '123456',
  `avatar_color` VARCHAR(50) DEFAULT 'bg-indigo-600',
  `permissions` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2. TABEL: categories (Kategori Bahan Baku)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `prefix` VARCHAR(20) NOT NULL,
  `icon` VARCHAR(50) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_categories_prefix` (`prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3. TABEL: suppliers (Pemasok / Distributor)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `phone` VARCHAR(50) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4. TABEL: customers (Pelanggan / Konsumen)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `customers` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(200) NOT NULL,
  `phone` VARCHAR(50) NOT NULL,
  `address` TEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_at` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_customers_name` (`name`),
  KEY `idx_customers_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5. TABEL: products (Master Stok Bahan Baku)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(50) NOT NULL,
  `code` VARCHAR(50) NOT NULL,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `unit` VARCHAR(50) NOT NULL,
  `current_stock` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `min_stock_alert` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `cost_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `selling_price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `description` TEXT DEFAULT NULL,
  `location` VARCHAR(100) DEFAULT 'Gudang Utama',
  `last_updated` VARCHAR(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_products_code` (`code`),
  KEY `idx_products_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6. TABEL: movements (Riwayat Mutasi Stok Gudang & Pemakaian)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `movements` (
  `id` VARCHAR(50) NOT NULL,
  `date` VARCHAR(50) NOT NULL,
  `product_id` VARCHAR(50) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `product_code` VARCHAR(50) NOT NULL,
  `category` VARCHAR(50) NOT NULL,
  `type` ENUM('restock','production','sale','adjustment') NOT NULL,
  `quantity` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `unit` VARCHAR(50) NOT NULL,
  `previous_stock` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `final_stock` DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  `reference_no` VARCHAR(100) NOT NULL,
  `notes` TEXT DEFAULT NULL,
  `total_value` DECIMAL(15,2) DEFAULT 0.00,
  `supplier_name` VARCHAR(255) DEFAULT NULL,
  `unit_price` DECIMAL(15,2) DEFAULT 0.00,
  `recipient_name` VARCHAR(150) DEFAULT NULL,
  `division_or_requester` VARCHAR(150) DEFAULT NULL,
  `billing_required` TINYINT(1) DEFAULT 0,
  `payment_status` VARCHAR(50) DEFAULT 'beban_internal',
  `payment_method` VARCHAR(100) DEFAULT NULL,
  `paid_amount` DECIMAL(15,2) DEFAULT 0.00,
  `billing_due_date` VARCHAR(50) DEFAULT NULL,
  `paid_at` VARCHAR(50) DEFAULT NULL,
  `performed_by` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_movements_date` (`date`),
  KEY `idx_movements_product` (`product_id`),
  KEY `idx_movements_type` (`type`),
  KEY `idx_movements_ref` (`reference_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7. TABEL: invoices (Faktur Penjualan & Piutang Konsumen)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` VARCHAR(50) NOT NULL,
  `invoice_number` VARCHAR(100) NOT NULL,
  `date` VARCHAR(50) NOT NULL,
  `due_date` VARCHAR(50) NOT NULL,
  `customer_name` VARCHAR(200) NOT NULL,
  `customer_phone` VARCHAR(50) DEFAULT NULL,
  `customer_address` TEXT DEFAULT NULL,
  `items` LONGTEXT NOT NULL,
  `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `tax_percent` DECIMAL(5,2) DEFAULT 0.00,
  `tax_amount` DECIMAL(15,2) DEFAULT 0.00,
  `grand_total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `payment_status` ENUM('lunas','belum_lunas','dp') NOT NULL DEFAULT 'belum_lunas',
  `paid_amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  `payment_method` VARCHAR(100) DEFAULT 'Tunai',
  `payment_history` LONGTEXT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `created_by` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_invoices_number` (`invoice_number`),
  KEY `idx_invoices_customer` (`customer_name`),
  KEY `idx_invoices_status` (`payment_status`),
  KEY `idx_invoices_due` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8. TABEL: activity_logs (Riwayat Aktivitas & Audit Trail)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` VARCHAR(50) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `user_id` VARCHAR(50) NOT NULL,
  `user_name` VARCHAR(150) NOT NULL,
  `user_role` VARCHAR(50) NOT NULL,
  `user_role_title` VARCHAR(150) DEFAULT NULL,
  `action_type` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `details` TEXT DEFAULT NULL,
  `severity` ENUM('info','success','warning','critical') DEFAULT 'info',
  PRIMARY KEY (`id`),
  KEY `idx_logs_timestamp` (`timestamp`),
  KEY `idx_logs_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 9. TABEL: notifications (Notifikasi Push & Peringatan Stok)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` VARCHAR(50) NOT NULL,
  `timestamp` VARCHAR(50) NOT NULL,
  `title` VARCHAR(255) NOT NULL,
  `message` TEXT NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'system',
  `read_status` TINYINT(1) NOT NULL DEFAULT 0,
  `meta` LONGTEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notifs_read` (`read_status`),
  KEY `idx_notifs_time` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 10. TABEL: settings (Pengaturan Profil, Kop Surat & Master Data)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` LONGTEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- SEED DATA AWAL (Pengguna, Kategori, Profil Perusahaan)
-- --------------------------------------------------------

INSERT INTO `users` (`id`, `name`, `role`, `role_title`, `email`, `password`, `avatar_color`, `permissions`) VALUES
('user-1', 'Owner', 'owner', 'Pemilik Usaha (Owner)', 'owner@cetakprint.com', '10203040', 'bg-indigo-600', '{"canViewFinancials":true,"canManageProducts":true,"canDeleteProducts":true,"canRestock":true,"canEditPurchases":true,"canDeletePurchases":true,"canUseForProduction":true,"canEditProductionUsage":true,"canDeleteProductionUsage":true,"canCreateSalesInvoice":true,"canEditSalesInvoice":true,"canDeleteSalesInvoice":true,"canManagePayments":true,"canManageMasterData":true,"canManageAccessControl":true,"canManageCompanyProfile":true,"canDeleteLogs":true,"canExportReports":true,"canStockOpname":true}'),
('user-2', 'Supervisor Gudang', 'warehouse_admin', 'Supervisor Gudang (SPV)', 'spv@cetakprint.com', 'spv123', 'bg-emerald-600', '{"canViewFinancials":false,"canManageProducts":true,"canDeleteProducts":true,"canRestock":true,"canEditPurchases":true,"canDeletePurchases":true,"canUseForProduction":false,"canEditProductionUsage":true,"canDeleteProductionUsage":true,"canCreateSalesInvoice":false,"canEditSalesInvoice":true,"canDeleteSalesInvoice":true,"canManagePayments":true,"canManageMasterData":true,"canManageAccessControl":false,"canManageCompanyProfile":true,"canDeleteLogs":false,"canExportReports":true,"canStockOpname":true}'),
('user-3', 'Rina Kasir', 'cashier_sales', 'Kasir & Sales Bahan', 'rina@cetakprint.com', '123456', 'bg-cyan-600', '{"canViewFinancials":false,"canManageProducts":false,"canDeleteProducts":false,"canRestock":false,"canEditPurchases":false,"canDeletePurchases":false,"canUseForProduction":false,"canEditProductionUsage":false,"canDeleteProductionUsage":false,"canCreateSalesInvoice":true,"canEditSalesInvoice":true,"canDeleteSalesInvoice":false,"canManagePayments":true,"canManageMasterData":false,"canManageAccessControl":false,"canManageCompanyProfile":false,"canDeleteLogs":false,"canExportReports":true,"canStockOpname":false}'),
('user-4', 'Dani Operator', 'production_staff', 'Operator Produksi Sablon', 'dani@cetakprint.com', '123456', 'bg-amber-600', '{"canViewFinancials":false,"canManageProducts":false,"canDeleteProducts":false,"canRestock":false,"canEditPurchases":false,"canDeletePurchases":false,"canUseForProduction":true,"canEditProductionUsage":false,"canDeleteProductionUsage":false,"canCreateSalesInvoice":false,"canEditSalesInvoice":false,"canDeleteSalesInvoice":false,"canManagePayments":false,"canManageMasterData":false,"canManageAccessControl":false,"canManageCompanyProfile":false,"canDeleteLogs":false,"canExportReports":false,"canStockOpname":false}')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `role`=VALUES(`role`);

INSERT INTO `categories` (`id`, `name`, `prefix`, `icon`, `description`) VALUES
('pet_film', 'PET Film DTF', 'PET', 'Layers', 'Roll lembaran film sablon transfer DTF berbagai lebar (30cm, 60cm)'),
('tinta_dtf', 'Tinta DTF', 'INK', 'Paintbrush', 'Tinta pigment tekstil CMYK & White untuk printer DTF'),
('powder_lem', 'Powder TPU / Lem', 'POW', 'Boxes', 'Bubuk kristal lem panas perekat sablon DTF ke kain'),
('kertas_sublime', 'Kertas Sublime', 'SUB', 'FileText', 'Kertas transfer sublimasi untuk cetak jersey, mug, hijab'),
('tinta_sublime', 'Tinta Sublimasi', 'SIN', 'Droplet', 'Tinta sublimasi disperse ink untuk kain polyester/dryfit'),
('finishing', 'Finishing & Tambahan', 'ACC', 'Sparkles', 'Teflon sheet, isolasi tahan panas, cleaner printhead')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `suppliers` (`id`, `name`, `phone`, `address`, `notes`) VALUES
('sup-1', 'PT Sinar Digital Printing', '0812-3456-7890', 'Sentra Industri Tekstil Kav. 12, Jakarta Barat', 'Distributor resmi tinta DTF & PET Film roll import.'),
('sup-2', 'CV Sumber Grafika Nusantara', '0813-8877-6655', 'Jl. Sukarno Hatta No. 210, Bandung', 'Penyedia bubuk lem TPU powder dan kertas sublimasi rol.'),
('sup-3', 'PT Asia Sublim Solusindo', '0821-1122-3344', 'Kawasan Industri Cikarang Blok B-4, Bekasi', 'Spesialis tinta sublime Korea dan kertas roll fast dry.')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `customers` (`id`, `name`, `phone`, `address`, `notes`, `created_at`) VALUES
('cust-1', 'Konveksi Kaos Berkah Mandiri', '0812-8899-0011', 'Jl. Cikutra No. 45, Bandung', 'Konveksi kaos distro langganan rutin PET film dan lem DTF.', '2026-09-01'),
('cust-2', 'Jersey Sport Velocity', '0857-1234-5678', 'Komplek Melati Indah B-10, Cimahi', 'Spesialis cetak jersey futsal & running, langganan kertas sublime.', '2026-09-05'),
('cust-3', 'Merchandise Creative Studio', '0878-9900-1122', 'Ruko Gateway Pasteur Lt. 2, Bandung', 'Studio custom mug, totebag, dan sablon DTF satuan.', '2026-09-10')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('company_profile', '{"companyName":"GUDANG SUPLAI SABLON DTF & SUBLIME","shortName":"DTF","tagline":"Pusat Pengadaan Bahan Baku Produksi Cetak Sablon Kaos, Jersey, Hoodie & Merchandise","address":"Kawasan Industri Kreatif No. 88, Bandung","city":"Bandung","phone":"0812-9988-7766","email":"logistik@dtfsublime.id","website":"www.dtfsublime.id","bankName":"BCA","bankAccountNo":"8820-192-381","bankAccountHolder":"CV DTF SUBLIME INDONESIA","appName":"DTF & Sublime","appSubtitle":"Manajemen Stok, Produksi & Invoice Konsumen","appVersion":"v2.5 Pro","appLogoBadge":"DTF"}'),
('master_lists', '{"units":["Roll","Botol (1 Liter)","Kg","Pack","Pcs","Rim","Set"],"locations":["Rak A-01 (Roll Film)","Rak A-02 (Roll Film)","Rak B-01 (Tinta DTF)","Rak B-02 (Tinta Sublime)","Rak C-01 (Powder TPU)","Rak C-02 (Kertas Sublime)","Rak D-01 (Finishing & Aksesoris)","Gudang Utama"],"divisions":["Divisi Sablon DTF Kaos","Divisi Jersey Sublimasi","Divisi Merchandise & Mug","Divisi Bordir & DTG","QC & Packing"]}')
ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`);

SET FOREIGN_KEY_CHECKS = 1;
COMMIT;
